import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { App } from './app/app';

// Schnellzugriff „Neue Buchung“ (Bauplan 7): ./?start=neue-buchung → #/neu, nach dem Entsperren direkt dorthin.
const start = new URLSearchParams(location.search).get('start');
if (start === 'neue-buchung') history.replaceState(null, '', location.pathname + '#/neu');

bootstrapApplication(App, appConfig).catch((err) => console.error(err));
