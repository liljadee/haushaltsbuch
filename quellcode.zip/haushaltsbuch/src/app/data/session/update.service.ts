import { Injectable, isDevMode, signal } from '@angular/core';

export type UpdateCheck = 'neu' | 'aktuell' | 'offline' | 'fehler';

/**
 * Updates (Bauplan 8.3) über den eigenen Service Worker sw.js: Eine neue Version wird im Hintergrund
 * geladen und wartet. Die App zeigt „Neue Version verfügbar“ und aktiviert sie erst nach Bestätigung.
 * Gesucht wird beim Start, bei jeder Rückkehr in den Vordergrund (höchstens alle 10 Minuten),
 * alle 6 Stunden und auf Knopfdruck in den Einstellungen.
 */
@Injectable({ providedIn: 'root' })
export class UpdateService {
  readonly ready = signal(false);
  private reg: ServiceWorkerRegistration | null = null;
  private lastCheck = 0;

  async start(): Promise<void> {
    if (isDevMode() || !('serviceWorker' in navigator)) return;
    try {
      this.reg = await navigator.serviceWorker.register('sw.js', { updateViaCache: 'none' });
    } catch {
      return;
    }
    const reg = this.reg;
    const watch = (w: ServiceWorker | null) => {
      if (!w) return;
      const check = () => {
        if (w.state === 'installed' && navigator.serviceWorker.controller) this.ready.set(true);
      };
      check();
      w.addEventListener('statechange', check);
    };
    if (reg.waiting && navigator.serviceWorker.controller) this.ready.set(true);
    watch(reg.installing);
    reg.addEventListener('updatefound', () => watch(reg.installing));
    // Android holt installierte Apps oft nur aus dem Hintergrund zurück, ohne neu zu laden
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible' && Date.now() - this.lastCheck > 10 * 60 * 1000)
        void this.check();
    });
    setInterval(() => void this.check(), 6 * 60 * 60 * 1000);
    this.lastCheck = Date.now();
  }

  /** Sucht sofort nach einer neuen Version und meldet das Ergebnis (Einstellungen → „Nach Updates suchen“). */
  async check(): Promise<UpdateCheck> {
    this.lastCheck = Date.now();
    if (!this.reg) return 'fehler';
    if (!navigator.onLine) return 'offline';
    try {
      await this.reg.update();
    } catch {
      return 'fehler';
    }
    const w = this.reg.installing ?? this.reg.waiting;
    if (!w) return 'aktuell';
    // warten, bis die neue Version fertig geladen ist (oder gescheitert)
    if (w.state === 'installing' || w.state === 'parsed')
      await new Promise<void>((resolve) => {
        const done = () => {
          if (w.state !== 'installing' && w.state !== 'parsed') {
            w.removeEventListener('statechange', done);
            resolve();
          }
        };
        w.addEventListener('statechange', done);
      });
    if (w.state === 'redundant') return 'fehler';
    if (navigator.serviceWorker.controller) this.ready.set(true);
    return 'neu';
  }

  apply(): void {
    const waiting = this.reg?.waiting;
    if (!waiting) return location.reload();
    navigator.serviceWorker.addEventListener('controllerchange', () => location.reload(), {
      once: true,
    });
    waiting.postMessage('SKIP_WAITING');
  }
}
