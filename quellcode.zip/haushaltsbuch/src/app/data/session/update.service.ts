import { Injectable, isDevMode, signal } from '@angular/core';

/**
 * Updates (Bauplan 8.3) über den eigenen Service Worker sw.js: Eine neue Version wird im Hintergrund
 * geladen und wartet. Die App zeigt „Neue Version verfügbar“ und aktiviert sie erst nach Bestätigung.
 */
@Injectable({ providedIn: 'root' })
export class UpdateService {
  readonly ready = signal(false);
  private reg: ServiceWorkerRegistration | null = null;

  async start(): Promise<void> {
    if (isDevMode() || !('serviceWorker' in navigator)) return;
    try {
      this.reg = await navigator.serviceWorker.register('sw.js');
    } catch {
      return;
    }
    const reg = this.reg;
    const watch = (w: ServiceWorker | null) => {
      if (!w) return;
      const check = () => {
        if (w.state === 'installed' && navigator.serviceWorker.controller) this.ready.set(true);
      };
      check();
      w.addEventListener('statechange', check);
    };
    if (reg.waiting && navigator.serviceWorker.controller) this.ready.set(true);
    watch(reg.installing);
    reg.addEventListener('updatefound', () => watch(reg.installing));
    setInterval(
      () => {
        if (navigator.onLine) reg.update().catch(() => undefined);
      },
      6 * 60 * 60 * 1000,
    );
  }

  apply(): void {
    const waiting = this.reg?.waiting;
    if (!waiting) return location.reload();
    navigator.serviceWorker.addEventListener('controllerchange', () => location.reload(), {
      once: true,
    });
    waiting.postMessage('SKIP_WAITING');
  }
}
