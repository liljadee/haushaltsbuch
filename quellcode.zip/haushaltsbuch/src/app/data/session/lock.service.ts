import { Injectable, NgZone, inject } from '@angular/core';
import { Router } from '@angular/router';
import { SessionData } from '../stores/session-data';
import { VaultService } from '../vault.service';

export const LOCK_AFTER_MS = 60_000;

/**
 * Sperre (Bauplan 5.3): Wird die App verlassen, verdeckt sie den Inhalt sofort und merkt sich die Zeit.
 * Ist beim Zurückkehren mehr als eine Minute vergangen, verwirft sie den Datenschlüssel und alle Daten.
 */
@Injectable({ providedIn: 'root' })
export class LockService {
  private readonly vault = inject(VaultService);
  private readonly data = inject(SessionData);
  private readonly router = inject(Router);
  private readonly zone = inject(NgZone);
  private hiddenAt: number | null = null;

  start(): void {
    document.addEventListener('visibilitychange', () =>
      this.zone.run(() => (document.hidden ? this.leave() : this.back())),
    );
    window.addEventListener('pagehide', () => this.leave());
  }

  private leave(): void {
    document.body.classList.add('hb-covered');
    this.hiddenAt ??= Date.now();
  }

  private back(): void {
    const away = this.hiddenAt === null ? 0 : Date.now() - this.hiddenAt;
    this.hiddenAt = null;
    if (this.vault.status() === 'entsperrt' && away >= LOCK_AFTER_MS) this.lockNow(this.router.url);
    document.body.classList.remove('hb-covered');
  }

  lockNow(returnTo = '/start'): void {
    this.vault.lock();
    this.data.clear();
    void this.router.navigate(['/entsperren'], {
      queryParams: { ziel: returnTo.startsWith('/entsperren') ? '/start' : returnTo },
    });
  }
}
