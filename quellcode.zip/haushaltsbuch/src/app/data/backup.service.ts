import { Injectable, inject } from '@angular/core';
import { todayLocal } from '../domain/shared/local-date';
import { PrefsStore } from './stores/prefs.store';
import { VaultService } from './vault.service';

export interface BackupResult {
  ok: boolean;
  message: string;
}

/**
 * Backup teilen oder herunterladen (Bauplan 7). Das Datum des letzten Backups zählt erst,
 * wenn die Datei wirklich geteilt oder gespeichert ist; ein abgebrochenes Teilen zählt nicht.
 */
@Injectable({ providedIn: 'root' })
export class BackupService {
  private readonly vault = inject(VaultService);
  private readonly prefs = inject(PrefsStore);
  readonly canShare = typeof navigator.canShare === 'function';

  async run(how: 'download' | 'share'): Promise<BackupResult> {
    try {
      const { name, text, entries } = await this.vault.createBackupFile();
      const done = `Backup „${name}“ erstellt (${entries} ${entries === 1 ? 'Datensatz' : 'Datensätze'}).`;
      let note = '';
      if (how === 'share') {
        const file = new File([text], name, { type: 'application/octet-stream' });
        if (navigator.canShare?.({ files: [file] })) {
          try {
            await navigator.share({ files: [file], title: name });
            await this.prefs.setLastBackup(todayLocal());
            return { ok: true, message: done };
          } catch (e) {
            if ((e as Error).name === 'AbortError')
              return {
                ok: false,
                message: 'Teilen abgebrochen; es wurde kein Backup gespeichert.',
              };
          }
        }
        note = 'Teilen klappt auf diesem Gerät nicht, die Datei wird stattdessen heruntergeladen. ';
      }
      const url = URL.createObjectURL(new Blob([text], { type: 'application/octet-stream' }));
      const a = document.createElement('a');
      a.href = url;
      a.download = name;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 10000);
      await this.prefs.setLastBackup(todayLocal());
      return { ok: true, message: `${note}${done} Du findest es im Ordner „Downloads“.` };
    } catch (e) {
      return {
        ok: false,
        message: `Backup fehlgeschlagen: ${e instanceof Error ? e.message : String(e)}`,
      };
    }
  }
}
