import { Injectable, computed, effect, inject, signal } from '@angular/core';
import { CheckItem } from './check/feasibility';
import { deleteMirror, getMirror, putMirror } from './storage/db';
import { VaultService } from './vault.service';

/** Erweiterungen der Dateischnittstelle, die in den Standard-Typen von TypeScript fehlen */
interface PermHandle {
  name: string;
  queryPermission(o: { mode: 'readwrite' }): Promise<PermissionState>;
  requestPermission(o: { mode: 'readwrite' }): Promise<PermissionState>;
  createWritable(): Promise<{ write(d: string): Promise<void>; close(): Promise<void> }>;
}
type Picker = (o: object) => Promise<PermHandle>;

export type MirrorState = 'nicht-unterstuetzt' | 'aus' | 'verbunden' | 'erlaubnis' | 'fehler';

/**
 * Sicherungsdatei (Wunsch 19.11.2026): eine verschlüsselte Kopie aller Daten im normalen Handyspeicher,
 * außerhalb der Browserdaten. Nach jeder Änderung (gebündelt nach 2 Sekunden) und beim Verlassen der App
 * aktualisiert. Format wie das Backup (.hhb); Wiederherstellen über „Backup einspielen“.
 */
@Injectable({ providedIn: 'root' })
export class MirrorService {
  private readonly vault = inject(VaultService);
  readonly supported =
    typeof (window as unknown as { showSaveFilePicker?: Picker }).showSaveFilePicker === 'function';
  readonly state = signal<MirrorState>(this.supported ? 'aus' : 'nicht-unterstuetzt');
  readonly fileName = signal<string | null>(null);
  readonly lastWrite = signal<string | null>(null);
  /** blieb die Schreiberlaubnis nach einem Neustart erhalten? (Machbarkeitsprüfung) */
  readonly permissionKept = signal<boolean | null>(null);
  readonly error = signal('');
  readonly active = computed(() => this.state() === 'verbunden');
  /** seit wann Änderungen nicht in der Datei stehen (überdauert Neustarts) */
  readonly dirtySince = signal<string | null>(null);
  /** Hinweis „verbinden“ nur, wenn Änderungen offen sind und die Datei älter als einen Tag ist */
  readonly needsAttention = computed(() => {
    if (this.state() !== 'erlaubnis' || !this.dirtySince()) return false;
    const last = this.lastWrite();
    return !last || this.now() - Date.parse(last) > 24 * 60 * 60 * 1000;
  });
  private readonly now = signal(Date.now());
  private handle: PermHandle | null = null;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private seen = 0;
  private dirty = false;

  constructor() {
    // jede gespeicherte Änderung: in 2 Sekunden schreiben (mehrere Änderungen werden gebündelt)
    effect(() => {
      const n = this.vault.changes();
      if (n === this.seen) return;
      this.seen = n;
      if (this.state() !== 'verbunden') {
        void this.markDirty();
        return;
      }
      this.dirty = true;
      if (this.timer) clearTimeout(this.timer);
      this.timer = setTimeout(() => void this.writeNow(), 2000);
    });
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden' && this.dirty) void this.writeNow();
    });
  }

  /** nach dem Entsperren: gespeicherte Datei wieder anbinden */
  async init(): Promise<void> {
    this.seen = this.vault.changes();
    const m = await getMirror();
    if (!m) return this.state.set(this.supported ? 'aus' : 'nicht-unterstuetzt');
    this.handle = m.handle as PermHandle;
    this.fileName.set(m.fileName);
    this.lastWrite.set(m.lastWrite);
    this.dirtySince.set(m.dirtySince ?? null);
    this.now.set(Date.now());
    try {
      const p = await this.handle.queryPermission({ mode: 'readwrite' });
      this.permissionKept.set(p === 'granted');
      await putMirror({ ...m, permissionKept: p === 'granted' });
      this.state.set(p === 'granted' ? 'verbunden' : 'erlaubnis');
    } catch {
      this.state.set('erlaubnis');
    }
  }

  clear(): void {
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
    this.handle = null;
  }

  /** Speicherort wählen (öffnet die Dateiauswahl des Handys) und sofort schreiben */
  async setup(): Promise<boolean> {
    const picker = (window as unknown as { showSaveFilePicker?: Picker }).showSaveFilePicker;
    if (!picker) return false;
    try {
      this.handle = await picker({
        suggestedName: 'haushaltsbuch-sicherung.hhb',
        types: [
          {
            description: 'Haushaltsbuch-Sicherung',
            accept: { 'application/octet-stream': ['.hhb'] },
          },
        ],
      });
    } catch (e) {
      if ((e as Error).name !== 'AbortError')
        this.error.set('Die Dateiauswahl ist fehlgeschlagen.');
      return false;
    }
    await putMirror({
      handle: this.handle,
      fileName: this.handle.name,
      lastWrite: null,
      permissionKept: null,
    });
    this.fileName.set(this.handle.name);
    this.state.set('verbunden');
    return this.writeNow();
  }

  /** Schreiberlaubnis erneut erteilen (nach einem Neustart, falls Android nachfragt) */
  async reconnect(): Promise<boolean> {
    if (!this.handle) return false;
    try {
      const p = await this.handle.requestPermission({ mode: 'readwrite' });
      if (p !== 'granted') return false;
      this.state.set('verbunden');
      return this.writeNow();
    } catch {
      return false;
    }
  }

  async writeNow(): Promise<boolean> {
    if (this.timer) clearTimeout(this.timer);
    this.timer = null;
    if (!this.handle || this.vault.status() !== 'entsperrt') return false;
    try {
      const { text } = await this.vault.createBackupFile();
      const w = await this.handle.createWritable();
      await w.write(text);
      await w.close();
      const now = new Date().toISOString();
      this.lastWrite.set(now);
      this.dirty = false;
      this.error.set('');
      const m = await getMirror();
      if (m) await putMirror({ ...m, lastWrite: now, dirtySince: null });
      this.dirtySince.set(null);
      return true;
    } catch (e) {
      const name = (e as Error).name;
      this.state.set(
        name === 'NotAllowedError' || name === 'SecurityError' ? 'erlaubnis' : 'fehler',
      );
      this.error.set(
        name === 'NotFoundError'
          ? 'Die Sicherungsdatei wurde gelöscht oder verschoben. Bitte neu einrichten.'
          : '',
      );
      return false;
    }
  }

  private async markDirty(): Promise<void> {
    if (this.dirtySince() || !this.handle) return;
    const since = new Date().toISOString();
    this.dirtySince.set(since);
    this.now.set(Date.now());
    const m = await getMirror();
    if (m) await putMirror({ ...m, dirtySince: since });
  }

  async disconnect(): Promise<void> {
    this.clear();
    await deleteMirror();
    this.fileName.set(null);
    this.lastWrite.set(null);
    this.permissionKept.set(null);
    this.state.set(this.supported ? 'aus' : 'nicht-unterstuetzt');
  }

  /** Punkte für die Machbarkeitsprüfung */
  checkItems(): CheckItem[] {
    const kept = this.permissionKept();
    return [
      {
        id: 'mirror-api',
        label: 'Sicherungsdatei möglich (Dateizugriff)',
        ok: this.supported,
        detail: this.supported ? 'ja' : 'nein, dieser Browser erlaubt keinen Dateizugriff',
      },
      {
        id: 'mirror-on',
        label: 'Sicherungsdatei eingerichtet',
        ok: this.state() === 'verbunden' ? true : this.state() === 'aus' ? null : false,
        detail:
          this.state() === 'verbunden'
            ? `ja, ${this.fileName()}`
            : this.state() === 'erlaubnis'
              ? 'eingerichtet, wartet auf „verbinden“'
              : 'noch nicht (Einstellungen → Sicherungsdatei)',
      },
      {
        id: 'mirror-kept',
        label: 'Schreiberlaubnis bleibt nach Neustart',
        ok: kept,
        detail:
          kept === null
            ? 'noch nicht geprüft: Datei einrichten, App ganz schließen, neu öffnen'
            : kept
              ? 'ja, kein Nachfragen nötig'
              : 'nein, nach jedem Neustart einmal „verbinden“ tippen',
      },
    ];
  }
}
