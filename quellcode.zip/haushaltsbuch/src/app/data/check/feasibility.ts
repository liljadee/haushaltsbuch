import { PasskeyService } from '../crypto/passkey.service';
import { VaultMeta } from '../storage/db';

export interface CheckItem {
  id: string;
  label: string;
  ok: boolean | null;
  detail: string;
}

/** Machbarkeitsprüfung für v0.1 (Bauplan 11): was das Handy kann, als Text zum Weitergeben. */
export async function runChecks(
  passkeys: PasskeyService,
  meta: VaultMeta | null,
  version: string,
): Promise<CheckItem[]> {
  const items: CheckItem[] = [];
  const add = (id: string, label: string, ok: boolean | null, detail: string) =>
    items.push({ id, label, ok, detail });
  add(
    'https',
    'Sichere Verbindung (https)',
    isSecureContext,
    isSecureContext ? 'ja' : 'nein – die App muss über https geöffnet werden',
  );
  const standalone =
    matchMedia('(display-mode: standalone)').matches ||
    matchMedia('(display-mode: minimal-ui)').matches;
  add(
    'installiert',
    'Als App installiert',
    standalone,
    standalone ? 'ja, läuft als eigene App' : 'nein, läuft im Browser-Tab',
  );
  const pk = await passkeys.isAvailable();
  add('passkey', 'Passkey mit Fingerabdruck möglich', pk, pk ? 'ja' : 'nein');
  const prfCap = await passkeys.prfCapability();
  add(
    'prf-browser',
    'Browser meldet PRF-Unterstützung',
    prfCap,
    prfCap === null ? 'Browser verrät es nicht' : prfCap ? 'ja' : 'nein',
  );
  add(
    'prf-echt',
    'Fingerabdruck entsperrt die Daten (PRF)',
    meta ? !!meta.passkey : null,
    meta
      ? meta.passkey
        ? 'ja, eingerichtet und benutzbar'
        : 'nein, Entsperren nur per App-Passwort'
      : 'noch nicht eingerichtet',
  );
  let persisted: boolean | null;
  try {
    persisted = (await navigator.storage?.persisted?.()) ?? null;
  } catch {
    persisted = null;
  }
  add(
    'speicher',
    'Dauerhafter Speicher gewährt',
    persisted,
    persisted === null
      ? 'unbekannt'
      : persisted
        ? 'ja, Chrome löscht die Daten nicht von selbst'
        : 'nein, Chrome könnte bei Platzmangel löschen',
  );
  let used = '';
  try {
    const e = await navigator.storage?.estimate?.();
    if (e?.usage !== undefined) used = `${Math.round(e.usage / 1024)} kB belegt`;
  } catch {
    used = '';
  }
  add('belegt', 'Speicherplatz', null, used || 'unbekannt');
  const sw = !!navigator.serviceWorker?.controller;
  add(
    'offline',
    'Offline bereit (Service Worker aktiv)',
    sw,
    sw ? 'ja' : 'noch nicht – App einmal schließen und neu öffnen',
  );
  const gz = typeof CompressionStream !== 'undefined';
  add('gzip', 'Komprimierung für Backups', gz, gz ? 'ja' : 'nein');
  add('version', 'App-Version', null, version);
  add('browser', 'Browser', null, navigator.userAgent);
  return items;
}

export function checksAsText(
  items: CheckItem[],
  manual: { label: string; done: boolean }[],
): string {
  const mark = (ok: boolean | null) => (ok === null ? '–' : ok ? 'OK' : 'NEIN');
  return [
    'Haushaltsbuch – Machbarkeitsprüfung v0.1',
    `Datum: ${new Date().toLocaleString('de-DE')}`,
    '',
    ...items.map((i) => `${mark(i.ok)}  ${i.label}: ${i.detail}`),
    '',
    'Von Hand geprüft:',
    ...manual.map((m) => `${m.done ? 'OK' : 'offen'}  ${m.label}`),
  ].join('\n');
}
