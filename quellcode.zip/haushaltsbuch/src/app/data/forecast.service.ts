import { Injectable, computed, inject } from '@angular/core';
import { currentBalance } from '../domain/accounts/balances';
import { forecast } from '../domain/forecast/forecast';
import { priceChanges } from '../domain/recurring/contracts';
import { todayLocal } from '../domain/shared/local-date';
import { AccountsStore } from './stores/accounts.store';
import { BookingsStore } from './stores/bookings.store';
import { CategoriesStore } from './stores/categories.store';
import { PrefsStore } from './stores/prefs.store';
import { RecurringStore } from './stores/recurring.store';

/** Prognose des ersten Girokontos aus den aktuellen Daten (rechnet bei jeder Änderung neu). */
@Injectable({ providedIn: 'root' })
export class ForecastService {
  private readonly accounts = inject(AccountsStore);
  private readonly bookings = inject(BookingsStore);
  private readonly cats = inject(CategoriesStore);
  private readonly prefs = inject(PrefsStore);
  private readonly recurring = inject(RecurringStore);
  readonly giro = computed(() => this.accounts.active().find((a) => a.type === 'giro') ?? null);
  readonly result = computed(() => {
    const g = this.giro();
    if (!g) return null;
    const bal = currentBalance(g, this.bookings.bookings());
    if (bal === null) return null;
    return forecast({
      today: todayLocal(),
      account: g,
      balance: bal,
      items: this.recurring.items(),
      bookings: this.bookings.bookings(),
      cats: this.cats.categories(),
      prudence: this.prefs.prudence(),
    });
  });
  readonly priceChanges = computed(() =>
    priceChanges(this.recurring.items(), this.bookings.bookings()),
  );
}
