import { RecurringItem } from '../domain/recurring/recurring';
import { specialIncomeSchedule } from '../domain/recurring/special-income';
import { withLoanSchedules } from '../domain/loans/forecast-schedules';
import { BausparStore } from './stores/bauspar.store';
import { LoansStore } from './stores/loans.store';
import { Injectable, computed, inject } from '@angular/core';
import { currentBalance } from '../domain/accounts/balances';
import { forecast } from '../domain/forecast/forecast';
import { priceChanges } from '../domain/recurring/contracts';
import { refineItem } from '../domain/recurring/recurring';
import { todayLocal } from '../domain/shared/local-date';
import { AccountsStore } from './stores/accounts.store';
import { BookingsStore } from './stores/bookings.store';
import { CategoriesStore } from './stores/categories.store';
import { PrefsStore } from './stores/prefs.store';
import { RecurringStore } from './stores/recurring.store';

/** Prognose des ersten Girokontos aus den aktuellen Daten (rechnet bei jeder Änderung neu). */
@Injectable({ providedIn: 'root' })
export class ForecastService {
  private readonly accounts = inject(AccountsStore);
  private readonly bookings = inject(BookingsStore);
  private readonly cats = inject(CategoriesStore);
  private readonly prefs = inject(PrefsStore);
  private readonly recurring = inject(RecurringStore);
  private readonly loans = inject(LoansStore);
  private readonly bauspar = inject(BausparStore);
  /** eingeplante Posten mit gelerntem Tag und Betrag (aus den tatsächlichen Zahlungen) */
  readonly refined = computed(() =>
    this.recurring.items().map((i) => refineItem(i, this.bookings.bookings(), todayLocal())),
  );
  /** für die Prognose: Kreditraten nach Tilgungsplan, Sparrate bis zur Ablösung, Rate des Bauspardarlehens (18.3) */
  readonly forecastItems = computed(() => {
    const bookings = this.bookings.bookings();
    const bauspar = this.bauspar.items().map((b) => {
      const acc = this.accounts.accounts().find((a) => a.id === b.accountId);
      return { b, balance: acc ? (currentBalance(acc, bookings) ?? 0) : 0 };
    });
    const specials = specialIncomeSchedule(this.prefs.specialIncome().confirmed, todayLocal()).map(
      ({ c, date }) =>
        ({
          id: `sonderzahlung-${c.key}-${date}`,
          label: c.label,
          accountId: c.accountId,
          amount: c.amount,
          categoryId: 'e-sonderzahlungen',
          subCategory: null,
          pattern: '',
          interval: 'jahr',
          day: c.day,
          months: [c.month],
          variable: false,
          active: true,
          transferTo: null,
          schedule: [{ date, amount: c.amount }],
        }) as RecurringItem,
    );
    return [
      ...withLoanSchedules(this.refined(), this.loans.loans(), bauspar, bookings, todayLocal()),
      ...specials,
    ];
  });
  readonly giro = computed(() => this.accounts.active().find((a) => a.type === 'giro') ?? null);
  readonly result = computed(() => {
    const g = this.giro();
    if (!g) return null;
    const bal = currentBalance(g, this.bookings.bookings());
    if (bal === null) return null;
    return forecast({
      today: todayLocal(),
      account: g,
      balance: bal,
      items: this.forecastItems(),
      bookings: this.bookings.bookings(),
      cats: this.cats.categories(),
      prudence: this.prefs.prudence(),
    });
  });
  readonly priceChanges = computed(() =>
    priceChanges(this.recurring.items(), this.bookings.bookings()),
  );
}
