import { Injectable, computed, inject } from '@angular/core';
import {
  Loan,
  LoanState,
  Split,
  isRate,
  isSpecial,
  latestSnapshot,
  loanState,
  validate,
  yearEnds,
} from '../domain/loans/loan';
import { RecurringItem, signatureOf } from '../domain/recurring/recurring';
import { todayLocal } from '../domain/shared/local-date';
import { loanOf } from '../domain/stats/groups';
import { BookingsStore } from './stores/bookings.store';
import { LoansStore } from './stores/loans.store';
import { RecurringStore } from './stores/recurring.store';
import { BausparStore } from './stores/bauspar.store';
import { AccountsStore } from './stores/accounts.store';
import { Bauspar, BausparProjection, projectBauspar } from '../domain/loans/bauspar';
import { currentBalance } from '../domain/accounts/balances';
import {
  STRATEGIES,
  SpecialResult,
  Strategy,
  recommend,
  simulate,
} from '../domain/loans/special-plan';
import { findStandingOrder } from '../domain/liquidity/pots';
import { PrefsStore } from './stores/prefs.store';
import { ForecastService } from './forecast.service';

export interface LoanView {
  loan: Loan;
  state: LoanState;
}

/** Kreditverwaltung (Lastenheft 18): Zustände, Summen, Verknüpfung mit Prognose und Statistik. */
@Injectable({ providedIn: 'root' })
export class LoansService {
  private readonly store = inject(LoansStore);
  private readonly bookings = inject(BookingsStore);
  private readonly recurring = inject(RecurringStore);
  private readonly bausparStore = inject(BausparStore);
  private readonly accounts = inject(AccountsStore);
  readonly bauspar = this.bausparStore.items;
  private readonly prefs = inject(PrefsStore);
  private readonly fc = inject(ForecastService);

  /** Sondertilgungsrücklage: Tagesgeldkonten mit Zweck „Sondertilgungsrücklage“ */
  readonly reserveAccounts = computed(() =>
    this.accounts.active().filter((a) => a.type === 'tagesgeld' && a.purpose === 'sondertilgung'),
  );
  readonly specialPool = computed(() =>
    this.reserveAccounts().reduce(
      (s, a) => s + Math.max(0, (currentBalance(a, this.bookings.bookings()) ?? 0) - a.reserve),
      0,
    ),
  );
  /** monatlich in die Rücklage: Dauerauftrag (eingetragen oder erkannt), sonst Durchschnitt der Eingänge der letzten 12 Monate */
  readonly detectedMonthly = computed<{ amount: number; source: string }>(() => {
    const g = this.fc.giro();
    let sum = 0;
    for (const a of this.reserveAccounts()) {
      const so = g
        ? findStandingOrder(
            [...this.fc.refined(), ...this.recurring.suggestions()],
            this.bookings.bookings(),
            g.id,
            a.id,
          )
        : null;
      if (so) {
        sum += so.amount;
        continue;
      }
      const since = new Date(Date.parse(todayLocal()) - 365 * 86400000).toISOString().slice(0, 10);
      const ins = this.bookings
        .bookings()
        .filter(
          (b) => b.accountId === a.id && b.kind === 'umbuchung' && b.amount > 0 && b.date >= since,
        )
        .reduce((s, b) => s + b.amount, 0);
      sum += Math.round(ins / 12);
    }
    return { amount: sum, source: sum ? 'erkannt' : 'keiner' };
  });
  readonly specialMonthly = computed(
    () => this.prefs.specialPlan().monthly ?? this.detectedMonthly().amount,
  );
  /** Kredite im Plan: aktive, nicht vom Bausparvertrag abgelöste */
  private readonly planLoans = computed(() =>
    this.active().filter((v) => !this.bauspar().some((b) => b.loanId === v.loan.id)),
  );
  readonly special = computed(() => {
    const loans = this.planLoans();
    if (!loans.some((v) => v.loan.special.allowed)) return null;
    const input = {
      loans: loans.map((v) => ({ loan: v.loan, state: v.state })),
      pool: this.specialPool(),
      monthly: this.specialMonthly(),
      today: todayLocal(),
    };
    const { best, results } = recommend(input);
    const chosen = (this.prefs.specialPlan().strategy as Strategy | null) ?? best;
    const result: SpecialResult = results[chosen] ?? results[best];
    const without = simulate({ ...input, pool: 0, monthly: 0 }, chosen);
    const freed = simulate({ ...input, freedRates: true }, chosen);
    return {
      best,
      chosen,
      results,
      result,
      without,
      freed,
      names: Object.fromEntries(loans.map((v) => [v.loan.id, v.loan.name])),
      labels: STRATEGIES,
    };
  });
  readonly all = this.store.loans;

  readonly views = computed<LoanView[]>(() =>
    this.all().map((loan) => ({
      loan,
      state: loanState(loan, this.bookings.bookings(), todayLocal()),
    })),
  );
  readonly active = computed(() => this.views().filter((v) => !v.loan.paidOff));
  readonly paidOff = computed(() => this.views().filter((v) => !!v.loan.paidOff));
  readonly totalBalance = computed(() => this.active().reduce((s, v) => s + v.state.balance, 0));
  readonly totalRate = computed(() =>
    this.active().reduce(
      (s, v) => s + (v.loan.kind === 'voraus' ? (v.state.plan.rows[0]?.payment ?? 0) : v.loan.rate),
      0,
    ),
  );
  /** Bausparverträge mit Prognose (Ablösung, Bauspardarlehen, Abgleich) */
  readonly bausparViews = computed<{ b: Bauspar; p: BausparProjection; balance: number }[]>(() =>
    this.bauspar().map((b) => {
      const acc = this.accounts.accounts().find((a) => a.id === b.accountId);
      const balance = acc ? (currentBalance(acc, this.bookings.bookings()) ?? 0) : 0;
      const v = this.views().find((x) => x.loan.id === b.loanId) ?? null;
      return {
        b,
        balance,
        p: projectBauspar(b, v?.loan ?? null, v?.state ?? null, balance, todayLocal()),
      };
    }),
  );
  /** schuldenfrei am: spätestes Tilgungsende ohne Sondertilgungen (null, wenn ein Kredit nie endet);
   *  ein vom Bausparvertrag abgelöstes Darlehen endet mit dem Bauspardarlehen */
  readonly debtFree = computed(() => {
    const ends = this.active().map((v) => {
      const bp = this.bausparViews().find((x) => x.b.loanId === v.loan.id);
      return bp ? (bp.p.gap > 0 ? null : bp.p.bauLoanEnd) : v.state.payoff;
    });
    return ends.length && ends.every((e) => !!e) ? [...(ends as string[])].sort().at(-1)! : null;
  });
  /** Gesamtschuld je Jahresende (Schuldendiagramm) */
  readonly chart = computed(() => {
    const today = todayLocal(),
      sum = new Map<number, number>();
    for (const v of this.active())
      for (const p of yearEnds(v.state.plan, v.state.balance, today))
        sum.set(p.year, (sum.get(p.year) ?? 0) + p.balance);
    // Kredite, die früher enden, zählen danach mit 0
    return [...sum.entries()]
      .sort((a, b) => a[0] - b[0])
      .map(([year, balance]) => ({ year, balance }));
  });
  /** Aufteilung jeder gebuchten Rate in Zinsen und Tilgung, mit Kreditnamen (für die Statistik) */
  readonly splits = computed(() => {
    const out: Record<string, Split & { name: string }> = {};
    for (const v of this.views())
      for (const [id, s] of Object.entries(v.state.splits)) out[id] = { ...s, name: v.loan.name };
    return out;
  });
  /** „Kreditrate X“-Texte aus den Buchungen als Vorschläge für die Erkennung */
  readonly detected = computed(() => {
    const names = new Map<string, string>();
    for (const b of this.bookings.bookings()) {
      const l = b.amount < 0 ? loanOf(b.text) : null;
      if (l && !names.has(l.key)) names.set(l.key, `Kreditrate ${l.name}`);
    }
    return [...names.values()].sort();
  });

  /** Hinweise für die Übersicht: bis 12 Monate vor der Ablösung, wenn Bauart offen, Lücke oder ein Punkt rot ist */
  readonly bausparHints = computed(() => {
    const limit = new Date(Date.parse(todayLocal()) + 365 * 86400000).toISOString().slice(0, 10);
    return this.bausparViews()
      .filter(
        ({ b, p }) =>
          p.payoff &&
          p.payoff <= limit &&
          (!b.type || p.gap > 0 || p.checks.some((c) => c.status === 'rot')),
      )
      .map(
        ({ b, p }) =>
          `${b.name}: Ablösung voraussichtlich ${p.payoff!.slice(8, 10)}.${p.payoff!.slice(5, 7)}.${p.payoff!.slice(0, 4)}. ${!b.type ? 'Die Bauart ist noch offen.' : p.gap > 0 ? 'Es bleibt eine Lücke für eine Anschlussfinanzierung.' : 'Ein Punkt passt nicht zusammen.'}`,
      );
  });

  async saveBauspar(b: Bauspar): Promise<string | null> {
    if (!b.name.trim()) return 'Bitte einen Namen eingeben, z. B. „LBS Bausparvertrag“.';
    if (!b.accountId)
      return 'Bitte das Konto des Bausparvertrags wählen (Kontoart „Bausparvertrag“).';
    if (b.sum <= 0) return 'Bitte die Bausparsumme eingeben.';
    if (
      b.loanRate > 0 &&
      b.loanMilli >= 0 &&
      b.loanRate <= Math.round((b.sum * 0.6 * b.loanMilli) / 1200000) &&
      b.loanMilli > 0
    )
      return 'Die Rate des Bauspardarlehens wirkt zu niedrig für den Darlehenszins. Bitte prüfen.';
    await this.bausparStore.save(b);
    return null;
  }

  async removeBauspar(id: string): Promise<void> {
    await this.bausparStore.remove(id);
  }

  bookingsOf(loan: Loan) {
    return this.bookings.bookings().filter((b) => isRate(loan, b) || isSpecial(loan, b));
  }

  /** Speichern (18.2a): prüfen, Rate als wiederkehrende Zahlung anlegen oder anpassen */
  async save(loan: Loan): Promise<string | null> {
    const err = validate(loan);
    if (err) return err;
    const pattern = signatureOf(loan.pattern || `Kreditrate ${loan.name}`);
    const snap = latestSnapshot(loan);
    const amount =
      loan.kind === 'voraus'
        ? Math.round(((snap?.balance ?? 0) * loan.rateMilli) / 1200000)
        : loan.rate;
    const existing =
      this.recurring.items().find((i) => i.id === loan.recurringId) ??
      this.recurring.items().find((i) => i.accountId === loan.accountId && i.pattern === pattern);
    const item: RecurringItem = {
      ...(existing ?? {
        id: crypto.randomUUID(),
        months: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
        variable: false,
      }),
      label: `Kreditrate ${loan.name}`,
      accountId: loan.accountId,
      amount: -amount,
      categoryId: 'a-kredite',
      subCategory: null,
      pattern,
      interval: 'monat',
      day: loan.day,
      active: !loan.paidOff,
      transferTo: null,
    } as RecurringItem;
    await this.recurring.save(item);
    await this.store.save({
      ...loan,
      pattern: loan.pattern.trim() || `Kreditrate ${loan.name}`,
      recurringId: item.id,
    });
    return null;
  }

  async addSnapshot(loan: Loan, date: string, balance: number): Promise<void> {
    await this.store.save({
      ...loan,
      snapshots: [...loan.snapshots.filter((s) => s.date !== date), { date, balance }],
    });
  }

  async setPaidOff(loan: Loan, month: string | null): Promise<void> {
    await this.store.save({ ...loan, paidOff: month });
    const it = this.recurring.items().find((i) => i.id === loan.recurringId);
    if (it) await this.recurring.save({ ...it, active: !month });
  }

  /** Löschen nur ohne zugeordnete Buchungen (z. B. nach einem Tippfehler beim Anlegen) */
  async remove(loan: Loan): Promise<string | null> {
    if (this.bookingsOf(loan).length)
      return 'Dieser Kredit hat schon Buchungen. Markiere ihn stattdessen als abbezahlt.';
    if (loan.recurringId) await this.recurring.remove(loan.recurringId);
    await this.store.remove(loan.id);
    return null;
  }
}
