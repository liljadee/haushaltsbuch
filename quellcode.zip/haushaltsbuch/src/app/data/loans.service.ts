import { Injectable, computed, inject } from '@angular/core';
import {
  Loan,
  LoanState,
  Split,
  isRate,
  isSpecial,
  latestSnapshot,
  loanState,
  validate,
  yearEnds,
} from '../domain/loans/loan';
import { RecurringItem, signatureOf } from '../domain/recurring/recurring';
import { todayLocal } from '../domain/shared/local-date';
import { loanOf } from '../domain/stats/groups';
import { BookingsStore } from './stores/bookings.store';
import { LoansStore } from './stores/loans.store';
import { RecurringStore } from './stores/recurring.store';

export interface LoanView {
  loan: Loan;
  state: LoanState;
}

/** Kreditverwaltung (Lastenheft 18): Zustände, Summen, Verknüpfung mit Prognose und Statistik. */
@Injectable({ providedIn: 'root' })
export class LoansService {
  private readonly store = inject(LoansStore);
  private readonly bookings = inject(BookingsStore);
  private readonly recurring = inject(RecurringStore);
  readonly all = this.store.loans;

  readonly views = computed<LoanView[]>(() =>
    this.all().map((loan) => ({
      loan,
      state: loanState(loan, this.bookings.bookings(), todayLocal()),
    })),
  );
  readonly active = computed(() => this.views().filter((v) => !v.loan.paidOff));
  readonly paidOff = computed(() => this.views().filter((v) => !!v.loan.paidOff));
  readonly totalBalance = computed(() => this.active().reduce((s, v) => s + v.state.balance, 0));
  readonly totalRate = computed(() =>
    this.active().reduce(
      (s, v) => s + (v.loan.kind === 'voraus' ? (v.state.plan.rows[0]?.payment ?? 0) : v.loan.rate),
      0,
    ),
  );
  /** schuldenfrei am: spätestes Tilgungsende ohne Sondertilgungen (null, wenn ein Kredit nie endet) */
  readonly debtFree = computed(() => {
    const ends = this.active().map((v) => v.state.payoff);
    return ends.length && ends.every((e) => !!e) ? [...(ends as string[])].sort().at(-1)! : null;
  });
  /** Gesamtschuld je Jahresende (Schuldendiagramm) */
  readonly chart = computed(() => {
    const today = todayLocal(),
      sum = new Map<number, number>();
    for (const v of this.active())
      for (const p of yearEnds(v.state.plan, v.state.balance, today))
        sum.set(p.year, (sum.get(p.year) ?? 0) + p.balance);
    // Kredite, die früher enden, zählen danach mit 0
    return [...sum.entries()]
      .sort((a, b) => a[0] - b[0])
      .map(([year, balance]) => ({ year, balance }));
  });
  /** Aufteilung jeder gebuchten Rate in Zinsen und Tilgung, mit Kreditnamen (für die Statistik) */
  readonly splits = computed(() => {
    const out: Record<string, Split & { name: string }> = {};
    for (const v of this.views())
      for (const [id, s] of Object.entries(v.state.splits)) out[id] = { ...s, name: v.loan.name };
    return out;
  });
  /** „Kreditrate X“-Texte aus den Buchungen als Vorschläge für die Erkennung */
  readonly detected = computed(() => {
    const names = new Map<string, string>();
    for (const b of this.bookings.bookings()) {
      const l = b.amount < 0 ? loanOf(b.text) : null;
      if (l && !names.has(l.key)) names.set(l.key, `Kreditrate ${l.name}`);
    }
    return [...names.values()].sort();
  });

  bookingsOf(loan: Loan) {
    return this.bookings.bookings().filter((b) => isRate(loan, b) || isSpecial(loan, b));
  }

  /** Speichern (18.2a): prüfen, Rate als wiederkehrende Zahlung anlegen oder anpassen */
  async save(loan: Loan): Promise<string | null> {
    const err = validate(loan);
    if (err) return err;
    const pattern = signatureOf(loan.pattern || `Kreditrate ${loan.name}`);
    const snap = latestSnapshot(loan);
    const amount =
      loan.kind === 'voraus'
        ? Math.round(((snap?.balance ?? 0) * loan.rateMilli) / 1200000)
        : loan.rate;
    const existing =
      this.recurring.items().find((i) => i.id === loan.recurringId) ??
      this.recurring.items().find((i) => i.accountId === loan.accountId && i.pattern === pattern);
    const item: RecurringItem = {
      ...(existing ?? {
        id: crypto.randomUUID(),
        months: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
        variable: false,
      }),
      label: `Kreditrate ${loan.name}`,
      accountId: loan.accountId,
      amount: -amount,
      categoryId: 'a-kredite',
      subCategory: null,
      pattern,
      interval: 'monat',
      day: loan.day,
      active: !loan.paidOff,
      transferTo: null,
    } as RecurringItem;
    await this.recurring.save(item);
    await this.store.save({
      ...loan,
      pattern: loan.pattern.trim() || `Kreditrate ${loan.name}`,
      recurringId: item.id,
    });
    return null;
  }

  async addSnapshot(loan: Loan, date: string, balance: number): Promise<void> {
    await this.store.save({
      ...loan,
      snapshots: [...loan.snapshots.filter((s) => s.date !== date), { date, balance }],
    });
  }

  async setPaidOff(loan: Loan, month: string | null): Promise<void> {
    await this.store.save({ ...loan, paidOff: month });
    const it = this.recurring.items().find((i) => i.id === loan.recurringId);
    if (it) await this.recurring.save({ ...it, active: !month });
  }

  /** Löschen nur ohne zugeordnete Buchungen (z. B. nach einem Tippfehler beim Anlegen) */
  async remove(loan: Loan): Promise<string | null> {
    if (this.bookingsOf(loan).length)
      return 'Dieser Kredit hat schon Buchungen. Markiere ihn stattdessen als abbezahlt.';
    if (loan.recurringId) await this.recurring.remove(loan.recurringId);
    await this.store.remove(loan.id);
    return null;
  }
}
