import { PotsStore } from './stores/pots.store';
import { DataStore } from './storage/db';
import { VaultService } from './vault.service';
import { specialHistory } from '../domain/loans/history';
import { Phase, phases } from '../domain/loans/phases';
import { rateIssues } from '../domain/loans/rate-check';
import { SettlementInput, planSettlement } from '../domain/loans/settlement';
import { calendarEvents, loanAlarms } from '../domain/loans/alarms';
import { roadmap } from '../domain/loans/roadmap';
import { Injectable, computed, inject, signal } from '@angular/core';
import {
  Loan,
  LoanState,
  Split,
  isRate,
  isSpecial,
  latestSnapshot,
  loanState,
  validate,
  defaultSpecial,
} from '../domain/loans/loan';
import { RecurringItem, signatureOf } from '../domain/recurring/recurring';
import { todayLocal } from '../domain/shared/local-date';
import { loanOf } from '../domain/stats/groups';
import { BookingsStore } from './stores/bookings.store';
import { LoansStore } from './stores/loans.store';
import { RecurringStore } from './stores/recurring.store';
import { BausparStore } from './stores/bauspar.store';
import { AccountsStore } from './stores/accounts.store';
import { Bauspar, BausparProjection, projectBauspar } from '../domain/loans/bauspar';
import { currentBalance } from '../domain/accounts/balances';
import {
  unprofitable,
  FixedEnd,
  BausparLink,
  STRATEGIES,
  SpecialResult,
  Strategy,
  recommend,
  simulate,
} from '../domain/loans/special-plan';
import { findStandingOrder, potRate } from '../domain/liquidity/pots';
import { PrefsStore } from './stores/prefs.store';
import { ForecastService } from './forecast.service';

export interface LoanView {
  loan: Loan;
  state: LoanState;
}

/** Kreditverwaltung (Lastenheft 18): Zustände, Summen, Verknüpfung mit Prognose und Statistik. */
@Injectable({ providedIn: 'root' })
export class LoansService {
  private readonly store = inject(LoansStore);
  private readonly vault = inject(VaultService);
  private readonly bookings = inject(BookingsStore);
  private readonly recurring = inject(RecurringStore);
  private readonly bausparStore = inject(BausparStore);
  private readonly accounts = inject(AccountsStore);
  readonly bauspar = this.bausparStore.items;
  private readonly prefs = inject(PrefsStore);
  private readonly fc = inject(ForecastService);
  private readonly potsStore = inject(PotsStore);

  /** Alarme und Fristen (18.5) und alle künftigen Termine für den Kalender */
  readonly alarms = computed(() => [
    ...this.rateIssues().map((i) => ({
      id: `${i.kind}-${i.date}-${i.bookingIds.join('-')}`,
      due: i.date,
      showFrom: i.date,
      title: i.title,
      text: i.text,
    })),
    ...loanAlarms(
      this.active(),
      this.bausparViews().filter((v) => !v.b.settled),
      this.bookings.bookings(),
      todayLocal(),
      this.special()?.result.fixedEnds ?? [],
      this.scenarioB()?.fixedEnds ?? [],
    ),
  ]);
  /**
   * Je Kredit dieselben Werte wie im Fahrplan (mit Sondertilgungsplan): Restschuld zum Zinsbindungsende, Rücklage,
   * Nachfinanzierung, Tilgung. Leer, wenn der Plan keine Sondertilgung vorsieht; abgelöste Darlehen ohne Tilgungstermin.
   */
  readonly planByLoan = computed(() => {
    const r = this.special()?.result;
    const out = new Map<string, { fixedEnd: FixedEnd | null; payoff: string | null }>();
    if (!r || !r.payments.length) return out;
    const replaced = new Set(r.replacements.map((x) => x.loanId));
    for (const v of this.active())
      out.set(v.loan.id, {
        fixedEnd: r.fixedEnds.find((f) => f.loanId === v.loan.id) ?? null,
        payoff: replaced.has(v.loan.id) ? null : (r.payoffs[v.loan.id] ?? null),
      });
    return out;
  });

  /** Rentabilität (18.6): Kredite, bei denen eine Sondertilgung rechnerisch nicht lohnt */
  readonly unprofitableLoans = computed(() =>
    unprofitable(
      this.active().map((v) => ({ loan: v.loan })),
      this.prefs.specialPlan().savingsMilli,
      this.prefs.specialPlan().taxMilli,
      todayLocal(),
    ),
  );
  /** Prüfung der Raten (18.3): ausgeblieben, doppelt, mögliche Sondertilgung */
  readonly rateIssues = computed(() =>
    this.active().flatMap((v) =>
      rateIssues(v.loan, this.bookings.bookings(), todayLocal()).map((i) => ({
        ...i,
        loanId: v.loan.id,
      })),
    ),
  );
  /** bisherige Sondertilgungen je Kredit und Szenario B „wie bisher“ (18.4) */
  readonly histories = computed(
    () =>
      new Map(
        this.active().map((v) => [
          v.loan.id,
          specialHistory(v.loan, this.bookings.bookings(), todayLocal()),
        ]),
      ),
  );
  readonly scenarioB = computed(() => {
    const extras = Object.fromEntries(
      [...this.histories()].filter(([, h]) => h.median > 0).map(([id, h]) => [id, h.median]),
    );
    if (!Object.keys(extras).length) return null;
    const r = simulate(
      {
        ...this.planInput(),
        pool: 0,
        monthly: 0,
        yearlyExtras: extras,
        loans: this.planInput().loans.map((x) => ({
          ...x,
          loan: { ...x.loan, forwardRate: false },
        })),
      },
      'zins',
    );
    return {
      debtFree: r.debtFree,
      interest: r.interest,
      fixedEnds: r.fixedEnds,
      uncertain: [...this.histories().values()].some((h) => h.median > 0 && h.uncertain),
    };
  });
  readonly events = computed(() =>
    calendarEvents(
      this.active(),
      this.bauspar().map((b) => ({ b })),
      todayLocal(),
    ),
  );

  /** Spartöpfe „für Sondertilgungen“: virtuelle Rücklage auf einem Tagesgeld (Lastenheft 16a, 18.6) */
  readonly specialPots = computed(() => this.potsStore.pots().filter((p) => p.forSpecial));
  /** Sondertilgungsrücklage: Tagesgeldkonten mit Zweck „Sondertilgungsrücklage“ */
  readonly reserveAccounts = computed(() =>
    this.accounts.active().filter((a) => a.type === 'tagesgeld' && a.purpose === 'sondertilgung'),
  );
  readonly specialPool = computed(
    () =>
      this.reserveAccounts().reduce(
        (s, a) => s + Math.max(0, (currentBalance(a, this.bookings.bookings()) ?? 0) - a.reserve),
        0,
      ) + this.specialPots().reduce((s, p) => s + Math.max(0, p.balance), 0),
  );
  /** monatlich in die Rücklage: Dauerauftrag (eingetragen oder erkannt), sonst Durchschnitt der Eingänge der letzten 12 Monate */
  readonly detectedMonthly = computed<{ amount: number; source: string }>(() => {
    const g = this.fc.giro();
    let sum = 0;
    // Monatsrate der Töpfe für Sondertilgungen (Dauerauftrag auf das Rücklagenkonto, auf die Töpfe verteilt)
    for (const p of this.specialPots()) sum += potRate(p, this.recurring.items(), todayLocal());
    for (const a of this.reserveAccounts()) {
      const so = g
        ? findStandingOrder(
            [...this.fc.refined(), ...this.recurring.suggestions()],
            this.bookings.bookings(),
            g.id,
            a.id,
          )
        : null;
      if (so) {
        sum += so.amount;
        continue;
      }
      const since = new Date(Date.parse(todayLocal()) - 365 * 86400000).toISOString().slice(0, 10);
      const ins = this.bookings
        .bookings()
        .filter(
          (b) => b.accountId === a.id && b.kind === 'umbuchung' && b.amount > 0 && b.date >= since,
        )
        .reduce((s, b) => s + b.amount, 0);
      sum += Math.round(ins / 12);
    }
    return { amount: sum, source: sum ? 'erkannt' : 'keiner' };
  });
  readonly specialMonthly = computed(
    () => this.prefs.specialPlan().monthly ?? this.detectedMonthly().amount,
  );
  /** vom Bausparvertrag abgelöste Darlehen: Ablösung mit Bauspardarlehen und ggf. Anschlussfinanzierung */
  private readonly links = computed<BausparLink[]>(() => {
    const st = this.prefs.specialPlan();
    return this.bausparViews()
      .filter(
        ({ b, p }) =>
          !b.settled && b.loanId && p.payoff && this.active().some((v) => v.loan.id === b.loanId),
      )
      .map(({ b, p }) => ({
        loanId: b.loanId!,
        payoff: p.payoff!,
        balanceAt: p.balanceAt,
        name: b.name,
        debtAt: p.debtAt,
        extraPayments: !!b.extraPayments,
        sum: b.sum,
        bauMilli: b.loanMilli,
        bauRate: b.loanRate,
        bauSpecial: st.bauSpecial
          ? defaultSpecial('raten')
          : { ...defaultSpecial('raten'), allowed: false },
        gapMilli: st.gapMilli,
        gapTilgungMilli: st.gapTilgungMilli,
      }));
  });
  private readonly planInput = computed(() => ({
    loans: this.active().map((v) => ({ loan: v.loan, state: v.state })),
    pool: this.specialPool(),
    monthly: this.specialMonthly(),
    today: todayLocal(),
    bauspar: this.links(),
  }));
  /** ohne Sondertilgungen und ohne weitergeleitete Raten, mit Ablösung durch Bausparverträge (Grundlage für „schuldenfrei“) */
  readonly baseline = computed(() =>
    simulate(
      {
        ...this.planInput(),
        pool: 0,
        monthly: 0,
        loans: this.planInput().loans.map((x) => ({
          ...x,
          loan: { ...x.loan, forwardRate: false },
        })),
      },
      'zins',
    ),
  );
  readonly special = computed(() => {
    const input = this.planInput();
    if (
      !input.loans.some((x) => x.loan.special.allowed) &&
      !(this.links().length && this.prefs.specialPlan().bauSpecial)
    )
      return null;
    const { best, results } = recommend(input);
    const chosen = (this.prefs.specialPlan().strategy as Strategy | null) ?? best;
    const result: SpecialResult = results[chosen] ?? results[best];
    const without = this.baseline();
    const freed = simulate({ ...input, freedRates: true }, chosen);
    return {
      best,
      chosen,
      results,
      result,
      without,
      freed,
      names: result.names,
      forwarding: input.loans.some((x) => x.loan.forwardRate),
      labels: STRATEGIES,
    };
  });
  readonly all = this.store.loans;

  readonly views = computed<LoanView[]>(() =>
    this.all().map((loan) => ({
      loan,
      state: loanState(loan, this.bookings.bookings(), todayLocal()),
    })),
  );
  readonly active = computed(() => this.views().filter((v) => !v.loan.paidOff));
  readonly paidOff = computed(() => this.views().filter((v) => !!v.loan.paidOff));
  readonly totalBalance = computed(() => this.active().reduce((s, v) => s + v.state.balance, 0));
  readonly totalRate = computed(() =>
    this.active().reduce(
      (s, v) => s + (v.loan.kind === 'voraus' ? (v.state.plan.rows[0]?.payment ?? 0) : v.loan.rate),
      0,
    ),
  );
  /** Bausparverträge mit Prognose (Ablösung, Bauspardarlehen, Abgleich) */
  readonly bausparViews = computed<{ b: Bauspar; p: BausparProjection; balance: number }[]>(() =>
    this.bauspar().map((b) => {
      const acc = this.accounts.accounts().find((a) => a.id === b.accountId);
      const balance = acc ? (currentBalance(acc, this.bookings.bookings()) ?? 0) : 0;
      const v = this.views().find((x) => x.loan.id === b.loanId) ?? null;
      return {
        b,
        balance,
        p: projectBauspar(b, v?.loan ?? null, v?.state ?? null, balance, todayLocal()),
      };
    }),
  );
  /** schuldenfrei am: spätestes Tilgungsende ohne Sondertilgungen (null, wenn ein Kredit nie endet);
   *  ein vom Bausparvertrag abgelöstes Darlehen endet mit dem Bauspardarlehen */
  readonly debtFree = computed(() => this.baseline().debtFree);
  /** Gesamtschuld je Jahresende (Schuldendiagramm): ohne Sondertilgungen, mit Ablösung durch Bausparverträge */
  readonly chart = computed(() => this.baseline().yearEnds);
  /** dasselbe mit dem Sondertilgungsplan */
  readonly chartWith = computed(() => this.special()?.result.yearEnds ?? null);
  /** je Kredit: Restschuld zum Jahresende ohne und mit Sondertilgungsplan (abgelöste Darlehen samt Nachfolgern) */
  readonly loanCharts = computed(() => {
    const base = this.baseline(),
      withPlan = this.special()?.result ?? null;
    return Object.keys(base.loanYearEnds).map((id) => ({
      id,
      name: this.all().find((l) => l.id === id)?.name ?? base.names[id] ?? 'Kredit',
      base: base.loanYearEnds[id],
      with: withPlan?.loanYearEnds[id] ?? null,
    }));
  });
  /** Fahrplan: was wann auf dich zukommt, nach dem gewählten Sondertilgungsplan (sonst ohne Sondertilgungen) */
  readonly roadmap = computed(() =>
    roadmap(
      this.special()?.result ?? this.baseline(),
      this.active().map((v) => v.loan),
      todayLocal(),
    ),
  );
  /** Wunsch aus einem Kredit heraus: mit einem Bausparvertrag verknüpfen (öffnet das Formular vorbelegt) */
  readonly linkRequest = signal<string | null>(null);
  /** Aufteilung jeder gebuchten Rate in Zinsen und Tilgung, mit Kreditnamen (für die Statistik) */
  readonly splits = computed(() => {
    const out: Record<string, Split & { name: string }> = {};
    for (const v of this.views())
      for (const [id, s] of Object.entries(v.state.splits)) out[id] = { ...s, name: v.loan.name };
    return out;
  });
  /** „Kreditrate X“-Texte aus den Buchungen als Vorschläge für die Erkennung */
  readonly detected = computed(() => {
    const names = new Map<string, string>();
    for (const b of this.bookings.bookings()) {
      const l = b.amount < 0 ? loanOf(b.text) : null;
      if (l && !names.has(l.key)) names.set(l.key, `Kreditrate ${l.name}`);
    }
    return [...names.values()].sort();
  });

  /** Hinweise für die Übersicht: bis 12 Monate vor der Ablösung, wenn Bauart offen, Lücke oder ein Punkt rot ist */
  readonly bausparHints = computed(() => {
    const limit = new Date(Date.parse(todayLocal()) + 365 * 86400000).toISOString().slice(0, 10);
    return this.bausparViews()
      .filter(
        ({ b, p }) =>
          !b.settled &&
          p.payoff &&
          p.payoff <= limit &&
          (!b.type || p.gap > 0 || p.checks.some((c) => c.status === 'rot')),
      )
      .map(
        ({ b, p }) =>
          `${b.name}: Ablösung voraussichtlich ${p.payoff!.slice(8, 10)}.${p.payoff!.slice(5, 7)}.${p.payoff!.slice(0, 4)}. ${!b.type ? 'Die Bauart ist noch offen.' : p.gap > 0 ? 'Es bleibt eine Lücke für eine Anschlussfinanzierung.' : 'Ein Punkt passt nicht zusammen.'}`,
      );
  });

  async saveBauspar(b: Bauspar): Promise<string | null> {
    if (!b.name.trim()) return 'Bitte einen Namen eingeben, z. B. „LBS Bausparvertrag“.';
    if (!b.accountId)
      return 'Bitte das Konto des Bausparvertrags wählen (Kontoart „Bausparvertrag“).';
    if (b.sum <= 0) return 'Bitte die Bausparsumme eingeben.';
    if (
      b.loanRate > 0 &&
      b.loanMilli >= 0 &&
      b.loanRate <= Math.round((b.sum * 0.6 * b.loanMilli) / 1200000) &&
      b.loanMilli > 0
    )
      return 'Die Rate des Bauspardarlehens wirkt zu niedrig für den Darlehenszins. Bitte prüfen.';
    await this.bausparStore.save(b);
    return null;
  }

  async removeBauspar(id: string): Promise<void> {
    await this.bausparStore.remove(id);
  }

  /** Zeitstrahl eines Kredits (18.4) */
  phasesOf(v: { loan: Loan; state: LoanState }): Phase[] {
    const link = this.bausparViews().find((x) => x.b.loanId === v.loan.id && !x.b.settled) ?? null;
    const plan = this.planByLoan().get(v.loan.id);
    return phases(
      v.loan,
      v.state,
      todayLocal(),
      link ? { b: link.b, p: link.p } : null,
      plan ? { fixedEndDebt: plan.fixedEnd?.debt ?? null, payoff: plan.payoff } : null,
    );
  }

  /** mögliche Sondertilgung bestätigen oder als „keine Sondertilgung“ abhaken (18.3) */
  async decidePayment(loan: Loan, bookingId: string, isSpecialPayment: boolean): Promise<void> {
    await this.store.save(
      isSpecialPayment
        ? {
            ...loan,
            confirmedSpecials: [...new Set([...(loan.confirmedSpecials ?? []), bookingId])],
          }
        : {
            ...loan,
            dismissedPayments: [...new Set([...(loan.dismissedPayments ?? []), bookingId])],
          },
    );
  }

  /**
   * Ablösung durch den Bausparvertrag in einem Schritt (18.10): Bauspardarlehen anlegen, Darlehen archivieren
   * oder als Anschlussfinanzierung weiterführen, Guthaben ausbuchen; alles in einer Transaktion.
   */
  async settleBauspar(
    b: Bauspar,
    input: SettlementInput,
    archiveAccount: boolean,
  ): Promise<string | null> {
    const loan = this.all().find((l) => l.id === b.loanId);
    if (!loan) return 'Der Bausparvertrag ist mit keinem Darlehen verknüpft.';
    const seq = Math.max(0, ...this.bookings.bookings().map((x) => x.seq)) + 1;
    const plan = planSettlement(loan, b, b.accountId, input, {
      bauLoanId: crypto.randomUUID(),
      bookingId: crypto.randomUUID(),
      seq,
    });
    if ('error' in plan) return plan.error;
    const entries: { store: DataStore; key: string; value: unknown }[] = [];
    const oldItem = this.recurring.items().find((i) => i.id === loan.recurringId) ?? null;
    if (oldItem)
      entries.push({
        store: 'recurring',
        key: oldItem.id,
        value: this.rateItem(plan.loan, oldItem),
      });
    entries.push({ store: 'loans', key: plan.loan.id, value: plan.loan });
    if (plan.bauLoan) {
      const item = this.rateItem(plan.bauLoan, null);
      entries.push(
        { store: 'recurring', key: item.id, value: item },
        { store: 'loans', key: plan.bauLoan.id, value: { ...plan.bauLoan, recurringId: item.id } },
      );
    }
    entries.push({ store: 'bauspar', key: plan.bauspar.id, value: plan.bauspar });
    // Sparrate (Dauerauftrag auf den Bausparvertrag) endet mit der Ablösung
    for (const i of this.recurring
      .items()
      .filter((x) => x.active && (x.transferTo === b.accountId || x.accountId === b.accountId)))
      entries.push({ store: 'recurring', key: i.id, value: { ...i, active: false } });
    if (plan.booking) {
      const month = plan.booking.date.slice(0, 7);
      entries.push({
        store: 'bookings',
        key: month,
        value: [
          ...this.bookings.bookings().filter((x) => x.date.slice(0, 7) === month),
          plan.booking,
        ],
      });
    }
    const acc = this.accounts.accounts().find((a) => a.id === b.accountId);
    if (archiveAccount && acc)
      entries.push({ store: 'accounts', key: acc.id, value: { ...acc, archived: true } });
    await this.vault.writeMany(entries);
    await Promise.all([
      this.store.load(),
      this.bausparStore.load(),
      this.bookings.load(),
      this.accounts.load(),
      this.recurring.load(),
    ]);
    return null;
  }

  /** Rate eines Kredits als wiederkehrende Zahlung (für die Prognose) */
  private rateItem(loan: Loan, existing: RecurringItem | null): RecurringItem {
    const snap = latestSnapshot(loan);
    const amount =
      loan.kind === 'voraus'
        ? Math.round(((snap?.balance ?? 0) * loan.rateMilli) / 1200000)
        : loan.rate;
    return {
      ...(existing ?? {
        id: crypto.randomUUID(),
        months: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
        variable: false,
      }),
      label: `Kreditrate ${loan.name}`,
      accountId: loan.accountId,
      amount: -amount,
      categoryId: 'a-kredite',
      subCategory: null,
      pattern: signatureOf(loan.pattern || `Kreditrate ${loan.name}`),
      interval: 'monat',
      day: loan.day,
      active: !loan.paidOff,
      transferTo: null,
    } as RecurringItem;
  }

  bookingsOf(loan: Loan) {
    return this.bookings.bookings().filter((b) => isRate(loan, b) || isSpecial(loan, b));
  }

  /** Speichern (18.2a): prüfen, Rate als wiederkehrende Zahlung anlegen oder anpassen */
  async save(loan: Loan): Promise<string | null> {
    const err = validate(loan);
    if (err) return err;
    const pattern = signatureOf(loan.pattern || `Kreditrate ${loan.name}`);
    const existing =
      this.recurring.items().find((i) => i.id === loan.recurringId) ??
      this.recurring.items().find((i) => i.accountId === loan.accountId && i.pattern === pattern) ??
      null;
    const item = this.rateItem(loan, existing);
    await this.recurring.save(item);
    await this.store.save({
      ...loan,
      pattern: loan.pattern.trim() || `Kreditrate ${loan.name}`,
      recurringId: item.id,
    });
    return null;
  }

  async addSnapshot(loan: Loan, date: string, balance: number): Promise<void> {
    await this.store.save({
      ...loan,
      snapshots: [...loan.snapshots.filter((s) => s.date !== date), { date, balance }],
    });
  }

  async setPaidOff(loan: Loan, month: string | null): Promise<void> {
    await this.store.save({ ...loan, paidOff: month });
    const it = this.recurring.items().find((i) => i.id === loan.recurringId);
    if (it) await this.recurring.save({ ...it, active: !month });
  }

  /** Löschen nur ohne zugeordnete Buchungen (z. B. nach einem Tippfehler beim Anlegen) */
  async remove(loan: Loan): Promise<string | null> {
    if (this.bookingsOf(loan).length)
      return 'Dieser Kredit hat schon Buchungen. Markiere ihn stattdessen als abbezahlt.';
    if (loan.recurringId) await this.recurring.remove(loan.recurringId);
    await this.store.remove(loan.id);
    return null;
  }
}
