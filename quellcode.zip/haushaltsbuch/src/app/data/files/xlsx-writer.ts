import { Table } from '../../domain/export/export';
import { zip } from './zip-writer';

/**
 * XLSX ohne Fremdbibliothek (ADR 0003): ein Blatt je Tabelle, fette Kopfzeile, fixierte erste Zeile, Filter,
 * Datum als echtes Datum (TT.MM.JJJJ), Beträge mit zwei Nachkommastellen und €.
 */
const esc = (s: string) =>
  s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const col = (i: number): string =>
  (i >= 26 ? col(Math.floor(i / 26) - 1) : '') + String.fromCharCode(65 + (i % 26));
/** Excel-Datum: Tage seit dem 30.12.1899 */
const serial = (iso: string) => Math.round((Date.parse(iso) - Date.UTC(1899, 11, 30)) / 86400000);
const sheetName = (n: string, used: Set<string>) => {
  let s = n.replace(/[[\]:*?/\\]/g, ' ').slice(0, 31) || 'Blatt';
  for (let i = 2; used.has(s); i++) s = `${s.slice(0, 28)} ${i}`;
  used.add(s);
  return s;
};
// Formate: 1 Kopfzeile fett, 2 Datum, 3 Euro, 4 Zahl mit Komma
const STYLE = { date: 2, euro: 3, percent: 4, number: 0, text: 0 } as const;

function sheetXml(t: Table): string {
  const widths = t.columns.map((c, i) =>
    Math.min(
      48,
      Math.max(
        c.title.length + 2,
        c.type === 'date' ? 11 : c.type === 'euro' ? 14 : 8,
        ...t.rows.slice(0, 200).map((r) => String(r[i] ?? '').length + 1),
      ),
    ),
  );
  const head = `<row r="1">${t.columns.map((c, i) => `<c r="${col(i)}1" t="inlineStr" s="1"><is><t>${esc(c.title)}</t></is></c>`).join('')}</row>`;
  const body = t.rows
    .map(
      (r, ri) =>
        `<row r="${ri + 2}">${r
          .map((v, i) => {
            const ref = `${col(i)}${ri + 2}`,
              type = t.columns[i].type;
            if (v === null || v === '') return '';
            if (type === 'date' && typeof v === 'string')
              return `<c r="${ref}" s="2"><v>${serial(v)}</v></c>`;
            if (typeof v === 'number') return `<c r="${ref}" s="${STYLE[type]}"><v>${v}</v></c>`;
            return `<c r="${ref}" t="inlineStr"><is><t xml:space="preserve">${esc(v)}</t></is></c>`;
          })
          .join('')}</row>`,
    )
    .join('');
  const last = `${col(t.columns.length - 1)}${t.rows.length + 1}`;
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>${widths.map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`).join('')}</cols><sheetData>${head}${body}</sheetData><autoFilter ref="A1:${last}"/></worksheet>`;
}

export async function writeXlsx(tables: Table[]): Promise<Uint8Array> {
  const used = new Set<string>();
  const names = tables.map((t) => sheetName(t.name, used));
  const files = [
    {
      name: '[Content_Types].xml',
      data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${tables.map((_, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('')}</Types>`,
    },
    {
      name: '_rels/.rels',
      data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`,
    },
    {
      name: 'xl/workbook.xml',
      data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>${names.map((n, i) => `<sheet name="${esc(n)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('')}</sheets>${names
        .map(
          (n, i) =>
            `<definedNames><definedName name="_xlnm._FilterDatabase" localSheetId="${i}" hidden="1">'${esc(n).replace(/'/g, "''")}'!$A$1:$${col(tables[i].columns.length - 1)}$${tables[i].rows.length + 1}</definedName></definedNames>`,
        )
        .join('')
        .replace(/<\/definedNames><definedNames>/g, '')}</workbook>`,
    },
    {
      name: 'xl/_rels/workbook.xml.rels',
      data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${tables.map((_, i) => `<Relationship Id="rId${i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('')}<Relationship Id="rId${tables.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`,
    },
    {
      name: 'xl/styles.xml',
      data: `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="2"><numFmt numFmtId="164" formatCode="#,##0.00\\ &quot;€&quot;"/><numFmt numFmtId="165" formatCode="0.00"/></numFmts><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="5"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/><xf numFmtId="14" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/><xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/></cellXfs></styleSheet>`,
    },
    ...tables.map((t, i) => ({ name: `xl/worksheets/sheet${i + 1}.xml`, data: sheetXml(t) })),
  ];
  return zip(files);
}
