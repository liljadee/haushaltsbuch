/**
 * Liest Tabellen aus einer XLSX-Datei, ohne fremde Bibliothek (Bauplan 6.1 Import).
 * Eine XLSX-Datei ist ein ZIP-Archiv mit XML-Dateien; entpackt wird mit DecompressionStream.
 * Nur Lesen: Zellwerte als Text, Zahl oder Wahrheitswert; Formeln liefern ihr gespeichertes Ergebnis.
 */
export type Cell = string | number | boolean | null;
export interface SheetData {
  name: string;
  rows: Cell[][];
}
export type Inflate = (data: Uint8Array<ArrayBuffer>) => Promise<Uint8Array<ArrayBuffer>>;

export class XlsxError extends Error {}

const browserInflate: Inflate = async (data) => {
  const stream = new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'));
  return new Uint8Array(await new Response(stream).arrayBuffer());
};

interface ZipEntry {
  method: number;
  size: number;
  offset: number;
}

function zipDirectory(buf: Uint8Array): Map<string, ZipEntry> {
  const v = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  let eocd = -1;
  for (let i = buf.length - 22; i >= Math.max(0, buf.length - 65557); i--)
    if (v.getUint32(i, true) === 0x06054b50) {
      eocd = i;
      break;
    }
  if (eocd < 0) throw new XlsxError('Die Datei ist keine gültige Excel-Datei (.xlsx).');
  const count = v.getUint16(eocd + 10, true);
  let p = v.getUint32(eocd + 16, true);
  const dec = new TextDecoder();
  const out = new Map<string, ZipEntry>();
  for (let n = 0; n < count; n++) {
    if (v.getUint32(p, true) !== 0x02014b50) throw new XlsxError('Die Excel-Datei ist beschädigt.');
    const method = v.getUint16(p + 10, true),
      size = v.getUint32(p + 20, true);
    const nameLen = v.getUint16(p + 28, true),
      extraLen = v.getUint16(p + 30, true),
      commentLen = v.getUint16(p + 32, true);
    const offset = v.getUint32(p + 42, true);
    out.set(dec.decode(buf.subarray(p + 46, p + 46 + nameLen)), { method, size, offset });
    p += 46 + nameLen + extraLen + commentLen;
  }
  return out;
}

async function readEntry(
  buf: Uint8Array<ArrayBuffer>,
  e: ZipEntry,
  inflate: Inflate,
): Promise<string> {
  const v = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  const start = e.offset + 30 + v.getUint16(e.offset + 26, true) + v.getUint16(e.offset + 28, true);
  const raw = buf.slice(start, start + e.size);
  const data = e.method === 0 ? raw : e.method === 8 ? await inflate(raw) : null;
  if (!data) throw new XlsxError('Die Excel-Datei nutzt ein unbekanntes Packverfahren.');
  return new TextDecoder().decode(data);
}

const xml = (s: string) => new DOMParser().parseFromString(s, 'application/xml');
const colIndex = (ref: string) =>
  [...ref.replace(/\d+/g, '')].reduce((n, c) => n * 26 + c.charCodeAt(0) - 64, 0) - 1;

export async function readXlsx(
  input: ArrayBuffer | Uint8Array,
  inflate: Inflate = browserInflate,
): Promise<SheetData[]> {
  const buf = input instanceof Uint8Array ? new Uint8Array(input) : new Uint8Array(input);
  const dir = zipDirectory(buf);
  const file = async (name: string) => {
    const e = dir.get(name);
    return e ? readEntry(buf, e, inflate) : null;
  };
  const wb = await file('xl/workbook.xml');
  if (!wb)
    throw new XlsxError('In der Datei fehlt die Arbeitsmappe. Ist es wirklich eine .xlsx-Datei?');
  const rels = xml((await file('xl/_rels/workbook.xml.rels')) ?? '<Relationships/>');
  const target = new Map<string, string>();
  for (const r of Array.from(rels.getElementsByTagName('Relationship')))
    target.set(r.getAttribute('Id') ?? '', r.getAttribute('Target') ?? '');
  const sharedXml = await file('xl/sharedStrings.xml');
  const shared = sharedXml
    ? Array.from(xml(sharedXml).getElementsByTagName('si')).map((si) =>
        Array.from(si.getElementsByTagName('t'))
          .map((t) => t.textContent ?? '')
          .join(''),
      )
    : [];
  const sheets: SheetData[] = [];
  for (const s of Array.from(xml(wb).getElementsByTagName('sheet'))) {
    const rid =
      s.getAttribute('r:id') ??
      s.getAttributeNS(
        'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
        'id',
      ) ??
      '';
    const t = (target.get(rid) ?? '').replace(/^\/?(xl\/)?/, '');
    const body = await file(`xl/${t}`);
    if (!body) continue;
    const rows: Cell[][] = [];
    for (const r of Array.from(xml(body).getElementsByTagName('row'))) {
      const idx = Number(r.getAttribute('r') ?? rows.length + 1) - 1;
      const row: Cell[] = [];
      for (const c of Array.from(r.getElementsByTagName('c'))) {
        const type = c.getAttribute('t'),
          raw = c.getElementsByTagName('v')[0]?.textContent ?? null;
        let value: Cell = null;
        if (type === 's') value = raw === null ? null : (shared[Number(raw)] ?? null);
        else if (type === 'inlineStr')
          value = Array.from(c.getElementsByTagName('t'))
            .map((x) => x.textContent ?? '')
            .join('');
        else if (type === 'str' || type === 'd') value = raw;
        else if (type === 'b') value = raw === '1';
        else if (raw !== null && raw !== '') value = Number(raw);
        row[colIndex(c.getAttribute('r') ?? 'A')] = value;
      }
      rows[idx] = Array.from(row, (x) => x ?? null);
    }
    sheets.push({ name: s.getAttribute('name') ?? '', rows: Array.from(rows, (x) => x ?? []) });
  }
  return sheets;
}
