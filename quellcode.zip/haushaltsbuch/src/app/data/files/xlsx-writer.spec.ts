import { inflateRawSync } from 'node:zlib';
import { describe, expect, it } from 'vitest';
import { readXlsx } from './xlsx-reader';
import { writeXlsx } from './xlsx-writer';
import { crc32, zip } from './zip-writer';

describe('Excel-Export ohne Fremdbibliothek', () => {
  it('CRC-32 nach Standard', () => {
    expect(crc32(new TextEncoder().encode('123456789'))).toBe(0xcbf43926);
  });
  it('geschriebene XLSX lässt sich wieder lesen: Blätter, Kopfzeile, Text, Datum, Betrag', async () => {
    const bytes = await writeXlsx([
      {
        name: 'Buchungen',
        columns: [
          { title: 'Datum', type: 'date' },
          { title: 'Text', type: 'text' },
          { title: 'Betrag', type: 'euro' },
        ],
        rows: [
          ['2026-11-19', 'Bäcker & Söhne <Ulm>', -12.5],
          ['2026-11-20', null, 2450],
        ],
      },
      {
        name: 'Kredite/Übersicht',
        columns: [{ title: 'Kredit', type: 'text' }],
        rows: [['Hauskredit']],
      },
    ]);
    const sheets = await readXlsx(bytes, async (d) => new Uint8Array(inflateRawSync(d)));
    expect(sheets.map((s) => s.name)).toEqual(['Buchungen', 'Kredite Übersicht']);
    const rows = sheets[0].rows.map((r) =>
      r.map((c) => (c === null || c === undefined ? null : String(c))),
    );
    expect(rows[0]).toEqual(['Datum', 'Text', 'Betrag']);
    expect(rows[1].slice(1)).toEqual(['Bäcker & Söhne <Ulm>', '-12.5']);
    expect(rows[1][0]).toBe(String((Date.UTC(2026, 10, 19) - Date.UTC(1899, 11, 30)) / 86400000));
    expect(rows[2][2]).toBe('2450');
  });
  it('mehrere CSV-Dateien als ZIP', async () => {
    const z = await zip([
      { name: 'a.csv', data: 'x;y' },
      { name: 'b.csv', data: 'z' },
    ]);
    expect(z.length).toBeGreaterThan(40);
    expect([z[0], z[1], z[2], z[3]]).toEqual([0x50, 0x4b, 0x03, 0x04]);
  });
});
