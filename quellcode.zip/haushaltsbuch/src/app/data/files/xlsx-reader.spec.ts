import { readFileSync } from 'node:fs';
import { inflateRawSync } from 'node:zlib';
import { describe, expect, it } from 'vitest';
import { parseLegacyWorkbook } from '../../domain/import/legacy';
import { XlsxError, readXlsx } from './xlsx-reader';

const inflate = async (d: Uint8Array<ArrayBuffer>) => new Uint8Array(inflateRawSync(d));
const file = () => new Uint8Array(readFileSync('test-data/altdaten-beispiel.xlsx'));

describe('XLSX-Leser', () => {
  it('liest Blätter, Text, Zahlen und Datumszellen aus einer echten XLSX-Datei', async () => {
    const sheets = await readXlsx(file(), inflate);
    expect(sheets.map((s) => s.name)).toEqual(['Ausgaben', 'Einnahmen', 'Überweisungen']);
    expect(sheets[0].rows[1]).toEqual([
      'Datum',
      'Kategorie',
      'Konto',
      'Betrag',
      'Währung',
      'Betrag (Konto)',
      'Wechselkurs',
      'Konto-Währung',
      'Kommentar',
    ]);
    expect(sheets[0].rows[2].slice(1, 5)).toEqual(['Versicherung', 'Girokonto', 29.59, 'EUR']);
    expect(typeof sheets[0].rows[2][0]).toBe('number');
    expect(sheets[0].rows[4][0]).toBe('08/15/2026');
  });

  it('ergibt mit dem Altdaten-Leser die erwarteten Buchungen', async () => {
    const p = parseLegacyWorkbook(await readXlsx(file(), inflate));
    expect(p.sheets.map((s) => s.count)).toEqual([7, 2, 2]);
    expect(p.problems).toEqual([
      { sheet: 'Ausgaben', row: 10, reason: 'Betrag fehlt oder ist unlesbar' },
    ]);
    expect(p.rows.find((r) => r.comment === 'Grundsteuer')).toMatchObject({
      date: '2026-08-15',
      amount: 12000,
      category: 'Nebenkosten',
    });
    expect(p.rows.find((r) => r.comment === 'AGILA Hundeversicherung')?.date).toBe('2026-09-13');
    expect(
      p.rows.filter((r) => r.kind === 'umbuchung').map((r) => [r.category, r.account, r.amount]),
    ).toEqual([
      ['Girokonto', 'Sondertilg 1250', 15000],
      ['Sondertilg 1250', 'Girokonto', 100000],
    ]);
  });

  it('meldet Dateien, die keine XLSX sind', async () => {
    await expect(
      readXlsx(new TextEncoder().encode('Datum;Betrag\n'), inflate),
    ).rejects.toBeInstanceOf(XlsxError);
  });
});
