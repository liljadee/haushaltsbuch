import { Injectable, inject } from '@angular/core';
import { ExportKind, ExportOptions, Table, buildExport, toCsv } from '../domain/export/export';
import { todayLocal } from '../domain/shared/local-date';
import { computeStats } from '../domain/stats/statistics';
import { writeXlsx } from './files/xlsx-writer';
import { zip } from './files/zip-writer';
import { LoansService } from './loans.service';
import { AccountsStore } from './stores/accounts.store';
import { BookingsStore } from './stores/bookings.store';
import { CategoriesStore } from './stores/categories.store';
import { PrefsStore } from './stores/prefs.store';

/** Export als XLSX oder CSV (Lastenheft 12, 18.9): baut die Tabellen und liefert die fertige Datei. */
@Injectable({ providedIn: 'root' })
export class ExportService {
  private readonly accounts = inject(AccountsStore);
  private readonly bookings = inject(BookingsStore);
  private readonly cats = inject(CategoriesStore);
  private readonly prefs = inject(PrefsStore);
  private readonly loans = inject(LoansService);

  tables(kind: ExportKind, opts: ExportOptions): Table[] {
    const st = this.prefs.statSettings();
    const bookings = this.bookings.bookings(),
      accounts = this.accounts.accounts(),
      cats = this.cats.categories();
    return buildExport(
      kind,
      {
        accounts,
        bookings,
        cats,
        loans: this.loans.views().map((v) => ({ loan: v.loan, state: v.state })),
        stats: (months) =>
          computeStats(
            bookings,
            accounts,
            cats,
            months,
            null,
            st.loanLabels,
            st.groups,
            st.pillars ?? {},
            this.loans.splits(),
          ),
        today: todayLocal(),
      },
      opts,
    );
  }

  async file(kind: ExportKind, opts: ExportOptions, format: 'xlsx' | 'csv'): Promise<File> {
    const tables = this.tables(kind, opts);
    const base = `haushaltsbuch-${kind}-${todayLocal()}`;
    if (format === 'xlsx')
      return new File([(await writeXlsx(tables)) as Uint8Array<ArrayBuffer>], `${base}.xlsx`, {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      });
    if (tables.length === 1)
      return new File([toCsv(tables[0])], `${base}.csv`, { type: 'text/csv;charset=utf-8' });
    const files = tables.map((t) => ({
      name: `${t.name.replace(/[^\p{L}\p{N} -]/gu, ' ').trim()}.csv`,
      data: toCsv(t),
    }));
    return new File([(await zip(files)) as Uint8Array<ArrayBuffer>], `${base}.zip`, {
      type: 'application/zip',
    });
  }
}
