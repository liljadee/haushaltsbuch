import { fromBase64, toBase64 } from '../../domain/shared/base64';
import {
  INFO_RECOVERY,
  PBKDF2_ITERATIONS,
  passwordKek,
  recoveryKek,
  unwrapDataKey,
} from '../crypto/key-derivation';
import { gunzip, gzip } from '../crypto/record-crypto';

/**
 * Backup-Datei .hhb (Bauplan 5.4, docs/backup-format.md): JSON mit unverschlüsseltem Kopf
 * und verschlüsseltem Inhalt. Der Backup-Schlüssel ist der Datenschlüssel; im Kopf liegt er
 * mit dem Wiederherstellungsschlüssel verpackt, optional zusätzlich mit dem App-Passwort.
 */
export const BACKUP_FORMAT = 'haushaltsbuch-backup';
export const BACKUP_VERSION = 1;
const AAD = `${BACKUP_FORMAT}|${BACKUP_VERSION}`;

export interface BackupContent {
  stores: Record<string, { key: string; value: unknown }[]>;
}

export interface BackupFile {
  format: typeof BACKUP_FORMAT;
  formatVersion: number;
  appVersion: string;
  createdAt: string;
  keys: {
    recovery: {
      kdf: 'HKDF-SHA-256';
      info: string;
      salt: string;
      wrap: 'AES-KW';
      wrappedKey: string;
    };
    password?: {
      kdf: 'PBKDF2-HMAC-SHA-256';
      iterations: number;
      salt: string;
      wrap: 'AES-KW';
      wrappedKey: string;
    };
  };
  payload: {
    cipher: 'AES-256-GCM';
    compression: 'gzip';
    encoding: 'base64';
    aad: string;
    iv: string;
    data: string;
  };
}

export interface WrappedCopies {
  recovery: { salt: string; wrappedKey: string };
  password?: { salt: string; iterations: number; wrappedKey: string };
}

export async function createBackup(
  dataKey: CryptoKey,
  wrapped: WrappedCopies,
  content: BackupContent,
  appVersion: string,
  now = new Date(),
): Promise<BackupFile> {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const packed = await gzip(new TextEncoder().encode(JSON.stringify(content)));
  const ct = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv, additionalData: new TextEncoder().encode(AAD) },
    dataKey,
    packed,
  );
  return {
    format: BACKUP_FORMAT,
    formatVersion: BACKUP_VERSION,
    appVersion,
    createdAt: now.toISOString(),
    keys: {
      recovery: {
        kdf: 'HKDF-SHA-256',
        info: INFO_RECOVERY,
        salt: wrapped.recovery.salt,
        wrap: 'AES-KW',
        wrappedKey: wrapped.recovery.wrappedKey,
      },
      ...(wrapped.password
        ? {
            password: {
              kdf: 'PBKDF2-HMAC-SHA-256' as const,
              iterations: wrapped.password.iterations,
              salt: wrapped.password.salt,
              wrap: 'AES-KW' as const,
              wrappedKey: wrapped.password.wrappedKey,
            },
          }
        : {}),
    },
    payload: {
      cipher: 'AES-256-GCM',
      compression: 'gzip',
      encoding: 'base64',
      aad: AAD,
      iv: toBase64(iv),
      data: toBase64(ct),
    },
  };
}

export class BackupError extends Error {}

/** Prüft die Datei auf das erwartete Format, ohne zu entschlüsseln. */
export function parseBackupFile(text: string): BackupFile {
  let j: BackupFile;
  try {
    j = JSON.parse(text) as BackupFile;
  } catch {
    throw new BackupError('Die Datei ist kein Haushaltsbuch-Backup (kein gültiges JSON).');
  }
  if (j?.format !== BACKUP_FORMAT)
    throw new BackupError('Die Datei ist kein Haushaltsbuch-Backup.');
  if (j.formatVersion > BACKUP_VERSION)
    throw new BackupError(
      'Das Backup stammt aus einer neueren App-Version. Bitte zuerst die App aktualisieren.',
    );
  if (!j.keys?.recovery?.wrappedKey || !j.payload?.data)
    throw new BackupError('Das Backup ist unvollständig.');
  return j;
}

/** Datenschlüssel aus dem Kopf holen, mit Wiederherstellungsschlüssel oder Passwort. */
export async function unlockBackup(
  file: BackupFile,
  secret: { recoveryKey: string } | { password: string },
  extractable = true,
): Promise<CryptoKey> {
  try {
    if ('recoveryKey' in secret) {
      const kek = await recoveryKek(secret.recoveryKey, fromBase64(file.keys.recovery.salt));
      return await unwrapDataKey(fromBase64(file.keys.recovery.wrappedKey), kek, extractable);
    }
    const p = file.keys.password;
    if (!p) throw new BackupError('Dieses Backup hat kein Passwort.');
    const kek = await passwordKek(
      secret.password,
      fromBase64(p.salt),
      p.iterations ?? PBKDF2_ITERATIONS,
    );
    return await unwrapDataKey(fromBase64(p.wrappedKey), kek, extractable);
  } catch (e) {
    if (e instanceof BackupError) throw e;
    throw new BackupError(
      'recoveryKey' in secret
        ? 'Der Wiederherstellungsschlüssel passt nicht zu diesem Backup.'
        : 'Das Passwort passt nicht zu diesem Backup.',
    );
  }
}

export async function readBackupContent(
  file: BackupFile,
  dataKey: CryptoKey,
): Promise<BackupContent> {
  try {
    const pt = await crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv: fromBase64(file.payload.iv),
        additionalData: new TextEncoder().encode(file.payload.aad),
      },
      dataKey,
      fromBase64(file.payload.data),
    );
    return JSON.parse(new TextDecoder().decode(await gunzip(new Uint8Array(pt)))) as BackupContent;
  } catch {
    throw new BackupError('Das Backup ist beschädigt oder wurde verändert.');
  }
}
