import { IDBPDatabase, openDB } from 'idb';
import { EncryptedRecord } from '../crypto/record-crypto';

/** IndexedDB (Bauplan 5.1). meta ist unverschlüsselt, alle anderen Speicher enthalten nur EncryptedRecord. */
export const DB_NAME = 'haushaltsbuch';
export const DB_VERSION = 5;
/** v0.2: Konten, Buchungen (ein Datensatz je Monat), Kategorien, Regeln, Einstellungen; v0.5: wiederkehrende Zahlungen; v0.6: Spartöpfe; v0.7: Kredite. */
export const DATA_STORES = [
  'accounts',
  'bookings',
  'categories',
  'rules',
  'settings',
  'recurring',
  'pots',
  'loans',
] as const;
export type DataStore = (typeof DATA_STORES)[number];

export interface VaultMeta {
  format: 'haushaltsbuch-vault';
  formatVersion: 1;
  createdAt: string;
  appVersion: string;
  passkey?: {
    credentialId: string;
    prfSalt: string;
    hkdfSalt: string;
    wrappedKey: string;
    createdAt: string;
  };
  recovery: { salt: string; wrappedKey: string };
  password?: { salt: string; iterations: number; wrappedKey: string };
}

let dbPromise: Promise<IDBPDatabase> | null = null;

export function db(): Promise<IDBPDatabase> {
  dbPromise ??= openDB(DB_NAME, DB_VERSION, {
    upgrade(d, oldVersion) {
      if (!d.objectStoreNames.contains('meta')) d.createObjectStore('meta');
      for (const s of DATA_STORES)
        if (!d.objectStoreNames.contains(s)) d.createObjectStore(s, { keyPath: 'key' });
      // Umzug v0.1 → v0.2: Schlüssel und Einrichtung bleiben, die Testbuchungen entfallen.
      if (oldVersion < 2 && d.objectStoreNames.contains('testdata'))
        d.deleteObjectStore('testdata');
    },
  });
  return dbPromise;
}

export async function getMeta(): Promise<VaultMeta | undefined> {
  return (await db()).get('meta', 'vault') as Promise<VaultMeta | undefined>;
}

/** Sicherungsdatei (v0.6.5): Dateihandle und Zustand, unverschlüsselt (enthält nur den Dateinamen, keine Daten) */
export interface MirrorMeta {
  handle: unknown;
  fileName: string;
  lastWrite: string | null;
  permissionKept: boolean | null;
  /** seit wann es Änderungen gibt, die noch nicht in der Datei stehen */
  dirtySince?: string | null;
}

export async function getMirror(): Promise<MirrorMeta | undefined> {
  return (await db()).get('meta', 'sicherungsdatei') as Promise<MirrorMeta | undefined>;
}

export async function putMirror(m: MirrorMeta): Promise<void> {
  await (await db()).put('meta', m, 'sicherungsdatei');
}

export async function deleteMirror(): Promise<void> {
  await (await db()).delete('meta', 'sicherungsdatei');
}

export async function putMeta(meta: VaultMeta): Promise<void> {
  await (await db()).put('meta', meta, 'vault');
}

/** Schreibt meta und Datensätze in einer Transaktion: entweder alles oder nichts. */
export async function writeAll(
  meta: VaultMeta,
  records: { store: DataStore; rec: EncryptedRecord }[],
  clear = false,
): Promise<void> {
  const d = await db();
  const tx = d.transaction(['meta', ...DATA_STORES], 'readwrite');
  if (clear) for (const s of DATA_STORES) await tx.objectStore(s).clear();
  await tx.objectStore('meta').put(meta, 'vault');
  for (const { store, rec } of records) await tx.objectStore(store).put(rec);
  await tx.done;
}

export async function putRecord(store: DataStore, rec: EncryptedRecord): Promise<void> {
  await (await db()).put(store, rec);
}

export async function deleteRecord(store: DataStore, key: string): Promise<void> {
  await (await db()).delete(store, key);
}

export async function getRecord(
  store: DataStore,
  key: string,
): Promise<EncryptedRecord | undefined> {
  return (await db()).get(store, key) as Promise<EncryptedRecord | undefined>;
}

export async function getAllRecords(store: DataStore): Promise<EncryptedRecord[]> {
  return (await db()).getAll(store) as Promise<EncryptedRecord[]>;
}

/** Löscht die gesamte Datenbank dieses Geräts. */
export async function deleteEverything(): Promise<void> {
  if (dbPromise) (await dbPromise).close();
  dbPromise = null;
  await new Promise<void>((resolve, reject) => {
    const r = indexedDB.deleteDatabase(DB_NAME);
    r.onsuccess = () => resolve();
    r.onerror = () => reject(r.error);
    r.onblocked = () => resolve();
  });
}
