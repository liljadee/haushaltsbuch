import { Injectable, inject } from '@angular/core';
import { Booking } from '../../domain/bookings/booking';
import { assignCategory, isRegular, toTransfer } from '../../domain/bookings/batch';
import { normalizeText } from '../../domain/categories/rules';
import { AccountsStore } from '../stores/accounts.store';
import { BookingsStore } from '../stores/bookings.store';
import { RulesStore } from '../stores/rules.store';
import { PrefsStore } from '../stores/prefs.store';
import { BIG_CHANGE } from './email-import.service';
import { nextSeq } from '../stores/seq';

/** Stapelverarbeitung in der Buchungsliste: gemeinsame Kategorie, Umbuchung, Löschen. */
@Injectable({ providedIn: 'root' })
export class BatchService {
  private readonly bookings = inject(BookingsStore);
  private readonly accounts = inject(AccountsStore);
  private readonly rules = inject(RulesStore);
  private readonly prefs = inject(PrefsStore);

  private async big(n: number): Promise<void> {
    if (n >= BIG_CHANGE) await this.prefs.markBigChange();
  }

  async assign(ids: string[], categoryId: string, subCategory: string | null): Promise<number> {
    const changed = assignCategory(
      this.bookings.bookings().filter((b) => ids.includes(b.id)),
      categoryId,
      subCategory,
    );
    await this.bookings.applyBatch(changed, []);
    await this.big(changed.length);
    // je unterschiedlichem Text eine Regel lernen
    const seen = new Set<string>();
    for (const b of changed) {
      const k = normalizeText(b.text);
      if (seen.has(k)) continue;
      seen.add(k);
      await this.rules.learnFrom(b.text, b.amount, categoryId, subCategory);
    }
    return changed.length;
  }

  async toTransfer(ids: string[], targetId: string): Promise<number> {
    const target = this.accounts.active().find((a) => a.id === targetId);
    if (!target) throw new Error('Bitte das Zielkonto wählen.');
    const changed: Booking[] = [],
      added: Booking[] = [];
    for (const b of this.bookings_().filter((x) => ids.includes(x.id) && isRegular(x))) {
      const own = this.accounts.accounts().find((a) => a.id === b.accountId);
      const pair = own
        ? toTransfer(
            b,
            own,
            target,
            { group: crypto.randomUUID(), counterpart: crypto.randomUUID() },
            nextSeq(),
          )
        : null;
      if (!pair) continue;
      changed.push(pair[0]);
      added.push(pair[1]);
    }
    await this.bookings.applyBatch(changed, added);
    await this.big(changed.length);
    return changed.length;
  }

  async remove(ids: string[]): Promise<number> {
    const all = this.bookings.bookings();
    const groups = new Set(
      all.filter((b) => ids.includes(b.id) && b.transferGroupId).map((b) => b.transferGroupId),
    );
    const gone = all
      .filter((b) => ids.includes(b.id) || (b.transferGroupId && groups.has(b.transferGroupId)))
      .map((b) => b.id);
    await this.bookings.applyBatch([], [], gone);
    await this.big(ids.length);
    return ids.length;
  }

  private bookings_() {
    return this.bookings.bookings();
  }
}
