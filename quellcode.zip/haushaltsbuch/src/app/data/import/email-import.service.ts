import { Injectable, inject } from '@angular/core';
import { Booking } from '../../domain/bookings/booking';
import { createTransfer } from '../../domain/bookings/transfer';
import { ImportPreview } from '../../domain/import/import-preview';
import { LocalDate } from '../../domain/shared/local-date';
import { AccountsStore } from '../stores/accounts.store';
import { BookingsStore } from '../stores/bookings.store';
import { RulesStore } from '../stores/rules.store';
import { nextSeq } from '../stores/seq';

export interface ImportRow {
  text: string;
  amount: number;
  categoryId: string | null;
  subCategory: string | null;
  include: boolean;
  confirmed: boolean;
  /** Umbuchung auf dieses eigene Konto statt normaler Buchung */
  transferTo: string | null;
  /** gehört zu dieser bestätigten Umbuchung (16.7) */
  confirmedOf?: string | null;
}

/** Übernimmt eine geprüfte Importvorschau: Buchungen, Stand laut Bank, gelernte Regeln (Lastenheft 8.1, 8.2). */
@Injectable({ providedIn: 'root' })
export class EmailImportService {
  private readonly bookings = inject(BookingsStore);
  private readonly accounts = inject(AccountsStore);
  private readonly rules = inject(RulesStore);

  /** Prüfwert der E-Mail: erkennt dieselbe E-Mail beim zweiten Einfügen (SHA-256 über den bereinigten Text). */
  async fingerprint(mail: string): Promise<string> {
    const norm = mail
      .replace(/\r\n?/g, '\n')
      .split('\n')
      .map((l) => l.trim().replace(/\s+/g, ' '))
      .filter(Boolean)
      .join('\n')
      .toLowerCase();
    const hash = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(norm));
    return [...new Uint8Array(hash)].map((b) => b.toString(16).padStart(2, '0')).join('');
  }

  async commit(
    preview: ImportPreview,
    rows: ImportRow[],
    date: LocalDate,
    newBalance: number | null,
    fingerprint: string,
  ): Promise<number> {
    const account = preview.account;
    if (!account) throw new Error('Bitte ein Konto wählen.');
    const items: Booking[] = [];
    const changed: Booking[] = [];
    for (const r of rows.filter((x) => x.include)) {
      if (r.confirmedOf) {
        // bestätigte Umbuchung: beide Seiten auf „gebucht“, diese Seite mit Text und Datum der E-Mail
        const own = this.bookings.bookings().find((b) => b.id === r.confirmedOf);
        if (own) {
          changed.push({
            ...own,
            status: 'gebucht',
            text: r.text,
            date,
            source: { type: 'email', fingerprint },
          });
          const other = this.bookings
            .bookings()
            .find(
              (b) =>
                b.transferGroupId && b.transferGroupId === own.transferGroupId && b.id !== own.id,
            );
          if (other) changed.push({ ...other, status: 'gebucht' });
        }
        continue;
      }
      const target = r.transferTo
        ? this.accounts.active().find((a) => a.id === r.transferTo)
        : null;
      if (target) {
        // Umbuchung: eigene Seite aus der E-Mail, Gegenseite auf dem anderen eigenen Konto
        const [from, to] = r.amount < 0 ? [account, target] : [target, account];
        const pair = createTransfer(
          from,
          to,
          Math.abs(r.amount),
          date,
          '',
          { group: crypto.randomUUID(), a: crypto.randomUUID(), b: crypto.randomUUID() },
          [nextSeq(), nextSeq()],
        );
        for (const p of pair)
          items.push(
            p.accountId === account.id
              ? { ...p, text: r.text, source: { type: 'email', fingerprint } }
              : p,
          );
        continue;
      }
      items.push({
        id: crypto.randomUUID(),
        accountId: account.id,
        kind: r.amount < 0 ? 'ausgabe' : 'einnahme',
        status: 'gebucht',
        amount: r.amount,
        date,
        seq: nextSeq(),
        text: r.text,
        splits: r.categoryId
          ? [{ categoryId: r.categoryId, subCategory: r.subCategory, amount: r.amount }]
          : [],
        confidence: !r.categoryId ? 'nicht_zugeordnet' : r.confirmed ? 'sicher' : 'unsicher',
        source: { type: 'email', fingerprint },
      });
    }
    if (items.length || changed.length) await this.bookings.applyBatch(changed, items);
    // „Neuer Saldo“ als Stand laut Bank, nach den Buchungen dieser E-Mail einsortiert
    if (newBalance !== null) await this.accounts.addSnapshot(account.id, date, newBalance, 'email');
    for (const r of rows.filter((x) => x.include && !x.transferTo && x.categoryId && x.confirmed))
      await this.rules.learnFrom(r.text, r.amount, r.categoryId, r.subCategory);
    return rows.filter((x) => x.include).length;
  }
}
