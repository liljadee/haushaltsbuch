import { Injectable, inject } from '@angular/core';
import { Booking } from '../../domain/bookings/booking';
import { createTransfer } from '../../domain/bookings/transfer';
import { LegacyPlan } from '../../domain/import/legacy';
import { AccountsStore } from '../stores/accounts.store';
import { BookingsStore } from '../stores/bookings.store';
import { nextSeq } from '../stores/seq';

/** Übernimmt den geprüften Plan des Altdaten-Imports in einem Schritt. */
@Injectable({ providedIn: 'root' })
export class LegacyImportService {
  private readonly bookings = inject(BookingsStore);
  private readonly accounts = inject(AccountsStore);

  async fingerprint(buf: ArrayBuffer): Promise<string> {
    const h = await crypto.subtle.digest('SHA-256', buf);
    return 'xlsx:' + [...new Uint8Array(h)].map((b) => b.toString(16).padStart(2, '0')).join('');
  }

  async commit(plan: LegacyPlan, fingerprint: string): Promise<number> {
    const acc = (id: string | null) => this.accounts.active().find((a) => a.id === id);
    const source = { type: 'xlsx' as const, fingerprint };
    const items: Booking[] = [];
    for (const r of plan.rows.filter((x) => x.include)) {
      const s = r.src;
      if (s.kind === 'umbuchung') {
        const from = acc(r.fromAccountId),
          to = acc(r.accountId);
        if (!from || !to) continue;
        items.push(
          ...createTransfer(
            from,
            to,
            s.amount,
            s.date,
            s.comment,
            { group: crypto.randomUUID(), a: crypto.randomUUID(), b: crypto.randomUUID() },
            [nextSeq(), nextSeq()],
            source,
          ),
        );
        continue;
      }
      const amount = s.kind === 'ausgabe' ? -s.amount : s.amount;
      items.push({
        id: crypto.randomUUID(),
        accountId: r.accountId!,
        kind: s.kind,
        status: 'gebucht',
        amount,
        date: s.date,
        seq: nextSeq(),
        text: s.comment || s.category,
        splits: r.categoryId
          ? [{ categoryId: r.categoryId, subCategory: r.subCategory, amount }]
          : [],
        confidence: r.categoryId ? 'sicher' : 'nicht_zugeordnet',
        source,
        note: `Aus der alten App: ${s.category}`,
      });
    }
    if (items.length) await this.bookings.add(items);
    return plan.rows.filter((x) => x.include).length;
  }
}
