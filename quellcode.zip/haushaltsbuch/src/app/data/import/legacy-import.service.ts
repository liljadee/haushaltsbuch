import { Injectable, inject } from '@angular/core';
import { Booking } from '../../domain/bookings/booking';
import { createTransfer } from '../../domain/bookings/transfer';
import { LegacyPlan } from '../../domain/import/legacy';
import { AccountsStore } from '../stores/accounts.store';
import { BookingsStore } from '../stores/bookings.store';
import { nextSeq } from '../stores/seq';

/** Übernimmt den geprüften Plan des Altdaten-Imports in einem Schritt. */
@Injectable({ providedIn: 'root' })
export class LegacyImportService {
  private readonly bookings = inject(BookingsStore);
  private readonly accounts = inject(AccountsStore);

  async fingerprint(buf: ArrayBuffer): Promise<string> {
    const h = await crypto.subtle.digest('SHA-256', buf);
    return 'xlsx:' + [...new Uint8Array(h)].map((b) => b.toString(16).padStart(2, '0')).join('');
  }

  async commit(plan: LegacyPlan, fingerprint: string, replaceLegacy = false): Promise<number> {
    const acc = (id: string | null) => this.accounts.active().find((a) => a.id === id);
    const source = { type: 'xlsx' as const, fingerprint };
    const items: Booking[] = [];
    for (const r of plan.rows.filter((x) => x.include)) {
      const s = r.src;
      if (s.kind === 'umbuchung') {
        const from = acc(r.fromAccountId),
          to = acc(r.accountId);
        if (!from || !to) continue;
        items.push(
          ...createTransfer(
            from,
            to,
            s.amount,
            s.date,
            s.comment,
            { group: crypto.randomUUID(), a: crypto.randomUUID(), b: crypto.randomUUID() },
            [nextSeq(), nextSeq()],
            source,
          ),
        );
        continue;
      }
      const amount = s.kind === 'ausgabe' ? -s.amount : s.amount;
      if (r.transferTo) {
        // „Sparen“ o. Ä.: Ausgabe wird Umbuchung aufs eigene Konto, Einnahme Umbuchung von dort
        const own = acc(r.accountId),
          target = acc(r.transferTo);
        if (!own || !target) continue;
        const [from, to] = amount < 0 ? [own, target] : [target, own];
        items.push(
          ...createTransfer(
            from,
            to,
            s.amount,
            s.date,
            s.comment || s.category,
            { group: crypto.randomUUID(), a: crypto.randomUUID(), b: crypto.randomUUID() },
            [nextSeq(), nextSeq()],
            source,
          ),
        );
        continue;
      }
      items.push({
        id: crypto.randomUUID(),
        accountId: r.accountId!,
        kind: s.kind,
        status: 'gebucht',
        amount,
        date: s.date,
        seq: nextSeq(),
        text: s.comment || s.category,
        splits: r.categoryId
          ? [{ categoryId: r.categoryId, subCategory: r.subCategory, amount }]
          : [],
        confidence: r.categoryId ? 'sicher' : 'nicht_zugeordnet',
        source,
        note: `Aus der alten App: ${s.category}`,
      });
    }
    const removed = replaceLegacy
      ? this.bookings
          .bookings()
          .filter((b) => b.source.type === 'xlsx')
          .map((b) => b.id)
      : [];
    if (items.length || removed.length) await this.bookings.applyBatch([], items, removed);
    return plan.rows.filter((x) => x.include).length;
  }
}
