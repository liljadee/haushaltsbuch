import { Injectable, inject, signal } from '@angular/core';
import { fromBase64, toBase64, toBase64Url, fromBase64Url } from '../domain/shared/base64';
import { generateRecoveryKey } from '../domain/shared/recovery-key';
import {
  BackupContent,
  BackupFile,
  createBackup,
  readBackupContent,
  unlockBackup,
} from './backup/backup-format';
import {
  MIN_PASSWORD_LENGTH,
  PBKDF2_ITERATIONS,
  generateDataKey,
  passkeyKek,
  passwordKek,
  randomBytes,
  recoveryKek,
  unwrapDataKey,
  wrapDataKey,
} from './crypto/key-derivation';
import { PasskeyError, PasskeyService } from './crypto/passkey.service';
import { EncryptedRecord, decryptRecord, encryptRecord } from './crypto/record-crypto';
import {
  DATA_STORES,
  DataStore,
  VaultMeta,
  deleteEverything,
  deleteRecord,
  getAllRecords,
  getMeta,
  getRecord,
  putMeta,
  putRecord,
  writeAll,
} from './storage/db';

export const APP_VERSION = '0.3.0';
export type VaultStatus = 'laden' | 'neu' | 'gesperrt' | 'entsperrt';

/** Laufende Einrichtung: hält den extrahierbaren Datenschlüssel nur bis zum Abschluss. */
export interface SetupSession {
  dataKey: CryptoKey;
  recoveryKey: string | null; // bei Wiederherstellung der eingegebene Schlüssel
  recovery?: VaultMeta['recovery']; // aus dem Backup übernommen
  passwordFromBackup?: VaultMeta['password'];
  passkey?: VaultMeta['passkey'];
  passkeyProblem?: string;
  content?: BackupContent;
}

/**
 * Tresor (Bauplan 5): verwaltet meta, den Datenschlüssel im Arbeitsspeicher und alle
 * verschlüsselten Datensätze. Die Oberfläche spricht nie direkt mit IndexedDB oder Web Crypto.
 */
@Injectable({ providedIn: 'root' })
export class VaultService {
  readonly status = signal<VaultStatus>('laden');
  readonly meta = signal<VaultMeta | null>(null);
  readonly unlockedWith = signal<'passkey' | 'passwort' | 'wiederherstellung' | null>(null);
  private dataKey: CryptoKey | null = null;
  private readonly passkeys = inject(PasskeyService);
  readonly ready: Promise<void> = this.load();

  private async load(): Promise<void> {
    const m = (await getMeta()) ?? null;
    this.meta.set(m);
    this.status.set(m ? 'gesperrt' : 'neu');
  }

  // ---------- Einrichtung ----------
  async startSetup(): Promise<SetupSession> {
    return { dataKey: await generateDataKey(), recoveryKey: generateRecoveryKey(randomBytes) };
  }

  /** Aus einem Backup: Datenschlüssel und Wiederherstellungsdaten stammen aus der Datei. */
  async startRestore(file: BackupFile, recoveryKey: string): Promise<SetupSession> {
    const dataKey = await unlockBackup(file, { recoveryKey }, true);
    const content = await readBackupContent(file, dataKey);
    return {
      dataKey,
      recoveryKey,
      content,
      recovery: { salt: file.keys.recovery.salt, wrappedKey: file.keys.recovery.wrappedKey },
      passwordFromBackup: file.keys.password
        ? {
            salt: file.keys.password.salt,
            iterations: file.keys.password.iterations,
            wrappedKey: file.keys.password.wrappedKey,
          }
        : undefined,
    };
  }

  /** Passkey anlegen und Datenschlüssel damit verpacken. Android fragt dafür ein- oder zweimal. */
  async addPasskey(session: SetupSession): Promise<void> {
    const prfSalt = randomBytes(32),
      hkdfSalt = randomBytes(16);
    const reg = await this.passkeys.register(prfSalt);
    let prf = reg.prf;
    if (!prf) {
      if (!reg.prfEnabled)
        throw new PasskeyError(
          'kein-prf',
          'Der Passkey wurde angelegt, kann aber keinen Schlüssel liefern (PRF fehlt).',
        );
      prf = await this.passkeys.evaluate(reg.credentialId, prfSalt);
    }
    session.passkey = {
      credentialId: toBase64Url(reg.credentialId),
      prfSalt: toBase64(prfSalt),
      hkdfSalt: toBase64(hkdfSalt),
      wrappedKey: toBase64(await wrapDataKey(session.dataKey, await passkeyKek(prf, hkdfSalt))),
      createdAt: new Date().toISOString(),
    };
  }

  async finishSetup(session: SetupSession, password: string | null): Promise<void> {
    let recovery = session.recovery;
    if (!recovery) {
      if (!session.recoveryKey) throw new Error('Wiederherstellungsschlüssel fehlt.');
      const salt = randomBytes(16);
      recovery = {
        salt: toBase64(salt),
        wrappedKey: toBase64(
          await wrapDataKey(session.dataKey, await recoveryKek(session.recoveryKey, salt)),
        ),
      };
    }
    const pw = password
      ? await this.wrapPassword(session.dataKey, password)
      : session.passwordFromBackup;
    if (!session.passkey && !pw) throw new Error('Ohne Fingerabdruck ist ein App-Passwort nötig.');
    const meta: VaultMeta = {
      format: 'haushaltsbuch-vault',
      formatVersion: 1,
      createdAt: new Date().toISOString(),
      appVersion: APP_VERSION,
      recovery,
      ...(session.passkey ? { passkey: session.passkey } : {}),
      ...(pw ? { password: pw } : {}),
    };
    const runtimeKey = await unwrapDataKey(
      fromBase64(recovery.wrappedKey),
      await this.recoveryKekFromSession(session, recovery),
      false,
    ).catch(() => session.dataKey);
    const records: { store: DataStore; rec: EncryptedRecord }[] = [];
    if (session.content) {
      for (const [store, items] of Object.entries(session.content.stores)) {
        if (!(DATA_STORES as readonly string[]).includes(store)) continue;
        for (const it of items)
          records.push({
            store: store as DataStore,
            rec: await encryptRecord(session.dataKey, store, it.key, it.value),
          });
      }
    }
    await writeAll(meta, records, true);
    try {
      await navigator.storage?.persist?.();
    } catch {
      /* nicht überall verfügbar */
    }
    this.meta.set(meta);
    this.dataKey = runtimeKey;
    session.recoveryKey = null;
    this.unlockedWith.set(session.passkey ? 'passkey' : 'passwort');
    this.status.set('entsperrt');
  }

  private async recoveryKekFromSession(
    session: SetupSession,
    recovery: VaultMeta['recovery'],
  ): Promise<CryptoKey> {
    if (!session.recoveryKey) throw new Error('kein Schlüssel');
    return recoveryKek(session.recoveryKey, fromBase64(recovery.salt));
  }

  private async wrapPassword(dataKey: CryptoKey, password: string): Promise<VaultMeta['password']> {
    if (password.length < MIN_PASSWORD_LENGTH)
      throw new Error(`Das App-Passwort braucht mindestens ${MIN_PASSWORD_LENGTH} Zeichen.`);
    const salt = randomBytes(16);
    return {
      salt: toBase64(salt),
      iterations: PBKDF2_ITERATIONS,
      wrappedKey: toBase64(await wrapDataKey(dataKey, await passwordKek(password, salt))),
    };
  }

  // ---------- Entsperren ----------
  async unlockWithPasskey(extractable = false): Promise<CryptoKey> {
    const m = this.requireMeta();
    if (!m.passkey)
      throw new PasskeyError(
        'nicht-verfuegbar',
        'Für dieses Gerät ist kein Fingerabdruck eingerichtet.',
      );
    const prf = await this.passkeys.evaluate(
      fromBase64Url(m.passkey.credentialId),
      fromBase64(m.passkey.prfSalt),
    );
    const key = await unwrapDataKey(
      fromBase64(m.passkey.wrappedKey),
      await passkeyKek(prf, fromBase64(m.passkey.hkdfSalt)),
      extractable,
    );
    if (!extractable) this.opened(key, 'passkey');
    return key;
  }

  async unlockWithPassword(password: string, extractable = false): Promise<CryptoKey> {
    const m = this.requireMeta();
    if (!m.password) throw new Error('Es ist kein App-Passwort eingerichtet.');
    let key: CryptoKey;
    try {
      key = await unwrapDataKey(
        fromBase64(m.password.wrappedKey),
        await passwordKek(password, fromBase64(m.password.salt), m.password.iterations),
        extractable,
      );
    } catch {
      throw new Error('Das App-Passwort stimmt nicht.');
    }
    if (!extractable) this.opened(key, 'passwort');
    return key;
  }

  /** Mit dem Wiederherstellungsschlüssel; liefert einen extrahierbaren Schlüssel für einen neuen Passkey. */
  async unlockWithRecovery(normalizedKey: string): Promise<CryptoKey> {
    const m = this.requireMeta();
    let key: CryptoKey;
    try {
      key = await unwrapDataKey(
        fromBase64(m.recovery.wrappedKey),
        await recoveryKek(normalizedKey, fromBase64(m.recovery.salt)),
        true,
      );
    } catch {
      throw new Error('Der Wiederherstellungsschlüssel passt nicht.');
    }
    this.opened(key, 'wiederherstellung');
    return key;
  }

  /** Neuen Fingerabdruck-Zugang einrichten (z. B. nach Wiederherstellung); die Daten bleiben unverändert. */
  async replacePasskey(extractableKey: CryptoKey): Promise<void> {
    const session: SetupSession = { dataKey: extractableKey, recoveryKey: null };
    await this.addPasskey(session);
    const meta = { ...this.requireMeta(), passkey: session.passkey };
    await putMeta(meta);
    this.meta.set(meta);
  }

  /** App-Passwort festlegen oder ändern; bestätigt wird mit Fingerabdruck oder bisherigem Passwort. */
  async setPassword(
    newPassword: string,
    confirm: { passkey: true } | { password: string },
  ): Promise<void> {
    const key =
      'passkey' in confirm
        ? await this.unlockWithPasskey(true)
        : await this.unlockWithPassword(confirm.password, true);
    const meta = { ...this.requireMeta(), password: await this.wrapPassword(key, newPassword) };
    await putMeta(meta);
    this.meta.set(meta);
  }

  private opened(key: CryptoKey, how: 'passkey' | 'passwort' | 'wiederherstellung'): void {
    this.dataKey = key;
    this.unlockedWith.set(how);
    this.status.set('entsperrt');
  }

  lock(): void {
    this.dataKey = null;
    this.unlockedWith.set(null);
    if (this.meta()) this.status.set('gesperrt');
  }

  // ---------- Datensätze ----------
  async read<T>(store: DataStore, key: string, fallback: T): Promise<T> {
    const rec = await getRecord(store, key);
    return rec ? decryptRecord<T>(this.requireKey(), store, rec) : fallback;
  }

  async readAll<T>(store: DataStore): Promise<T[]> {
    const key = this.requireKey();
    return Promise.all((await getAllRecords(store)).map((r) => decryptRecord<T>(key, store, r)));
  }

  async remove(store: DataStore, key: string): Promise<void> {
    this.requireKey();
    await deleteRecord(store, key);
  }

  async write(store: DataStore, key: string, value: unknown): Promise<void> {
    await putRecord(store, await encryptRecord(this.requireKey(), store, key, value));
  }

  // ---------- Backup ----------
  async createBackupFile(): Promise<{ name: string; text: string; entries: number }> {
    const key = this.requireKey(),
      m = this.requireMeta();
    const stores: BackupContent['stores'] = {};
    let entries = 0;
    for (const s of DATA_STORES) {
      stores[s] = await Promise.all(
        (await getAllRecords(s)).map(async (r) => ({
          key: r.key,
          value: await decryptRecord<unknown>(key, s, r),
        })),
      );
      entries += stores[s].length;
    }
    const file = await createBackup(
      key,
      { recovery: m.recovery, password: m.password },
      { stores },
      APP_VERSION,
    );
    const d = new Date();
    const stamp = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    return {
      name: `haushaltsbuch-backup-${stamp}.hhb`,
      text: JSON.stringify(file, null, 1),
      entries,
    };
  }

  async deleteEverything(): Promise<void> {
    this.lock();
    await deleteEverything();
    this.meta.set(null);
    this.status.set('neu');
  }

  private requireMeta(): VaultMeta {
    const m = this.meta();
    if (!m) throw new Error('Die App ist noch nicht eingerichtet.');
    return m;
  }

  private requireKey(): CryptoKey {
    if (!this.dataKey) throw new Error('Die App ist gesperrt.');
    return this.dataKey;
  }
}
