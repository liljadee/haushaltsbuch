import { Injectable, inject, signal } from '@angular/core';
import { Category, DEFAULT_CATEGORIES } from '../../domain/categories/categories';
import { VaultService } from '../vault.service';

/** Kategorien (Lastenheft 9): beim ersten Start mit dem abgestimmten Bestand gefüllt. */
@Injectable({ providedIn: 'root' })
export class CategoriesStore {
  private readonly vault = inject(VaultService);
  readonly categories = signal<Category[]>([]);

  async load(): Promise<void> {
    let list = await this.vault.readAll<Category>('categories');
    if (!list.length) {
      for (const c of DEFAULT_CATEGORIES) await this.vault.write('categories', c.id, c);
      list = DEFAULT_CATEGORIES;
    }
    this.categories.set(list);
  }

  clear(): void {
    this.categories.set([]);
  }
}
