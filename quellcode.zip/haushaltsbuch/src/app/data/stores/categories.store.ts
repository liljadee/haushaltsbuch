import { Injectable, inject, signal } from '@angular/core';
import { Category, DEFAULT_CATEGORIES } from '../../domain/categories/categories';
import { VaultService } from '../vault.service';

/** Kategorien (Lastenheft 9): beim ersten Start mit dem abgestimmten Bestand gefüllt. */
@Injectable({ providedIn: 'root' })
export class CategoriesStore {
  private readonly vault = inject(VaultService);
  readonly categories = signal<Category[]>([]);

  async load(): Promise<void> {
    const list = await this.vault.readAll<Category>('categories');
    // neue Standardkategorien (z. B. „Sparen“) auch in bestehenden Installationen ergänzen
    const missing = DEFAULT_CATEGORIES.filter((d) => !list.some((c) => c.id === d.id));
    for (const c of missing) await this.vault.write('categories', c.id, c);
    this.categories.set([...list, ...missing]);
  }

  clear(): void {
    this.categories.set([]);
  }
}
