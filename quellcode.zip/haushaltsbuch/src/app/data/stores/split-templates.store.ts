import { Injectable, inject, signal } from '@angular/core';
import { SplitTemplate } from '../../domain/bookings/split-templates';
import { VaultService } from '../vault.service';

/** Aufteilungsvorlagen für Sammelabbuchungen; liegen in den Einstellungen (und damit im Backup). */
@Injectable({ providedIn: 'root' })
export class SplitTemplatesStore {
  private readonly vault = inject(VaultService);
  readonly templates = signal<SplitTemplate[]>([]);

  async load(): Promise<void> {
    this.templates.set(
      await this.vault.read<SplitTemplate[]>('settings', 'aufteilungsvorlagen', []),
    );
  }

  clear(): void {
    this.templates.set([]);
  }

  async save(t: SplitTemplate): Promise<void> {
    const next = [...this.templates().filter((x) => x.id !== t.id), t];
    await this.vault.write('settings', 'aufteilungsvorlagen', next);
    this.templates.set(next);
  }

  async remove(id: string): Promise<void> {
    const next = this.templates().filter((x) => x.id !== id);
    await this.vault.write('settings', 'aufteilungsvorlagen', next);
    this.templates.set(next);
  }
}
