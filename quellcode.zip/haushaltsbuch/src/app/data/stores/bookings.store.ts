import { todayLocal } from '../../domain/shared/local-date';
import { Injectable, inject, signal } from '@angular/core';
import { Booking, stampImported } from '../../domain/bookings/booking';
import { monthOf } from '../../domain/shared/local-date';
import { VaultService } from '../vault.service';

/** Buchungen (Bauplan 5.1): ein verschlüsselter Datensatz je Buchungsmonat (Schlüssel JJJJ-MM). */
@Injectable({ providedIn: 'root' })
export class BookingsStore {
  private readonly vault = inject(VaultService);
  readonly bookings = signal<Booking[]>([]);

  async load(): Promise<void> {
    this.bookings.set((await this.vault.readAll<Booking[]>('bookings')).flat());
  }

  clear(): void {
    this.bookings.set([]);
  }

  /** Fügt Buchungen hinzu; jeder betroffene Monatsdatensatz wird einmal neu geschrieben. */
  async add(items: Booking[]): Promise<void> {
    items = stampImported(items, todayLocal());
    const next = [...this.bookings(), ...items];
    await this.writeMonths(next, new Set(items.map((b) => monthOf(b.date))));
    this.bookings.set(next);
  }

  /** Ersetzt eine Buchung; ändert sich der Monat, werden beide Monatsdatensätze geschrieben. */
  async update(b: Booking): Promise<void> {
    const old = this.bookings().find((x) => x.id === b.id);
    if (!old) throw new Error('Buchung nicht gefunden.');
    const next = this.bookings().map((x) => (x.id === b.id ? b : x));
    await this.writeMonths(next, new Set([monthOf(old.date), monthOf(b.date)]));
    this.bookings.set(next);
  }

  /** Löscht eine Buchung; bei Umbuchungen beide Seiten. */
  async remove(id: string): Promise<void> {
    const b = this.bookings().find((x) => x.id === id);
    if (!b) return;
    const gone = this.bookings().filter(
      (x) => x.id === id || (b.transferGroupId && x.transferGroupId === b.transferGroupId),
    );
    const next = this.bookings().filter((x) => !gone.includes(x));
    await this.writeMonths(next, new Set(gone.map((x) => monthOf(x.date))));
    this.bookings.set(next);
  }

  /** Ändert, ergänzt und löscht Buchungen in einem Schritt (Stapelverarbeitung, Ersetzen von Importen). */
  async applyBatch(changed: Booking[], added: Booking[], removedIds: string[] = []): Promise<void> {
    const before = this.bookings();
    const removed = before.filter((x) => removedIds.includes(x.id));
    const next = [
      ...before
        .filter((x) => !removedIds.includes(x.id))
        .map((x) => changed.find((c) => c.id === x.id) ?? x),
      ...added,
    ];
    const months = new Set(
      [
        ...removed,
        ...changed,
        ...added,
        ...before.filter((x) => changed.some((c) => c.id === x.id)),
      ].map((x) => monthOf(x.date)),
    );
    await this.writeMonths(next, months);
    this.bookings.set(next);
  }

  /** Ändert mehrere Buchungen auf einmal (z. B. beide Seiten einer Umbuchung). */
  async updateMany(items: Booking[]): Promise<void> {
    const old = this.bookings().filter((x) => items.some((i) => i.id === x.id));
    const next = this.bookings().map((x) => items.find((i) => i.id === x.id) ?? x);
    await this.writeMonths(next, new Set([...old, ...items].map((x) => monthOf(x.date))));
    this.bookings.set(next);
  }

  private async writeMonths(all: Booking[], months: Set<string>): Promise<void> {
    for (const m of months) {
      const list = all.filter((b) => monthOf(b.date) === m);
      if (list.length) await this.vault.write('bookings', m, list);
      else await this.vault.remove('bookings', m);
    }
  }
}
