import { Injectable, inject, signal } from '@angular/core';
import { Bauspar } from '../../domain/loans/bauspar';
import { VaultService } from '../vault.service';

/** Bausparverträge (Lastenheft 18.10): ein verschlüsselter Datensatz je Vertrag. */
@Injectable({ providedIn: 'root' })
export class BausparStore {
  private readonly vault = inject(VaultService);
  readonly items = signal<Bauspar[]>([]);

  async load(): Promise<void> {
    this.items.set(
      (await this.vault.readAll<Bauspar>('bauspar')).sort((a, b) => a.order - b.order),
    );
  }

  clear(): void {
    this.items.set([]);
  }

  async save(b: Bauspar): Promise<void> {
    await this.vault.write('bauspar', b.id, b);
    this.items.update((l) =>
      [...l.filter((x) => x.id !== b.id), b].sort((a, c) => a.order - c.order),
    );
  }

  async remove(id: string): Promise<void> {
    await this.vault.remove('bauspar', id);
    this.items.update((l) => l.filter((x) => x.id !== id));
  }
}
