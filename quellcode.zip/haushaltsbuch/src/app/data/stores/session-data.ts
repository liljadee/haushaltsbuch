import { Injectable, inject } from '@angular/core';
import { AccountsStore } from './accounts.store';
import { BookingsStore } from './bookings.store';
import { CategoriesStore } from './categories.store';
import { RulesStore } from './rules.store';
import { PrefsStore } from './prefs.store';
import { RecurringStore } from './recurring.store';
import { PotsStore } from './pots.store';
import { MirrorService } from '../mirror.service';
import { LoansStore } from './loans.store';
import { SplitTemplatesStore } from './split-templates.store';

/** Lädt nach dem Entsperren alle Daten einmal in den Arbeitsspeicher und leert sie beim Sperren (Bauplan 5.3). */
@Injectable({ providedIn: 'root' })
export class SessionData {
  private readonly accounts = inject(AccountsStore);
  private readonly bookings = inject(BookingsStore);
  private readonly categories = inject(CategoriesStore);
  private readonly rules = inject(RulesStore);
  private readonly prefs = inject(PrefsStore);
  private readonly recurring = inject(RecurringStore);
  private readonly pots = inject(PotsStore);
  private readonly mirror = inject(MirrorService);
  private readonly loans = inject(LoansStore);
  private readonly splits = inject(SplitTemplatesStore);
  private loaded: Promise<void> | null = null;

  ensure(): Promise<void> {
    this.loaded ??= Promise.all([
      this.bookings.load(),
      this.accounts.load(),
      this.categories.load(),
      this.rules.load(),
      this.prefs.load(),
      this.recurring.load(),
      this.pots.load(),
      this.loans.load(),
      this.splits.load(),
    ]).then(() => this.mirror.init());
    return this.loaded;
  }

  clear(): void {
    this.loaded = null;
    this.accounts.clear();
    this.bookings.clear();
    this.categories.clear();
    this.rules.clear();
    this.prefs.clear();
    this.recurring.clear();
    this.pots.clear();
    this.loans.clear();
    this.splits.clear();
    this.mirror.clear();
  }
}
