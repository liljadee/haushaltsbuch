import { Injectable, inject } from '@angular/core';
import { AccountsStore } from './accounts.store';
import { BookingsStore } from './bookings.store';
import { CategoriesStore } from './categories.store';
import { RulesStore } from './rules.store';
import { PrefsStore } from './prefs.store';

/** Lädt nach dem Entsperren alle Daten einmal in den Arbeitsspeicher und leert sie beim Sperren (Bauplan 5.3). */
@Injectable({ providedIn: 'root' })
export class SessionData {
  private readonly accounts = inject(AccountsStore);
  private readonly bookings = inject(BookingsStore);
  private readonly categories = inject(CategoriesStore);
  private readonly rules = inject(RulesStore);
  private readonly prefs = inject(PrefsStore);
  private loaded: Promise<void> | null = null;

  ensure(): Promise<void> {
    this.loaded ??= Promise.all([
      this.bookings.load(),
      this.accounts.load(),
      this.categories.load(),
      this.rules.load(),
      this.prefs.load(),
    ]).then(() => undefined);
    return this.loaded;
  }

  clear(): void {
    this.loaded = null;
    this.accounts.clear();
    this.bookings.clear();
    this.categories.clear();
    this.rules.clear();
    this.prefs.clear();
  }
}
