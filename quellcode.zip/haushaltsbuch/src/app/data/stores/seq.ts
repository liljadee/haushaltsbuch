/** Fortlaufende Erfassungsnummer: ordnet Buchungen und Kontostände desselben Tages (Bauplan 6.1). */
let last = 0;
export function nextSeq(): number {
  last = Math.max(Date.now() * 1000, last + 1);
  return last;
}
