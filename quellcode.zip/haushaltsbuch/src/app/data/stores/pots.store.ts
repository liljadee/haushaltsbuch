import { Injectable, inject, signal } from '@angular/core';
import { Pot } from '../../domain/liquidity/pots';

export interface DistributionEntry {
  date: string;
  amount: number;
  parts: Record<string, number>;
}
export interface DistributionState {
  startedAt: string | null;
  done: Record<string, DistributionEntry>;
}
export const EMPTY_DISTRIBUTION: DistributionState = { startedAt: null, done: {} };
import { VaultService } from '../vault.service';

/** Spartöpfe (Lastenheft 16a): ein verschlüsselter Datensatz je Topf. */
@Injectable({ providedIn: 'root' })
export class PotsStore {
  private readonly vault = inject(VaultService);
  readonly pots = signal<Pot[]>([]);
  /** automatische Verteilung: Start und schon verteilte Eingänge (Buchungs-ID → Aufteilung) */
  readonly distribution = signal<DistributionState>(EMPTY_DISTRIBUTION);

  async load(): Promise<void> {
    this.pots.set((await this.vault.readAll<Pot>('pots')).sort((a, b) => a.order - b.order));
    this.distribution.set(
      await this.vault.read<DistributionState>('settings', 'topf-verteilung', EMPTY_DISTRIBUTION),
    );
  }

  clear(): void {
    this.pots.set([]);
    this.distribution.set(EMPTY_DISTRIBUTION);
  }

  async saveDistribution(d: DistributionState): Promise<void> {
    await this.vault.write('settings', 'topf-verteilung', d);
    this.distribution.set(d);
  }

  async save(p: Pot): Promise<void> {
    await this.vault.write('pots', p.id, p);
    this.pots.update((l) =>
      [...l.filter((x) => x.id !== p.id), p].sort((a, b) => a.order - b.order),
    );
  }

  async saveAll(list: Pot[]): Promise<void> {
    for (const p of list) await this.vault.write('pots', p.id, p);
    this.pots.update((l) =>
      [...l.filter((x) => !list.some((p) => p.id === x.id)), ...list].sort(
        (a, b) => a.order - b.order,
      ),
    );
  }

  async remove(id: string): Promise<void> {
    await this.vault.remove('pots', id);
    this.pots.update((l) => l.filter((x) => x.id !== id));
  }
}
