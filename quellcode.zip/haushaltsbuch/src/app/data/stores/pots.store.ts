import { Injectable, inject, signal } from '@angular/core';
import { Pot } from '../../domain/liquidity/pots';
import { VaultService } from '../vault.service';

/** Spartöpfe (Lastenheft 16a): ein verschlüsselter Datensatz je Topf. */
@Injectable({ providedIn: 'root' })
export class PotsStore {
  private readonly vault = inject(VaultService);
  readonly pots = signal<Pot[]>([]);

  async load(): Promise<void> {
    this.pots.set((await this.vault.readAll<Pot>('pots')).sort((a, b) => a.order - b.order));
  }

  clear(): void {
    this.pots.set([]);
  }

  async save(p: Pot): Promise<void> {
    await this.vault.write('pots', p.id, p);
    this.pots.update((l) =>
      [...l.filter((x) => x.id !== p.id), p].sort((a, b) => a.order - b.order),
    );
  }

  async saveAll(list: Pot[]): Promise<void> {
    for (const p of list) await this.vault.write('pots', p.id, p);
    this.pots.update((l) =>
      [...l.filter((x) => !list.some((p) => p.id === x.id)), ...list].sort(
        (a, b) => a.order - b.order,
      ),
    );
  }

  async remove(id: string): Promise<void> {
    await this.vault.remove('pots', id);
    this.pots.update((l) => l.filter((x) => x.id !== id));
  }
}
