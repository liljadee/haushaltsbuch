import { Injectable, inject, signal } from '@angular/core';
import { EMPTY_STAT_SETTINGS, StatSettings } from '../../domain/stats/groups';
import { VaultService } from '../vault.service';

export type Prudence = 'ausgewogen' | 'vorsichtig';

/** Kleine Einstellungen im verschlüsselten Speicher: letztes Backup, Vorsichtsstufe, Statistik-Gruppen. */
@Injectable({ providedIn: 'root' })
export class PrefsStore {
  private readonly vault = inject(VaultService);
  readonly lastBackup = signal<string | null>(null);
  /** Vorsichtsstufe der Prognose (Lastenheft 15) */
  readonly prudence = signal<Prudence>('ausgewogen');
  /** Anzeigenamen der Kredite und eigene Gruppen für die Statistik */
  readonly statSettings = signal<StatSettings>(EMPTY_STAT_SETTINGS);

  async load(): Promise<void> {
    this.lastBackup.set(await this.vault.read<string | null>('settings', 'letztes-backup', null));
    this.prudence.set(await this.vault.read<Prudence>('settings', 'vorsicht', 'ausgewogen'));
    this.statSettings.set(
      await this.vault.read<StatSettings>('settings', 'statistik-gruppen', EMPTY_STAT_SETTINGS),
    );
  }

  clear(): void {
    this.lastBackup.set(null);
    this.prudence.set('ausgewogen');
    this.statSettings.set(EMPTY_STAT_SETTINGS);
  }

  async setPrudence(p: Prudence): Promise<void> {
    await this.vault.write('settings', 'vorsicht', p);
    this.prudence.set(p);
  }

  async setStatSettings(s: StatSettings): Promise<void> {
    await this.vault.write('settings', 'statistik-gruppen', s);
    this.statSettings.set(s);
  }

  async setLastBackup(date: string): Promise<void> {
    await this.vault.write('settings', 'letztes-backup', date);
    this.lastBackup.set(date);
  }
}
