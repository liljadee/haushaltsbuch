import { Injectable, inject, signal } from '@angular/core';
import { EMPTY_STAT_SETTINGS, StatSettings } from '../../domain/stats/groups';
import { DEFAULT_ADVICE } from '../../domain/liquidity/advice';
import { VaultService } from '../vault.service';

export type Prudence = 'ausgewogen' | 'vorsichtig';

/** Liquidität (Lastenheft 16, 16a): Puffer, Überschuss-Schwelle, Topfkonto, letzter Verteilmonat */
export interface LiquiditySettings {
  buffer: number;
  surplusThreshold: number;
  potAccountId: string | null;
  lastDistribution: string | null;
}
export const DEFAULT_LIQUIDITY: LiquiditySettings = {
  ...DEFAULT_ADVICE,
  potAccountId: null,
  lastDistribution: null,
};

/** Kleine Einstellungen im verschlüsselten Speicher: letztes Backup, Vorsichtsstufe, Statistik-Gruppen. */
@Injectable({ providedIn: 'root' })
export class PrefsStore {
  private readonly vault = inject(VaultService);
  readonly lastBackup = signal<string | null>(null);
  /** Vorsichtsstufe der Prognose (Lastenheft 15) */
  readonly prudence = signal<Prudence>('ausgewogen');
  /** Anzeigenamen der Kredite und eigene Gruppen für die Statistik */
  readonly statSettings = signal<StatSettings>(EMPTY_STAT_SETTINGS);
  readonly liquidity = signal<LiquiditySettings>(DEFAULT_LIQUIDITY);
  /** Backup-Erinnerung nach so vielen Tagen (Standard wöchentlich) */
  readonly backupInterval = signal(7);
  /** seit dem letzten Backup gab es eine größere Änderung (Import, Stapeländerung) */
  readonly bigChange = signal(false);
  /** Tipp „Sicherungsdatei einrichten“ ausgeblendet */
  readonly mirrorTipOff = signal(false);
  /** Sondertilgungsplan: gewählte Reihenfolge (null = Empfehlung) und monatlicher Zufluss (null = erkannt) */
  readonly specialPlan = signal<{ strategy: string | null; monthly: number | null }>({
    strategy: null,
    monthly: null,
  });

  async load(): Promise<void> {
    this.lastBackup.set(await this.vault.read<string | null>('settings', 'letztes-backup', null));
    this.backupInterval.set(await this.vault.read<number>('settings', 'backup-intervall', 7));
    this.bigChange.set(
      await this.vault.read<boolean>('settings', 'backup-grosse-aenderung', false),
    );
    this.mirrorTipOff.set(
      await this.vault.read<boolean>('settings', 'sicherungsdatei-tipp-aus', false),
    );
    this.specialPlan.set(
      await this.vault.read('settings', 'sondertilgungsplan', { strategy: null, monthly: null }),
    );
    this.prudence.set(await this.vault.read<Prudence>('settings', 'vorsicht', 'ausgewogen'));
    this.statSettings.set(
      await this.vault.read<StatSettings>('settings', 'statistik-gruppen', EMPTY_STAT_SETTINGS),
    );
    this.liquidity.set({
      ...DEFAULT_LIQUIDITY,
      ...(await this.vault.read<Partial<LiquiditySettings>>('settings', 'liquiditaet', {})),
    });
  }

  clear(): void {
    this.lastBackup.set(null);
    this.backupInterval.set(7);
    this.bigChange.set(false);
    this.prudence.set('ausgewogen');
    this.statSettings.set(EMPTY_STAT_SETTINGS);
    this.liquidity.set(DEFAULT_LIQUIDITY);
  }

  async setPrudence(p: Prudence): Promise<void> {
    await this.vault.write('settings', 'vorsicht', p);
    this.prudence.set(p);
  }

  async setStatSettings(s: StatSettings): Promise<void> {
    await this.vault.write('settings', 'statistik-gruppen', s);
    this.statSettings.set(s);
  }

  async setLiquidity(l: Partial<LiquiditySettings>): Promise<void> {
    const next = { ...this.liquidity(), ...l };
    await this.vault.write('settings', 'liquiditaet', next);
    this.liquidity.set(next);
  }

  async setLastBackup(date: string): Promise<void> {
    await this.vault.write('settings', 'letztes-backup', date);
    await this.vault.write('settings', 'backup-grosse-aenderung', false);
    this.lastBackup.set(date);
    this.bigChange.set(false);
  }

  async setSpecialPlan(
    x: Partial<{ strategy: string | null; monthly: number | null }>,
  ): Promise<void> {
    const next = { ...this.specialPlan(), ...x };
    await this.vault.write('settings', 'sondertilgungsplan', next);
    this.specialPlan.set(next);
  }

  async hideMirrorTip(): Promise<void> {
    await this.vault.write('settings', 'sicherungsdatei-tipp-aus', true);
    this.mirrorTipOff.set(true);
  }

  async setBackupInterval(days: number): Promise<void> {
    await this.vault.write('settings', 'backup-intervall', days);
    this.backupInterval.set(days);
  }

  /** nach Importen und großen Stapeländerungen: an ein Backup erinnern */
  async markBigChange(): Promise<void> {
    if (this.bigChange()) return;
    await this.vault.write('settings', 'backup-grosse-aenderung', true);
    this.bigChange.set(true);
  }
}
