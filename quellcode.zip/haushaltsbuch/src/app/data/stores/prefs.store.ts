import { Injectable, inject, signal } from '@angular/core';
import { VaultService } from '../vault.service';

/** Kleine Einstellungen im verschlüsselten Speicher, z. B. Datum des letzten Backups (Lastenheft 13.1 Hinweise). */
@Injectable({ providedIn: 'root' })
export class PrefsStore {
  private readonly vault = inject(VaultService);
  readonly lastBackup = signal<string | null>(null);

  async load(): Promise<void> {
    this.lastBackup.set(await this.vault.read<string | null>('settings', 'letztes-backup', null));
  }

  clear(): void {
    this.lastBackup.set(null);
  }

  async setLastBackup(date: string): Promise<void> {
    await this.vault.write('settings', 'letztes-backup', date);
    this.lastBackup.set(date);
  }
}
