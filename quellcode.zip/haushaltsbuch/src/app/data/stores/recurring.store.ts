import { Injectable, computed, inject, signal } from '@angular/core';
import { RecurringItem, detectRecurring } from '../../domain/recurring/recurring';
import { todayLocal } from '../../domain/shared/local-date';
import { VaultService } from '../vault.service';
import { BookingsStore } from './bookings.store';

const REJECTED = 'wiederkehrend-abgelehnt';

/** Bestätigte wiederkehrende Zahlungen (ein Datensatz je Posten) und abgelehnte Vorschläge (Lastenheft 14). */
@Injectable({ providedIn: 'root' })
export class RecurringStore {
  private readonly vault = inject(VaultService);
  private readonly bookings = inject(BookingsStore);
  readonly items = signal<RecurringItem[]>([]);
  readonly rejected = signal<string[]>([]);
  readonly suggestions = computed(() =>
    detectRecurring(this.bookings.bookings(), todayLocal(), this.items(), this.rejected()),
  );

  async load(): Promise<void> {
    this.items.set(await this.vault.readAll<RecurringItem>('recurring'));
    this.rejected.set(await this.vault.read<string[]>('settings', REJECTED, []));
  }

  clear(): void {
    this.items.set([]);
    this.rejected.set([]);
  }

  async confirm(s: RecurringItem): Promise<RecurringItem> {
    const item: RecurringItem = { ...s, id: crypto.randomUUID() };
    await this.save(item);
    return item;
  }

  async confirmAll(): Promise<number> {
    const list = this.suggestions();
    for (const s of list) await this.confirm(s);
    return list.length;
  }

  async reject(s: RecurringItem): Promise<void> {
    const next = [...this.rejected(), `${s.accountId}|${s.pattern}`];
    await this.vault.write('settings', REJECTED, next);
    this.rejected.set(next);
  }

  async save(item: RecurringItem): Promise<void> {
    await this.vault.write('recurring', item.id, item);
    this.items.update((l) => [...l.filter((x) => x.id !== item.id), item]);
  }

  async remove(id: string): Promise<void> {
    await this.vault.remove('recurring', id);
    this.items.update((l) => l.filter((x) => x.id !== id));
  }
}
