import { Injectable, inject, signal } from '@angular/core';
import { Rule, learn } from '../../domain/categories/rules';
import { Cents } from '../../domain/shared/money';
import { VaultService } from '../vault.service';

/** Gelernte Regeln (Lastenheft 9.4): ein verschlüsselter Datensatz je Regel. */
@Injectable({ providedIn: 'root' })
export class RulesStore {
  private readonly vault = inject(VaultService);
  readonly rules = signal<Rule[]>([]);

  async load(): Promise<void> {
    this.rules.set(await this.vault.readAll<Rule>('rules'));
  }

  clear(): void {
    this.rules.set([]);
  }

  /** Aus einer bestätigten Zuordnung lernen. */
  async learnFrom(
    text: string,
    amount: Cents,
    categoryId: string | null,
    subCategory: string | null,
  ): Promise<void> {
    if (!categoryId) return;
    const changed = learn(text, amount, categoryId, subCategory, this.rules(), () =>
      crypto.randomUUID(),
    );
    for (const r of changed) await this.vault.write('rules', r.id, r);
    this.rules.update((l) => [...l.filter((r) => !changed.some((c) => c.id === r.id)), ...changed]);
  }

  async remove(id: string): Promise<void> {
    await this.vault.remove('rules', id);
    this.rules.update((l) => l.filter((r) => r.id !== id));
  }
}
