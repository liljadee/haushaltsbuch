import { Injectable, computed, inject, signal } from '@angular/core';
import {
  Account,
  AccountDraft,
  BalanceSnapshot,
  normalizeIdentifier,
} from '../../domain/accounts/account';
import {
  GapReport,
  correctionFor,
  currentBalance,
  gapReport,
} from '../../domain/accounts/balances';
import { Booking } from '../../domain/bookings/booking';
import { Cents } from '../../domain/shared/money';
import { LocalDate } from '../../domain/shared/local-date';
import { VaultService } from '../vault.service';
import { BookingsStore } from './bookings.store';
import { nextSeq } from './seq';

export interface AccountView {
  account: Account;
  balance: Cents | null;
  gap: GapReport;
}

/** Konten (Lastenheft 7): ein verschlüsselter Datensatz je Konto. */
@Injectable({ providedIn: 'root' })
export class AccountsStore {
  private readonly vault = inject(VaultService);
  private readonly bookings = inject(BookingsStore);
  readonly accounts = signal<Account[]>([]);
  readonly active = computed(() =>
    this.accounts()
      .filter((a) => !a.archived)
      .sort((a, b) => a.order - b.order),
  );
  readonly views = computed<AccountView[]>(() => {
    const b = this.bookings.bookings();
    return this.active().map((account) => ({
      account,
      balance: currentBalance(account, b),
      gap: gapReport(account, b),
    }));
  });
  readonly total = computed(() => this.views().reduce((s, v) => s + (v.balance ?? 0), 0));

  async load(): Promise<void> {
    this.accounts.set(await this.vault.readAll<Account>('accounts'));
  }

  clear(): void {
    this.accounts.set([]);
  }

  byIdentifier(id: string): Account | undefined {
    return this.active().find((a) => a.identifier === id);
  }

  async create(d: AccountDraft, start: { date: LocalDate; balance: Cents }): Promise<Account> {
    const a: Account = {
      id: crypto.randomUUID(),
      name: d.name.trim(),
      type: d.type,
      identifier: normalizeIdentifier(d.identifier),
      purpose: d.type === 'tagesgeld' ? d.purpose : 'allgemein',
      reserve: d.reserve ?? 0,
      leadDays: d.leadDays ?? 2,
      snapshots: [
        {
          id: crypto.randomUUID(),
          date: start.date,
          seq: nextSeq(),
          balance: start.balance,
          source: 'start',
        },
      ],
      archived: false,
      order: Math.max(-1, ...this.accounts().map((x) => x.order)) + 1,
    };
    await this.save(a);
    return a;
  }

  async update(id: string, d: AccountDraft): Promise<void> {
    const a = this.require(id);
    await this.save({
      ...a,
      name: d.name.trim(),
      type: d.type,
      identifier: normalizeIdentifier(d.identifier),
      purpose: d.type === 'tagesgeld' ? d.purpose : 'allgemein',
      reserve: d.reserve ?? 0,
      leadDays: d.leadDays ?? 2,
    });
  }

  /** Stand laut Bank eintragen; die Differenz wird als offener Hinweis berechnet. */
  async addSnapshot(
    id: string,
    date: LocalDate,
    balance: Cents,
    source: BalanceSnapshot['source'],
  ): Promise<void> {
    const a = this.require(id);
    await this.save({
      ...a,
      snapshots: [
        ...a.snapshots,
        { id: crypto.randomUUID(), date, seq: nextSeq(), balance, source },
      ],
    });
  }

  /** Offene Differenz als Korrekturbuchung übernehmen; Kontostand und Statistik bleiben unverändert. */
  async bookCorrection(id: string): Promise<Booking | null> {
    const a = this.require(id);
    const c = correctionFor(a, gapReport(a, this.bookings.bookings()));
    if (!c) return null;
    const b: Booking = {
      id: crypto.randomUUID(),
      accountId: a.id,
      kind: 'korrektur',
      status: 'gebucht',
      amount: c.amount,
      date: c.date,
      seq: c.seqBefore,
      text: 'Korrektur: Differenz zum Stand laut Bank',
      splits: [],
      confidence: 'sicher',
      source: { type: 'abgleich' },
    };
    await this.bookings.add([b]);
    return b;
  }

  async archive(id: string): Promise<void> {
    await this.save({ ...this.require(id), archived: true });
  }

  private require(id: string): Account {
    const a = this.accounts().find((x) => x.id === id);
    if (!a) throw new Error('Konto nicht gefunden.');
    return a;
  }

  private async save(a: Account): Promise<void> {
    await this.vault.write('accounts', a.id, a);
    this.accounts.update((l) => [...l.filter((x) => x.id !== a.id), a]);
  }
}
