import { Injectable, computed, inject, signal } from '@angular/core';
import { Cents } from '../../domain/shared/money';
import { VaultService } from '../vault.service';

export interface TestEntry {
  id: string;
  date: string;
  amount: Cents;
  text: string;
}

/** Verschlüsselter Testdatensatz für v0.1 (Bauplan 10). Echte Buchungen folgen mit v0.2. */
@Injectable({ providedIn: 'root' })
export class TestDataStore {
  readonly entries = signal<TestEntry[]>([]);
  readonly total = computed(() => this.entries().reduce((s, e) => s + e.amount, 0));
  private readonly vault = inject(VaultService);

  async load(): Promise<void> {
    this.entries.set(await this.vault.read<TestEntry[]>('testdata', 'eintraege', []));
  }

  async add(e: Omit<TestEntry, 'id'>): Promise<void> {
    const next = [{ ...e, id: crypto.randomUUID() }, ...this.entries()].sort((a, b) =>
      b.date.localeCompare(a.date),
    );
    await this.vault.write('testdata', 'eintraege', next);
    this.entries.set(next);
  }

  async remove(id: string): Promise<void> {
    const next = this.entries().filter((e) => e.id !== id);
    await this.vault.write('testdata', 'eintraege', next);
    this.entries.set(next);
  }

  clear(): void {
    this.entries.set([]);
  }
}
