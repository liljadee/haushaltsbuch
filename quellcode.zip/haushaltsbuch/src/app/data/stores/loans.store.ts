import { Injectable, inject, signal } from '@angular/core';
import { Loan } from '../../domain/loans/loan';
import { VaultService } from '../vault.service';

/** Kredite (Lastenheft 18): ein verschlüsselter Datensatz je Kredit. */
@Injectable({ providedIn: 'root' })
export class LoansStore {
  private readonly vault = inject(VaultService);
  readonly loans = signal<Loan[]>([]);

  async load(): Promise<void> {
    this.loans.set((await this.vault.readAll<Loan>('loans')).sort((a, b) => a.order - b.order));
  }

  clear(): void {
    this.loans.set([]);
  }

  async save(l: Loan): Promise<void> {
    await this.vault.write('loans', l.id, l);
    this.loans.update((list) =>
      [...list.filter((x) => x.id !== l.id), l].sort((a, b) => a.order - b.order),
    );
  }

  async remove(id: string): Promise<void> {
    await this.vault.remove('loans', id);
    this.loans.update((list) => list.filter((x) => x.id !== id));
  }
}
