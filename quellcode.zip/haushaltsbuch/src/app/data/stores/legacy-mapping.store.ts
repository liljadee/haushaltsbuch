import { Injectable, inject } from '@angular/core';
import { LegacyMapping } from '../../domain/import/legacy';
import { VaultService } from '../vault.service';

const KEY = 'altdaten-zuordnung';

/** Merkt sich die Zuordnung von Konten und Kategorien der alten App für spätere Importe (Lastenheft 11). */
@Injectable({ providedIn: 'root' })
export class LegacyMappingStore {
  private readonly vault = inject(VaultService);

  load(): Promise<LegacyMapping> {
    return this.vault.read<LegacyMapping>('settings', KEY, {
      categories: {},
      comments: {},
      accounts: {},
    });
  }

  save(m: LegacyMapping): Promise<void> {
    return this.vault.write('settings', KEY, m);
  }
}
