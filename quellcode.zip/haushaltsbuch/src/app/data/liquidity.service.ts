import { Injectable, computed, inject } from '@angular/core';
import { currentBalance } from '../domain/accounts/balances';
import { Booking } from '../domain/bookings/booking';
import { createTransfer } from '../domain/bookings/transfer';
import { Advice, PotItem, SourceAccount, advise } from '../domain/liquidity/advice';
import {
  Pot,
  allocate,
  findStandingOrder,
  pendingInflows,
  potFree,
  potItems,
  potOrder,
  potRate,
  shift,
  startPlan,
  withdraw,
} from '../domain/liquidity/pots';
import { todayLocal } from '../domain/shared/local-date';
import { signatureOf } from '../domain/recurring/recurring';
import { formatEuro } from '../domain/shared/money';
import { ForecastService } from './forecast.service';
import { AccountsStore } from './stores/accounts.store';
import { BookingsStore } from './stores/bookings.store';
import { DistributionEntry, PotsStore } from './stores/pots.store';
import { PrefsStore } from './stores/prefs.store';
import { RecurringStore } from './stores/recurring.store';
import { nextSeq } from './stores/seq';

/** Liquiditätsabgleich, Umbuchungsempfehlung und Spartöpfe (Lastenheft 16, 16a). Die App bewegt nie selbst Geld. */
@Injectable({ providedIn: 'root' })
export class LiquidityService {
  private readonly fc = inject(ForecastService);
  private readonly accounts = inject(AccountsStore);
  private readonly bookings = inject(BookingsStore);
  private readonly potsStore = inject(PotsStore);
  private readonly prefs = inject(PrefsStore);
  private readonly recurring = inject(RecurringStore);
  readonly settings = this.prefs.liquidity;
  readonly distribution = this.potsStore.distribution;

  readonly sources = computed<SourceAccount[]>(() =>
    this.accounts
      .active()
      .filter((a) => a.type === 'tagesgeld')
      .map((account) => ({
        account,
        balance: currentBalance(account, this.bookings.bookings()) ?? 0,
      })),
  );
  /** Topfkonto: gewählt, sonst das Tagesgeld „Allgemeine Rücklage“ */
  readonly potAccount = computed(() => {
    const id = this.settings().potAccountId;
    return (
      this.sources().find((s) => s.account.id === id) ??
      this.sources().find((s) => s.account.purpose === 'allgemein') ??
      null
    );
  });
  readonly pots = this.potsStore.pots;
  readonly ordered = computed(() => potOrder(this.pots(), this.fc.refined(), todayLocal()));
  readonly free = computed(() => {
    const pa = this.potAccount();
    return pa ? potFree(pa.balance, pa.account.reserve, this.pots()) : 0;
  });
  readonly rateSum = computed(() =>
    this.pots().reduce((s, p) => s + potRate(p, this.fc.refined(), todayLocal()), 0),
  );
  /** Dauerauftrag vom Girokonto aufs Topfkonto: eingeplant oder aus der Historie erkannt */
  readonly standingOrder = computed(() => {
    const g = this.fc.giro(),
      pa = this.potAccount();
    if (!g || !pa) return null;
    return findStandingOrder(
      [...this.fc.refined(), ...this.recurring.suggestions()],
      this.bookings.bookings(),
      g.id,
      pa.account.id,
    );
  });
  readonly pendingInflows = computed(() => {
    const pa = this.potAccount();
    return pa
      ? pendingInflows(
          this.bookings.bookings(),
          this.standingOrder(),
          pa.account.id,
          this.distribution().startedAt,
          this.distribution().done,
        )
      : [];
  });
  readonly startPreview = computed(() =>
    startPlan(this.pots(), this.fc.refined(), this.free(), todayLocal()),
  );
  readonly potItems = computed<PotItem[]>(() =>
    potItems(
      this.pots(),
      this.fc.refined(),
      this.bookings.bookings(),
      this.fc.result(),
      todayLocal(),
    ),
  );
  readonly advice = computed<Advice | null>(() => {
    const f = this.fc.result();
    if (!f) return null;
    // Auf dem Topfkonto ist für einen Fehlbetrag nur der freie Teil verfügbar; Topfgeld kommt nur über die Topf-Anteile
    const pa = this.potAccount(),
      inPots = this.pots().reduce((s, p) => s + p.balance, 0),
      fromPots = this.potItems().reduce((s, i) => s + i.amount, 0);
    const sources = this.sources().map((s) =>
      s.account.id === pa?.account.id
        ? { ...s, account: { ...s.account, reserve: s.account.reserve + inPots - fromPots } }
        : s,
    );
    return advise(f, todayLocal(), this.settings(), sources, this.potItems(), pa?.account.id);
  });
  /** bestätigte Umbuchungen, die noch auf die Bank warten (16.7) */
  readonly pending = computed(() =>
    this.bookings.bookings().filter((b) => b.status === 'bestaetigt' && b.amount > 0),
  );

  /** „Jetzt umgebucht“ (16.5): zwei verknüpfte Buchungen mit Status „bestätigt“; Töpfe werden kleiner. */
  async confirm(
    amount: number,
    fromId: string,
    toId: string,
    takenPotItems: PotItem[] = [],
  ): Promise<void> {
    const from = this.accounts.active().find((a) => a.id === fromId),
      to = this.accounts.active().find((a) => a.id === toId);
    if (!from || !to || amount <= 0) throw new Error('Bitte Betrag und Konten prüfen.');
    const pair = createTransfer(
      from,
      to,
      amount,
      todayLocal(),
      '',
      { group: crypto.randomUUID(), a: crypto.randomUUID(), b: crypto.randomUUID() },
      [nextSeq(), nextSeq()],
    ).map((b) => ({ ...b, status: 'bestaetigt' as const }));
    const settled: Booking[] = this.bookings
      .bookings()
      .filter((b) => takenPotItems.some((i) => i.bookingId === b.id && i.amount > 0))
      .map((b) => ({ ...b, potSettled: true }));
    await this.bookings.applyBatch(settled, pair);
    if (takenPotItems.length)
      await this.potsStore.saveAll(
        withdraw(this.pots(), takenPotItems).filter((p, i) => p !== this.pots()[i]),
      );
  }

  private running: Promise<number> | null = null;
  /** Neue Eingänge des Dauerauftrags automatisch nach den Monatsraten verteilen, jeden genau einmal. */
  autoDistribute(): Promise<number> {
    if (this.running) return this.running;
    const run = (async () => {
      let n = 0;
      for (const b of this.pendingInflows()) {
        const parts = allocate(b.amount, this.pots(), this.fc.refined(), todayLocal());
        await this.potsStore.saveAll(
          this.pots()
            .filter((p) => parts[p.id])
            .map((p) => ({ ...p, balance: p.balance + parts[p.id] })),
        );
        const d = this.distribution();
        await this.potsStore.saveDistribution({
          ...d,
          done: { ...d.done, [b.id]: { date: b.date, amount: b.amount, parts } },
        });
        n++;
      }
      return n;
    })();
    // Sperre gegen doppeltes Verteilen; wird erst nach dem Lauf freigegeben (auch wenn nichts zu tun war)
    this.running = run;
    void run
      .catch(() => 0)
      .then(() => {
        if (this.running === run) this.running = null;
      });
    return run;
  }

  /** Startverteilung übernehmen; danach verteilt die App neue Eingänge automatisch. */
  async applyStart(balances: Record<string, number>): Promise<string | null> {
    const pa = this.potAccount();
    if (!pa) return 'Bitte zuerst ein Topfkonto wählen.';
    const total = Object.values(balances).reduce((s, v) => s + v, 0);
    if (total > pa.balance - pa.account.reserve)
      return `Die Töpfe dürfen zusammen höchstens ${formatEuro(pa.balance - pa.account.reserve)} enthalten.`;
    await this.potsStore.saveAll(
      this.pots().map((p) => ({ ...p, balance: balances[p.id] ?? p.balance })),
    );
    // Eingänge bis heute stecken schon im Kontostand und damit in der Startverteilung
    const today = todayLocal();
    const done: Record<string, DistributionEntry> = {};
    for (const b of pendingInflows(
      this.bookings.bookings(),
      this.standingOrder(),
      pa.account.id,
      today,
      {},
    ))
      done[b.id] = { date: b.date, amount: b.amount, parts: {} };
    await this.potsStore.saveDistribution({ startedAt: today, done });
    return null;
  }

  /** Aufteilung eines verteilten Eingangs ändern; die Töpfe ändern sich um die Differenz. */
  async editDistribution(bookingId: string, parts: Record<string, number>): Promise<string | null> {
    const d = this.distribution(),
      entry = d.done[bookingId];
    if (!entry) return 'Verteilung nicht gefunden.';
    const sum = Object.values(parts).reduce((s, v) => s + v, 0);
    if (sum > entry.amount) return `Höchstens ${formatEuro(entry.amount)} lassen sich verteilen.`;
    const changed = this.pots().map((p) => ({
      ...p,
      balance: p.balance + (parts[p.id] ?? 0) - (entry.parts[p.id] ?? 0),
    }));
    if (changed.some((p) => p.balance < 0)) return 'Ein Topf würde ins Minus rutschen.';
    if (sum - Object.values(entry.parts).reduce((s, v) => s + v, 0) > this.free())
      return `Dafür ist nicht genug frei (${formatEuro(this.free())}).`;
    await this.potsStore.saveAll(changed);
    await this.potsStore.saveDistribution({
      ...d,
      done: { ...d.done, [bookingId]: { ...entry, parts } },
    });
    return null;
  }

  /** Umschichten zwischen Töpfen oder mit dem freien Teil ('frei'). */
  async shiftPots(from: string, to: string, amount: number): Promise<string | null> {
    const r = shift(this.pots(), from, to, amount, this.free());
    if (r.error) return r.error;
    await this.potsStore.saveAll(r.pots.filter((p, i) => p.balance !== this.pots()[i].balance));
    return null;
  }

  /** Dauerauftrag vom Girokonto aufs Topfkonto eintragen (regelmäßige Umbuchung, monatlich) */
  async addStandingOrder(amount: number, day: number): Promise<string | null> {
    const g = this.fc.giro(),
      pa = this.potAccount();
    if (!g || !pa) return 'Es fehlt ein Girokonto oder ein Tagesgeldkonto.';
    if (!(amount > 0)) return 'Bitte einen Betrag eingeben.';
    if (!(day >= 1 && day <= 31)) return 'Bitte einen Tag von 1 bis 31 eingeben.';
    const label = `Dauerauftrag ${pa.account.name}`;
    await this.recurring.save({
      id: crypto.randomUUID(),
      label,
      accountId: g.id,
      amount: -amount,
      categoryId: null,
      subCategory: null,
      pattern: signatureOf(label),
      interval: 'monat',
      months: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
      day,
      variable: false,
      active: true,
      transferTo: pa.account.id,
    });
    return null;
  }

  async savePot(p: Pot): Promise<void> {
    await this.potsStore.save(p);
  }

  async removePot(id: string): Promise<void> {
    await this.potsStore.remove(id);
  }
}
