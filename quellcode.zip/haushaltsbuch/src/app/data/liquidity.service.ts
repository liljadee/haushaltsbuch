import { Injectable, computed, inject } from '@angular/core';
import { currentBalance } from '../domain/accounts/balances';
import { Booking } from '../domain/bookings/booking';
import { createTransfer } from '../domain/bookings/transfer';
import { Advice, PotItem, SourceAccount, advise } from '../domain/liquidity/advice';
import {
  Pot,
  distributeRates,
  potFree,
  potItems,
  potRate,
  withdraw,
} from '../domain/liquidity/pots';
import { todayLocal } from '../domain/shared/local-date';
import { ForecastService } from './forecast.service';
import { AccountsStore } from './stores/accounts.store';
import { BookingsStore } from './stores/bookings.store';
import { PotsStore } from './stores/pots.store';
import { PrefsStore } from './stores/prefs.store';
import { nextSeq } from './stores/seq';

/** Liquiditätsabgleich, Umbuchungsempfehlung und Spartöpfe (Lastenheft 16, 16a). Die App bewegt nie selbst Geld. */
@Injectable({ providedIn: 'root' })
export class LiquidityService {
  private readonly fc = inject(ForecastService);
  private readonly accounts = inject(AccountsStore);
  private readonly bookings = inject(BookingsStore);
  private readonly potsStore = inject(PotsStore);
  private readonly prefs = inject(PrefsStore);
  readonly settings = this.prefs.liquidity;

  readonly sources = computed<SourceAccount[]>(() =>
    this.accounts
      .active()
      .filter((a) => a.type === 'tagesgeld')
      .map((account) => ({
        account,
        balance: currentBalance(account, this.bookings.bookings()) ?? 0,
      })),
  );
  /** Topfkonto: gewählt, sonst das Tagesgeld „Allgemeine Rücklage“ */
  readonly potAccount = computed(() => {
    const id = this.settings().potAccountId;
    return (
      this.sources().find((s) => s.account.id === id) ??
      this.sources().find((s) => s.account.purpose === 'allgemein') ??
      null
    );
  });
  readonly pots = this.potsStore.pots;
  readonly free = computed(() => {
    const pa = this.potAccount();
    return pa ? potFree(pa.balance, pa.account.reserve, this.pots()) : 0;
  });
  readonly rateSum = computed(() =>
    this.pots().reduce((s, p) => s + potRate(p, this.fc.refined(), todayLocal()), 0),
  );
  readonly potItems = computed<PotItem[]>(() =>
    potItems(
      this.pots(),
      this.fc.refined(),
      this.bookings.bookings(),
      this.fc.result(),
      todayLocal(),
    ),
  );
  readonly advice = computed<Advice | null>(() => {
    const f = this.fc.result();
    if (!f) return null;
    return advise(
      f,
      todayLocal(),
      this.settings(),
      this.sources(),
      this.potItems(),
      this.potAccount()?.account.id,
    );
  });
  /** bestätigte Umbuchungen, die noch auf die Bank warten (16.7) */
  readonly pending = computed(() =>
    this.bookings.bookings().filter((b) => b.status === 'bestaetigt' && b.amount > 0),
  );

  /** „Jetzt umgebucht“ (16.5): zwei verknüpfte Buchungen mit Status „bestätigt“; Töpfe werden kleiner. */
  async confirm(
    amount: number,
    fromId: string,
    toId: string,
    takenPotItems: PotItem[] = [],
  ): Promise<void> {
    const from = this.accounts.active().find((a) => a.id === fromId),
      to = this.accounts.active().find((a) => a.id === toId);
    if (!from || !to || amount <= 0) throw new Error('Bitte Betrag und Konten prüfen.');
    const pair = createTransfer(
      from,
      to,
      amount,
      todayLocal(),
      '',
      { group: crypto.randomUUID(), a: crypto.randomUUID(), b: crypto.randomUUID() },
      [nextSeq(), nextSeq()],
    ).map((b) => ({ ...b, status: 'bestaetigt' as const }));
    const settled: Booking[] = this.bookings
      .bookings()
      .filter((b) => takenPotItems.some((i) => i.bookingId === b.id && i.amount > 0))
      .map((b) => ({ ...b, potSettled: true }));
    await this.bookings.applyBatch(settled, pair);
    if (takenPotItems.length)
      await this.potsStore.saveAll(
        withdraw(this.pots(), takenPotItems).filter((p, i) => p !== this.pots()[i]),
      );
  }

  /** Monatsraten auf die Töpfe verteilen (nach Eingang des Dauerauftrags), höchstens bis zum freien Teil. */
  async distribute(): Promise<number> {
    const r = distributeRates(this.pots(), this.fc.refined(), this.free(), todayLocal());
    await this.potsStore.saveAll(
      r.pots.filter((p) => p.balance !== this.pots().find((x) => x.id === p.id)?.balance),
    );
    await this.prefs.setLiquidity({ lastDistribution: todayLocal().slice(0, 7) });
    return r.distributed;
  }

  async savePot(p: Pot): Promise<void> {
    await this.potsStore.save(p);
  }

  async removePot(id: string): Promise<void> {
    await this.potsStore.remove(id);
  }
}
