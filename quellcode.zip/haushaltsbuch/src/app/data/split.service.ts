import { Injectable, inject, signal } from '@angular/core';
import { Booking } from '../domain/bookings/booking';
import {
  SplitProposal,
  SplitTemplate,
  findTemplate,
  learnTemplate,
  proposeSplit,
  retroCandidates,
} from '../domain/bookings/split-templates';
import { todayLocal } from '../domain/shared/local-date';
import { formatEuro } from '../domain/shared/money';
import { BookingsStore } from './stores/bookings.store';
import { PrefsStore } from './stores/prefs.store';
import { SplitTemplatesStore } from './stores/split-templates.store';

/** Sammelabbuchungen: lernen, vorschlagen, rückwirkend übernehmen (Wunsch 19.11.2026). */
@Injectable({ providedIn: 'root' })
export class SplitService {
  private readonly store = inject(SplitTemplatesStore);
  private readonly bookings = inject(BookingsStore);
  private readonly prefs = inject(PrefsStore);
  readonly templates = this.store.templates;
  /** Angebot nach dem Lernen: frühere Abbuchungen desselben Empfängers aufteilen */
  readonly retro = signal<{
    template: SplitTemplate;
    items: { booking: Booking; proposal: SplitProposal }[];
  } | null>(null);

  /** Vorschlag für eine Abbuchung (Formular, Import) */
  proposal(
    b: Pick<Booking, 'accountId' | 'text' | 'amount' | 'kind'>,
  ): { template: SplitTemplate; proposal: SplitProposal } | null {
    const t = findTemplate(this.templates(), b as Booking);
    const p = t ? proposeSplit(t, -b.amount) : null;
    return t && p ? { template: t, proposal: p } : null;
  }

  /** Aus einer von Hand aufgeteilten Ausgabe lernen; danach frühere Abbuchungen zum Übernehmen anbieten */
  async learn(b: Booking): Promise<void> {
    const existing = this.templates().find((t) => findTemplate([t], b));
    const t = learnTemplate(existing, b, todayLocal());
    if (!t) return;
    await this.store.save(t);
    const items = retroCandidates(t, this.bookings.bookings(), b.id);
    this.retro.set(items.length ? { template: t, items } : null);
  }

  /** Auf eine neue Buchung anwenden (Import): genau passend = sicher, angepasst oder mit Rest = „Zu prüfen“ */
  apply(b: Booking): Booking {
    if (b.kind !== 'ausgabe' || b.splits.length > 1) return b;
    const hit = this.proposal(b);
    if (!hit) return b;
    const p = hit.proposal;
    const note = p.exact
      ? undefined
      : p.rest
        ? `Aufteilung nach Vorlage; ${formatEuro(p.rest)} sind keinem bekannten Teil zuzuordnen.`
        : `Aufteilung nach Vorlage; Beiträge um ${formatEuro(p.adjustment)} angepasst, bitte prüfen.`;
    return {
      ...b,
      splits: p.splits,
      confidence: p.exact ? 'sicher' : 'unsicher',
      ...(note ? { note } : {}),
    };
  }

  async applyRetro(): Promise<number> {
    const r = this.retro();
    if (!r) return 0;
    const changed = r.items.map(({ booking, proposal }) => ({
      ...booking,
      splits: proposal.splits,
      confidence: 'sicher' as const,
      note: booking.note || `Aufgeteilt wie „${r.template.label}“`,
    }));
    await this.bookings.applyBatch(changed, []);
    if (changed.length >= 10) await this.prefs.markBigChange();
    this.retro.set(null);
    return changed.length;
  }

  dismissRetro(): void {
    this.retro.set(null);
  }

  async remove(id: string): Promise<void> {
    await this.store.remove(id);
  }
}
