import { Injectable } from '@angular/core';

interface PrfResult {
  enabled?: boolean;
  results?: { first?: ArrayBuffer };
}
export type PasskeyFailure = 'abgebrochen' | 'nicht-verfuegbar' | 'kein-prf' | 'fehler';
export class PasskeyError extends Error {
  constructor(
    readonly reason: PasskeyFailure,
    message: string,
  ) {
    super(message);
  }
}

/**
 * Passkey mit PRF-Erweiterung (Bauplan 5.3). Es gibt keinen Server: Die Anmeldung wird nicht
 * geprüft, entscheidend ist allein das PRF-Ergebnis, das nur das Gerät nach dem Fingerabdruck liefert.
 */
@Injectable({ providedIn: 'root' })
export class PasskeyService {
  async isAvailable(): Promise<boolean> {
    try {
      return (
        !!window.PublicKeyCredential &&
        (await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable())
      );
    } catch {
      return false;
    }
  }

  /** true/false, wenn der Browser es verrät; null, wenn er es nicht verrät. */
  async prfCapability(): Promise<boolean | null> {
    const pkc = window.PublicKeyCredential as unknown as
      { getClientCapabilities?: () => Promise<Record<string, boolean>> } | undefined;
    if (!pkc?.getClientCapabilities) return null;
    try {
      const c = await pkc.getClientCapabilities();
      return 'extension:prf' in c ? !!c['extension:prf'] : null;
    } catch {
      return null;
    }
  }

  /** Legt einen Passkey an und liefert seine ID und, falls möglich, gleich das PRF-Ergebnis. */
  async register(prfSalt: Uint8Array<ArrayBuffer>): Promise<{
    credentialId: Uint8Array<ArrayBuffer>;
    prf: Uint8Array<ArrayBuffer> | null;
    prfEnabled: boolean;
  }> {
    if (!(await this.isAvailable()))
      throw new PasskeyError(
        'nicht-verfuegbar',
        'Auf diesem Gerät sind keine Passkeys mit Fingerabdruck verfügbar.',
      );
    let cred: PublicKeyCredential;
    try {
      cred = (await navigator.credentials.create({
        publicKey: {
          rp: { name: 'Mein Haushaltsbuch', id: location.hostname },
          user: {
            id: crypto.getRandomValues(new Uint8Array(16)),
            name: 'Haushaltsbuch',
            displayName: 'Mein Haushaltsbuch',
          },
          challenge: crypto.getRandomValues(new Uint8Array(32)),
          pubKeyCredParams: [
            { type: 'public-key', alg: -7 },
            { type: 'public-key', alg: -257 },
          ],
          authenticatorSelection: {
            authenticatorAttachment: 'platform',
            residentKey: 'required',
            userVerification: 'required',
          },
          timeout: 120000,
          extensions: { prf: { eval: { first: prfSalt } } } as AuthenticationExtensionsClientInputs,
        },
      })) as PublicKeyCredential;
    } catch (e) {
      throw this.translate(e);
    }
    const prf = (cred.getClientExtensionResults() as { prf?: PrfResult }).prf;
    return {
      credentialId: new Uint8Array(cred.rawId),
      prf: prf?.results?.first ? new Uint8Array(prf.results.first) : null,
      prfEnabled: !!prf?.enabled || !!prf?.results?.first,
    };
  }

  /** Fragt den Passkey ab (Fingerabdruck) und liefert das PRF-Ergebnis. */
  async evaluate(
    credentialId: Uint8Array<ArrayBuffer>,
    prfSalt: Uint8Array<ArrayBuffer>,
  ): Promise<Uint8Array<ArrayBuffer>> {
    let cred: PublicKeyCredential;
    try {
      cred = (await navigator.credentials.get({
        publicKey: {
          challenge: crypto.getRandomValues(new Uint8Array(32)),
          rpId: location.hostname,
          allowCredentials: [{ type: 'public-key', id: credentialId }],
          userVerification: 'required',
          timeout: 120000,
          extensions: { prf: { eval: { first: prfSalt } } } as AuthenticationExtensionsClientInputs,
        },
      })) as PublicKeyCredential;
    } catch (e) {
      throw this.translate(e);
    }
    const first = (cred.getClientExtensionResults() as { prf?: PrfResult }).prf?.results?.first;
    if (!first)
      throw new PasskeyError(
        'kein-prf',
        'Der Passkey liefert keinen Schlüssel (PRF wird nicht unterstützt).',
      );
    return new Uint8Array(first);
  }

  private translate(e: unknown): PasskeyError {
    const name = (e as { name?: string })?.name;
    if (name === 'NotAllowedError' || name === 'AbortError')
      return new PasskeyError(
        'abgebrochen',
        'Abgebrochen oder Zeit abgelaufen. Bitte nochmal versuchen.',
      );
    if (name === 'NotSupportedError' || name === 'SecurityError')
      return new PasskeyError(
        'nicht-verfuegbar',
        'Passkeys werden hier nicht unterstützt. Ist die App über https geöffnet?',
      );
    return new PasskeyError('fehler', `Unerwarteter Fehler: ${name ?? String(e)}`);
  }
}
