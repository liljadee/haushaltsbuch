// @vitest-environment node
import { describe, expect, it } from 'vitest';
import { toBase64 } from '../../domain/shared/base64';
import { generateRecoveryKey } from '../../domain/shared/recovery-key';
import {
  createBackup,
  parseBackupFile,
  readBackupContent,
  unlockBackup,
} from '../backup/backup-format';
import {
  generateDataKey,
  passkeyKek,
  passwordKek,
  randomBytes,
  recoveryKek,
  unwrapDataKey,
  wrapDataKey,
} from './key-derivation';
import { decryptRecord, encryptRecord } from './record-crypto';

const rnd = (n: number) => crypto.getRandomValues(new Uint8Array(n));

describe('Schlüsselhierarchie', () => {
  it('entpackt den Datenschlüssel über alle drei Wege', async () => {
    const dk = await generateDataKey();
    const rec = await encryptRecord(dk, 'testdata', 'k', { a: 1 });
    const prf = randomBytes(32),
      s1 = randomBytes(16),
      s2 = randomBytes(16),
      s3 = randomBytes(16),
      key = generateRecoveryKey(rnd);
    const ways: [CryptoKey, () => Promise<CryptoKey>][] = [
      [await passkeyKek(prf, s1), () => passkeyKek(prf, s1)],
      [await recoveryKek(key, s2), () => recoveryKek(key, s2)],
      [
        await passwordKek('ein langes Passwort', s3, 1000),
        () => passwordKek('ein langes Passwort', s3, 1000),
      ],
    ];
    for (const [kek, again] of ways) {
      const w = await wrapDataKey(dk, kek);
      expect(w.byteLength).toBe(40);
      const back = await unwrapDataKey(w, await again());
      expect(await decryptRecord(back, 'testdata', rec)).toEqual({ a: 1 });
      expect(back.extractable).toBe(false);
    }
  });
  it('lehnt falsche Geheimnisse ab', async () => {
    const dk = await generateDataKey(),
      salt = randomBytes(16);
    const w = await wrapDataKey(dk, await recoveryKek('A'.repeat(30), salt));
    await expect(unwrapDataKey(w, await recoveryKek('B'.repeat(30), salt))).rejects.toThrow();
    const wp = await wrapDataKey(dk, await passwordKek('richtig-richtig', salt, 1000));
    await expect(
      unwrapDataKey(wp, await passwordKek('falsch-falsch!', salt, 1000)),
    ).rejects.toThrow();
  });
  it('erkennt umkopierte oder veränderte Datensätze', async () => {
    const dk = await generateDataKey();
    const rec = await encryptRecord(dk, 'testdata', '2026-11', [1, 2, 3]);
    await expect(decryptRecord(dk, 'testdata', { ...rec, key: '2026-12' })).rejects.toThrow();
    await expect(decryptRecord(dk, 'bookings', rec)).rejects.toThrow();
    const ct = rec.ct.slice(0, 5) + (rec.ct[5] === 'A' ? 'B' : 'A') + rec.ct.slice(6);
    await expect(decryptRecord(dk, 'testdata', { ...rec, ct })).rejects.toThrow();
  });
  it('nutzt bei jedem Schreiben einen neuen IV', async () => {
    const dk = await generateDataKey();
    const a = await encryptRecord(dk, 's', 'k', 'x'),
      b = await encryptRecord(dk, 's', 'k', 'x');
    expect(a.iv).not.toBe(b.iv);
    expect(a.ct).not.toBe(b.ct);
  });
});

describe('Backup .hhb', () => {
  it('lässt sich mit dem Wiederherstellungsschlüssel und dem Passwort öffnen', async () => {
    const dk = await generateDataKey(),
      key = generateRecoveryKey(rnd),
      rs = randomBytes(16),
      ps = randomBytes(16);
    const wrapped = {
      recovery: {
        salt: toBase64(rs),
        wrappedKey: toBase64(await wrapDataKey(dk, await recoveryKek(key, rs))),
      },
      password: {
        salt: toBase64(ps),
        iterations: 1000,
        wrappedKey: toBase64(
          await wrapDataKey(dk, await passwordKek('mein-app-passwort', ps, 1000)),
        ),
      },
    };
    const content = {
      stores: {
        testdata: [
          {
            key: 'eintraege',
            value: [{ id: '1', amount: -1234, text: 'Bäckerei Müller', date: '2026-11-16' }],
          },
        ],
      },
    };
    const file = parseBackupFile(JSON.stringify(await createBackup(dk, wrapped, content, '0.1.0')));
    expect(file.payload.data).not.toContain('Müller');
    expect(await readBackupContent(file, await unlockBackup(file, { recoveryKey: key }))).toEqual(
      content,
    );
    expect(
      await readBackupContent(file, await unlockBackup(file, { password: 'mein-app-passwort' })),
    ).toEqual(content);
    await expect(unlockBackup(file, { recoveryKey: 'Z'.repeat(30) })).rejects.toThrow(
      'passt nicht',
    );
  });
  it('meldet fremde, neuere und beschädigte Dateien verständlich', async () => {
    expect(() => parseBackupFile('kein json')).toThrow('kein Haushaltsbuch-Backup');
    expect(() => parseBackupFile('{"format":"x"}')).toThrow('kein Haushaltsbuch-Backup');
    expect(() => parseBackupFile('{"format":"haushaltsbuch-backup","formatVersion":99}')).toThrow(
      'neueren App-Version',
    );
    const dk = await generateDataKey(),
      key = generateRecoveryKey(rnd),
      rs = randomBytes(16);
    const wrapped = {
      recovery: {
        salt: toBase64(rs),
        wrappedKey: toBase64(await wrapDataKey(dk, await recoveryKek(key, rs))),
      },
    };
    const file = await createBackup(dk, wrapped, { stores: {} }, '0.1.0');
    const broken = {
      ...file,
      payload: { ...file.payload, data: file.payload.data.slice(0, -8) + 'AAAAAAA=' },
    };
    await expect(
      readBackupContent(broken, await unlockBackup(broken, { recoveryKey: key })),
    ).rejects.toThrow('beschädigt');
  });
});
