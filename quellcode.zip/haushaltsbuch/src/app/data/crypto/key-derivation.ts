/**
 * Schlüsselableitung und -verpackung (Bauplan 5.2). Nur Web Crypto, keine Bibliotheken.
 * Ein zufälliger Datenschlüssel (AES-256-GCM) verschlüsselt alle Datensätze. Er liegt bis zu
 * dreifach verpackt (AES-KW) in meta: mit dem Passkey-Schlüssel, dem Wiederherstellungsschlüssel
 * und optional dem App-Passwort.
 */
const enc = new TextEncoder();
export const INFO_PASSKEY = 'haushaltsbuch/v1/passkey-kek';
export const INFO_RECOVERY = 'haushaltsbuch/v1/recovery-kek';
export const PBKDF2_ITERATIONS = 600_000;
export const MIN_PASSWORD_LENGTH = 12;

export function randomBytes(n: number): Uint8Array<ArrayBuffer> {
  return crypto.getRandomValues(new Uint8Array(n));
}

export async function generateDataKey(): Promise<CryptoKey> {
  // extrahierbar nur, damit er verpackt werden kann; entpackt wird er nicht extrahierbar.
  return crypto.subtle.generateKey({ name: 'AES-GCM', length: 256 }, true, ['encrypt', 'decrypt']);
}

/** HKDF-SHA-256 → Schlüssel zum Verpacken (AES-KW 256). */
export async function hkdfKek(
  ikm: BufferSource,
  salt: BufferSource,
  info: string,
): Promise<CryptoKey> {
  const base = await crypto.subtle.importKey('raw', ikm, 'HKDF', false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    { name: 'HKDF', hash: 'SHA-256', salt, info: enc.encode(info) },
    base,
    { name: 'AES-KW', length: 256 },
    false,
    ['wrapKey', 'unwrapKey'],
  );
}

/** Wiederherstellungsschlüssel (normalisiert, 30 Zeichen) → Verpackungsschlüssel. */
export function recoveryKek(normalizedKey: string, salt: BufferSource): Promise<CryptoKey> {
  return hkdfKek(enc.encode(normalizedKey), salt, INFO_RECOVERY);
}

/** PRF-Ergebnis des Passkeys → Verpackungsschlüssel. */
export function passkeyKek(prfOutput: BufferSource, salt: BufferSource): Promise<CryptoKey> {
  return hkdfKek(prfOutput, salt, INFO_PASSKEY);
}

/** App-Passwort → Verpackungsschlüssel über PBKDF2-HMAC-SHA-256. */
export async function passwordKek(
  password: string,
  salt: BufferSource,
  iterations = PBKDF2_ITERATIONS,
): Promise<CryptoKey> {
  const base = await crypto.subtle.importKey(
    'raw',
    enc.encode(password.normalize('NFC')),
    'PBKDF2',
    false,
    ['deriveKey'],
  );
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', hash: 'SHA-256', salt, iterations },
    base,
    { name: 'AES-KW', length: 256 },
    false,
    ['wrapKey', 'unwrapKey'],
  );
}

export async function wrapDataKey(
  dataKey: CryptoKey,
  kek: CryptoKey,
): Promise<Uint8Array<ArrayBuffer>> {
  return new Uint8Array(await crypto.subtle.wrapKey('raw', dataKey, kek, 'AES-KW'));
}

/** Entpackt den Datenschlüssel; falscher Schlüssel → Fehler (AES-KW prüft die Integrität). */
export function unwrapDataKey(
  wrapped: BufferSource,
  kek: CryptoKey,
  extractable = false,
): Promise<CryptoKey> {
  return crypto.subtle.unwrapKey(
    'raw',
    wrapped,
    kek,
    'AES-KW',
    { name: 'AES-GCM', length: 256 },
    extractable,
    ['encrypt', 'decrypt'],
  );
}
