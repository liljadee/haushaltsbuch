import { fromBase64, toBase64 } from '../../domain/shared/base64';

/** Verschlüsselter Datensatz in IndexedDB (Bauplan 5.1). */
export interface EncryptedRecord {
  key: string;
  v: number;
  iv: string;
  ct: string;
}

const enc = new TextEncoder();
const dec = new TextDecoder();

/** Zusatzdaten: Speichername und Schlüssel – ein Datensatz lässt sich nicht unbemerkt umkopieren. */
const aad = (store: string, key: string) => enc.encode(`${store}|${key}`);

export async function encryptRecord(
  dataKey: CryptoKey,
  store: string,
  key: string,
  value: unknown,
  v = 1,
): Promise<EncryptedRecord> {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv, additionalData: aad(store, key) },
    dataKey,
    enc.encode(JSON.stringify(value)),
  );
  return { key, v, iv: toBase64(iv), ct: toBase64(ct) };
}

export async function decryptRecord<T>(
  dataKey: CryptoKey,
  store: string,
  rec: EncryptedRecord,
): Promise<T> {
  const pt = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv: fromBase64(rec.iv), additionalData: aad(store, rec.key) },
    dataKey,
    fromBase64(rec.ct),
  );
  return JSON.parse(dec.decode(pt)) as T;
}

export async function gzip(data: Uint8Array<ArrayBuffer>): Promise<Uint8Array<ArrayBuffer>> {
  const stream = new Blob([data]).stream().pipeThrough(new CompressionStream('gzip'));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}

export async function gunzip(data: Uint8Array<ArrayBuffer>): Promise<Uint8Array<ArrayBuffer>> {
  const stream = new Blob([data]).stream().pipeThrough(new DecompressionStream('gzip'));
  return new Uint8Array(await new Response(stream).arrayBuffer());
}
