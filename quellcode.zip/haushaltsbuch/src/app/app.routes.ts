import { inject } from '@angular/core';
import { CanActivateFn, Router, Routes } from '@angular/router';
import { CheckPage } from './features/check/check.page';
import { NewEntryPage } from './features/new-entry/new-entry.page';
import { SettingsPage } from './features/settings/settings.page';
import { SetupPage } from './features/setup/setup.page';
import { StartPage } from './features/start/start.page';
import { UnlockPage } from './features/unlock/unlock.page';
import { TestDataStore } from './data/stores/testdata.store';
import { VaultService } from './data/vault.service';

/** Sperr-Guard (Bauplan 7): gesperrt → Entsperren, danach direkt zum gemerkten Ziel. */
const unlocked: CanActivateFn = async (_route, state) => {
  // Alle Dienste vor dem ersten await holen (Angular erlaubt inject nur synchron).
  const vault = inject(VaultService),
    router = inject(Router),
    store = inject(TestDataStore);
  await vault.ready;
  if (vault.status() === 'neu') return router.parseUrl('/einrichtung');
  if (vault.status() !== 'entsperrt')
    return router.createUrlTree(['/entsperren'], { queryParams: { ziel: state.url } });
  await store.load();
  return true;
};
const notSetUp: CanActivateFn = async () => {
  const vault = inject(VaultService),
    router = inject(Router);
  await vault.ready;
  return vault.status() === 'neu' || vault.status() === 'entsperrt'
    ? true
    : router.parseUrl('/entsperren');
};
const locked: CanActivateFn = async () => {
  const vault = inject(VaultService),
    router = inject(Router);
  await vault.ready;
  if (vault.status() === 'neu') return router.parseUrl('/einrichtung');
  return true;
};

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'start' },
  {
    path: 'einrichtung',
    canActivate: [notSetUp],
    component: SetupPage,
    title: 'Einrichtung',
  },
  {
    path: 'entsperren',
    canActivate: [locked],
    component: UnlockPage,
    title: 'Entsperren',
  },
  {
    path: 'start',
    canActivate: [unlocked],
    component: StartPage,
    title: 'Haushaltsbuch',
  },
  {
    path: 'neu',
    canActivate: [unlocked],
    component: NewEntryPage,
    title: 'Neue Buchung',
  },
  {
    path: 'einstellungen',
    canActivate: [unlocked],
    component: SettingsPage,
    title: 'Einstellungen',
  },
  {
    path: 'pruefung',
    component: CheckPage,
    title: 'Machbarkeitsprüfung',
  },
  { path: '**', redirectTo: 'start' },
];
