import { inject } from '@angular/core';
import { CanActivateFn, Router, Routes } from '@angular/router';
import { BookingsPage } from './features/bookings/bookings.page';
import { CheckPage } from './features/check/check.page';
import { LegacyImportPage } from './features/import/legacy-import.page';
import { NewEntryPage } from './features/new-entry/new-entry.page';
import { SettingsPage } from './features/settings/settings.page';
import { SetupPage } from './features/setup/setup.page';
import { OverviewPage } from './features/overview/overview.page';
import { UnlockPage } from './features/unlock/unlock.page';
import { SessionData } from './data/stores/session-data';
import { VaultService } from './data/vault.service';

/** Sperr-Guard (Bauplan 7): gesperrt → Entsperren, danach direkt zum gemerkten Ziel. */
const unlocked: CanActivateFn = async (_route, state) => {
  // Alle Dienste vor dem ersten await holen (Angular erlaubt inject nur synchron).
  const vault = inject(VaultService),
    router = inject(Router),
    data = inject(SessionData);
  await vault.ready;
  if (vault.status() === 'neu') return router.parseUrl('/einrichtung');
  if (vault.status() !== 'entsperrt')
    return router.createUrlTree(['/entsperren'], { queryParams: { ziel: state.url } });
  await data.ensure();
  return true;
};
const notSetUp: CanActivateFn = async () => {
  const vault = inject(VaultService),
    router = inject(Router);
  await vault.ready;
  return vault.status() === 'neu' || vault.status() === 'entsperrt'
    ? true
    : router.parseUrl('/entsperren');
};
const locked: CanActivateFn = async () => {
  const vault = inject(VaultService),
    router = inject(Router);
  await vault.ready;
  if (vault.status() === 'neu') return router.parseUrl('/einrichtung');
  return true;
};

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'start' },
  {
    path: 'einrichtung',
    canActivate: [notSetUp],
    component: SetupPage,
    title: 'Einrichtung',
  },
  {
    path: 'entsperren',
    canActivate: [locked],
    component: UnlockPage,
    title: 'Entsperren',
  },
  {
    path: 'start',
    canActivate: [unlocked],
    component: OverviewPage,
    title: 'Übersicht',
  },
  {
    path: 'buchungen',
    canActivate: [unlocked],
    component: BookingsPage,
    title: 'Buchungen',
  },
  {
    path: 'neu',
    canActivate: [unlocked],
    component: NewEntryPage,
    title: 'Neue Buchung',
  },
  {
    path: 'einstellungen',
    canActivate: [unlocked],
    component: SettingsPage,
    title: 'Einstellungen',
  },
  {
    path: 'import',
    canActivate: [unlocked],
    component: LegacyImportPage,
    title: 'Daten importieren',
  },
  {
    path: 'pruefung',
    component: CheckPage,
    title: 'Machbarkeitsprüfung',
  },
  { path: '**', redirectTo: 'start' },
];
