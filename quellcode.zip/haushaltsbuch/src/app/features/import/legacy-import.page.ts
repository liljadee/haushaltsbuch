import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  computed,
  inject,
  signal,
} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { Router, RouterLink } from '@angular/router';
import {
  LegacyKind,
  LegacyMapping,
  Target,
  catKey,
  commentKey,
  guessAccount,
  parseLegacyWorkbook,
  planLegacyImport,
  sheetKind,
} from '../../domain/import/legacy';
import { suggest } from '../../domain/categories/rules';
import { categoryLabel, guessCategory } from '../../domain/categories/categories';
import { formatDate } from '../../domain/shared/local-date';
import { formatEuro } from '../../domain/shared/money';
import { SheetData, XlsxError, readXlsx } from '../../data/files/xlsx-reader';
import { LegacyImportService } from '../../data/import/legacy-import.service';
import { AccountsStore } from '../../data/stores/accounts.store';
import { BookingsStore } from '../../data/stores/bookings.store';
import { CategoriesStore } from '../../data/stores/categories.store';
import { LegacyMappingStore } from '../../data/stores/legacy-mapping.store';
import { RulesStore } from '../../data/stores/rules.store';
import { SelectValue } from '../../shared/select-value';
import { CategoryPicker } from '../bookings/category-picker';

const KIND_LABEL: Record<LegacyKind, string> = {
  ausgabe: 'Ausgaben',
  einnahme: 'Einnahmen',
  umbuchung: 'Überweisungen',
};

interface Group {
  key: string;
  kind: LegacyKind;
  category: string;
  count: number;
  sum: number;
  comments: { text: string; count: number; key: string; rule: string | null }[];
}

/** Altdaten aus der bisherigen App übernehmen (Lastenheft 11): Datei, Konten, Kategorien, Vorschau, Übernahme. */
@Component({
  selector: 'app-legacy-import-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    MatButtonModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatInputModule,
    RouterLink,
    SelectValue,
    CategoryPicker,
  ],
  templateUrl: './legacy-import.page.html',
  styles: [
    `
      .grid2 {
        display: grid;
        grid-template-columns: 1fr auto;
        gap: 0 10px;
        align-items: center;
      }
      .grp {
        border-top: 1px solid var(--hb-line);
        padding: 10px 0 4px;
      }
      .grp-head {
        display: flex;
        justify-content: space-between;
        gap: 8px;
        font-weight: 600;
      }
      .cm {
        margin: 4px 0 0 12px;
        padding-left: 10px;
        border-left: 3px solid var(--hb-line);
      }
      .cm-row {
        font-size: 14px;
        margin: 8px 0 0;
      }
      .sum {
        display: grid;
        grid-template-columns: 1fr auto;
        gap: 4px 12px;
        margin: 0;
      }
      .sum dt {
        color: var(--hb-muted);
      }
      .sum dd {
        margin: 0;
        text-align: right;
        font-weight: 650;
      }
      .problems {
        font-size: 13px;
        color: var(--hb-muted);
        max-height: 200px;
        overflow: auto;
      }
      .linkish {
        background: none;
        border: 0;
        color: var(--hb-primary);
        text-decoration: underline;
        padding: 0;
        font: inherit;
        cursor: pointer;
      }
    `,
  ],
})
export class LegacyImportPage implements OnInit {
  private readonly accountsStore = inject(AccountsStore);
  private readonly bookings = inject(BookingsStore);
  private readonly cats = inject(CategoriesStore);
  private readonly rules = inject(RulesStore);
  private readonly mappingStore = inject(LegacyMappingStore);
  private readonly importer = inject(LegacyImportService);
  private readonly router = inject(Router);

  protected readonly accounts = this.accountsStore.active;
  protected readonly fileName = signal('');
  protected readonly sheets = signal<SheetData[]>([]);
  protected readonly kinds = signal<Record<string, LegacyKind | null>>({});
  protected readonly mapping = signal<LegacyMapping>({
    categories: {},
    comments: {},
    accounts: {},
  });
  protected readonly onlyBefore = signal(true);
  protected readonly replaceLegacy = signal(false);
  protected readonly existingLegacy = computed(
    () => this.bookings.bookings().filter((b) => b.source.type === 'xlsx').length,
  );
  protected readonly openGroup = signal<string | null>(null);
  protected readonly error = signal('');
  protected readonly busy = signal(false);
  private fp = '';
  protected readonly euro = formatEuro;
  protected readonly de = formatDate;
  protected readonly kindLabel = KIND_LABEL;
  protected readonly kindOptions = Object.entries(KIND_LABEL) as [LegacyKind, string][];

  protected readonly parsed = computed(() => parseLegacyWorkbook(this.sheets(), this.kinds()));
  protected readonly plan = computed(() =>
    planLegacyImport(
      this.parsed(),
      this.mapping(),
      this.accounts(),
      this.bookings.bookings(),
      this.rules.rules(),
      this.cats.categories(),
      this.onlyBefore(),
      this.replaceLegacy(),
    ),
  );
  protected readonly accountNames = computed(() => {
    const m = new Map<string, number>();
    for (const r of this.parsed().rows) {
      m.set(r.account, (m.get(r.account) ?? 0) + 1);
      if (r.kind === 'umbuchung') m.set(r.category, (m.get(r.category) ?? 0) + 1);
    }
    return [...m.entries()]
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count);
  });
  protected readonly groups = computed<Group[]>(() => {
    const m = new Map<string, Group>();
    for (const r of this.parsed().rows) {
      if (r.kind === 'umbuchung') continue;
      const key = catKey(r.kind, r.category);
      const g = m.get(key) ?? {
        key,
        kind: r.kind,
        category: r.category,
        count: 0,
        sum: 0,
        comments: [],
      };
      g.count++;
      g.sum += r.kind === 'ausgabe' ? -r.amount : r.amount;
      if (r.comment) {
        const ck = commentKey(r.kind, r.category, r.comment);
        const c = g.comments.find((x) => x.key === ck);
        if (c) c.count++;
        else {
          const s = suggest(
            r.comment,
            r.kind === 'ausgabe' ? -r.amount : r.amount,
            null,
            this.rules.rules(),
            this.cats.categories(),
          );
          g.comments.push({
            text: r.comment,
            count: 1,
            key: ck,
            rule:
              s.confidence === 'sicher'
                ? categoryLabel(this.cats.categories(), s.categoryId, s.subCategory)
                : null,
          });
        }
      }
      m.set(key, g);
    }
    return [...m.values()]
      .map((g) => ({ ...g, comments: g.comments.sort((a, b) => b.count - a.count).slice(0, 30) }))
      .sort((a, b) => a.kind.localeCompare(b.kind) || b.count - a.count);
  });
  protected readonly range = computed(() => {
    const d = this.plan()
      .rows.filter((r) => r.include)
      .map((r) => r.src.date)
      .sort();
    return d.length ? `${formatDate(d[0])} bis ${formatDate(d[d.length - 1])}` : '';
  });

  async ngOnInit(): Promise<void> {
    this.mapping.set(await this.mappingStore.load());
  }

  protected val(ev: Event): string {
    return (ev.target as HTMLInputElement).value;
  }

  protected async pickFile(ev: Event): Promise<void> {
    const f = (ev.target as HTMLInputElement).files?.[0];
    this.error.set('');
    this.sheets.set([]);
    if (!f) return;
    this.busy.set(true);
    try {
      const buf = await f.arrayBuffer();
      const sheets = await readXlsx(buf);
      this.fp = await this.importer.fingerprint(buf);
      this.kinds.set(Object.fromEntries(sheets.map((s) => [s.name, sheetKind(s.name)])));
      this.sheets.set(sheets);
      this.fileName.set(f.name);
      // Konten vorschlagen, wo noch keine Zuordnung besteht
      const m = { ...this.mapping(), accounts: { ...this.mapping().accounts } };
      for (const { name } of this.accountNames())
        if (!(name in m.accounts) || !this.accounts().some((a) => a.id === m.accounts[name]))
          m.accounts[name] = guessAccount(name, this.accounts());
      // unsere Kategorienamen in Spalte B von selbst zuordnen (z. B. „Haushalt › Lebensmittel“)
      for (const g of this.groups()) {
        if (m.categories[g.key]) continue;
        const guess = guessCategory(
          g.category,
          g.kind === 'ausgabe' ? 'ausgabe' : 'einnahme',
          this.cats.categories(),
        );
        if (guess) m.categories = { ...m.categories, [g.key]: guess };
      }
      this.mapping.set(m);
      if (!this.parsed().rows.length)
        this.error.set(
          'In der Datei wurden keine Buchungen erkannt. Prüfe unten, welches Blatt was enthält.',
        );
    } catch (e) {
      this.error.set(
        e instanceof XlsxError
          ? e.message
          : 'Die Datei ließ sich nicht lesen. Ist es die .xlsx-Datei aus der alten App?',
      );
    } finally {
      this.busy.set(false);
    }
  }

  protected setKind(sheet: string, v: string): void {
    this.kinds.update((k) => ({ ...k, [sheet]: (v || null) as LegacyKind | null }));
  }

  protected setAccount(name: string, id: string): void {
    this.mapping.update((m) => ({ ...m, accounts: { ...m.accounts, [name]: id || null } }));
  }

  protected setCategory(
    key: string,
    t: { categoryId: string | null; subCategory: string | null },
  ): void {
    const v: Target | null = t.categoryId
      ? { categoryId: t.categoryId, subCategory: t.subCategory }
      : null;
    this.mapping.update((m) => ({ ...m, categories: { ...m.categories, [key]: v } }));
  }

  protected setTransfer(key: string, accountId: string, comment = false): void {
    const v: Target | null = accountId
      ? { categoryId: null, subCategory: null, transferTo: accountId }
      : null;
    this.mapping.update((m) =>
      comment
        ? { ...m, comments: { ...m.comments, [key]: v } }
        : { ...m, categories: { ...m.categories, [key]: v } },
    );
  }

  protected setComment(
    key: string,
    t: { categoryId: string | null; subCategory: string | null },
  ): void {
    const v: Target | null = t.categoryId
      ? { categoryId: t.categoryId, subCategory: t.subCategory }
      : null;
    this.mapping.update((m) => ({ ...m, comments: { ...m.comments, [key]: v } }));
  }

  protected toggleGroup(key: string): void {
    this.openGroup.set(this.openGroup() === key ? null : key);
  }

  protected async commit(): Promise<void> {
    this.busy.set(true);
    try {
      await this.mappingStore.save(this.mapping());
      const n = await this.importer.commit(this.plan(), this.fp, this.replaceLegacy());
      void this.router.navigate(['/start'], {
        state: {
          msg: `${n} Buchungen aus der alten App übernommen. Du findest sie unter „Buchungen“ (ältere über „Ältere Buchungen anzeigen“).`,
        },
      });
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : String(e));
    } finally {
      this.busy.set(false);
    }
  }
}
