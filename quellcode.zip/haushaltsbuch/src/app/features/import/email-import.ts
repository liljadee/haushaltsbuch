import {
  ChangeDetectionStrategy,
  Component,
  computed,
  effect,
  inject,
  output,
  signal,
} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { buildPreview } from '../../domain/import/import-preview';
import { gapMessage, parseKontowecker } from '../../domain/import/kontowecker-parser';
import { formatDate, todayLocal } from '../../domain/shared/local-date';
import { formatEuro } from '../../domain/shared/money';
import { EmailImportService, ImportRow } from '../../data/import/email-import.service';
import { AccountsStore } from '../../data/stores/accounts.store';
import { BookingsStore } from '../../data/stores/bookings.store';
import { CategoriesStore } from '../../data/stores/categories.store';
import { RulesStore } from '../../data/stores/rules.store';
import { SelectValue } from '../../shared/select-value';
import { CategoryPicker } from '../bookings/category-picker';

interface Override {
  categoryId?: string | null;
  subCategory?: string | null;
  include?: boolean;
  transferTo?: string | null;
}

/** Kontowecker-E-Mail einfügen, prüfen, übernehmen (Lastenheft 8.1, 8.2, 8.4a). */
@Component({
  selector: 'app-email-import',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    MatButtonModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatInputModule,
    CategoryPicker,
    SelectValue,
  ],
  templateUrl: './email-import.html',
  styles: [
    `
      textarea {
        font:
          14px/1.4 ui-monospace,
          monospace;
      }
      .row {
        border-top: 1px solid var(--hb-line);
        padding: 10px 0 2px;
      }
      .head {
        display: grid;
        grid-template-columns: auto 1fr auto;
        gap: 8px;
        align-items: center;
      }
      .t {
        font-weight: 600;
      }
      .amt {
        font-weight: 650;
        white-space: nowrap;
      }
      .pos {
        color: var(--hb-primary);
      }
      .tag {
        font-size: 12px;
        border-radius: 8px;
        padding: 1px 6px;
        margin-left: 4px;
        border: 1px solid var(--hb-line);
      }
      .tag.ok {
        border-color: var(--hb-primary);
        color: var(--hb-primary-ink);
      }
      .tag.todo {
        background: var(--hb-warn-soft);
        color: var(--hb-warn-ink);
        border-color: transparent;
      }
      .off {
        opacity: 0.55;
      }
      .unknown {
        font-size: 13px;
        color: var(--hb-muted);
      }
    `,
  ],
})
export class EmailImport {
  private readonly accounts = inject(AccountsStore);
  private readonly bookings = inject(BookingsStore);
  private readonly cats = inject(CategoriesStore);
  private readonly rules = inject(RulesStore);
  private readonly importer = inject(EmailImportService);
  readonly done = output<string>();

  protected readonly text = signal('');
  protected readonly date = signal(todayLocal());
  protected readonly chosenAccount = signal<string | null>(null);
  protected readonly overrides = signal<Record<number, Override>>({});
  protected readonly fp = signal('');
  protected readonly busy = signal(false);
  protected readonly error = signal('');
  protected readonly today = todayLocal();
  protected readonly euro = formatEuro;
  protected readonly de = formatDate;
  protected readonly activeAccounts = this.accounts.active;

  protected readonly parsed = computed(() => parseKontowecker(this.text()));
  protected readonly preview = computed(() =>
    buildPreview(
      this.parsed(),
      this.accounts.active(),
      this.bookings.bookings(),
      this.rules.rules(),
      this.cats.categories(),
      this.date(),
      this.fp(),
      this.chosenAccount(),
    ),
  );
  protected readonly rows = computed<ImportRow[]>(() =>
    this.preview().rows.map((r, i) => {
      const o = this.overrides()[i] ?? {};
      const picked = 'categoryId' in o;
      return {
        text: r.text,
        amount: r.amount,
        include: o.include ?? r.include,
        categoryId: picked ? (o.categoryId ?? null) : r.suggestion.categoryId,
        subCategory: picked ? (o.subCategory ?? null) : r.suggestion.subCategory,
        confirmed: picked ? !!o.categoryId : r.suggestion.confidence === 'sicher',
        transferTo: o.transferTo ?? null,
      };
    }),
  );
  protected readonly count = computed(() => this.rows().filter((r) => r.include).length);
  protected readonly reconcileText = computed(() => gapMessage(this.preview().reconciliation));

  constructor() {
    effect(() => {
      const t = this.text();
      void this.importer.fingerprint(t).then((fp) => this.fp.set(fp));
    });
  }

  protected val(ev: Event): string {
    return (ev.target as HTMLInputElement).value;
  }

  protected setText(t: string): void {
    this.text.set(t);
    this.overrides.set({});
    this.chosenAccount.set(null);
    this.error.set('');
  }

  protected async paste(): Promise<void> {
    try {
      this.setText(await navigator.clipboard.readText());
    } catch {
      this.error.set(
        'Einfügen aus der Zwischenablage ging nicht. Bitte lange ins Textfeld tippen und „Einfügen“ wählen.',
      );
    }
  }

  protected override(i: number, o: Override): void {
    this.overrides.update((m) => ({ ...m, [i]: { ...m[i], ...o } }));
  }

  protected tag(i: number): { cls: string; text: string } {
    const r = this.preview().rows[i],
      row = this.rows()[i];
    if (r.duplicateOf) return { cls: 'todo', text: 'schon vorhanden' };
    if (row.transferTo) return { cls: 'ok', text: 'Umbuchung' };
    if (!row.categoryId) return { cls: 'todo', text: 'bitte zuordnen' };
    if (!row.confirmed) return { cls: 'todo', text: 'bitte prüfen' };
    return { cls: 'ok', text: 'erkannt' };
  }

  protected otherAccounts() {
    const own = this.preview().account?.id;
    return this.activeAccounts().filter((a) => a.id !== own);
  }

  protected async commit(): Promise<void> {
    const p = this.preview();
    if (!p.account) return this.error.set('Bitte das Konto wählen.');
    this.busy.set(true);
    try {
      const n = await this.importer.commit(
        p,
        this.rows(),
        this.date(),
        this.parsed().newBalance,
        this.fp(),
      );
      const gap = this.reconcileText();
      this.done.emit(
        `${n} ${n === 1 ? 'Buchung' : 'Buchungen'} übernommen.${gap ? ' ' + gap : ''}`,
      );
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : String(e));
    } finally {
      this.busy.set(false);
    }
  }
}
