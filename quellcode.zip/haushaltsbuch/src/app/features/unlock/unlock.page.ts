import { MatInput } from '@angular/material/input';
import { MatFormField, MatLabel } from '@angular/material/form-field';
import { MatButton } from '@angular/material/button';
import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { normalizeRecoveryKey, recoveryKeyProblem } from '../../domain/shared/recovery-key';
import { PasskeyError } from '../../data/crypto/passkey.service';
import { VaultService } from '../../data/vault.service';
import { Icon } from '../../shared/icon';

@Component({
  selector: 'app-unlock-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, Icon, MatButton, MatFormField, MatLabel, MatInput],
  template: `
    <div class="page">
      <h1>Haushaltsbuch ist gesperrt</h1>
      @if (vault.meta()?.passkey) {
        <div class="card">
          <button
            mat-flat-button
            type="button"
            class="full big"
            data-testid="unlock-passkey"
            [disabled]="busy()"
            (click)="withPasskey()"
          >
            <app-icon name="fingerprint" /> Mit Fingerabdruck entsperren
          </button>
        </div>
      }
      @if (error()) {
        <p class="bad" role="alert">{{ error() }}</p>
      }

      @if (vault.meta()?.password) {
        <div class="card">
          @if (mode() !== 'passwort') {
            <button
              mat-stroked-button
              type="button"
              class="full"
              data-testid="show-pw"
              (click)="mode.set('passwort')"
            >
              Mit App-Passwort entsperren
            </button>
          } @else {
            <mat-form-field appearance="outline">
              <mat-label>App-Passwort</mat-label>
              <input
                matInput
                type="password"
                data-testid="unlock-pw"
                autocomplete="current-password"
                [value]="pw"
                (input)="pw = val($event)"
                (keyup.enter)="withPassword()"
              />
            </mat-form-field>
            <button
              mat-flat-button
              type="button"
              data-testid="unlock-pw-go"
              [disabled]="busy()"
              (click)="withPassword()"
            >
              {{ busy() ? 'Einen Moment …' : 'Entsperren' }}
            </button>
          }
        </div>
      }

      <div class="card">
        @if (mode() === 'wiederherstellung') {
          @if (!recovered()) {
            <p>Gib deinen Wiederherstellungsschlüssel vom Zettel ein.</p>
            <mat-form-field appearance="outline">
              <mat-label>Wiederherstellungsschlüssel</mat-label>
              <input
                matInput
                data-testid="unlock-recovery"
                autocomplete="off"
                autocapitalize="characters"
                spellcheck="false"
                [value]="key"
                (input)="key = val($event)"
              />
            </mat-form-field>
            <button
              mat-flat-button
              type="button"
              data-testid="unlock-recovery-go"
              [disabled]="busy()"
              (click)="withRecovery()"
            >
              Entsperren
            </button>
          } @else {
            <p class="hint">
              Entsperrt. Willst du für dieses Handy den Fingerabdruck neu einrichten? Danach
              entsperrst du wieder ohne Zettel.
            </p>
            <div class="actions">
              <button
                mat-flat-button
                type="button"
                data-testid="new-passkey"
                [disabled]="busy()"
                (click)="newPasskey()"
              >
                <app-icon name="fingerprint" /> Fingerabdruck neu einrichten
              </button>
              <button mat-button type="button" (click)="done()">Später</button>
            </div>
          }
        } @else {
          <button
            mat-button
            type="button"
            class="full"
            data-testid="show-recovery"
            (click)="mode.set('wiederherstellung')"
          >
            Fingerabdruck klappt nicht? Wiederherstellungsschlüssel verwenden
          </button>
        }
      </div>
      <p class="small muted"><a routerLink="/pruefung">Machbarkeitsprüfung ansehen</a></p>
    </div>
  `,
  styles: ['.big { min-height: 64px; font-size: 17px; }'],
})
export class UnlockPage {
  protected readonly vault = inject(VaultService);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  protected readonly busy = signal(false);
  protected readonly error = signal('');
  protected readonly mode = signal<'' | 'passwort' | 'wiederherstellung'>('');
  protected readonly recovered = signal(false);
  private recoveredKey: CryptoKey | null = null;
  protected pw = '';
  protected key = '';

  protected val(ev: Event): string {
    return (ev.target as HTMLInputElement).value;
  }

  private async run(fn: () => Promise<unknown>, after = true): Promise<void> {
    this.busy.set(true);
    this.error.set('');
    try {
      await fn();
      if (after) this.done();
    } catch (e) {
      this.error.set(e instanceof PasskeyError || e instanceof Error ? e.message : String(e));
    } finally {
      this.busy.set(false);
    }
  }

  protected withPasskey(): Promise<void> {
    return this.run(() => this.vault.unlockWithPasskey());
  }

  protected withPassword(): Promise<void> {
    return this.run(async () => {
      await this.vault.unlockWithPassword(this.pw);
      this.pw = '';
    });
  }

  protected withRecovery(): Promise<void> {
    return this.run(async () => {
      const k = normalizeRecoveryKey(this.key);
      if (!k) throw new Error(recoveryKeyProblem(this.key) ?? 'Der Schlüssel ist ungültig.');
      this.recoveredKey = await this.vault.unlockWithRecovery(k);
      this.key = '';
      this.recovered.set(true);
    }, false);
  }

  protected newPasskey(): Promise<void> {
    return this.run(async () => {
      if (this.recoveredKey) await this.vault.replacePasskey(this.recoveredKey);
      this.recoveredKey = null;
    });
  }

  protected done(): void {
    this.recoveredKey = null;
    const ziel = this.route.snapshot.queryParamMap.get('ziel');
    void this.router.navigateByUrl(
      ziel && ziel.startsWith('/') && !ziel.startsWith('/entsperren') ? ziel : '/start',
    );
  }
}
