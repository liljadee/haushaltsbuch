import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatButton } from '@angular/material/button';
import { toSignal } from '@angular/core/rxjs-interop';
import { NavigationEnd, Router } from '@angular/router';
import { filter, map } from 'rxjs';
import { PrefsStore } from '../../data/stores/prefs.store';
import { TourService } from './tour';

/** Willkommen beim allerersten Start (nur nach der Neueinrichtung): Ersteinrichtung, Führung oder selbst entdecken. */
@Component({
  selector: 'app-welcome',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatButton],
  template: `
    @if (prefs.onboarding() === 'offen' && onOverview()) {
      <div class="veil"></div>
      <section
        class="box"
        role="dialog"
        aria-modal="true"
        aria-labelledby="welcome-title"
        data-testid="welcome"
      >
        <h2 id="welcome-title">Willkommen! Wie möchtest du starten?</h2>
        <button
          mat-flat-button
          type="button"
          class="opt"
          data-testid="welcome-wizard"
          (click)="pick('wizard')"
        >
          Hilf mir bei der Einrichtung
        </button>
        <p class="small muted">
          Ich frage dich nach deinen Konten und lege sie für dich an. Jederzeit abbrechbar.
        </p>
        <button
          mat-stroked-button
          type="button"
          class="opt"
          data-testid="welcome-tour"
          (click)="pick('tour')"
        >
          Zeig mir die App
        </button>
        <p class="small muted">
          Eine kurze Führung erklärt die Bereiche direkt auf dem Bildschirm.
        </p>
        <button
          mat-button
          type="button"
          class="opt"
          data-testid="welcome-self"
          (click)="pick('self')"
        >
          Ich schaue mich selbst um
        </button>
        <p class="small muted">
          Diese Auswahl erscheint nur jetzt. Die Führung findest du später unter Einstellungen →
          Hilfe.
        </p>
      </section>
    }
  `,
  styles: [
    `
      .veil {
        position: fixed;
        inset: 0;
        z-index: 900;
        background: rgb(0 0 0 / 0.5);
      }
      .box {
        position: fixed;
        z-index: 901;
        left: 12px;
        right: 12px;
        top: max(12px, 6vh);
        max-height: calc(100dvh - 24px - max(12px, 6vh));
        overflow-y: auto;
        overscroll-behavior: contain;
        max-width: 460px;
        margin: 0 auto;
        background: var(--hb-surface);
        color: var(--hb-ink);
        border-radius: 18px;
        padding: 18px 18px 10px;
        box-shadow: 0 10px 34px rgb(0 0 0 / 0.3);
      }
      .box h2 {
        margin: 0 0 12px;
        font-size: 20px;
      }
      .opt {
        width: 100%;
        margin-top: 6px;
      }
      .box p {
        margin: 4px 2px 8px;
      }
    `,
  ],
})
export class Welcome {
  protected readonly prefs = inject(PrefsStore);
  private readonly router = inject(Router);
  private readonly tour = inject(TourService);
  /** erst auf der Übersicht zeigen, nicht schon auf der letzten Seite der Einrichtung */
  protected readonly onOverview = toSignal(
    this.router.events.pipe(
      filter((e): e is NavigationEnd => e instanceof NavigationEnd),
      map((e) => e.urlAfterRedirects.startsWith('/start')),
    ),
    { initialValue: this.router.url.startsWith('/start') },
  );

  protected async pick(choice: 'wizard' | 'tour' | 'self'): Promise<void> {
    // sofort erledigt: die Auswahl erscheint nie wieder, auch wenn Einrichtung oder Führung abgebrochen werden
    await this.prefs.setOnboarding('erledigt');
    if (choice === 'wizard') await this.router.navigateByUrl('/willkommen');
    if (choice === 'tour') await this.tour.start();
  }
}
