import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { MatButton } from '@angular/material/button';
import { MatFormField, MatLabel } from '@angular/material/form-field';
import { MatInput } from '@angular/material/input';
import { Router } from '@angular/router';
import {
  cleanRecoveryInput,
  normalizeRecoveryKey,
  recoveryKeyProblem,
} from '../../domain/shared/recovery-key';
import { BackupFile, parseBackupFile } from '../../data/backup/backup-format';
import { AccountsStore } from '../../data/stores/accounts.store';
import { BookingsStore } from '../../data/stores/bookings.store';
import { SessionData } from '../../data/stores/session-data';
import { SetupSession, VaultService } from '../../data/vault.service';

/**
 * Backup in der laufenden App einspielen (z. B. nach Willkommen und Führung): ersetzt alle Daten durch das Backup.
 * Gleicher Weg wie bei der Einrichtung: Backup mit dem Schlüssel öffnen, Fingerabdruck verknüpfen, in einem Schritt schreiben.
 */
@Component({
  selector: 'app-restore-backup',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatButton, MatFormField, MatLabel, MatInput],
  template: `
    <section class="card" data-testid="restore-page">
      <h1>Backup einspielen</h1>
      @if (!session()) {
        <p class="small">
          Wähle die Backup-Datei (endet auf .hhb, auch die Sicherungsdatei aus dem Handyspeicher)
          und gib den Wiederherstellungsschlüssel dieses Backups ein.
        </p>
        <label class="small" for="riFile"><strong>1. Backup-Datei auswählen</strong></label>
        <input
          id="riFile"
          type="file"
          accept=".hhb,application/json"
          data-testid="ri-file"
          (change)="pick($event)"
        />
        @if (info()) {
          <p class="small muted" data-testid="ri-info">{{ info() }}</p>
        }
        <mat-form-field appearance="outline">
          <mat-label>2. Wiederherstellungsschlüssel</mat-label>
          <input
            matInput
            autocomplete="off"
            autocapitalize="characters"
            spellcheck="false"
            data-testid="ri-key"
            [value]="key()"
            (input)="key.set(val($event))"
          />
        </mat-form-field>
        <p class="small muted">{{ count() }} von 30 Zeichen</p>
        <div class="actions">
          <button
            mat-flat-button
            type="button"
            data-testid="ri-open"
            [disabled]="busy()"
            (click)="open()"
          >
            Backup öffnen
          </button>
          <button mat-button type="button" (click)="leave()">Abbrechen</button>
        </div>
      } @else {
        <p data-testid="ri-opened">{{ info() }}</p>
        <p class="warn" data-testid="ri-warning">
          Das Backup ersetzt alle Daten in dieser App{{
            hasData() ? ', auch deine jetzigen Konten und Buchungen' : ''
          }}. Danach gilt der Wiederherstellungsschlüssel des Backups. Bestätige mit deinem
          Fingerabdruck.
        </p>
        <div class="actions">
          <button
            mat-flat-button
            type="button"
            data-testid="ri-apply"
            [disabled]="busy()"
            (click)="apply()"
          >
            Mit Fingerabdruck bestätigen und einspielen
          </button>
          <button mat-button type="button" (click)="leave()">Abbrechen</button>
        </div>
      }
      @if (error()) {
        <p class="warn small" data-testid="ri-error">{{ error() }}</p>
      }
    </section>
  `,
})
export class RestoreBackupPage {
  private readonly vault = inject(VaultService);
  private readonly data = inject(SessionData);
  private readonly router = inject(Router);
  private readonly accounts = inject(AccountsStore);
  private readonly bookings = inject(BookingsStore);
  private file: BackupFile | null = null;
  protected readonly key = signal('');
  protected readonly count = computed(() => cleanRecoveryInput(this.key()).length);
  protected readonly info = signal('');
  protected readonly error = signal('');
  protected readonly busy = signal(false);
  protected readonly session = signal<SetupSession | null>(null);
  protected readonly hasData = computed(
    () => this.accounts.accounts().length > 0 || this.bookings.bookings().length > 0,
  );

  protected val(ev: Event): string {
    return (ev.target as HTMLInputElement).value;
  }

  protected async pick(ev: Event): Promise<void> {
    const f = (ev.target as HTMLInputElement).files?.[0];
    this.file = null;
    this.error.set('');
    this.info.set('');
    if (!f) return;
    try {
      this.file = parseBackupFile(await f.text());
      this.info.set(
        `Backup vom ${new Date(this.file.createdAt).toLocaleString('de-DE')}, App-Version ${this.file.appVersion}.`,
      );
    } catch (e) {
      this.error.set(`Die Datei ist kein Backup dieser App: ${(e as Error).message}`);
    }
  }

  protected async open(): Promise<void> {
    this.error.set('');
    if (!this.file) return this.error.set('Bitte zuerst die Backup-Datei auswählen.');
    const key = normalizeRecoveryKey(this.key());
    if (!key)
      return this.error.set(
        recoveryKeyProblem(this.key()) ?? 'Der Wiederherstellungsschlüssel ist ungültig.',
      );
    this.busy.set(true);
    try {
      const s = await this.vault.startRestore(this.file, key);
      const n = Object.values(s.content?.stores ?? {}).reduce((sum, l) => sum + l.length, 0);
      this.info.set(`Backup geöffnet: ${n} ${n === 1 ? 'Datensatz' : 'Datensätze'}.`);
      this.session.set(s);
    } catch {
      this.error.set('Der Wiederherstellungsschlüssel passt nicht zu diesem Backup.');
    } finally {
      this.busy.set(false);
    }
  }

  protected async apply(): Promise<void> {
    const s = this.session();
    if (!s) return;
    this.busy.set(true);
    this.error.set('');
    try {
      await this.vault.addPasskey(s);
      await this.vault.finishSetup(s, null);
      await this.data.reload();
      this.session.set(null);
      await this.router.navigateByUrl('/start');
    } catch (e) {
      this.error.set(`Nicht eingespielt, deine Daten sind unverändert: ${(e as Error).message}`);
    } finally {
      this.busy.set(false);
    }
  }

  protected leave(): void {
    this.session.set(null);
    void this.router.navigateByUrl('/start');
  }
}
