import {
  ChangeDetectionStrategy,
  Component,
  HostListener,
  Injectable,
  computed,
  effect,
  inject,
  signal,
} from '@angular/core';
import { MatButton } from '@angular/material/button';
import { Router } from '@angular/router';

/** Ein Schritt der Führung: zeigt auf ein Bedienelement (data-testid) und erklärt es in zwei, drei Sätzen. */
export interface TourStep {
  target: string | null;
  title: string;
  text: string;
}

/** Reihenfolge wie beim ersten Gebrauch: Konten, Buchen, Bereiche, Sicherheit. */
export const TOUR: TourStep[] = [
  {
    target: null,
    title: 'Willkommen im Haushaltsbuch',
    text: 'Diese kurze Führung zeigt dir in zehn Schritten, wo was ist. Du kannst sie jederzeit beenden.',
  },
  {
    target: 'acc-new',
    title: 'Zuerst: deine Konten',
    text: 'Hier legst du Girokonto, Tagesgeld und Bausparvertrag an, jeweils mit dem heutigen Kontostand. Damit fängst du an.',
  },
  {
    target: 'fab',
    title: 'Neue Buchung',
    text: 'Mit dem Plus erfasst du Ausgaben, Einnahmen und Umbuchungen, oder du liest die Umsätze aus einer Kontowecker-E-Mail ein.',
  },
  {
    target: 'month-card',
    title: 'Dein Monat auf einen Blick',
    text: 'Einnahmen, Fixkosten, Konsum, Finanzierung und Sparen des laufenden Monats und was frei verfügbar bleibt.',
  },
  {
    target: 'nav-buchungen',
    title: 'Buchungen',
    text: 'Alle Umsätze, ein Kalender und die wiederkehrenden Zahlungen wie Gehalt, Daueraufträge und Verträge.',
  },
  {
    target: 'nav-ruecklagen',
    title: 'Rücklagen',
    text: 'Spartöpfe für Jahreszahlungen und Sparziele. Die App sagt dir, wann du vom Tagesgeld umbuchen solltest; Geld bewegt sie nie selbst.',
  },
  {
    target: 'nav-kredite',
    title: 'Kredite',
    text: 'Restschuld, Tilgungsplan, Sondertilgungen und Bausparvertrag, mit einem Fahrplan, was wann auf dich zukommt.',
  },
  {
    target: 'nav-statistik',
    title: 'Statistik',
    text: 'Wohin das Geld geht: nach Monat, Jahr oder frei gewähltem Zeitraum, aufgeteilt nach Kategorien.',
  },
  {
    target: 'nav-settings',
    title: 'Einstellungen',
    text: 'Hier liegen das Backup, der Export als Excel oder CSV und die Datenabdeckung. Mach regelmäßig ein Backup außerhalb des Handys.',
  },
  {
    target: 'lock-now',
    title: 'Sperren',
    text: 'Sperrt die App sofort. Im Hintergrund sperrt sie sich nach einer Minute von selbst; entsperrt wird mit dem Fingerabdruck.',
  },
  {
    target: null,
    title: 'Fertig',
    text: 'Am besten legst du jetzt dein erstes Konto an. Die Führung findest du später unter Einstellungen → Hilfe.',
  },
];

@Injectable({ providedIn: 'root' })
export class TourService {
  private readonly router = inject(Router);
  readonly index = signal<number | null>(null);
  readonly step = computed(() => {
    const i = this.index();
    return i === null ? null : TOUR[i];
  });

  async start(): Promise<void> {
    await this.router.navigateByUrl('/start');
    this.index.set(0);
  }

  next(): void {
    const i = this.index();
    if (i === null) return;
    let n = i + 1;
    // Schritte ohne sichtbares Ziel überspringen (z. B. Monatskarte ohne Buchungen)
    while (
      n < TOUR.length &&
      TOUR[n].target &&
      !document.querySelector(`[data-testid="${TOUR[n].target}"]`)
    )
      n++;
    this.index.set(n < TOUR.length ? n : null);
  }

  back(): void {
    const i = this.index();
    if (i === null || i === 0) return;
    let n = i - 1;
    while (n > 0 && TOUR[n].target && !document.querySelector(`[data-testid="${TOUR[n].target}"]`))
      n--;
    this.index.set(n);
  }

  end(): void {
    this.index.set(null);
  }
}

/** Hinweisfeld der Führung: dunkelt alles ab außer dem erklärten Element. */
@Component({
  selector: 'app-tour',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatButton],
  template: `
    @if (tour.step(); as s) {
      <div class="veil" [class.solid]="!rect()"></div>
      @if (rect(); as r) {
        <div
          class="spot"
          [style.top.px]="r.top - 6"
          [style.left.px]="r.left - 6"
          [style.width.px]="r.width + 12"
          [style.height.px]="r.height + 12"
        ></div>
      }
      <section
        class="tip"
        role="dialog"
        aria-modal="true"
        [attr.aria-label]="s.title"
        data-testid="tour"
        [style.top.px]="tipTop()"
      >
        <p class="count">{{ (tour.index() ?? 0) + 1 }} von {{ total }}</p>
        <h2>{{ s.title }}</h2>
        <p>{{ s.text }}</p>
        <div class="actions">
          <button mat-button type="button" data-testid="tour-end" (click)="tour.end()">
            Beenden
          </button>
          <span class="grow"></span>
          @if (tour.index()) {
            <button mat-button type="button" data-testid="tour-back" (click)="tour.back()">
              Zurück
            </button>
          }
          <button mat-flat-button type="button" data-testid="tour-next" (click)="tour.next()">
            {{ tour.index() === total - 1 ? 'Fertig' : 'Weiter' }}
          </button>
        </div>
      </section>
    }
  `,
  styles: [
    `
      .veil {
        position: fixed;
        inset: 0;
        z-index: 1000;
      }
      .veil.solid {
        background: rgb(0 0 0 / 0.55);
      }
      .spot {
        position: fixed;
        z-index: 1001;
        border-radius: 14px;
        box-shadow: 0 0 0 9999px rgb(0 0 0 / 0.55);
        pointer-events: none;
        transition: all 0.2s ease;
      }
      .tip {
        position: fixed;
        z-index: 1002;
        left: 12px;
        right: 12px;
        max-height: calc(100dvh - 24px);
        overflow-y: auto;
        max-width: 460px;
        margin: 0 auto;
        background: var(--hb-surface);
        color: var(--hb-ink);
        border-radius: 16px;
        padding: 14px 16px 8px;
        box-shadow: 0 8px 30px rgb(0 0 0 / 0.3);
      }
      .tip h2 {
        margin: 0 0 6px;
        font-size: 18px;
      }
      .tip p {
        margin: 0 0 8px;
        line-height: 1.45;
      }
      .count {
        font-size: 12px;
        color: var(--hb-muted);
      }
      .actions {
        display: flex;
        gap: 6px;
        align-items: center;
      }
      .grow {
        flex: 1;
      }
    `,
  ],
})
export class TourOverlay {
  protected readonly tour = inject(TourService);
  protected readonly total = TOUR.length;
  private readonly tick = signal(0);
  protected readonly rect = computed(() => {
    this.tick();
    const t = this.tour.step()?.target;
    const el = t ? document.querySelector<HTMLElement>(`[data-testid="${t}"]`) : null;
    return el ? el.getBoundingClientRect() : null;
  });
  /** Hinweis unter dem Element, wenn darunter Platz ist, sonst darüber; ohne Element mittig */
  protected readonly tipTop = computed(() => {
    const r = this.rect(),
      h = window.innerHeight;
    if (!r) return Math.max(24, h / 2 - 120);
    const tip = Math.min(240, h - 24);
    return r.bottom + tip + 14 < h ? r.bottom + 14 : Math.max(12, r.top - tip - 14);
  });

  constructor() {
    effect(() => {
      const t = this.tour.step()?.target;
      const el = t ? document.querySelector<HTMLElement>(`[data-testid="${t}"]`) : null;
      if (el) {
        el.scrollIntoView({ block: 'center' });
        setTimeout(() => this.tick.update((n) => n + 1), 50);
      }
    });
  }

  @HostListener('window:resize')
  @HostListener('window:scroll')
  protected remeasure(): void {
    if (this.tour.index() !== null) this.tick.update((n) => n + 1);
  }
}
