import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { MatButton } from '@angular/material/button';
import { MatFormField, MatLabel } from '@angular/material/form-field';
import { MatInput } from '@angular/material/input';
import { Router } from '@angular/router';
import { AccountPurpose, AccountType, validateAccount } from '../../domain/accounts/account';
import { formatEuro, parseEuro } from '../../domain/shared/money';
import { todayLocal } from '../../domain/shared/local-date';
import { AccountsStore } from '../../data/stores/accounts.store';

interface AccountQuestion {
  key: string;
  type: AccountType;
  purpose: AccountPurpose;
  question: string;
  explain: string;
  name: string;
  again?: string;
}
/** Fragen der Ersteinrichtung, in der Reihenfolge, in der man die App in Gebrauch nimmt */
const ACCOUNTS: AccountQuestion[] = [
  {
    key: 'giro',
    type: 'giro',
    purpose: 'allgemein',
    question: 'Hast du ein Girokonto?',
    explain: 'Das Konto, auf dem das Gehalt eingeht und von dem die meisten Zahlungen abgehen.',
    name: 'Girokonto',
    again: 'Noch ein Girokonto, zum Beispiel ein gemeinsames?',
  },
  {
    key: 'tagesgeld',
    type: 'tagesgeld',
    purpose: 'allgemein',
    question: 'Hast du ein Tagesgeldkonto als Rücklage?',
    explain:
      'Für Notgroschen und Jahreszahlungen. Die App verteilt es auf Spartöpfe und sagt dir, wann du umbuchen solltest.',
    name: 'Tagesgeld',
  },
  {
    key: 'sonder',
    type: 'tagesgeld',
    purpose: 'sondertilgung',
    question: 'Sparst du auf einem eigenen Konto für Sondertilgungen?',
    explain:
      'Ein eigenes Tagesgeld nur für Sondertilgungen deiner Kredite. Ohne eigenes Konto geht es später auch mit einem Spartopf.',
    name: 'Sondertilgung',
  },
  {
    key: 'bauspar',
    type: 'bauspar',
    purpose: 'allgemein',
    question: 'Hast du einen Bausparvertrag?',
    explain:
      'Hier trägst du nur das aktuelle Guthaben ein. Die Vertragsdaten folgen später unter Kredite → Bausparverträge.',
    name: 'Bausparvertrag',
  },
];
type Step = 'start' | string | 'kredite' | 'altdaten' | 'mail' | 'fertig';
const STEPS: Step[] = [
  'start',
  ...ACCOUNTS.map((a) => a.key),
  'kredite',
  'altdaten',
  'mail',
  'fertig',
];

/** Kontoentwurf der Ersteinrichtung: 10 € Notreserve und 2 Bankarbeitstage Überweisungsdauer wie im Kontodialog */
export function wizardDraft(
  name: string,
  type: AccountType,
  purpose: AccountPurpose,
  identifier: string,
) {
  return {
    name: name.trim(),
    type,
    identifier: identifier.trim(),
    purpose,
    reserve: 1000,
    leadDays: 2,
  };
}

/** Ersteinrichtung im Frage-Antwort-Stil; jederzeit abbrechbar, alles später änderbar. */
@Component({
  selector: 'app-setup-wizard',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatButton, MatFormField, MatLabel, MatInput],
  template: `
    <section class="card wz" data-testid="wizard">
      <div class="top">
        <span class="small muted">{{
          step() === 'start' || step() === 'fertig'
            ? 'Ersteinrichtung'
            : 'Frage ' + i() + ' von ' + (steps.length - 2)
        }}</span>
        <button mat-button type="button" data-testid="wz-cancel" (click)="leave()">
          Abbrechen
        </button>
      </div>
      @switch (step()) {
        @case ('start') {
          <h1>Los geht’s</h1>
          <p>
            Ich stelle dir ein paar kurze Fragen zu deinen Konten und lege sie für dich an. Du
            kannst jederzeit abbrechen; alles lässt sich später ändern.
          </p>
          <button mat-flat-button type="button" data-testid="wz-next" (click)="next()">
            Starten
          </button>
        }
        @case ('kredite') {
          <h1>Hast du Kredite, zum Beispiel eine Baufinanzierung?</h1>
          <p>
            Kredite trägst du am besten mit den Unterlagen der Bank ein: Restschuld, Rate, Zins und
            Zinsbindung. Ich bringe dich am Ende hin.
          </p>
          <div class="yn">
            <button
              mat-flat-button
              type="button"
              data-testid="wz-yes"
              (click)="flag('kredite', true)"
            >
              Ja</button
            ><button
              mat-stroked-button
              type="button"
              data-testid="wz-no"
              (click)="flag('kredite', false)"
            >
              Nein
            </button>
          </div>
        }
        @case ('altdaten') {
          <h1>Hast du Daten aus deiner bisherigen Haushaltsbuch-App?</h1>
          <p>
            Eine Excel-Datei der alten App lässt sich einlesen; dann hast du gleich deine Historie.
            Ich bringe dich am Ende hin.
          </p>
          <div class="yn">
            <button
              mat-flat-button
              type="button"
              data-testid="wz-yes"
              (click)="flag('altdaten', true)"
            >
              Ja</button
            ><button
              mat-stroked-button
              type="button"
              data-testid="wz-no"
              (click)="flag('altdaten', false)"
            >
              Nein
            </button>
          </div>
        }
        @case ('mail') {
          <h1>Umsätze per E-Mail</h1>
          <p>
            Viele Banken schicken Umsätze per E-Mail, zum Beispiel mit dem Kontowecker der
            Sparkasse. Den Text der E-Mail fügst du unter <strong>+ → Aus E-Mail</strong> ein; die
            App liest die Umsätze und schlägt Kategorien vor.
          </p>
          <button mat-flat-button type="button" data-testid="wz-next" (click)="next()">
            Weiter
          </button>
        }
        @case ('fertig') {
          <h1>Fertig eingerichtet</h1>
          @if (created().length) {
            <ul data-testid="wz-summary">
              @for (c of created(); track c) {
                <li>{{ c }}</li>
              }
            </ul>
          } @else {
            <p>
              Noch kein Konto angelegt. Das geht jederzeit auf der Übersicht mit „Konto anlegen“.
            </p>
          }
          <p>
            Denk an ein Backup außerhalb des Handys: unter Einstellungen → Backup, am besten mit
            „Teilen“ auf Google Drive.
          </p>
          <div class="col">
            @if (wants().kredite) {
              <button
                mat-flat-button
                type="button"
                data-testid="wz-to-loans"
                (click)="go('/kredite')"
              >
                Kredite eintragen
              </button>
            }
            @if (wants().altdaten) {
              <button
                mat-stroked-button
                type="button"
                data-testid="wz-to-import"
                (click)="go('/import')"
              >
                Bisherige Daten einlesen
              </button>
            }
            <button mat-button type="button" data-testid="wz-finish" (click)="go('/start')">
              Zur Übersicht
            </button>
          </div>
        }
        @default {
          @if (question(); as q) {
            <h1>{{ form() ? (createdHere() ? q.again : q.name + ' anlegen') : q.question }}</h1>
            @if (!form()) {
              <p>{{ q.explain }}</p>
              <div class="yn">
                <button mat-flat-button type="button" data-testid="wz-yes" (click)="openForm(q)">
                  Ja</button
                ><button mat-stroked-button type="button" data-testid="wz-no" (click)="next()">
                  Nein
                </button>
              </div>
            } @else {
              <mat-form-field appearance="outline"
                ><mat-label>Name</mat-label
                ><input
                  matInput
                  data-testid="wz-name"
                  [value]="name()"
                  (input)="name.set(val($event))"
              /></mat-form-field>
              <div class="grid2">
                <mat-form-field appearance="outline"
                  ><mat-label>Kontostand €</mat-label
                  ><input
                    matInput
                    inputmode="decimal"
                    data-testid="wz-balance"
                    [value]="balance()"
                    (input)="balance.set(val($event))"
                /></mat-form-field>
                <mat-form-field appearance="outline"
                  ><mat-label>Endziffern</mat-label
                  ><input
                    matInput
                    inputmode="numeric"
                    data-testid="wz-ident"
                    [value]="ident()"
                    (input)="ident.set(val($event))"
                /></mat-form-field>
              </div>
              <p class="small muted">
                Die letzten Ziffern helfen beim Einlesen der Kontowecker-E-Mails, wenn du mehrere
                Konten hast.
              </p>
              @if (error()) {
                <p class="warn small" data-testid="wz-error">{{ error() }}</p>
              }
              <div class="yn">
                <button mat-flat-button type="button" data-testid="wz-create" (click)="create(q)">
                  Anlegen
                </button>
                <button mat-stroked-button type="button" data-testid="wz-skip" (click)="next()">
                  {{ createdHere() ? 'Weiter' : 'Überspringen' }}
                </button>
              </div>
            }
          }
        }
      }
      @if (msg()) {
        <p class="hint small" data-testid="wz-msg">{{ msg() }}</p>
      }
    </section>
  `,
  styles: [
    `
      .wz h1 {
        font-size: 20px;
        margin: 4px 0 8px;
      }
      .top {
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .yn {
        display: flex;
        gap: 8px;
        margin-top: 8px;
      }
      .col {
        display: grid;
        gap: 8px;
        margin-top: 8px;
      }
      .grid2 {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 0 10px;
      }
    `,
  ],
})
export class SetupWizardPage {
  private readonly router = inject(Router);
  private readonly accounts = inject(AccountsStore);
  protected readonly steps = STEPS;
  protected readonly i = signal(0);
  protected readonly step = computed(() => STEPS[this.i()]);
  protected readonly question = computed(() => ACCOUNTS.find((a) => a.key === this.step()) ?? null);
  protected readonly form = signal(false);
  protected readonly createdHere = signal(false);
  protected readonly name = signal('');
  protected readonly balance = signal('');
  protected readonly ident = signal('');
  protected readonly error = signal('');
  protected readonly msg = signal('');
  protected readonly created = signal<string[]>([]);
  protected readonly wants = signal({ kredite: false, altdaten: false });

  protected val(ev: Event): string {
    return (ev.target as HTMLInputElement).value;
  }

  protected next(): void {
    this.form.set(false);
    this.createdHere.set(false);
    this.error.set('');
    this.msg.set('');
    this.i.update((n) => Math.min(STEPS.length - 1, n + 1));
  }

  protected openForm(q: AccountQuestion): void {
    const taken = this.accounts.accounts().some((a) => a.name === q.name);
    this.name.set(taken ? `${q.name} 2` : q.name);
    this.balance.set('');
    this.ident.set('');
    this.error.set('');
    this.form.set(true);
  }

  protected async create(q: AccountQuestion): Promise<void> {
    const balance = parseEuro(this.balance() || '');
    const draft = wizardDraft(this.name(), q.type, q.purpose, this.ident());
    const errors = [
      ...validateAccount(draft, this.accounts.accounts()),
      ...(balance === null ? ['Bitte den heutigen Kontostand eintragen (0 € ist erlaubt).'] : []),
    ];
    if (errors.length) return this.error.set(errors.join(' '));
    await this.accounts.create(draft, { date: todayLocal(), balance: balance ?? 0 });
    this.created.update((l) => [...l, `${draft.name}: ${formatEuro(balance ?? 0)}`]);
    if (q.again) {
      this.createdHere.set(true);
      this.openForm(q);
      this.msg.set(`„${draft.name}“ ist angelegt.`);
    } else {
      this.next();
      this.msg.set(`„${draft.name}“ ist angelegt.`);
    }
  }

  protected flag(key: 'kredite' | 'altdaten', v: boolean): void {
    this.wants.update((w) => ({ ...w, [key]: v }));
    this.next();
  }

  protected leave(): void {
    void this.router.navigateByUrl('/start');
  }

  protected go(url: string): void {
    void this.router.navigateByUrl(url);
  }
}
