import { describe, expect, it } from 'vitest';
import { validateAccount } from '../../domain/accounts/account';
import { wizardDraft } from './setup-wizard.page';

describe('Ersteinrichtung', () => {
  it('Kontoentwürfe des Assistenten bestehen die Kontoprüfung', () => {
    for (const [type, purpose] of [
      ['giro', 'allgemein'],
      ['tagesgeld', 'allgemein'],
      ['tagesgeld', 'sondertilgung'],
      ['bauspar', 'allgemein'],
    ] as const)
      expect(validateAccount(wizardDraft(' Konto ', type, purpose, ''), [])).toEqual([]);
    expect(validateAccount(wizardDraft('Giro', 'giro', 'allgemein', '12x'), [])[0]).toContain(
      'letzten 2 bis 6 Ziffern',
    );
  });
});
