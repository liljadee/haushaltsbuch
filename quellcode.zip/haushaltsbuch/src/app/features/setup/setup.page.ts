import { MatInput } from '@angular/material/input';
import { MatFormField, MatLabel } from '@angular/material/form-field';
import { MatButton } from '@angular/material/button';
import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import {
  normalizeGroup,
  normalizeRecoveryKey,
  splitRecoveryKey,
} from '../../domain/shared/recovery-key';
import { BackupError, BackupFile, parseBackupFile } from '../../data/backup/backup-format';
import { MIN_PASSWORD_LENGTH } from '../../data/crypto/key-derivation';
import { PasskeyError } from '../../data/crypto/passkey.service';
import { SetupSession, VaultService } from '../../data/vault.service';
import { Icon } from '../../shared/icon';

type Step = 'start' | 'restore' | 'passkey' | 'key' | 'confirm' | 'password' | 'done';

@Component({
  selector: 'app-setup-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, Icon, MatButton, MatFormField, MatLabel, MatInput],
  templateUrl: './setup.page.html',
})
export class SetupPage {
  private readonly vault = inject(VaultService);
  private readonly router = inject(Router);
  protected readonly step = signal<Step>('start');
  protected readonly busy = signal(false);
  protected readonly error = signal('');
  protected readonly passkeyOk = signal<boolean | null>(null);
  protected readonly passkeyInfo = signal('');
  protected readonly restoring = signal(false);
  protected readonly backupInfo = signal('');
  protected readonly groups = signal<string[]>([]);
  protected readonly ask = signal<[number, number]>([0, 0]);
  protected readonly minPw = MIN_PASSWORD_LENGTH;
  private session: SetupSession | null = null;
  private backup: BackupFile | null = null;
  protected answer1 = '';
  protected answer2 = '';
  protected pw1 = '';
  protected pw2 = '';
  protected restoreKey = '';

  protected stepNo(): number {
    if (this.restoring()) return this.step() === 'passkey' ? 1 : 2;
    return { start: 0, restore: 0, passkey: 1, key: 2, confirm: 3, password: 4, done: 4 }[
      this.step()
    ];
  }
  protected total(): number {
    return this.restoring() ? 2 : 4;
  }

  protected async begin(): Promise<void> {
    this.restoring.set(false);
    this.session = await this.vault.startSetup();
    this.groups.set(splitRecoveryKey(this.session.recoveryKey ?? ''));
    this.go('passkey');
  }

  protected beginRestore(): void {
    this.restoring.set(true);
    this.go('restore');
  }

  protected async pickBackup(ev: Event): Promise<void> {
    const f = (ev.target as HTMLInputElement).files?.[0];
    this.error.set('');
    this.backup = null;
    this.backupInfo.set('');
    if (!f) return;
    try {
      this.backup = parseBackupFile(await f.text());
      this.backupInfo.set(
        `Backup vom ${new Date(this.backup.createdAt).toLocaleString('de-DE')}, App-Version ${this.backup.appVersion}.`,
      );
    } catch (e) {
      this.error.set(e instanceof BackupError ? e.message : 'Die Datei lässt sich nicht lesen.');
    }
  }

  protected async openBackup(): Promise<void> {
    this.error.set('');
    const key = normalizeRecoveryKey(this.restoreKey);
    if (!this.backup) return this.error.set('Bitte zuerst die Backup-Datei auswählen.');
    if (!key)
      return this.error.set(
        'Der Wiederherstellungsschlüssel hat 30 Zeichen in sechs Gruppen, z. B. 7K2QX-…',
      );
    this.busy.set(true);
    try {
      this.session = await this.vault.startRestore(this.backup, key);
      const n = Object.values(this.session.content?.stores ?? {}).reduce((s, l) => s + l.length, 0);
      this.backupInfo.set(
        `Backup geöffnet (${n} ${n === 1 ? 'Datensatz' : 'Datensätze'}). Jetzt noch den Fingerabdruck für dieses Handy einrichten.`,
      );
      this.go('passkey');
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : String(e));
    } finally {
      this.busy.set(false);
    }
  }

  protected async createPasskey(): Promise<void> {
    if (!this.session) return;
    this.busy.set(true);
    this.error.set('');
    try {
      await this.vault.addPasskey(this.session);
      this.passkeyOk.set(true);
      this.passkeyInfo.set('Fingerabdruck eingerichtet. Damit entsperrst du die App ab jetzt.');
      this.go(this.restoring() ? 'password' : 'key');
    } catch (e) {
      const pe = e instanceof PasskeyError ? e : null;
      if (pe?.reason === 'kein-prf' || pe?.reason === 'nicht-verfuegbar') {
        this.passkeyOk.set(false);
        this.passkeyInfo.set(
          `${pe.message} Kein Problem: Du entsperrst stattdessen mit einem App-Passwort. Bitte gib mir dieses Ergebnis weiter.`,
        );
      } else {
        this.error.set(pe?.message ?? String(e));
      }
    } finally {
      this.busy.set(false);
    }
  }

  protected withoutPasskey(): void {
    this.passkeyOk.set(false);
    if (!this.passkeyInfo())
      this.passkeyInfo.set('Ohne Fingerabdruck: Du entsperrst mit einem App-Passwort.');
    this.go(this.restoring() ? 'password' : 'key');
  }

  protected keyWritten(): void {
    const a = Math.floor(Math.random() * 6);
    let b = Math.floor(Math.random() * 5);
    if (b >= a) b++;
    this.ask.set(a < b ? [a, b] : [b, a]);
    this.answer1 = '';
    this.answer2 = '';
    this.go('confirm');
  }

  protected checkKey(): void {
    const [a, b] = this.ask(),
      g = this.groups();
    if (normalizeGroup(this.answer1) === g[a] && normalizeGroup(this.answer2) === g[b])
      this.go('password');
    else
      this.error.set(
        'Das stimmt noch nicht. Bitte mit deinem Zettel vergleichen oder den Schlüssel nochmal ansehen.',
      );
  }

  protected async finish(withPassword: boolean): Promise<void> {
    if (!this.session) return;
    this.error.set('');
    if (withPassword) {
      if (this.pw1.length < MIN_PASSWORD_LENGTH)
        return this.error.set(
          `Das App-Passwort braucht mindestens ${MIN_PASSWORD_LENGTH} Zeichen. Ein Satz aus mehreren Wörtern ist gut zu merken.`,
        );
      if (this.pw1 !== this.pw2) return this.error.set('Die beiden Passwörter sind nicht gleich.');
    }
    this.busy.set(true);
    try {
      await this.vault.finishSetup(this.session, withPassword ? this.pw1 : null);
      this.session = null;
      this.pw1 = this.pw2 = '';
      this.go('done');
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : String(e));
    } finally {
      this.busy.set(false);
    }
  }

  protected toApp(): void {
    void this.router.navigateByUrl('/start');
  }

  protected go(s: Step): void {
    this.error.set('');
    this.step.set(s);
    window.scrollTo(0, 0);
  }

  protected val(ev: Event): string {
    return (ev.target as HTMLInputElement).value;
  }
}
