import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { RouterLink } from '@angular/router';
import { formatEuro } from '../../domain/shared/money';
import { TestDataStore } from '../../data/stores/testdata.store';
import { VaultService } from '../../data/vault.service';
import { Icon } from '../../shared/icon';

@Component({
  selector: 'app-start-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatButtonModule, RouterLink, Icon],
  template: `
    <div class="page">
      <h1>Version 0.1: Machbarkeitstest</h1>
      <p class="muted">
        Diese Version prüft, ob alles Wichtige auf deinem Handy funktioniert. Echte Buchungen kommen
        mit Version 0.2.
      </p>
      @if (vault.unlockedWith() === 'wiederherstellung') {
        <p class="warn">
          Mit dem Wiederherstellungsschlüssel entsperrt. Richte den Fingerabdruck beim nächsten
          Entsperren neu ein.
        </p>
      }
      <div class="card">
        <h2>Testbuchungen</h2>
        <p class="muted small">
          Verschlüsselt gespeichert. Erfasse zwei, drei Einträge und prüfe, ob sie nach dem Sperren,
          ohne Netz und im Backup wieder da sind.
        </p>
        @for (e of store.entries(); track e.id) {
          <div class="row">
            <div>
              <div class="t">{{ e.text }}</div>
              <div class="muted small">{{ de(e.date) }}</div>
            </div>
            <div class="num amt" [class.pos]="e.amount > 0">{{ euro(e.amount) }}</div>
            <button
              mat-icon-button
              type="button"
              [attr.aria-label]="'Löschen: ' + e.text"
              (click)="store.remove(e.id)"
            >
              <app-icon name="trash" [size]="20" />
            </button>
          </div>
        } @empty {
          <p class="muted">Noch keine Testbuchungen.</p>
        }
        <div class="actions">
          <a mat-flat-button routerLink="/neu" data-testid="new-entry"
            ><app-icon name="plus" /> Testbuchung erfassen</a
          >
        </div>
      </div>
      <div class="card">
        <h2>Dein Prüfauftrag</h2>
        <p class="small">
          Die Machbarkeitsprüfung zeigt, was dein Handy kann, und hat eine Checkliste für die Tests
          von Hand. Am Ende kopierst du das Ergebnis und schickst es mir.
        </p>
        <div class="actions">
          <a mat-stroked-button routerLink="/pruefung">Machbarkeitsprüfung öffnen</a>
          <a mat-button routerLink="/einstellungen">Backup erstellen</a>
        </div>
      </div>
    </div>
  `,
  styles: [
    `
      .row {
        display: grid;
        grid-template-columns: 1fr auto auto;
        gap: 8px;
        align-items: center;
        padding: 6px 0;
        border-bottom: 1px solid var(--hb-line);
      }
      .t {
        font-weight: 600;
      }
      .amt {
        font-weight: 650;
      }
      .pos {
        color: var(--hb-primary);
      }
    `,
  ],
})
export class StartPage {
  protected readonly vault = inject(VaultService);
  protected readonly store = inject(TestDataStore);
  protected readonly euro = formatEuro;
  protected de(d: string): string {
    return new Date(d + 'T12:00:00').toLocaleDateString('de-DE', {
      weekday: 'short',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });
  }
}
