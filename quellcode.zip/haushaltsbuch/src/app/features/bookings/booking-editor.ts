import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  computed,
  inject,
  input,
  output,
  signal,
} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { Booking, Split } from '../../domain/bookings/booking';
import { normalizeSplits, remaining, validateBooking } from '../../domain/bookings/booking-draft';
import { findDuplicate } from '../../domain/bookings/duplicates';
import { counterpart } from '../../domain/bookings/transfer';
import { formatDate } from '../../domain/shared/local-date';
import { suggest } from '../../domain/categories/rules';
import { todayLocal } from '../../domain/shared/local-date';
import { formatEuro, parseEuro } from '../../domain/shared/money';
import { AccountsStore } from '../../data/stores/accounts.store';
import { BookingsStore } from '../../data/stores/bookings.store';
import { CategoriesStore } from '../../data/stores/categories.store';
import { RulesStore } from '../../data/stores/rules.store';
import { nextSeq } from '../../data/stores/seq';
import { Icon } from '../../shared/icon';
import { SelectValue } from '../../shared/select-value';
import { CategoryPicker } from './category-picker';

interface SplitRow {
  categoryId: string | null;
  subCategory: string | null;
  amount: string;
}
const euroIn = (c: number) =>
  (Math.abs(c) / 100).toLocaleString('de-DE', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

/** Buchung erfassen oder bearbeiten (Lastenheft 8.4), mit Aufteilung auf mehrere Kategorien. */
@Component({
  selector: 'app-booking-editor',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    MatButtonModule,
    MatButtonToggleModule,
    MatFormFieldModule,
    MatInputModule,
    CategoryPicker,
    Icon,
    SelectValue,
  ],
  templateUrl: './booking-editor.html',
  styles: [
    `
      .kind {
        margin: 0 0 14px;
      }
      .grid2 {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 0 10px;
      }
      .split {
        border-left: 3px solid var(--hb-primary);
        padding-left: 10px;
        margin: 0 0 6px;
      }
      .split .amt {
        display: grid;
        grid-template-columns: 1fr auto;
        gap: 8px;
        align-items: start;
      }
      .rest {
        font-size: 14px;
        margin: 0 0 8px;
      }
      .ok {
        color: var(--hb-primary-ink);
      }
      .danger {
        color: var(--hb-bad-ink);
      }
    `,
  ],
})
export class BookingEditor implements OnInit {
  private readonly bookings = inject(BookingsStore);
  private readonly cats = inject(CategoriesStore);
  private readonly rules = inject(RulesStore);
  protected readonly accounts = inject(AccountsStore);
  readonly booking = input<Booking | null>(null);
  readonly done = output<string>();

  protected readonly today = todayLocal();
  protected readonly kind = signal<'aus' | 'ein'>('aus');
  protected readonly amount = signal('');
  protected text = '';
  protected readonly accountId = signal<string | null>(null);
  protected date = todayLocal();
  protected note = '';
  protected readonly splitMode = signal(false);
  protected readonly rows = signal<SplitRow[]>([
    { categoryId: null, subCategory: null, amount: '' },
  ]);
  protected readonly errors = signal<string[]>([]);
  protected readonly saved = signal('');
  protected readonly confirmDelete = signal(false);
  protected readonly dupWarning = signal('');
  private dupAccepted = false;
  protected readonly special = computed(() => {
    const k = this.booking()?.kind;
    return k === 'korrektur' || k === 'umbuchung';
  });
  protected readonly type = computed(() => (this.kind() === 'aus' ? 'ausgabe' : 'einnahme'));
  protected readonly rest = computed(() => {
    const total = parseEuro(this.amount());
    if (total === null || !this.splitMode()) return null;
    const sign = this.kind() === 'aus' ? -1 : 1;
    return remaining(
      sign * Math.abs(total),
      this.rows().map((r) => ({
        categoryId: r.categoryId,
        subCategory: r.subCategory,
        amount: sign * Math.abs(parseEuro(r.amount) ?? 0),
      })),
    );
  });
  protected readonly euro = formatEuro;

  ngOnInit(): void {
    const b = this.booking();
    if (!b) {
      const giro =
        this.accounts.active().find((a) => a.type === 'giro') ?? this.accounts.active()[0];
      this.accountId.set(giro?.id ?? null);
      return;
    }
    this.kind.set(b.amount < 0 ? 'aus' : 'ein');
    this.amount.set(euroIn(b.amount));
    this.text = b.text;
    this.accountId.set(b.accountId);
    this.date = b.date;
    this.note = b.note ?? '';
    if (b.splits.length)
      this.rows.set(
        b.splits.map((s) => ({
          categoryId: s.categoryId,
          subCategory: s.subCategory,
          amount: euroIn(s.amount),
        })),
      );
    this.splitMode.set(b.splits.length > 1);
  }

  protected val(ev: Event): string {
    this.errors.set([]);
    this.saved.set('');
    return (ev.target as HTMLInputElement).value;
  }

  /** Kategorie aus den Regeln vorschlagen, solange noch keine gewählt ist (Lastenheft 8.4). */
  protected suggestFromText(): void {
    if (this.booking() || this.splitMode() || this.rows()[0].categoryId || !this.text.trim())
      return;
    const sign = this.kind() === 'aus' ? -1 : 1;
    const s = suggest(
      this.text,
      sign * Math.abs(parseEuro(this.amount()) ?? 1),
      this.accountId(),
      this.rules.rules(),
      this.cats.categories(),
    );
    if (s.categoryId)
      this.rows.set([{ categoryId: s.categoryId, subCategory: s.subCategory, amount: '' }]);
  }

  protected setKind(k: 'aus' | 'ein'): void {
    if (k === this.kind()) return;
    this.kind.set(k);
    this.rows.set([{ categoryId: null, subCategory: null, amount: '' }]);
    this.splitMode.set(false);
  }

  protected pick(i: number, v: { categoryId: string | null; subCategory: string | null }): void {
    this.errors.set([]);
    this.rows.update((l) => l.map((r, k) => (k === i ? { ...r, ...v } : r)));
  }

  protected rowAmount(i: number, v: string): void {
    this.rows.update((l) => l.map((r, k) => (k === i ? { ...r, amount: v } : r)));
  }

  protected toggleSplit(): void {
    if (this.splitMode()) {
      this.rows.update((l) => [l[0]]);
      this.splitMode.set(false);
    } else {
      this.rows.update((l) => [
        { ...l[0], amount: this.amount() },
        { categoryId: null, subCategory: null, amount: '' },
      ]);
      this.splitMode.set(true);
    }
  }

  protected addRow(): void {
    const r = this.rest();
    this.rows.update((l) => [
      ...l,
      { categoryId: null, subCategory: null, amount: r ? euroIn(r) : '' },
    ]);
  }

  protected removeRow(i: number): void {
    this.rows.update((l) => l.filter((_, k) => k !== i));
    if (this.rows().length === 1) this.splitMode.set(false);
  }

  protected async save(more: boolean): Promise<void> {
    const b = this.booking();
    const sign = this.kind() === 'aus' ? -1 : 1;
    const parsed = parseEuro(this.amount());
    const total = parsed === null ? null : sign * Math.abs(parsed);
    let splits: Split[] = [];
    if (!this.special()) {
      splits = this.rows().map((r) => ({
        categoryId: r.categoryId,
        subCategory: r.subCategory,
        amount: sign * Math.abs(parseEuro(r.amount) ?? 0),
      }));
      if (total !== null) splits = normalizeSplits(total, splits);
    }
    const errs = this.special()
      ? total === null || total === 0
        ? ['Bitte einen Betrag eingeben.']
        : []
      : validateBooking(
          { accountId: this.accountId(), amount: total, date: this.date, text: this.text, splits },
          this.cats.categories(),
          this.today,
        );
    this.errors.set(errs);
    if (errs.length || total === null) return;
    const note = this.note.trim() || undefined;
    if (splits.length === 1)
      await this.rules.learnFrom(this.text, total, splits[0].categoryId, splits[0].subCategory);
    if (b) {
      const changed = {
        ...b,
        amount: total,
        text: this.text.trim(),
        accountId: this.accountId() ?? b.accountId,
        date: this.date,
        splits: b.kind === 'korrektur' || b.kind === 'umbuchung' ? b.splits : splits,
        note,
        confidence: 'sicher' as const,
      };
      const other = b.kind === 'umbuchung' ? counterpart(b, this.bookings.bookings()) : null;
      if (other)
        await this.bookings.updateMany([changed, { ...other, amount: -total, date: this.date }]);
      else await this.bookings.update(changed);
      this.done.emit('Buchung gespeichert.');
      return;
    }
    const dup = findDuplicate(
      this.text,
      total,
      this.accountId()!,
      this.date,
      this.bookings.bookings(),
    );
    if (dup && !this.dupAccepted) {
      this.dupWarning.set(
        `Sieht aus wie „${dup.text}“ vom ${formatDate(dup.date)} über ${formatEuro(dup.amount)}. Ist es eine eigene Buchung, tippe nochmal auf Speichern.`,
      );
      this.dupAccepted = true;
      return;
    }
    this.dupAccepted = false;
    this.dupWarning.set('');
    await this.bookings.add([
      {
        id: crypto.randomUUID(),
        accountId: this.accountId()!,
        kind: sign < 0 ? 'ausgabe' : 'einnahme',
        status: 'gebucht',
        amount: total,
        date: this.date,
        seq: nextSeq(),
        text: this.text.trim(),
        splits,
        confidence: 'sicher',
        source: { type: 'manuell' },
        note,
      },
    ]);
    const msg = `Gespeichert: ${this.text.trim()} ${formatEuro(total)}`;
    if (more) {
      this.saved.set(msg);
      this.amount.set('');
      this.text = '';
      this.note = '';
      this.rows.set([{ categoryId: null, subCategory: null, amount: '' }]);
      this.splitMode.set(false);
    } else this.done.emit(msg);
  }

  protected async remove(): Promise<void> {
    const b = this.booking();
    if (!b) return;
    await this.bookings.remove(b.id);
    this.done.emit('Buchung gelöscht.');
  }
}
