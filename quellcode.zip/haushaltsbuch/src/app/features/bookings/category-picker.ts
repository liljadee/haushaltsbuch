import { MatInput } from '@angular/material/input';
import { MatFormField, MatLabel } from '@angular/material/form-field';
import { ChangeDetectionStrategy, Component, computed, inject, input, output } from '@angular/core';
import { CategoryType, forType } from '../../domain/categories/categories';
import { CategoriesStore } from '../../data/stores/categories.store';
import { SelectValue } from '../../shared/select-value';

/** Zweistufige Auswahl (Lastenheft 9.3): erst Kategorie, dann, falls vorhanden, Unterkategorie. */
@Component({
  selector: 'app-category-picker',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [SelectValue, MatFormField, MatLabel, MatInput],
  template: `
    <div class="pick">
      <mat-form-field appearance="outline">
        <mat-label>Kategorie</mat-label>
        <select
          matNativeControl
          data-testid="cat"
          [appSelectValue]="categoryId()"
          (change)="pickCat($event)"
        >
          <option value="" disabled>Bitte wählen</option>
          @for (c of list(); track c.id) {
            <option [value]="c.id">{{ c.name }}</option>
          }
        </select>
      </mat-form-field>
      @if (subs().length) {
        <mat-form-field appearance="outline">
          <mat-label>Unterkategorie</mat-label>
          <select
            matNativeControl
            data-testid="sub"
            [appSelectValue]="sub()"
            (change)="pickSub($event)"
          >
            <option value="">ohne</option>
            @for (s of subs(); track s.name) {
              <option [value]="s.name">{{ s.name }}</option>
            }
          </select>
        </mat-form-field>
      }
    </div>
  `,
  styles: [
    '.pick { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 0 10px; }',
  ],
})
export class CategoryPicker {
  private readonly store = inject(CategoriesStore);
  readonly type = input<CategoryType>('ausgabe');
  readonly categoryId = input<string | null>(null);
  readonly sub = input<string | null>(null);
  readonly picked = output<{ categoryId: string | null; subCategory: string | null }>();
  protected readonly list = computed(() => forType(this.store.categories(), this.type()));
  protected readonly subs = computed(
    () => this.list().find((c) => c.id === this.categoryId())?.subs ?? [],
  );

  protected pickCat(ev: Event): void {
    this.picked.emit({
      categoryId: (ev.target as HTMLSelectElement).value || null,
      subCategory: null,
    });
  }

  protected pickSub(ev: Event): void {
    this.picked.emit({
      categoryId: this.categoryId(),
      subCategory: (ev.target as HTMLSelectElement).value || null,
    });
  }
}
