import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { Booking } from '../../domain/bookings/booking';
import { categoryLabel, isTaxRelevant } from '../../domain/categories/categories';
import { formatDate, todayLocal } from '../../domain/shared/local-date';
import { formatEuro } from '../../domain/shared/money';
import { AccountsStore } from '../../data/stores/accounts.store';
import { BookingsStore } from '../../data/stores/bookings.store';
import { CategoriesStore } from '../../data/stores/categories.store';
import { SelectValue } from '../../shared/select-value';
import { BookingEditor } from './booking-editor';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { CalendarView } from '../recurring/calendar-view';
import { RecurringView } from '../recurring/recurring-view';
import { CategoryPicker } from './category-picker';
import { BatchService } from '../../data/import/batch.service';
import { isRegular } from '../../domain/bookings/batch';

const WEEKDAY = new Intl.DateTimeFormat('de-DE', {
  weekday: 'short',
  day: '2-digit',
  month: '2-digit',
  year: 'numeric',
  timeZone: 'UTC',
});
const monthsBack = (d: string, n: number) => {
  const [y, m] = d.split('-').map(Number);
  const t = y * 12 + (m - 1) - n;
  return `${Math.floor(t / 12)}-${String((t % 12) + 1).padStart(2, '0')}-01`;
};

/** Buchungsliste (Lastenheft 19): nach Tagen gruppiert, Suche, Bearbeiten direkt an der Buchung. */
@Component({
  selector: 'app-bookings-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatButtonToggleModule,
    BookingEditor,
    SelectValue,
    CategoryPicker,
    CalendarView,
    RecurringView,
  ],
  template: `
    <div class="page">
      <h1>Buchungen</h1>
      <mat-button-toggle-group
        class="tabs"
        [value]="tab()"
        (change)="setTab($event.value)"
        aria-label="Ansicht"
      >
        <mat-button-toggle value="liste" data-testid="tab-liste">Liste</mat-button-toggle>
        <mat-button-toggle value="kalender" data-testid="tab-kalender">Kalender</mat-button-toggle>
        <mat-button-toggle value="wiederkehrend" data-testid="tab-wiederkehrend"
          >Wiederkehrend</mat-button-toggle
        >
      </mat-button-toggle-group>
      @if (tab() === 'kalender') {
        <app-calendar-view />
      } @else if (tab() === 'wiederkehrend') {
        <app-recurring-view [openId]="openItem" />
      } @else {
        <div class="filters">
          <mat-form-field appearance="outline">
            <mat-label>Suchen</mat-label>
            <input
              matInput
              type="search"
              data-testid="search"
              autocomplete="off"
              placeholder="Text, Kategorie oder Betrag"
              [value]="q()"
              (input)="q.set(val($event))"
            />
          </mat-form-field>
          @if (accounts.active().length > 1) {
            <mat-form-field appearance="outline">
              <mat-label>Konto</mat-label>
              <select matNativeControl [appSelectValue]="acc()" (change)="acc.set(val($event))">
                <option value="">Alle Konten</option>
                @for (a of accounts.active(); track a.id) {
                  <option [value]="a.id">{{ a.name }}</option>
                }
              </select>
            </mat-form-field>
          }
        </div>
        <div class="actions selbar">
          @if (!selectMode()) {
            <button
              mat-stroked-button
              type="button"
              data-testid="select-mode"
              (click)="startSelect()"
            >
              Auswählen
            </button>
          } @else {
            <span class="small"
              ><strong>{{ selected().size }}</strong> ausgewählt</span
            >
            <button mat-button type="button" data-testid="select-all" (click)="selectAll()">
              Alle {{ filteredCount() }} auswählen
            </button>
            <button mat-button type="button" (click)="stopSelect()">Fertig</button>
          }
        </div>
        @if (unclear() > 0 || check()) {
          <div class="actions chips">
            <button
              mat-stroked-button
              type="button"
              data-testid="filter-check"
              [class.on]="check()"
              (click)="check.set(!check())"
            >
              Zu prüfen ({{ unclear() }})
            </button>
          </div>
        }
        @if (msg()) {
          <p class="hint" role="status">{{ msg() }}</p>
        }
        @for (g of groups(); track g.date) {
          <h2 class="day">{{ g.label }}</h2>
          <div class="card list">
            @for (b of g.items; track b.id) {
              <div class="bk" [class.open]="open() === b.id">
                <button
                  type="button"
                  class="row"
                  [attr.aria-expanded]="open() === b.id"
                  (click)="selectMode() ? toggleSelect(b.id) : toggle(b.id)"
                >
                  <span class="l">
                    @if (selectMode()) {
                      <span class="sel" [class.on]="selected().has(b.id)" aria-hidden="true">{{
                        selected().has(b.id) ? '✓' : ''
                      }}</span>
                    }
                    <span class="t">{{ b.text }}</span>
                    <span class="meta">
                      {{ meta(b) }}
                      @if (b.kind === 'korrektur') {
                        <span class="badge">Korrektur</span>
                      }
                      @if (tax(b)) {
                        <span class="badge info">steuerrelevant</span>
                      }
                      @if (b.splits.length > 1) {
                        <span class="badge">aufgeteilt</span>
                      }
                      @if (
                        (b.kind === 'ausgabe' || b.kind === 'einnahme') && b.confidence !== 'sicher'
                      ) {
                        <span class="badge todo">{{
                          b.confidence === 'unsicher' ? 'bitte prüfen' : 'bitte zuordnen'
                        }}</span>
                      }
                    </span>
                  </span>
                  <span class="num amt" [class.pos]="b.amount > 0">{{ euro(b.amount) }}</span>
                </button>
                @if (open() === b.id && !selectMode()) {
                  <app-booking-editor [booking]="b" (done)="closed($event)" />
                }
              </div>
            }
          </div>
        } @empty {
          <p class="muted">
            {{
              q()
                ? 'Keine Buchung passt zur Suche.'
                : 'Noch keine Buchungen. Tippe unten auf das Plus, um die erste zu erfassen.'
            }}
          </p>
        }
        @if (selectMode() && selected().size) {
          <div class="card batch" data-testid="batch-panel">
            <h2>
              {{ selected().size }} {{ selected().size === 1 ? 'Buchung' : 'Buchungen' }} bearbeiten
            </h2>
            @if (selType(); as t) {
              <app-category-picker
                [type]="t"
                [categoryId]="batchCat().categoryId"
                [sub]="batchCat().subCategory"
                (picked)="batchCat.set($event)"
              />
              <button
                mat-flat-button
                type="button"
                data-testid="batch-assign"
                [disabled]="!batchCat().categoryId"
                (click)="assign()"
              >
                Kategorie zuordnen
              </button>
            } @else {
              <p class="small muted">
                Ausgaben und Einnahmen gemischt: Eine gemeinsame Kategorie geht nur für eine Art.
              </p>
            }
            @if (accounts.active().length > 1) {
              <div class="tr">
                <mat-form-field appearance="outline">
                  <mat-label>Oder Umbuchung auf eigenes Konto</mat-label>
                  <select
                    matNativeControl
                    data-testid="batch-target"
                    [appSelectValue]="batchTarget()"
                    (change)="batchTarget.set(val($event))"
                  >
                    <option value="">Konto wählen</option>
                    @for (a of accounts.active(); track a.id) {
                      <option [value]="a.id">{{ a.name }}</option>
                    }
                  </select>
                </mat-form-field>
                <button
                  mat-stroked-button
                  type="button"
                  data-testid="batch-transfer"
                  [disabled]="!batchTarget()"
                  (click)="transfer()"
                >
                  Umwandeln
                </button>
              </div>
            }
            <div class="actions">
              @if (!batchDelete()) {
                <button mat-button type="button" class="danger" (click)="batchDelete.set(true)">
                  Löschen …
                </button>
              } @else {
                <span class="small">{{ selected().size }} Buchungen wirklich löschen?</span>
                <button
                  mat-flat-button
                  type="button"
                  data-testid="batch-delete"
                  (click)="removeSelected()"
                >
                  Ja, löschen
                </button>
                <button mat-button type="button" (click)="batchDelete.set(false)">Nein</button>
              }
            </div>
          </div>
        }
        @if (older() > 0) {
          <div class="actions">
            <button mat-stroked-button type="button" (click)="more()">
              Ältere Buchungen anzeigen ({{ older() }})
            </button>
          </div>
        }
      }
    </div>
  `,
  styles: [
    `
      .filters {
        display: grid;
        grid-template-columns: 1fr auto;
        gap: 0 10px;
      }
      .filters > :only-child {
        grid-column: 1 / -1;
      }
      .day {
        font-size: 14px;
        color: var(--hb-muted);
        margin: 14px 4px 6px;
        font-weight: 650;
      }
      .list {
        padding: 4px 14px;
      }
      .bk + .bk {
        border-top: 1px solid var(--hb-line);
      }
      .bk.open {
        background: var(--hb-bg);
        border-radius: 12px;
        padding: 0 10px 10px;
        margin: 4px -10px;
      }
      .row {
        display: flex;
        justify-content: space-between;
        gap: 12px;
        width: 100%;
        padding: 10px 0;
        background: none;
        border: 0;
        text-align: left;
        font: inherit;
        color: inherit;
        cursor: pointer;
      }
      .l {
        display: grid;
        gap: 2px;
        min-width: 0;
      }
      .t {
        font-weight: 600;
        overflow-wrap: anywhere;
      }
      .meta {
        font-size: 13px;
        color: var(--hb-muted);
      }
      .amt {
        font-weight: 650;
        white-space: nowrap;
      }
      .pos {
        color: var(--hb-primary);
      }
      .badge {
        display: inline-block;
        font-size: 12px;
        border: 1px solid var(--hb-line);
        border-radius: 8px;
        padding: 0 6px;
        margin-left: 4px;
      }
      .tabs {
        margin: 0 0 10px;
      }
      .selbar {
        margin: -4px 0 6px;
        align-items: center;
      }
      .sel {
        display: inline-grid;
        place-items: center;
        width: 22px;
        height: 22px;
        border: 2px solid var(--hb-muted);
        border-radius: 6px;
        margin-right: 8px;
        font-weight: 800;
        color: var(--mat-sys-on-primary);
        vertical-align: middle;
      }
      .sel.on {
        background: var(--hb-primary);
        border-color: var(--hb-primary);
      }
      .batch {
        position: sticky;
        bottom: calc(64px + env(safe-area-inset-bottom, 0px));
        z-index: 4;
        box-shadow: 0 -2px 12px rgb(0 0 0 / 0.15);
      }
      .batch h2 {
        font-size: 16px;
      }
      .tr {
        display: grid;
        grid-template-columns: 1fr auto;
        gap: 8px;
        align-items: start;
        margin-top: 8px;
      }
      .danger {
        color: var(--hb-bad-ink);
      }
      .badge.todo {
        background: var(--hb-warn-soft);
        color: var(--hb-warn-ink);
        border-color: transparent;
      }
      .badge.info {
        border-color: var(--hb-primary);
        color: var(--hb-primary-ink);
      }
    `,
  ],
})
export class BookingsPage {
  private readonly store = inject(BookingsStore);
  private readonly cats = inject(CategoriesStore);
  protected readonly accounts = inject(AccountsStore);
  protected readonly q = signal('');
  protected readonly acc = signal('');
  protected readonly open = signal<string | null>(null);
  protected readonly msg = signal('');
  private readonly route = inject(ActivatedRoute);
  private readonly qp = this.route.snapshot.queryParamMap;
  protected readonly tab = signal<'liste' | 'kalender' | 'wiederkehrend'>(
    (this.qp.get('ansicht') as 'kalender' | 'wiederkehrend') ?? 'liste',
  );
  protected readonly openItemSig = signal<string | null>(this.qp.get('posten'));
  protected get openItem(): string | null {
    return this.openItemSig();
  }
  constructor() {
    // Wechsel der Adresse innerhalb der Buchungen (z. B. Link auf „Wiederkehrend“) übernehmen;
    // im Konstruktor, damit alle Felder (auch der Filter „Zu prüfen“) schon angelegt sind
    this.route.queryParamMap.pipe(takeUntilDestroyed()).subscribe((q) => {
      this.tab.set((q.get('ansicht') as 'kalender' | 'wiederkehrend') ?? 'liste');
      this.openItemSig.set(q.get('posten'));
      this.check.set(q.get('pruefen') === '1');
      if (q.get('suche')) this.q.set(q.get('suche')!);
    });
  }

  protected setTab(t: 'liste' | 'kalender' | 'wiederkehrend'): void {
    this.tab.set(t);
    this.stopSelect();
  }
  protected readonly check = signal(
    inject(ActivatedRoute).snapshot.queryParamMap.get('pruefen') === '1',
  );
  protected readonly unclear = computed(
    () =>
      this.store
        .bookings()
        .filter((b) => (b.kind === 'ausgabe' || b.kind === 'einnahme') && b.confidence !== 'sicher')
        .length,
  );
  private readonly from = signal(monthsBack(todayLocal(), 1));
  protected readonly euro = formatEuro;

  private readonly filtered = computed(() => {
    const q = this.q().trim().toLowerCase(),
      acc = this.acc(),
      cats = this.cats.categories();
    return this.store
      .bookings()
      .filter((b) => b.status === 'gebucht' && (!acc || b.accountId === acc))
      .filter(
        (b) =>
          !this.check() ||
          ((b.kind === 'ausgabe' || b.kind === 'einnahme') && b.confidence !== 'sicher'),
      )
      .filter(
        (b) =>
          !q ||
          `${b.text} ${b.splits.map((s) => categoryLabel(cats, s.categoryId, s.subCategory)).join(' ')} ${formatEuro(b.amount)} ${b.note ?? ''}`
            .toLowerCase()
            .includes(q),
      )
      .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : b.seq - a.seq));
  });
  protected readonly older = computed(() =>
    this.q() ? 0 : this.filtered().filter((b) => b.date < this.from()).length,
  );
  protected readonly groups = computed(() => {
    const out: { date: string; label: string; items: Booking[] }[] = [];
    for (const b of this.filtered()) {
      if (!this.q() && !this.check() && b.date < this.from()) continue;
      const last = out.at(-1);
      if (last?.date === b.date) last.items.push(b);
      else
        out.push({
          date: b.date,
          label: WEEKDAY.format(new Date(b.date + 'T00:00:00Z')),
          items: [b],
        });
    }
    return out;
  });

  protected val(ev: Event): string {
    return (ev.target as HTMLInputElement).value;
  }

  protected meta(b: Booking): string {
    if (b.kind === 'umbuchung') {
      const other = this.store
        .bookings()
        .find((x) => x.transferGroupId === b.transferGroupId && x.id !== b.id);
      const name = (id?: string) =>
        this.accounts.accounts().find((a) => a.id === id)?.name ?? 'eigenem Konto';
      return `${name(b.accountId)}: Umbuchung ${b.amount < 0 ? 'nach' : 'von'} ${name(other?.accountId)}`;
    }
    const cats = this.cats.categories();
    const cat =
      b.kind === 'korrektur'
        ? 'Ausgleich zum Stand laut Bank'
        : b.splits.length
          ? b.splits.map((s) => categoryLabel(cats, s.categoryId, s.subCategory)).join(' + ')
          : 'Nicht zugeordnet';
    const acc =
      this.accounts.active().length > 1
        ? `${this.accounts.accounts().find((a) => a.id === b.accountId)?.name ?? ''}, `
        : '';
    return acc + cat;
  }

  protected tax(b: Booking): boolean {
    return b.splits.some((s) => isTaxRelevant(this.cats.categories(), s.categoryId, s.subCategory));
  }

  protected toggle(id: string): void {
    this.msg.set('');
    this.open.set(this.open() === id ? null : id);
  }

  protected closed(m: string): void {
    this.open.set(null);
    this.msg.set(m);
  }

  private readonly batch = inject(BatchService);
  protected readonly selectMode = signal(false);
  protected readonly selected = signal<Set<string>>(new Set());
  protected readonly batchCat = signal<{ categoryId: string | null; subCategory: string | null }>({
    categoryId: null,
    subCategory: null,
  });
  protected readonly batchTarget = signal('');
  protected readonly batchDelete = signal(false);
  protected readonly filteredCount = computed(() => this.filtered().length);
  protected readonly selType = computed<'ausgabe' | 'einnahme' | null>(() => {
    const sel = this.store.bookings().filter((b) => this.selected().has(b.id) && isRegular(b));
    if (!sel.length) return null;
    const out = sel.every((b) => b.amount < 0),
      inc = sel.every((b) => b.amount > 0);
    return out ? 'ausgabe' : inc ? 'einnahme' : null;
  });

  protected startSelect(): void {
    this.open.set(null);
    this.msg.set('');
    this.selectMode.set(true);
  }

  protected stopSelect(): void {
    this.selectMode.set(false);
    this.selected.set(new Set());
    this.batchDelete.set(false);
  }

  protected toggleSelect(id: string): void {
    const s = new Set(this.selected());
    if (s.has(id)) s.delete(id);
    else s.add(id);
    this.selected.set(s);
  }

  protected selectAll(): void {
    this.selected.set(new Set(this.filtered().map((b) => b.id)));
  }

  private done(text: string): void {
    this.msg.set(text);
    this.selected.set(new Set());
    this.batchDelete.set(false);
  }

  protected async assign(): Promise<void> {
    const c = this.batchCat();
    if (!c.categoryId) return;
    const n = await this.batch.assign([...this.selected()], c.categoryId, c.subCategory);
    this.done(`${n} Buchungen zugeordnet. Die App merkt sich die Texte als Regeln.`);
  }

  protected async transfer(): Promise<void> {
    const n = await this.batch.toTransfer([...this.selected()], this.batchTarget());
    this.done(`${n} Buchungen in Umbuchungen umgewandelt.`);
  }

  protected async removeSelected(): Promise<void> {
    const n = await this.batch.remove([...this.selected()]);
    this.done(`${n} Buchungen gelöscht.`);
  }

  protected more(): void {
    this.from.set(monthsBack(this.from(), 3));
  }

  protected readonly de = formatDate;
}
