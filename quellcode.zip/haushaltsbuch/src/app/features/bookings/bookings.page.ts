import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { Booking } from '../../domain/bookings/booking';
import { categoryLabel, isTaxRelevant } from '../../domain/categories/categories';
import { formatDate, todayLocal } from '../../domain/shared/local-date';
import { formatEuro } from '../../domain/shared/money';
import { AccountsStore } from '../../data/stores/accounts.store';
import { BookingsStore } from '../../data/stores/bookings.store';
import { CategoriesStore } from '../../data/stores/categories.store';
import { SelectValue } from '../../shared/select-value';
import { BookingEditor } from './booking-editor';

const WEEKDAY = new Intl.DateTimeFormat('de-DE', {
  weekday: 'short',
  day: '2-digit',
  month: '2-digit',
  year: 'numeric',
  timeZone: 'UTC',
});
const monthsBack = (d: string, n: number) => {
  const [y, m] = d.split('-').map(Number);
  const t = y * 12 + (m - 1) - n;
  return `${Math.floor(t / 12)}-${String((t % 12) + 1).padStart(2, '0')}-01`;
};

/** Buchungsliste (Lastenheft 19): nach Tagen gruppiert, Suche, Bearbeiten direkt an der Buchung. */
@Component({
  selector: 'app-bookings-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatFormFieldModule, MatInputModule, MatButtonModule, BookingEditor, SelectValue],
  template: `
    <div class="page">
      <h1>Buchungen</h1>
      <div class="filters">
        <mat-form-field appearance="outline">
          <mat-label>Suchen</mat-label>
          <input
            matInput
            type="search"
            data-testid="search"
            autocomplete="off"
            placeholder="Text, Kategorie oder Betrag"
            [value]="q()"
            (input)="q.set(val($event))"
          />
        </mat-form-field>
        @if (accounts.active().length > 1) {
          <mat-form-field appearance="outline">
            <mat-label>Konto</mat-label>
            <select matNativeControl [appSelectValue]="acc()" (change)="acc.set(val($event))">
              <option value="">Alle Konten</option>
              @for (a of accounts.active(); track a.id) {
                <option [value]="a.id">{{ a.name }}</option>
              }
            </select>
          </mat-form-field>
        }
      </div>
      @if (unclear() > 0 || check()) {
        <div class="actions chips">
          <button
            mat-stroked-button
            type="button"
            data-testid="filter-check"
            [class.on]="check()"
            (click)="check.set(!check())"
          >
            Zu prüfen ({{ unclear() }})
          </button>
        </div>
      }
      @if (msg()) {
        <p class="hint" role="status">{{ msg() }}</p>
      }
      @for (g of groups(); track g.date) {
        <h2 class="day">{{ g.label }}</h2>
        <div class="card list">
          @for (b of g.items; track b.id) {
            <div class="bk" [class.open]="open() === b.id">
              <button
                type="button"
                class="row"
                [attr.aria-expanded]="open() === b.id"
                (click)="toggle(b.id)"
              >
                <span class="l">
                  <span class="t">{{ b.text }}</span>
                  <span class="meta">
                    {{ meta(b) }}
                    @if (b.kind === 'korrektur') {
                      <span class="badge">Korrektur</span>
                    }
                    @if (tax(b)) {
                      <span class="badge info">steuerrelevant</span>
                    }
                    @if (b.splits.length > 1) {
                      <span class="badge">aufgeteilt</span>
                    }
                    @if (
                      (b.kind === 'ausgabe' || b.kind === 'einnahme') && b.confidence !== 'sicher'
                    ) {
                      <span class="badge todo">{{
                        b.confidence === 'unsicher' ? 'bitte prüfen' : 'bitte zuordnen'
                      }}</span>
                    }
                  </span>
                </span>
                <span class="num amt" [class.pos]="b.amount > 0">{{ euro(b.amount) }}</span>
              </button>
              @if (open() === b.id) {
                <app-booking-editor [booking]="b" (done)="closed($event)" />
              }
            </div>
          }
        </div>
      } @empty {
        <p class="muted">
          {{
            q()
              ? 'Keine Buchung passt zur Suche.'
              : 'Noch keine Buchungen. Tippe unten auf das Plus, um die erste zu erfassen.'
          }}
        </p>
      }
      @if (older() > 0) {
        <div class="actions">
          <button mat-stroked-button type="button" (click)="more()">
            Ältere Buchungen anzeigen ({{ older() }})
          </button>
        </div>
      }
    </div>
  `,
  styles: [
    `
      .filters {
        display: grid;
        grid-template-columns: 1fr auto;
        gap: 0 10px;
      }
      .filters > :only-child {
        grid-column: 1 / -1;
      }
      .day {
        font-size: 14px;
        color: var(--hb-muted);
        margin: 14px 4px 6px;
        font-weight: 650;
      }
      .list {
        padding: 4px 14px;
      }
      .bk + .bk {
        border-top: 1px solid var(--hb-line);
      }
      .bk.open {
        background: var(--hb-bg);
        border-radius: 12px;
        padding: 0 10px 10px;
        margin: 4px -10px;
      }
      .row {
        display: flex;
        justify-content: space-between;
        gap: 12px;
        width: 100%;
        padding: 10px 0;
        background: none;
        border: 0;
        text-align: left;
        font: inherit;
        color: inherit;
        cursor: pointer;
      }
      .l {
        display: grid;
        gap: 2px;
        min-width: 0;
      }
      .t {
        font-weight: 600;
        overflow-wrap: anywhere;
      }
      .meta {
        font-size: 13px;
        color: var(--hb-muted);
      }
      .amt {
        font-weight: 650;
        white-space: nowrap;
      }
      .pos {
        color: var(--hb-primary);
      }
      .badge {
        display: inline-block;
        font-size: 12px;
        border: 1px solid var(--hb-line);
        border-radius: 8px;
        padding: 0 6px;
        margin-left: 4px;
      }
      .badge.todo {
        background: var(--hb-warn-soft);
        color: var(--hb-warn-ink);
        border-color: transparent;
      }
      .badge.info {
        border-color: var(--hb-primary);
        color: var(--hb-primary-ink);
      }
    `,
  ],
})
export class BookingsPage {
  private readonly store = inject(BookingsStore);
  private readonly cats = inject(CategoriesStore);
  protected readonly accounts = inject(AccountsStore);
  protected readonly q = signal('');
  protected readonly acc = signal('');
  protected readonly open = signal<string | null>(null);
  protected readonly msg = signal('');
  protected readonly check = signal(
    inject(ActivatedRoute).snapshot.queryParamMap.get('pruefen') === '1',
  );
  protected readonly unclear = computed(
    () =>
      this.store
        .bookings()
        .filter((b) => (b.kind === 'ausgabe' || b.kind === 'einnahme') && b.confidence !== 'sicher')
        .length,
  );
  private readonly from = signal(monthsBack(todayLocal(), 1));
  protected readonly euro = formatEuro;

  private readonly filtered = computed(() => {
    const q = this.q().trim().toLowerCase(),
      acc = this.acc(),
      cats = this.cats.categories();
    return this.store
      .bookings()
      .filter((b) => b.status === 'gebucht' && (!acc || b.accountId === acc))
      .filter(
        (b) =>
          !this.check() ||
          ((b.kind === 'ausgabe' || b.kind === 'einnahme') && b.confidence !== 'sicher'),
      )
      .filter(
        (b) =>
          !q ||
          `${b.text} ${b.splits.map((s) => categoryLabel(cats, s.categoryId, s.subCategory)).join(' ')} ${formatEuro(b.amount)} ${b.note ?? ''}`
            .toLowerCase()
            .includes(q),
      )
      .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : b.seq - a.seq));
  });
  protected readonly older = computed(() =>
    this.q() ? 0 : this.filtered().filter((b) => b.date < this.from()).length,
  );
  protected readonly groups = computed(() => {
    const out: { date: string; label: string; items: Booking[] }[] = [];
    for (const b of this.filtered()) {
      if (!this.q() && !this.check() && b.date < this.from()) continue;
      const last = out.at(-1);
      if (last?.date === b.date) last.items.push(b);
      else
        out.push({
          date: b.date,
          label: WEEKDAY.format(new Date(b.date + 'T00:00:00Z')),
          items: [b],
        });
    }
    return out;
  });

  protected val(ev: Event): string {
    return (ev.target as HTMLInputElement).value;
  }

  protected meta(b: Booking): string {
    if (b.kind === 'umbuchung') {
      const other = this.store
        .bookings()
        .find((x) => x.transferGroupId === b.transferGroupId && x.id !== b.id);
      const name = (id?: string) =>
        this.accounts.accounts().find((a) => a.id === id)?.name ?? 'eigenem Konto';
      return `${name(b.accountId)}: Umbuchung ${b.amount < 0 ? 'nach' : 'von'} ${name(other?.accountId)}`;
    }
    const cats = this.cats.categories();
    const cat =
      b.kind === 'korrektur'
        ? 'Ausgleich zum Stand laut Bank'
        : b.splits.length
          ? b.splits.map((s) => categoryLabel(cats, s.categoryId, s.subCategory)).join(' + ')
          : 'Nicht zugeordnet';
    const acc =
      this.accounts.active().length > 1
        ? `${this.accounts.accounts().find((a) => a.id === b.accountId)?.name ?? ''}, `
        : '';
    return acc + cat;
  }

  protected tax(b: Booking): boolean {
    return b.splits.some((s) => isTaxRelevant(this.cats.categories(), s.categoryId, s.subCategory));
  }

  protected toggle(id: string): void {
    this.msg.set('');
    this.open.set(this.open() === id ? null : id);
  }

  protected closed(m: string): void {
    this.open.set(null);
    this.msg.set(m);
  }

  protected more(): void {
    this.from.set(monthsBack(this.from(), 3));
  }

  protected readonly de = formatDate;
}
