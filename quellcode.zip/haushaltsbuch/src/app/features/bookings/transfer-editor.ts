import { ChangeDetectionStrategy, Component, inject, output, signal } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { createTransfer, validateTransfer } from '../../domain/bookings/transfer';
import { todayLocal } from '../../domain/shared/local-date';
import { formatEuro, parseEuro } from '../../domain/shared/money';
import { AccountsStore } from '../../data/stores/accounts.store';
import { BookingsStore } from '../../data/stores/bookings.store';
import { nextSeq } from '../../data/stores/seq';
import { SelectValue } from '../../shared/select-value';

/** Umbuchung zwischen eigenen Konten erfassen (zwei verbundene Buchungen). */
@Component({
  selector: 'app-transfer-editor',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatButtonModule, MatFormFieldModule, MatInputModule, SelectValue],
  template: `
    <div class="grid2">
      <mat-form-field appearance="outline">
        <mat-label>Von</mat-label>
        <select
          matNativeControl
          data-testid="tr-from"
          [appSelectValue]="from()"
          (change)="from.set(val($event))"
        >
          @for (a of accounts.active(); track a.id) {
            <option [value]="a.id">{{ a.name }}</option>
          }
        </select>
      </mat-form-field>
      <mat-form-field appearance="outline">
        <mat-label>Nach</mat-label>
        <select
          matNativeControl
          data-testid="tr-to"
          [appSelectValue]="to()"
          (change)="to.set(val($event))"
        >
          @for (a of accounts.active(); track a.id) {
            <option [value]="a.id">{{ a.name }}</option>
          }
        </select>
      </mat-form-field>
      <mat-form-field appearance="outline">
        <mat-label>Betrag in €</mat-label>
        <input
          matInput
          data-testid="tr-amount"
          inputmode="decimal"
          autocomplete="off"
          placeholder="z. B. 500,00"
          [value]="amount"
          (input)="amount = val($event)"
        />
      </mat-form-field>
      <mat-form-field appearance="outline">
        <mat-label>Datum</mat-label>
        <input matInput type="date" [max]="today" [value]="date" (input)="date = val($event)" />
      </mat-form-field>
    </div>
    <mat-form-field appearance="outline">
      <mat-label>Text (freiwillig)</mat-label>
      <input
        matInput
        autocomplete="off"
        placeholder="z. B. Rücklage für Urlaub"
        [value]="text"
        (input)="text = val($event)"
      />
    </mat-form-field>
    <p class="muted small">
      Eine Umbuchung verschiebt Geld zwischen deinen eigenen Konten. Sie zählt nicht als Ausgabe
      oder Einnahme.
    </p>
    @for (e of errors(); track e) {
      <p class="bad" role="alert">{{ e }}</p>
    }
    <div class="actions">
      <button mat-flat-button type="button" data-testid="tr-save" (click)="save()">
        Umbuchung speichern
      </button>
      <button mat-button type="button" (click)="done.emit('')">Abbrechen</button>
    </div>
  `,
  styles: ['.grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 0 10px; }'],
})
export class TransferEditor {
  protected readonly accounts = inject(AccountsStore);
  private readonly bookings = inject(BookingsStore);
  readonly done = output<string>();
  protected readonly today = todayLocal();
  protected readonly from = signal<string>(
    this.accounts.active().find((a) => a.type === 'giro')?.id ??
      this.accounts.active()[0]?.id ??
      '',
  );
  protected readonly to = signal<string>(
    this.accounts.active().find((a) => a.id !== this.from())?.id ?? '',
  );
  protected amount = '';
  protected date = todayLocal();
  protected text = '';
  protected readonly errors = signal<string[]>([]);

  protected val(ev: Event): string {
    this.errors.set([]);
    return (ev.target as HTMLInputElement).value;
  }

  protected async save(): Promise<void> {
    const amount = parseEuro(this.amount);
    const errs = validateTransfer(
      {
        fromId: this.from(),
        toId: this.to(),
        amount: amount === null ? null : Math.abs(amount),
        date: this.date,
        text: this.text,
      },
      this.today,
    );
    this.errors.set(errs);
    if (errs.length || amount === null) return;
    const from = this.accounts.active().find((a) => a.id === this.from())!,
      to = this.accounts.active().find((a) => a.id === this.to())!;
    const pair = createTransfer(
      from,
      to,
      Math.abs(amount),
      this.date,
      this.text,
      { group: crypto.randomUUID(), a: crypto.randomUUID(), b: crypto.randomUUID() },
      [nextSeq(), nextSeq()],
    );
    await this.bookings.add(pair);
    this.done.emit(
      `Umbuchung über ${formatEuro(Math.abs(amount))} von ${from.name} nach ${to.name} gespeichert.`,
    );
  }
}
