import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { SCOPES, Scope } from '../../domain/categories/categories';
import { formatDate, todayLocal } from '../../domain/shared/local-date';
import { formatEuro } from '../../domain/shared/money';
import {
  Bucket,
  Period,
  assignMonth,
  changePercent,
  comparisonOf,
  computeStats,
  monthName,
  monthPeriod,
  shiftMonth,
  yearPeriod,
} from '../../domain/stats/statistics';
import { AccountsStore } from '../../data/stores/accounts.store';
import { BookingsStore } from '../../data/stores/bookings.store';
import { CategoriesStore } from '../../data/stores/categories.store';
import { Icon } from '../../shared/icon';
import { PrefsStore } from '../../data/stores/prefs.store';
import { computeGroups } from '../../domain/stats/groups';

const SHORT = ['Jan', 'Feb', 'Mär', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dez'];

/** Statistik (Lastenheft 13): Monat oder Jahr, drei Ebenen, alles antippbar bis zur Buchung. */
@Component({
  selector: 'app-stats-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatButtonModule, MatButtonToggleModule, Icon],
  templateUrl: './stats.page.html',
  styleUrl: './stats.page.scss',
})
export class StatsPage {
  private readonly bookings = inject(BookingsStore);
  private readonly accounts = inject(AccountsStore);
  private readonly cats = inject(CategoriesStore);
  private readonly today = todayLocal();
  protected readonly euro = formatEuro;
  protected readonly de = formatDate;

  protected readonly mode = signal<'monat' | 'jahr'>('monat');
  protected readonly month = signal(this.today.slice(0, 7));
  protected readonly year = signal(Number(this.today.slice(0, 4)));
  protected readonly openCat = signal<string | null>(null);
  protected readonly openSub = signal<string | null>(null);
  protected readonly openList = signal<string | null>(null);
  private readonly prefs = inject(PrefsStore);
  private readonly labels = computed(() => this.prefs.statSettings().loanLabels);
  protected readonly groups = computed(() =>
    computeGroups(
      this.bookings.bookings(),
      this.accounts.accounts(),
      this.prefs.statSettings(),
      this.period().months,
    ),
  );
  protected readonly groupsBefore = computed(() =>
    computeGroups(
      this.bookings.bookings(),
      this.accounts.accounts(),
      this.prefs.statSettings(),
      this.cmp().months,
      this.cmp().cutoffDay,
    ),
  );
  protected groupBefore(id: string): number {
    return this.groupsBefore().find((g) => g.group.id === id)?.total ?? 0;
  }

  private readonly first = computed(() => {
    const ms = this.bookings
      .bookings()
      .filter((b) => b.status === 'gebucht')
      .map(assignMonth)
      .sort();
    return ms[0] ?? this.today.slice(0, 7);
  });
  protected readonly period = computed<Period>(() =>
    this.mode() === 'monat'
      ? monthPeriod(this.month(), this.today)
      : yearPeriod(this.year(), this.today),
  );
  protected readonly cmp = computed(() => comparisonOf(this.period(), this.today));
  protected readonly stats = computed(() =>
    computeStats(
      this.bookings.bookings(),
      this.accounts.accounts(),
      this.cats.categories(),
      this.period().months,
      null,
      this.labels(),
    ),
  );
  protected readonly before = computed(() =>
    computeStats(
      this.bookings.bookings(),
      this.accounts.accounts(),
      this.cats.categories(),
      this.cmp().months,
      this.cmp().cutoffDay,
      this.labels(),
    ),
  );
  protected readonly hasBefore = computed(() => this.before().count > 0);
  protected readonly canPrev = computed(() =>
    this.mode() === 'monat'
      ? this.month() > this.first()
      : this.year() > Number(this.first().slice(0, 4)),
  );
  protected readonly canNext = computed(() =>
    this.mode() === 'monat'
      ? this.month() < this.today.slice(0, 7)
      : this.year() < Number(this.today.slice(0, 4)),
  );
  // Durchschnitt nur über Monate mit Daten (die Historie beginnt evtl. mitten im Jahr)
  protected readonly nMonths = computed(() =>
    Math.max(1, this.period().months.filter((m) => m >= this.first()).length),
  );
  protected readonly maxCat = computed(() =>
    Math.max(1, ...this.stats().byCategory.map((c) => c.amount)),
  );
  protected readonly bars = computed(() => {
    if (this.mode() !== 'jahr') return [];
    const y = this.year();
    const months = Array.from({ length: 12 }, (_, i) => `${y}-${String(i + 1).padStart(2, '0')}`);
    const data = months.map((m) =>
      m <= this.today.slice(0, 7) && m >= this.first()
        ? computeStats(this.bookings.bookings(), this.accounts.accounts(), this.cats.categories(), [
            m,
          ])
        : null,
    );
    const max = Math.max(1, ...data.map((d) => (d ? Math.max(d.income, d.consumption) : 0)));
    return months.map((m, i) => ({
      month: m,
      label: SHORT[i],
      d: data[i],
      inc: data[i] ? (data[i]!.income / max) * 100 : 0,
      out: data[i] ? (data[i]!.consumption / max) * 100 : 0,
    }));
  });

  protected scopeLabel(key: string): string {
    return SCOPES[key as Scope] ?? key;
  }

  protected delta(now: number, before: number, min = 0): string {
    if (!this.hasBefore()) return '';
    const p = changePercent(now, before, min);
    return p === null ? '' : `${p > 0 ? '+' : p < 0 ? '−' : '±'}${Math.abs(p)} %`;
  }

  protected catBefore(key: string): number {
    return this.before().byCategory.find((c) => c.key === key)?.amount ?? 0;
  }

  protected avg(v: number): string {
    return this.nMonths() > 1 ? `Ø ${formatEuro(Math.round(v / this.nMonths()))} je Monat` : '';
  }

  protected rate(p: number | null): string {
    return p === null ? '–' : `${(p / 10).toLocaleString('de-DE', { maximumFractionDigits: 1 })} %`;
  }

  protected setMode(m: 'monat' | 'jahr'): void {
    this.mode.set(m);
    if (m === 'jahr') this.year.set(Number(this.month().slice(0, 4)));
    this.collapse();
  }

  protected step(d: number): void {
    if (this.mode() === 'monat') this.month.set(shiftMonth(this.month(), d));
    else this.year.set(this.year() + d);
    this.collapse();
  }

  protected openMonth(m: string): void {
    this.mode.set('monat');
    this.month.set(m);
    this.collapse();
    window.scrollTo(0, 0);
  }

  protected toggleCat(k: string): void {
    this.openCat.set(this.openCat() === k ? null : k);
    this.openSub.set(null);
  }

  protected toggleSub(k: string): void {
    this.openSub.set(this.openSub() === k ? null : k);
  }

  protected toggleList(k: string): void {
    this.openList.set(this.openList() === k ? null : k);
  }

  protected items(b: Bucket) {
    return [...b.items].sort((x, y) => (x.booking.date < y.booking.date ? 1 : -1));
  }

  protected accName(id: string): string {
    return this.accounts.accounts().find((a) => a.id === id)?.name ?? 'Konto';
  }

  private collapse(): void {
    this.openCat.set(null);
    this.openSub.set(null);
    this.openList.set(null);
  }

  protected readonly monthName = monthName;
}
