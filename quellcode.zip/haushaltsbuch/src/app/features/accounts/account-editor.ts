import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  input,
  output,
  signal,
  OnInit,
} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import {
  ACCOUNT_TYPES,
  Account,
  AccountPurpose,
  AccountType,
  PURPOSES,
  validSnapshotInput,
  validateAccount,
} from '../../domain/accounts/account';
import { currentBalance, gapReport, sortedSnapshots } from '../../domain/accounts/balances';
import { formatDate, todayLocal } from '../../domain/shared/local-date';
import { formatEuro, parseEuro } from '../../domain/shared/money';
import { AccountsStore } from '../../data/stores/accounts.store';
import { SelectValue } from '../../shared/select-value';
import { BookingsStore } from '../../data/stores/bookings.store';

const euroIn = (c: number) =>
  (c / 100).toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/** Konto anlegen oder bearbeiten, direkt am Konto (Lastenheft 7.1, 19). */
@Component({
  selector: 'app-account-editor',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatButtonModule, MatFormFieldModule, MatInputModule, SelectValue],
  templateUrl: './account-editor.html',
  styles: [
    `
      .sub {
        font-size: 15px;
        margin: 16px 0 6px;
      }
      .grid2 {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 0 10px;
      }
      .snaps {
        list-style: none;
        margin: 0;
        padding: 0;
        font-size: 14px;
      }
      .snaps li {
        display: flex;
        justify-content: space-between;
        gap: 8px;
        padding: 4px 0;
        border-bottom: 1px solid var(--hb-line);
      }
      .preview {
        font-size: 14px;
      }
      hr {
        border: 0;
        border-top: 1px solid var(--hb-line);
        margin: 16px 0 4px;
      }
    `,
  ],
})
export class AccountEditor implements OnInit {
  private readonly store = inject(AccountsStore);
  private readonly bookings = inject(BookingsStore);
  readonly account = input<Account | null>(null);
  readonly focusReconcile = input(false);
  readonly closed = output<string>();

  protected readonly types = Object.entries(ACCOUNT_TYPES) as [AccountType, string][];
  protected readonly purposes = Object.entries(PURPOSES) as [AccountPurpose, string][];
  protected readonly errors = signal<string[]>([]);
  protected readonly busy = signal(false);
  protected readonly today = todayLocal();
  protected readonly euro = formatEuro;
  protected readonly de = formatDate;

  protected name = '';
  protected readonly type = signal<AccountType>('giro');
  protected identifier = '';
  protected readonly purpose = signal<AccountPurpose>('allgemein');
  // Notreserve Standard 10 € (Lastenheft 16.3)
  protected reserve = '10,00';
  protected leadDays = '2';
  protected startDate = todayLocal();
  protected startBalance = '';
  protected snapDate = todayLocal();
  protected readonly snapBalance = signal('');

  protected readonly balance = computed(() => {
    const a = this.account();
    return a ? currentBalance(a, this.bookings.bookings()) : null;
  });
  protected readonly gap = computed(() => {
    const a = this.account();
    return a ? gapReport(a, this.bookings.bookings()) : null;
  });
  protected readonly snapshots = computed(() =>
    [...sortedSnapshots(this.account() ?? ({ snapshots: [] } as unknown as Account))]
      .reverse()
      .slice(0, 5),
  );
  protected readonly snapPreview = computed(() => {
    const v = parseEuro(this.snapBalance());
    const b = this.balance();
    if (v === null || b === null) return '';
    const d = v - b;
    return d === 0
      ? 'Passt genau zum berechneten Stand.'
      : `Die App rechnet mit ${formatEuro(b)}. Differenz: ${formatEuro(d)}.`;
  });

  ngOnInit(): void {
    const a = this.account();
    if (!a) return;
    this.name = a.name;
    this.type.set(a.type);
    this.identifier = a.identifier ?? '';
    this.purpose.set(a.purpose);
    this.reserve = euroIn(a.reserve);
    this.leadDays = String(a.leadDays);
  }

  protected val(ev: Event): string {
    return (ev.target as HTMLInputElement).value;
  }

  protected draft() {
    return {
      name: this.name,
      type: this.type(),
      identifier: this.identifier,
      purpose: this.purpose(),
      reserve: parseEuro(this.reserve || '0'),
      leadDays: /^\d+$/.test(this.leadDays) ? +this.leadDays : null,
    };
  }

  protected async save(): Promise<void> {
    const a = this.account();
    const errs = validateAccount(this.draft(), this.store.accounts(), a?.id);
    if (!a) {
      const e = validSnapshotInput(this.startDate, parseEuro(this.startBalance), this.today);
      if (e) errs.push(e.replace('Kontostand', 'Kontostand am Stichtag'));
    }
    this.errors.set(errs);
    if (errs.length) return;
    this.busy.set(true);
    try {
      if (a) await this.store.update(a.id, this.draft());
      else
        await this.store.create(this.draft(), {
          date: this.startDate,
          balance: parseEuro(this.startBalance) ?? 0,
        });
      this.closed.emit(a ? 'Konto gespeichert.' : `Konto „${this.name.trim()}“ angelegt.`);
    } finally {
      this.busy.set(false);
    }
  }

  protected async reconcile(): Promise<void> {
    const a = this.account();
    if (!a) return;
    const v = parseEuro(this.snapBalance());
    const e = validSnapshotInput(this.snapDate, v, this.today);
    if (e) return this.errors.set([e]);
    this.errors.set([]);
    await this.store.addSnapshot(a.id, this.snapDate, v ?? 0, 'abgleich');
    this.snapBalance.set('');
  }

  protected async correction(): Promise<void> {
    const a = this.account();
    if (a) await this.store.bookCorrection(a.id);
  }

  protected async archive(): Promise<void> {
    const a = this.account();
    if (!a) return;
    await this.store.archive(a.id);
    this.closed.emit(`Konto „${a.name}“ archiviert.`);
  }

  protected source(s: string): string {
    return { start: 'Startsaldo', abgleich: 'von Hand abgeglichen', email: 'aus E-Mail' }[s] ?? s;
  }
}
