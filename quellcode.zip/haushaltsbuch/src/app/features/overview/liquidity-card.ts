import { MatInput } from '@angular/material/input';
import { MatFormField, MatLabel } from '@angular/material/form-field';
import { MatButton } from '@angular/material/button';
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  effect,
  inject,
  signal,
} from '@angular/core';
import { formatDate } from '../../domain/shared/local-date';
import { formatEuro, parseEuro } from '../../domain/shared/money';
import { ForecastService } from '../../data/forecast.service';
import { LiquidityService } from '../../data/liquidity.service';
import { AccountsStore } from '../../data/stores/accounts.store';
import { SelectValue } from '../../shared/select-value';
import { euroInput } from '../../domain/shared/format';

/** Liquiditätsabgleich auf der Übersicht (Lastenheft 16.1–16.8). Die App bewegt nie selbst Geld. */
@Component({
  selector: 'app-liquidity-card',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [SelectValue, MatButton, MatFormField, MatLabel, MatInput],
  template: `
    @if (svc.advice(); as a) {
      <section class="card" data-testid="advice">
        @if (a.type === 'jetzt' || a.type === 'umbuchen') {
          <h2 data-testid="advice-title">
            {{
              a.type === 'jetzt'
                ? 'Jetzt umbuchen: ' + euro(a.amount)
                : 'Umbuchung empfohlen: ' + euro(a.amount) + ' bis spätestens ' + de(a.deadline!)
            }}
          </h2>
          <dl class="kv">
            <dt>Tiefster Stand ohne Umbuchung</dt>
            <dd class="num">{{ euro(a.low.balance) }} am {{ de(a.low.date) }}</dd>
            <dt>Sicherheitspuffer</dt>
            <dd class="num">{{ euro(svc.settings().buffer) }}</dd>
            @if (a.residual) {
              <dt>Fehlbetrag</dt>
              <dd class="num">{{ euro(a.residual) }}</dd>
            }
            @for (i of a.potItems; track i.label) {
              <dt>{{ i.label }}</dt>
              <dd class="num">{{ euro(i.amount) }}</dd>
            }
          </dl>
          @for (i of gaps(); track i.label) {
            <p class="warn small">
              {{ i.label }}: Der Topf reicht nicht, {{ euro(i.gap) }} trägt das Girokonto.
            </p>
          }
        } @else if (a.type === 'ueberschuss') {
          <h2 data-testid="advice-title">
            Überschuss: {{ euro(a.amount) }} könnten aufs Tagesgeld
          </h2>
          <p class="small muted">
            Tiefster Stand bis {{ de(fc.result()!.next.end) }} voraussichtlich
            {{ euro(a.low.balance) }}; darüber hinaus über dem Puffer von
            {{ euro(svc.settings().buffer) }}.
          </p>
        } @else {
          <h2 data-testid="advice-title">Kein Umbuchungsbedarf</h2>
          <p class="small muted">
            Der Puffer von {{ euro(svc.settings().buffer) }} wird bis
            {{ de(fc.result()!.next.end) }} eingehalten; tiefster Stand {{ euro(a.low.balance) }} am
            {{ de(a.low.date) }}.
          </p>
        }
        @if (a.type !== 'ok') {
          @if (svc.sources().length) {
            <div class="grid2">
              <mat-form-field appearance="outline">
                <mat-label>{{
                  a.type === 'ueberschuss' ? 'Auf das Konto' : 'Vom Konto'
                }}</mat-label>
                <select
                  matNativeControl
                  data-testid="advice-account"
                  [appSelectValue]="accountId()"
                  (change)="accountId.set(val($event))"
                >
                  @for (s of svc.sources(); track s.account.id) {
                    <option [value]="s.account.id">
                      {{ s.account.name }} ({{ euro(s.balance) }})
                    </option>
                  }
                </select>
              </mat-form-field>
              <mat-form-field appearance="outline">
                <mat-label>Betrag in €</mat-label>
                <input
                  matInput
                  inputmode="decimal"
                  data-testid="advice-amount"
                  [value]="amount()"
                  (input)="amount.set(val($event))"
                />
              </mat-form-field>
            </div>
            @if (a.type !== 'ueberschuss' && chosen(); as c) {
              <p class="small muted">
                Verfügbar ohne Notreserve: {{ euro(availOf(c.balance, c.account.reserve)) }}; danach
                {{ euro(c.balance - (parsed() ?? 0)) }}.
              </p>
              @if ((parsed() ?? 0) > availOf(c.balance, c.account.reserve)) {
                <p class="warn small" data-testid="advice-uncovered">
                  Das Konto reicht nicht ganz:
                  {{ euro((parsed() ?? 0) - availOf(c.balance, c.account.reserve)) }} fehlen, ohne
                  die Notreserve anzutasten.
                </p>
              }
            }
            <p class="small muted">
              Überweise selbst im Online-Banking; die App bewegt kein Geld. Danach hier bestätigen.
            </p>
            <button
              mat-flat-button
              type="button"
              data-testid="advice-confirm"
              [disabled]="!parsed()"
              (click)="confirm()"
            >
              Jetzt umgebucht
            </button>
          } @else {
            <p class="warn small">
              Für eine Umbuchung fehlt ein Tagesgeldkonto. Leg es unter „Konten“ an.
            </p>
          }
        }
        @if (error()) {
          <p class="bad" role="alert">{{ error() }}</p>
        }
        @if (svc.pending().length) {
          <div class="pending small">
            @for (b of svc.pending(); track b.id) {
              <div>
                Bestätigt am {{ de(b.date) }}: {{ euro(b.amount) }} auf {{ accName(b.accountId) }};
                wartet auf die Bank.
              </div>
            }
          </div>
        }
      </section>
    }
  `,
  styles: [
    `
      h2 {
        font-size: 18px;
      }
      .kv {
        display: grid;
        grid-template-columns: 1fr auto;
        gap: 4px 12px;
        margin: 0 0 8px;
        font-size: 14px;
      }
      .kv dt {
        color: var(--hb-muted);
      }
      .kv dd {
        margin: 0;
        text-align: right;
      }
      .grid2 {
        display: grid;
        grid-template-columns: 1.4fr 1fr;
        gap: 0 10px;
      }
      .pending {
        margin-top: 10px;
        color: var(--hb-muted);
        border-top: 1px solid var(--hb-line);
        padding-top: 6px;
      }
    `,
  ],
})
export class LiquidityCard {
  protected readonly svc = inject(LiquidityService);
  protected readonly fc = inject(ForecastService);
  private readonly accounts = inject(AccountsStore);
  protected readonly euro = formatEuro;
  protected readonly de = formatDate;
  protected readonly accountId = signal('');
  protected readonly amount = signal('');
  protected readonly error = signal('');
  protected readonly parsed = computed(() => {
    const v = parseEuro(this.amount());
    return v && v > 0 ? v : null;
  });
  protected readonly chosen = computed(
    () => this.svc.sources().find((s) => s.account.id === this.accountId()) ?? null,
  );
  protected readonly gaps = computed(() =>
    (this.svc.advice()?.potItems ?? []).filter((i) => i.gap > 0),
  );

  constructor() {
    // Vorschlag übernehmen, sobald er sich ändert (16.6 dynamische Neuberechnung)
    effect(() => {
      const a = this.svc.advice();
      if (!a) return;
      this.amount.set(a.amount ? euroInput(a.amount) : '');
      this.accountId.set(a.source?.account.id ?? this.svc.sources()[0]?.account.id ?? '');
    });
  }

  protected val(ev: Event): string {
    return (ev.target as HTMLInputElement).value;
  }

  protected availOf(balance: number, reserve: number): number {
    return Math.max(0, balance - reserve);
  }

  protected accName(id: string): string {
    return this.accounts.accounts().find((a) => a.id === id)?.name ?? 'Konto';
  }

  protected async confirm(): Promise<void> {
    const a = this.svc.advice(),
      giro = this.fc.giro(),
      amount = this.parsed();
    if (!a || !giro || !amount) return;
    this.error.set('');
    try {
      if (a.type === 'ueberschuss') await this.svc.confirm(amount, giro.id, this.accountId());
      else {
        // Topf-Anteile werden zurückgeholt, wenn vom Topfkonto umgebucht wird
        const fromPotAccount = this.accountId() === this.svc.potAccount()?.account.id;
        await this.svc.confirm(amount, this.accountId(), giro.id, fromPotAccount ? a.potItems : []);
      }
    } catch (e) {
      this.error.set(e instanceof Error ? e.message : String(e));
    }
  }
}
