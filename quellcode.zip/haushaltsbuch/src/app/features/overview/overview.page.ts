import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { RouterLink } from '@angular/router';
import { PrefsStore } from '../../data/stores/prefs.store';
import { BackupService } from '../../data/backup.service';
import { LiquidityService } from '../../data/liquidity.service';
import { ForecastService } from '../../data/forecast.service';
import { RecurringStore } from '../../data/stores/recurring.store';
import { NOTICE_HINT_DAYS, contractState } from '../../domain/recurring/contracts';
import { ForecastCard } from './forecast-card';
import { LiquidityCard } from './liquidity-card';
import { CategoriesStore } from '../../data/stores/categories.store';
import { computeStats, monthName } from '../../domain/stats/statistics';
import { todayLocal } from '../../domain/shared/local-date';
import { BookingsStore } from '../../data/stores/bookings.store';
import { ACCOUNT_TYPES } from '../../domain/accounts/account';
import { formatDate } from '../../domain/shared/local-date';
import { formatEuro } from '../../domain/shared/money';
import { AccountsStore } from '../../data/stores/accounts.store';
import { Icon } from '../../shared/icon';
import { AccountEditor } from '../accounts/account-editor';

/** Übersicht (Lastenheft 13, 19): Hinweise oben, darunter die Konten; bearbeitet wird am Konto. */
@Component({
  selector: 'app-overview-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatButtonModule, RouterLink, Icon, AccountEditor, ForecastCard, LiquidityCard],
  template: `
    <div class="page">
      <h1>Übersicht</h1>
      <app-forecast-card />
      <app-liquidity-card />
      @if (hints().length || unclear() || backupDue() || notices().length) {
        <section class="card">
          <h2>Hinweise</h2>
          @for (n of notices(); track n.id) {
            <a
              class="hint-row"
              routerLink="/buchungen"
              [queryParams]="{ ansicht: 'wiederkehrend', posten: n.id }"
              data-testid="hint-notice"
              >{{ n.text }}</a
            >
          }
          @if (backupDue()) {
            <div class="hint-row backup" data-testid="hint-backup">
              <span>{{ backupText() }}</span>
              <button
                mat-flat-button
                type="button"
                data-testid="hint-backup-run"
                [disabled]="backupBusy()"
                (click)="runBackup()"
              >
                {{ backup.canShare ? 'Backup teilen' : 'Backup herunterladen' }}
              </button>
            </div>
          }
          @if (unclear()) {
            <a
              class="hint-row"
              routerLink="/buchungen"
              [queryParams]="{ pruefen: 1 }"
              data-testid="hint-unclear"
              >{{ unclear() }} {{ unclear() === 1 ? 'Buchung ist' : 'Buchungen sind' }} noch nicht
              sicher zugeordnet. Antippen zum Prüfen.</a
            >
          }
          @for (h of hints(); track h.id) {
            <button type="button" class="hint-row" (click)="open(h.id, true)">
              <span
                ><strong>{{ h.name }}:</strong> Vermutlich fehlen Buchungen über
                {{ euro(h.amount) }} seit {{ de(h.since) }}. Antippen zum Klären.</span
              >
            </button>
          }
        </section>
      }
      @if (store.views().length) {
        <section class="card month" data-testid="month-card">
          <h2>{{ monthLabel }}</h2>
          <dl class="mk">
            <div class="wide">
              <dt>Einnahmen</dt>
              <dd class="num" data-testid="m-income">{{ euro(month().income) }}</dd>
            </div>
            <div>
              <dt>− Fixkosten</dt>
              <dd class="num" data-testid="m-fix">{{ euro(month().fix) }}</dd>
            </div>
            <div>
              <dt>− Konsum</dt>
              <dd class="num" data-testid="m-konsum">{{ euro(month().konsum) }}</dd>
            </div>
            <div>
              <dt>− Finanzierung</dt>
              <dd class="num" data-testid="m-finanzierung">{{ euro(month().finanzierung) }}</dd>
            </div>
            <div>
              <dt>− Sparen</dt>
              <dd class="num" data-testid="m-sparen">{{ euro(month().savings) }}</dd>
            </div>
            <div class="wide">
              <dt>= Frei verfügbar</dt>
              <dd class="num" data-testid="m-free" [class.neg]="month().free < 0">
                {{ euro(month().free) }}
              </dd>
            </div>
          </dl>
          <a mat-button routerLink="/statistik">Mehr in der Statistik</a>
        </section>
      }
      <section class="card">
        <div class="head">
          <h2>Konten</h2>
          @if (editing() !== 'neu') {
            <button mat-stroked-button type="button" data-testid="acc-new" (click)="open('neu')">
              <app-icon name="plus" [size]="18" /> Konto anlegen
            </button>
          }
        </div>
        @if (editing() === 'neu') {
          <div class="newbox">
            <h3>Neues Konto</h3>
            <app-account-editor (closed)="done($event)" />
          </div>
        }
        @for (v of store.views(); track v.account.id) {
          <div class="acc" [class.open]="editing() === v.account.id">
            <button
              type="button"
              class="row"
              [attr.aria-expanded]="editing() === v.account.id"
              (click)="open(v.account.id)"
            >
              <span>
                <span class="t">{{ v.account.name }}</span>
                <span class="muted small"
                  >{{ typeLabel(v.account.type)
                  }}{{ v.account.identifier ? ', *' + v.account.identifier : ''
                  }}{{ v.gap.open !== 0 ? ', Differenz offen' : '' }}</span
                >
              </span>
              <span class="num amt" [class.neg]="(v.balance ?? 0) < 0">{{
                v.balance === null ? '–' : euro(v.balance)
              }}</span>
            </button>
            @if (editing() === v.account.id) {
              <app-account-editor
                [account]="v.account"
                [focusReconcile]="focus()"
                (closed)="done($event)"
              />
            }
          </div>
        } @empty {
          @if (editing() !== 'neu') {
            <p class="muted">
              Noch keine Konten. Leg zuerst dein Girokonto an, mit den letzten Ziffern der
              Kontonummer und dem heutigen Kontostand laut Online-Banking.
            </p>
          }
        }
        @if (store.views().length > 1) {
          <div class="row total">
            <span class="t">Summe der Konten</span
            ><span class="num amt">{{ euro(store.total()) }}</span>
          </div>
        }
      </section>
      @if (msg()) {
        <p class="hint" role="status">{{ msg() }}</p>
      }
    </div>
  `,
  styles: [
    `
      .mk {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 8px 12px;
        margin: 0 0 4px;
      }
      .mk .wide {
        grid-column: 1 / -1;
      }
      .mk dt {
        font-size: 13px;
        color: var(--hb-muted);
      }
      .mk dd {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
      }
      .mk .neg {
        color: var(--hb-bad-ink);
      }
      .head {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 8px;
        margin-bottom: 4px;
      }
      .head h2 {
        margin: 0;
      }
      .acc {
        border-bottom: 1px solid var(--hb-line);
      }
      .acc.open {
        background: var(--hb-bg);
        border-radius: 12px;
        padding: 0 10px 10px;
        margin: 4px -10px;
        border: 0;
      }
      .row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 12px;
        width: 100%;
        padding: 12px 0;
        background: none;
        border: 0;
        text-align: left;
        font: inherit;
        color: inherit;
        cursor: pointer;
      }
      .row > span:first-child {
        display: grid;
      }
      .t {
        font-weight: 650;
      }
      .amt {
        font-weight: 650;
        white-space: nowrap;
      }
      .neg {
        color: var(--hb-bad-ink);
      }
      .total {
        cursor: default;
        border-top: 2px solid var(--hb-ink);
        margin-top: 4px;
      }
      .newbox {
        background: var(--hb-bg);
        border-radius: 12px;
        padding: 4px 10px 10px;
        margin: 8px -10px;
      }
      .newbox h3 {
        font-size: 16px;
        margin: 8px 0;
      }
      .hint-row.backup {
        display: grid;
        gap: 8px;
        justify-items: start;
        text-decoration: none;
      }
      .hint-row {
        display: block;
        width: 100%;
        text-align: left;
        background: var(--hb-warn-soft);
        color: var(--hb-warn-ink);
        border: 0;
        border-radius: 12px;
        padding: 10px 12px;
        margin: 0 0 8px;
        font: inherit;
        font-size: 15px;
        cursor: pointer;
      }
    `,
  ],
})
export class OverviewPage {
  protected readonly store = inject(AccountsStore);
  private readonly bookings = inject(BookingsStore);
  protected readonly prefs = inject(PrefsStore);
  private readonly fcs = inject(ForecastService);
  private readonly recurring = inject(RecurringStore);
  /** Kündigungsfristen in 45 Tagen und nicht quittierte Preiserhöhungen (Lastenheft 14a) */
  protected readonly notices = computed(() => {
    const out: { id: string; text: string }[] = [];
    for (const i of this.recurring.items()) {
      const cs = contractState(i, this.todayStr);
      if (cs?.deadline && cs.days !== null && cs.days <= NOTICE_HINT_DAYS)
        out.push({
          id: i.id,
          text: `${i.contract?.provider || i.label}: Kündigung bis ${formatDate(cs.deadline)} möglich (in ${cs.days} Tagen), sonst Verlängerung bis ${formatDate(cs.renewUntil!)}.`,
        });
    }
    for (const p of this.fcs.priceChanges().filter((x) => !x.acknowledged))
      out.push({
        id: p.item.id,
        text: `Preiserhöhung: ${p.item.label} kostet seit ${formatDate(p.last.date)} ${formatEuro(-p.last.amount)} statt ${formatEuro(-p.previous.amount)} (+${p.percent.toLocaleString('de-DE')} %).`,
      });
    return out;
  });
  private readonly cats = inject(CategoriesStore);
  private readonly todayStr = todayLocal();
  protected readonly monthLabel = `Dieser Monat: ${monthName(this.todayStr.slice(0, 7))}`;
  protected readonly month = computed(() =>
    computeStats(
      this.bookings.bookings(),
      this.store.accounts(),
      this.cats.categories(),
      [this.todayStr.slice(0, 7)],
      null,
      this.prefs.statSettings().loanLabels,
      this.prefs.statSettings().groups,
      this.prefs.statSettings().pillars ?? {},
    ),
  );
  protected readonly backupAge = computed(() => {
    const d = this.prefs.lastBackup();
    return d ? Math.floor((Date.parse(this.todayStr) - Date.parse(d)) / 86400000) : null;
  });
  protected readonly backupDue = computed(
    () =>
      this.store.views().length > 0 &&
      (this.backupAge() === null ||
        this.backupAge()! >= this.prefs.backupInterval() ||
        this.prefs.bigChange()),
  );
  protected readonly backup = inject(BackupService);
  private readonly liquidity = inject(LiquidityService);
  constructor() {
    // neue Eingänge des Dauerauftrags auf die Spartöpfe verteilen (einmal je Eingang)
    void this.liquidity.autoDistribute();
  }
  protected readonly backupBusy = signal(false);
  protected readonly backupText = computed(() => {
    if (this.prefs.bigChange())
      return 'Seit dem letzten Backup gab es größere Änderungen, zum Beispiel einen Import. Jetzt sichern, am besten auf Google Drive.';
    return this.prefs.lastBackup()
      ? `Letztes Backup vor ${this.backupAge()} Tagen. Jetzt sichern, am besten auf Google Drive.`
      : 'Noch kein Backup. Jetzt sichern, am besten auf Google Drive.';
  });
  protected async runBackup(): Promise<void> {
    this.backupBusy.set(true);
    const r = await this.backup.run(this.backup.canShare ? 'share' : 'download');
    this.backupBusy.set(false);
    this.msg.set(r.message);
  }
  protected readonly unclear = computed(
    () =>
      this.bookings
        .bookings()
        .filter((b) => (b.kind === 'ausgabe' || b.kind === 'einnahme') && b.confidence !== 'sicher')
        .length,
  );
  protected readonly editing = signal<string | null>(null);
  protected readonly focus = signal(false);
  protected readonly msg = signal<string>((history.state as { msg?: string } | null)?.msg ?? '');
  protected readonly euro = formatEuro;
  protected readonly de = formatDate;
  protected readonly hints = computed(() =>
    this.store
      .views()
      .filter((v) => v.gap.open !== 0)
      .map((v) => ({
        id: v.account.id,
        name: v.account.name,
        amount: v.gap.open,
        since: v.gap.since ?? '',
      })),
  );

  protected typeLabel(t: keyof typeof ACCOUNT_TYPES): string {
    return ACCOUNT_TYPES[t];
  }

  protected open(id: string, reconcile = false): void {
    this.msg.set('');
    this.focus.set(reconcile);
    this.editing.set(this.editing() === id && !reconcile ? null : id);
    if (reconcile)
      setTimeout(
        () =>
          document
            .getElementById('abgleich')
            ?.scrollIntoView({ behavior: 'smooth', block: 'center' }),
        50,
      );
  }

  protected done(message: string): void {
    this.editing.set(null);
    this.msg.set(message);
  }
}
