import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { RouterLink } from '@angular/router';
import { BookingsStore } from '../../data/stores/bookings.store';
import { ACCOUNT_TYPES } from '../../domain/accounts/account';
import { formatDate } from '../../domain/shared/local-date';
import { formatEuro } from '../../domain/shared/money';
import { AccountsStore } from '../../data/stores/accounts.store';
import { Icon } from '../../shared/icon';
import { AccountEditor } from '../accounts/account-editor';

/** Übersicht (Lastenheft 13, 19): Hinweise oben, darunter die Konten; bearbeitet wird am Konto. */
@Component({
  selector: 'app-overview-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatButtonModule, RouterLink, Icon, AccountEditor],
  template: `
    <div class="page">
      <h1>Übersicht</h1>
      @if (hints().length || unclear()) {
        <section class="card">
          <h2>Hinweise</h2>
          @if (unclear()) {
            <a
              class="hint-row"
              routerLink="/buchungen"
              [queryParams]="{ pruefen: 1 }"
              data-testid="hint-unclear"
              >{{ unclear() }} {{ unclear() === 1 ? 'Buchung ist' : 'Buchungen sind' }} noch nicht
              sicher zugeordnet. Antippen zum Prüfen.</a
            >
          }
          @for (h of hints(); track h.id) {
            <button type="button" class="hint-row" (click)="open(h.id, true)">
              <span
                ><strong>{{ h.name }}:</strong> Vermutlich fehlen Buchungen über
                {{ euro(h.amount) }} seit {{ de(h.since) }}. Antippen zum Klären.</span
              >
            </button>
          }
        </section>
      }
      <section class="card">
        <div class="head">
          <h2>Konten</h2>
          @if (editing() !== 'neu') {
            <button mat-stroked-button type="button" data-testid="acc-new" (click)="open('neu')">
              <app-icon name="plus" [size]="18" /> Konto anlegen
            </button>
          }
        </div>
        @if (editing() === 'neu') {
          <div class="newbox">
            <h3>Neues Konto</h3>
            <app-account-editor (closed)="done($event)" />
          </div>
        }
        @for (v of store.views(); track v.account.id) {
          <div class="acc" [class.open]="editing() === v.account.id">
            <button
              type="button"
              class="row"
              [attr.aria-expanded]="editing() === v.account.id"
              (click)="open(v.account.id)"
            >
              <span>
                <span class="t">{{ v.account.name }}</span>
                <span class="muted small"
                  >{{ typeLabel(v.account.type)
                  }}{{ v.account.identifier ? ', *' + v.account.identifier : ''
                  }}{{ v.gap.open !== 0 ? ', Differenz offen' : '' }}</span
                >
              </span>
              <span class="num amt" [class.neg]="(v.balance ?? 0) < 0">{{
                v.balance === null ? '–' : euro(v.balance)
              }}</span>
            </button>
            @if (editing() === v.account.id) {
              <app-account-editor
                [account]="v.account"
                [focusReconcile]="focus()"
                (closed)="done($event)"
              />
            }
          </div>
        } @empty {
          @if (editing() !== 'neu') {
            <p class="muted">
              Noch keine Konten. Leg zuerst dein Girokonto an, mit den letzten Ziffern der
              Kontonummer und dem heutigen Kontostand laut Online-Banking.
            </p>
          }
        }
        @if (store.views().length > 1) {
          <div class="row total">
            <span class="t">Summe der Konten</span
            ><span class="num amt">{{ euro(store.total()) }}</span>
          </div>
        }
      </section>
      @if (msg()) {
        <p class="hint" role="status">{{ msg() }}</p>
      }
    </div>
  `,
  styles: [
    `
      .head {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 8px;
        margin-bottom: 4px;
      }
      .head h2 {
        margin: 0;
      }
      .acc {
        border-bottom: 1px solid var(--hb-line);
      }
      .acc.open {
        background: var(--hb-bg);
        border-radius: 12px;
        padding: 0 10px 10px;
        margin: 4px -10px;
        border: 0;
      }
      .row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 12px;
        width: 100%;
        padding: 12px 0;
        background: none;
        border: 0;
        text-align: left;
        font: inherit;
        color: inherit;
        cursor: pointer;
      }
      .row > span:first-child {
        display: grid;
      }
      .t {
        font-weight: 650;
      }
      .amt {
        font-weight: 650;
        white-space: nowrap;
      }
      .neg {
        color: var(--hb-bad-ink);
      }
      .total {
        cursor: default;
        border-top: 2px solid var(--hb-ink);
        margin-top: 4px;
      }
      .newbox {
        background: var(--hb-bg);
        border-radius: 12px;
        padding: 4px 10px 10px;
        margin: 8px -10px;
      }
      .newbox h3 {
        font-size: 16px;
        margin: 8px 0;
      }
      .hint-row {
        display: block;
        width: 100%;
        text-align: left;
        background: var(--hb-warn-soft);
        color: var(--hb-warn-ink);
        border: 0;
        border-radius: 12px;
        padding: 10px 12px;
        margin: 0 0 8px;
        font: inherit;
        font-size: 15px;
        cursor: pointer;
      }
    `,
  ],
})
export class OverviewPage {
  protected readonly store = inject(AccountsStore);
  private readonly bookings = inject(BookingsStore);
  protected readonly unclear = computed(
    () =>
      this.bookings
        .bookings()
        .filter((b) => (b.kind === 'ausgabe' || b.kind === 'einnahme') && b.confidence !== 'sicher')
        .length,
  );
  protected readonly editing = signal<string | null>(null);
  protected readonly focus = signal(false);
  protected readonly msg = signal<string>((history.state as { msg?: string } | null)?.msg ?? '');
  protected readonly euro = formatEuro;
  protected readonly de = formatDate;
  protected readonly hints = computed(() =>
    this.store
      .views()
      .filter((v) => v.gap.open !== 0)
      .map((v) => ({
        id: v.account.id,
        name: v.account.name,
        amount: v.gap.open,
        since: v.gap.since ?? '',
      })),
  );

  protected typeLabel(t: keyof typeof ACCOUNT_TYPES): string {
    return ACCOUNT_TYPES[t];
  }

  protected open(id: string, reconcile = false): void {
    this.msg.set('');
    this.focus.set(reconcile);
    this.editing.set(this.editing() === id && !reconcile ? null : id);
    if (reconcile)
      setTimeout(
        () =>
          document
            .getElementById('abgleich')
            ?.scrollIntoView({ behavior: 'smooth', block: 'center' }),
        50,
      );
  }

  protected done(message: string): void {
    this.editing.set(null);
    this.msg.set(message);
  }
}
