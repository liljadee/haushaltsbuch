import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { RouterLink } from '@angular/router';
import { balanceAt } from '../../domain/accounts/balances';
import { categoryLabel } from '../../domain/categories/categories';
import { addDays } from '../../domain/shared/bank-days';
import { formatDate, todayLocal } from '../../domain/shared/local-date';
import { formatEuro } from '../../domain/shared/money';
import { ForecastService } from '../../data/forecast.service';
import { BookingsStore } from '../../data/stores/bookings.store';
import { CategoriesStore } from '../../data/stores/categories.store';
import { PrefsStore } from '../../data/stores/prefs.store';
import { RecurringStore } from '../../data/stores/recurring.store';

const W = 340,
  H = 170,
  L = 46,
  R = 8,
  T = 12,
  B = 22;

/** Prognose auf der Übersicht (Lastenheft 13.1, 15): Leitaussage, Kontoverlauf, Überfälliges, Rechenweg. */
@Component({
  selector: 'app-forecast-card',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatButtonModule, RouterLink],
  template: `
    @if (fc.result(); as f) {
      <section class="hero card" data-testid="forecast">
        <h2 class="verdict" data-testid="verdict">{{ verdict() }}</h2>
        <p class="sub">{{ sub() }}</p>
        @if (!recurring.items().length && recurring.suggestions().length) {
          <a
            class="hint-row"
            routerLink="/buchungen"
            [queryParams]="{ ansicht: 'wiederkehrend' }"
            data-testid="hint-recurring"
            >Die App hat {{ recurring.suggestions().length }} regelmäßige Zahlungen erkannt.
            Übernimm sie, damit die Prognose Gehälter, Abbuchungen und Daueraufträge kennt.</a
          >
        }
        <svg
          [attr.viewBox]="'0 0 ' + W + ' ' + H"
          class="chart"
          role="img"
          [attr.aria-label]="verdict()"
        >
          @for (g of chart().grid; track g.y) {
            <line class="grid" [attr.x1]="L" [attr.x2]="W - R" [attr.y1]="g.y" [attr.y2]="g.y" />
            <text class="tick" [attr.x]="L - 4" [attr.y]="g.y + 3" text-anchor="end">
              {{ g.label }}
            </text>
          }
          @if (chart().zero !== null) {
            <line
              class="zero"
              [attr.x1]="L"
              [attr.x2]="W - R"
              [attr.y1]="chart().zero"
              [attr.y2]="chart().zero"
            />
          }
          <line
            class="todayline"
            [attr.x1]="chart().tx"
            [attr.x2]="chart().tx"
            [attr.y1]="T"
            [attr.y2]="H - B"
          />
          <text class="tick" [attr.x]="chart().tx" [attr.y]="H - 8" text-anchor="middle">
            heute
          </text>
          <text class="tick" [attr.x]="chart().sx" [attr.y]="H - 8" text-anchor="middle">
            Gehalt
          </text>
          <path class="hist" [attr.d]="chart().hist" />
          <path class="fut" [attr.d]="chart().fut" />
          <circle class="low" [attr.cx]="chart().lx" [attr.cy]="chart().ly" r="4" />
        </svg>
        <p class="legend small">
          <span class="lg h"></span> bisher <span class="lg f"></span> Prognose; Punkt = tiefster
          Stand
        </p>
        @if (overdue().length) {
          <div class="warn small" data-testid="overdue">
            <strong>Überfällig:</strong>
            @for (e of overdue(); track e.itemId) {
              <div>{{ e.label }} {{ euro(e.amount) }}, eingeplant für morgen</div>
            }
          </div>
        }
        <details class="calc">
          <summary>So rechnet die Prognose</summary>
          <ul class="small">
            <li>Kontostand Girokonto heute: {{ euro(f.startBalance) }}</li>
            <li>
              Gehaltszyklus: {{ de(f.cur.start) }} bis {{ de(f.cur.end) }}, danach
              {{ de(f.next.start) }} bis {{ de(f.next.end)
              }}{{
                f.anchor
                  ? ' (nach „' + f.anchor.label + '“)'
                  : ' (Kalendermonat, kein festes Gehalt eingeplant)'
              }}
            </li>
            <li>
              Feste Termine: {{ f.events.length }} Zahlungen aus „Wiederkehrend“ (Einnahmen
              {{ euro(sumIn()) }}, Ausgaben {{ euro(sumOut()) }})
            </li>
            <li>
              Variable Ausgaben je Monat: {{ euro(f.varMonthly) }} ({{
                prefs.prudence() === 'vorsichtig'
                  ? 'vorsichtig, 75-%-Quantil'
                  : 'ausgewogen, Mittelwert'
              }}
              der letzten 6 Monate, Ausreißer herausgerechnet)
            </li>
            @for (e of f.estimates.slice(0, 6); track e.categoryId) {
              <li class="indent">
                {{ cat(e.categoryId) }}: {{ euro(e.monthly)
                }}{{ e.outliers ? ' (' + e.outliers + ' Ausreißer)' : '' }}
              </li>
            }
            <li>Rest im laufenden Zyklus: {{ euro(f.curVarRest) }}</li>
            @for (s of f.seasonal; track s.categoryId + s.month) {
              <li>Saisonposten {{ cat(s.categoryId) }}: +{{ euro(s.extra) }} wie im Vorjahr</li>
            }
          </ul>
        </details>
      </section>
    }
  `,
  styles: [
    `
      .hero {
        padding-bottom: 8px;
      }
      .verdict {
        font-size: 21px;
        line-height: 1.25;
        margin: 0 0 6px;
      }
      .sub {
        color: var(--hb-muted);
        margin: 0 0 8px;
      }
      .chart {
        width: 100%;
        height: auto;
        display: block;
      }
      .grid {
        stroke: var(--hb-line);
        stroke-width: 1;
      }
      .zero {
        stroke: var(--hb-bad-ink);
        stroke-width: 1;
        stroke-dasharray: 3 3;
      }
      .todayline {
        stroke: var(--hb-muted);
        stroke-width: 1;
        stroke-dasharray: 2 3;
      }
      .tick {
        font-size: 9px;
        fill: var(--hb-muted);
      }
      .hist {
        fill: none;
        stroke: var(--hb-primary);
        stroke-width: 2;
      }
      .fut {
        fill: none;
        stroke: var(--hb-primary);
        stroke-width: 2;
        stroke-dasharray: 5 4;
      }
      .low {
        fill: var(--hb-surface);
        stroke: var(--hb-bad-ink);
        stroke-width: 2;
      }
      .legend .lg {
        display: inline-block;
        width: 14px;
        height: 0;
        border-top: 2px solid var(--hb-primary);
        vertical-align: middle;
      }
      .legend .lg.f {
        border-top-style: dashed;
      }
      .hint-row {
        display: block;
        background: var(--hb-warn-soft);
        color: var(--hb-warn-ink);
        border-radius: 12px;
        padding: 10px 12px;
        margin: 0 0 8px;
        text-decoration: none;
      }
      .calc summary {
        cursor: pointer;
        color: var(--hb-primary);
        font-size: 14px;
      }
      .indent {
        list-style: none;
        margin-left: 8px;
      }
    `,
  ],
})
export class ForecastCard {
  protected readonly fc = inject(ForecastService);
  protected readonly recurring = inject(RecurringStore);
  protected readonly prefs = inject(PrefsStore);
  private readonly bookings = inject(BookingsStore);
  private readonly cats = inject(CategoriesStore);
  private readonly today = todayLocal();
  protected readonly euro = formatEuro;
  protected readonly de = formatDate;
  protected readonly W = W;
  protected readonly L = L;
  protected readonly R = R;
  protected readonly T = T;
  protected readonly H = H;
  protected readonly B = B;

  protected readonly overdue = computed(
    () => this.fc.result()?.events.filter((e) => e.overdue) ?? [],
  );
  protected readonly sumIn = computed(() =>
    (this.fc.result()?.events ?? []).filter((e) => e.amount > 0).reduce((s, e) => s + e.amount, 0),
  );
  protected readonly sumOut = computed(() =>
    (this.fc.result()?.events ?? []).filter((e) => e.amount < 0).reduce((s, e) => s + e.amount, 0),
  );
  protected readonly verdict = computed(() => {
    const f = this.fc.result();
    if (!f) return '';
    if (f.firstNegative)
      return `Am ${formatDate(f.firstNegative.date)} rutscht das Girokonto voraussichtlich ins Minus.`;
    const buffer = this.prefs.liquidity().buffer;
    if (f.low.balance < buffer)
      return `Das Geld reicht bis zum Gehalt am ${formatDate(f.next.start)}, aber knapp: Der Puffer von ${formatEuro(buffer)} wird unterschritten.`;
    return `Das Geld reicht bis zum Gehalt am ${formatDate(f.next.start)}.`;
  });
  protected readonly sub = computed(() => {
    const f = this.fc.result();
    if (!f) return '';
    return `Tiefster Stand voraussichtlich ${formatEuro(f.low.balance)} am ${formatDate(f.low.date)}. Die Prognose reicht bis ${formatDate(f.next.end)}.`;
  });
  protected readonly chart = computed(() => {
    const f = this.fc.result()!;
    const giro = this.fc.giro()!;
    const hist: { date: string; balance: number }[] = [];
    for (let d = addDays(this.today, -14); d <= this.today; d = addDays(d, 1)) {
      const b = balanceAt(giro, this.bookings.bookings(), d);
      if (b !== null) hist.push({ date: d, balance: b });
    }
    const fut = [{ date: this.today, balance: f.startBalance }, ...f.series];
    const all = [...hist, ...fut],
      first = all[0].date,
      last = all[all.length - 1].date;
    const t = (d: string) =>
      (Date.parse(d) - Date.parse(first)) / Math.max(1, Date.parse(last) - Date.parse(first));
    const vals = all.map((p) => p.balance);
    let lo = Math.min(0, ...vals),
      hi = Math.max(...vals);
    const step =
      Math.pow(10, Math.floor(Math.log10(Math.max(1, hi - lo)))) *
      (hi - lo > 5 * Math.pow(10, Math.floor(Math.log10(Math.max(1, hi - lo)))) ? 1 : 0.5);
    lo = Math.floor(lo / step) * step;
    hi = Math.ceil(hi / step) * step || step;
    const X = (d: string) => L + t(d) * (W - L - R),
      Y = (v: number) => T + ((hi - v) / (hi - lo)) * (H - T - B);
    const path = (ps: { date: string; balance: number }[]) =>
      ps
        .map((p, i) => `${i ? 'L' : 'M'}${X(p.date).toFixed(1)} ${Y(p.balance).toFixed(1)}`)
        .join('');
    const grid = [];
    for (let v = lo; v <= hi + 1; v += step)
      grid.push({
        y: Y(v),
        label: new Intl.NumberFormat('de-DE', { maximumFractionDigits: 0 }).format(v / 100),
      });
    return {
      hist: path(hist),
      fut: path(fut),
      grid,
      zero: lo < 0 ? Y(0) : null,
      tx: X(this.today),
      sx: X(f.next.start),
      lx: X(f.low.date),
      ly: Y(f.low.balance),
    };
  });

  protected cat(id: string): string {
    return id === 'none' ? 'Nicht zugeordnet' : categoryLabel(this.cats.categories(), id, null);
  }
}
