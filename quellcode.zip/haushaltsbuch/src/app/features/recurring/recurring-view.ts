import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  computed,
  inject,
  input,
  signal,
} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { categoryLabel } from '../../domain/categories/categories';
import { NOTICE_HINT_DAYS, contractState, isUsageBased } from '../../domain/recurring/contracts';
import { INTERVALS, Interval, RecurringItem, occurrences } from '../../domain/recurring/recurring';
import { addDays } from '../../domain/shared/bank-days';
import { formatDate, todayLocal } from '../../domain/shared/local-date';
import { formatEuro, parseEuro } from '../../domain/shared/money';
import { ForecastService } from '../../data/forecast.service';
import { AccountsStore } from '../../data/stores/accounts.store';
import { CategoriesStore } from '../../data/stores/categories.store';
import { RecurringStore } from '../../data/stores/recurring.store';
import { SelectValue } from '../../shared/select-value';
import { CategoryPicker } from '../bookings/category-picker';

const MONTHS = ['Jan', 'Feb', 'Mär', 'Apr', 'Mai', 'Jun', 'Jul', 'Aug', 'Sep', 'Okt', 'Nov', 'Dez'];
const euroIn = (c: number) =>
  (Math.abs(c) / 100).toLocaleString('de-DE', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

/** Wiederkehrende Zahlungen: Vorschläge bestätigen, Posten und Vertragsdaten pflegen (Lastenheft 14, 14a). */
@Component({
  selector: 'app-recurring-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    MatButtonModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatInputModule,
    SelectValue,
    CategoryPicker,
  ],
  templateUrl: './recurring-view.html',
  styleUrl: './recurring-view.scss',
})
export class RecurringView implements OnInit {
  protected readonly store = inject(RecurringStore);
  private readonly cats = inject(CategoriesStore);
  private readonly accounts = inject(AccountsStore);
  private readonly fc = inject(ForecastService);
  readonly openId = input<string | null>(null);
  private readonly today = todayLocal();
  protected readonly euro = formatEuro;
  protected readonly de = formatDate;
  protected readonly intervals = Object.entries(INTERVALS) as [
    Interval,
    { label: string; months: number },
  ][];
  protected readonly monthNames = MONTHS;
  protected readonly open = signal<string | null>(null);
  protected readonly draft = signal<RecurringItem | null>(null);
  protected readonly amount = signal('');
  protected readonly error = signal('');
  protected readonly msg = signal('');

  protected readonly list = computed(() =>
    this.store
      .items()
      .map((item) => {
        const next = occurrences(item, this.today, addDays(this.today, 400))[0]?.date ?? null;
        const cs = contractState(item, this.today);
        const pc =
          this.fc.priceChanges().find((p) => p.item.id === item.id && !p.acknowledged) ?? null;
        return { item, next, cs, pc };
      })
      .sort((a, b) => (a.next ?? '9999').localeCompare(b.next ?? '9999')),
  );

  ngOnInit(): void {
    const id = this.openId();
    if (id) this.edit(this.store.items().find((i) => i.id === id) ?? null);
  }

  protected rhythm(i: RecurringItem): string {
    const base = INTERVALS[i.interval].label;
    const ms = i.interval === 'monat' ? '' : ` (${i.months.map((m) => MONTHS[m - 1]).join(', ')})`;
    return `${base}${ms} am ${i.day}.`;
  }

  protected cat(i: RecurringItem): string {
    return i.categoryId
      ? categoryLabel(this.cats.categories(), i.categoryId, i.subCategory)
      : i.amount < 0
        ? 'ohne Kategorie'
        : 'Einnahme';
  }

  protected accName(id: string): string {
    return this.accounts.accounts().find((a) => a.id === id)?.name ?? '';
  }

  protected usage(i: RecurringItem): boolean {
    return isUsageBased(i);
  }

  protected soon(days: number | null): boolean {
    return days !== null && days <= NOTICE_HINT_DAYS;
  }

  protected async confirm(s: RecurringItem): Promise<void> {
    await this.store.confirm(s);
    this.msg.set(`„${s.label}“ wird ab jetzt eingeplant.`);
  }

  protected async confirmAll(): Promise<void> {
    const n = await this.store.confirmAll();
    this.msg.set(`${n} wiederkehrende Zahlungen übernommen.`);
  }

  protected async reject(s: RecurringItem): Promise<void> {
    await this.store.reject(s);
    this.msg.set(`„${s.label}“ wird nicht mehr vorgeschlagen.`);
  }

  protected edit(i: RecurringItem | null): void {
    this.error.set('');
    if (!i || this.open() === i.id) {
      this.open.set(null);
      this.draft.set(null);
      return;
    }
    this.open.set(i.id);
    this.draft.set({ ...i, contract: i.contract ? { ...i.contract } : null });
    this.amount.set(euroIn(i.amount));
  }

  protected patch(p: Partial<RecurringItem>): void {
    const d = this.draft();
    if (d) this.draft.set({ ...d, ...p });
  }

  protected setInterval(v: string): void {
    const d = this.draft();
    if (!d) return;
    const interval = v as Interval,
      step = INTERVALS[interval].months,
      first = d.months[0] ?? 1;
    this.patch({
      interval,
      months: Array.from({ length: 12 / step }, (_, k) => ((first - 1 + k * step) % 12) + 1).sort(
        (a, b) => a - b,
      ),
    });
  }

  /** mögliche erste Monate: bei vierteljährlich Jan bis Mär, halbjährlich Jan bis Jun, jährlich alle */
  protected firstMonths(d: RecurringItem): number[] {
    return Array.from({ length: INTERVALS[d.interval].months }, (_, k) => k + 1);
  }

  protected setFirstMonth(v: string): void {
    const d = this.draft();
    if (!d) return;
    const step = INTERVALS[d.interval].months,
      first = Number(v);
    this.patch({
      months: Array.from({ length: 12 / step }, (_, k) => ((first - 1 + k * step) % 12) + 1).sort(
        (a, b) => a - b,
      ),
    });
  }

  protected setContract(on: boolean): void {
    const d = this.draft();
    if (!d) return;
    this.patch({
      contract: on
        ? (d.contract ?? {
            provider: d.label,
            monthly: false,
            until: null,
            noticeN: 1,
            noticeUnit: 'Monate',
            renewMonths: 12,
          })
        : null,
    });
  }

  protected patchContract(p: Record<string, unknown>): void {
    const d = this.draft();
    if (d?.contract) this.patch({ contract: { ...d.contract, ...p } });
  }

  protected async save(): Promise<void> {
    const d = this.draft();
    if (!d) return;
    const a = parseEuro(this.amount());
    if (a === null || a === 0) return this.error.set('Bitte einen Betrag wie 29,59 eingeben.');
    if (!d.label.trim()) return this.error.set('Bitte eine Bezeichnung eingeben.');
    if (!(d.day >= 1 && d.day <= 31)) return this.error.set('Der Tag ist eine Zahl von 1 bis 31.');
    await this.store.save({
      ...d,
      label: d.label.trim(),
      amount: Math.sign(d.amount || -1) * Math.abs(a),
    });
    this.msg.set('Gespeichert. Die Prognose rechnet neu.');
    this.edit(null);
  }

  protected async remove(): Promise<void> {
    const d = this.draft();
    if (!d) return;
    await this.store.remove(d.id);
    this.msg.set(`„${d.label}“ entfernt.`);
    this.edit(null);
  }

  protected async ackPrice(id: string): Promise<void> {
    const pc = this.fc.priceChanges().find((p) => p.item.id === id);
    if (!pc) return;
    await this.store.save({ ...pc.item, priceAckBookingId: pc.last.id, amount: pc.last.amount });
    this.msg.set('Zur Kenntnis genommen. Die Prognose rechnet mit dem neuen Betrag.');
  }

  protected val(ev: Event): string {
    return (ev.target as HTMLInputElement).value;
  }
}
