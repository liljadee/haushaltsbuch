import { MatIconButton } from '@angular/material/button';
import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { occurrences } from '../../domain/recurring/recurring';
import { addDays, daysInMonth, isBankDay, weekday } from '../../domain/shared/bank-days';
import { formatDate, todayLocal } from '../../domain/shared/local-date';
import { formatEuro } from '../../domain/shared/money';
import { monthName, shiftMonth } from '../../domain/stats/statistics';
import { ForecastService } from '../../data/forecast.service';
import { BookingsStore } from '../../data/stores/bookings.store';
import { RecurringStore } from '../../data/stores/recurring.store';
import { Icon } from '../../shared/icon';

interface Entry {
  text: string;
  amount: number;
  planned: boolean;
  overdue?: boolean;
}

/** Kalender des Girokontos (Lastenheft 19): gebuchte und geplante Zahlungen je Tag. */
@Component({
  selector: 'app-calendar-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [Icon, MatIconButton],
  template: `
    <div class="nav">
      <button mat-icon-button type="button" aria-label="Vormonat" (click)="month.set(shift(-1))">
        <app-icon name="back" />
      </button>
      <h2 data-testid="cal-label">{{ label() }}</h2>
      <button
        mat-icon-button
        type="button"
        aria-label="Folgemonat"
        class="flip"
        (click)="month.set(shift(1))"
      >
        <app-icon name="back" />
      </button>
    </div>
    <p class="muted small">
      Girokonto. Gestrichelt umrandet: geplant; variable Ausgaben wie Einkäufe sind nicht einzeln
      eingeplant.
    </p>
    <div class="grid" role="grid">
      @for (w of weekdays; track w) {
        <div class="w">{{ w }}</div>
      }
      @for (c of cells(); track $index) {
        @if (c) {
          <button
            type="button"
            class="cell"
            [class.fut]="c.date > today"
            [class.today]="c.date === today"
            [class.sel]="c.date === day()"
            [class.off]="!c.bank"
            [attr.data-testid]="'cal-' + c.date"
            (click)="day.set(c.date)"
          >
            <span class="d">{{ +c.date.slice(8) }}</span>
            @if (c.out) {
              <span class="o">−{{ short(c.out) }}</span>
            }
            @if (c.inc) {
              <span class="i">+{{ short(c.inc) }}</span>
            }
          </button>
        } @else {
          <div class="cell empty"></div>
        }
      }
    </div>
    <section class="card detail">
      <h2>{{ day() ? de(day()!) : 'Tag antippen' }}</h2>
      @for (e of entries(); track $index) {
        <div class="row">
          <span
            >{{ e.text }}
            <span class="muted small">{{
              e.overdue ? 'überfällig' : e.planned ? 'geplant' : 'gebucht'
            }}</span></span
          ><span class="num" [class.pos]="e.amount > 0">{{ euro(e.amount) }}</span>
        </div>
      } @empty {
        <p class="muted">An diesem Tag ist nichts gebucht oder geplant.</p>
      }
    </section>
  `,
  styles: [
    `
      .nav {
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      .nav h2 {
        margin: 0;
        font-size: 17px;
      }
      .flip {
        transform: scaleX(-1);
      }
      .grid {
        display: grid;
        grid-template-columns: repeat(7, 1fr);
        gap: 4px;
      }
      .w {
        text-align: center;
        font-size: 12px;
        font-weight: 650;
        color: var(--hb-muted);
      }
      .cell {
        min-height: 56px;
        border-radius: 10px;
        background: var(--hb-surface);
        border: 1px solid transparent;
        padding: 4px 2px;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 1px;
        cursor: pointer;
        font: inherit;
        color: inherit;
        font-variant-numeric: tabular-nums;
      }
      .cell.empty {
        background: transparent;
        cursor: default;
      }
      .cell.fut {
        background: transparent;
        border: 1px dashed var(--hb-line);
      }
      .cell.today {
        border: 2px solid var(--hb-primary);
      }
      .cell.sel {
        background: var(--hb-primary-soft);
      }
      .cell.off .d {
        color: var(--hb-muted);
      }
      .d {
        font-size: 13px;
        font-weight: 650;
      }
      .o {
        font-size: 11px;
      }
      .i {
        font-size: 11px;
        color: var(--hb-primary);
        font-weight: 650;
      }
      .detail {
        margin-top: 12px;
      }
      .row {
        display: flex;
        justify-content: space-between;
        gap: 10px;
        padding: 6px 0;
        border-top: 1px solid var(--hb-line);
      }
      .pos {
        color: var(--hb-primary);
      }
    `,
  ],
})
export class CalendarView {
  private readonly bookings = inject(BookingsStore);
  private readonly recurring = inject(RecurringStore);
  private readonly fc = inject(ForecastService);
  protected readonly today = todayLocal();
  protected readonly month = signal(this.today.slice(0, 7));
  protected readonly day = signal<string | null>(this.today);
  protected readonly weekdays = ['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'];
  protected readonly euro = formatEuro;
  protected readonly de = formatDate;
  protected readonly label = computed(() => monthName(this.month()));

  private readonly byDay = computed(() => {
    const giro = this.fc.giro();
    const map = new Map<string, Entry[]>();
    if (!giro) return map;
    const m = this.month(),
      first = `${m}-01`,
      last = `${m}-${String(daysInMonth(+m.slice(0, 4), +m.slice(5, 7))).padStart(2, '0')}`;
    const push = (d: string, e: Entry) => map.set(d, [...(map.get(d) ?? []), e]);
    for (const b of this.bookings.bookings())
      if (b.accountId === giro.id && b.status === 'gebucht' && b.date >= first && b.date <= last)
        push(b.date, { text: b.text, amount: b.amount, planned: false });
    const f = this.fc.result();
    const horizon = f?.next.end ?? this.today;
    for (const ev of f?.events ?? [])
      if (ev.date >= first && ev.date <= last)
        push(ev.date, { text: ev.label, amount: ev.amount, planned: true, overdue: ev.overdue });
    // jenseits des Prognosezeitraums: Termine der eingeplanten Zahlungen
    const from = horizon >= first ? addDays(horizon, 1) : first;
    if (from <= last)
      for (const item of this.fc.refined().filter((i) => i.active && i.accountId === giro.id))
        for (const o of occurrences(item, from, last))
          push(o.date, { text: item.label, amount: item.amount, planned: true });
    return map;
  });
  protected readonly cells = computed(() => {
    const m = this.month(),
      y = +m.slice(0, 4),
      mo = +m.slice(5, 7),
      n = daysInMonth(y, mo);
    const offset = (weekday(`${m}-01`) + 6) % 7;
    const out: ({ date: string; out: number; inc: number; bank: boolean } | null)[] = Array.from(
      { length: offset },
      () => null,
    );
    for (let d = 1; d <= n; d++) {
      const date = `${m}-${String(d).padStart(2, '0')}`,
        list = this.byDay().get(date) ?? [];
      out.push({
        date,
        out: -list.filter((e) => e.amount < 0).reduce((s, e) => s + e.amount, 0),
        inc: list.filter((e) => e.amount > 0).reduce((s, e) => s + e.amount, 0),
        bank: isBankDay(date),
      });
    }
    return out;
  });
  protected readonly entries = computed(() =>
    [...(this.byDay().get(this.day() ?? '') ?? [])].sort((a, b) => a.amount - b.amount),
  );

  protected shift(n: number): string {
    this.day.set(null);
    return shiftMonth(this.month(), n);
  }

  protected short(c: number): string {
    return new Intl.NumberFormat('de-DE', { maximumFractionDigits: 0 }).format(c / 100);
  }
}
