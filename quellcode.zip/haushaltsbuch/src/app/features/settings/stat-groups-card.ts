import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import {
  StatGroup,
  StatGroupMember,
  StatSettings,
  listLoans,
  loanLabel,
} from '../../domain/stats/groups';
import { AccountsStore } from '../../data/stores/accounts.store';
import { BookingsStore } from '../../data/stores/bookings.store';
import { PrefsStore } from '../../data/stores/prefs.store';

/** Einstellungen → Statistik: Kredite benennen, Kredite und Sparkonten zu eigenen Gruppen zusammenfassen. */
@Component({
  selector: 'app-stat-groups-card',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatButtonModule, MatCheckboxModule, MatFormFieldModule, MatInputModule],
  template: `
    <div class="card" data-testid="stat-groups">
      <h2>Statistik: Kredite und Bausparen</h2>
      <p class="small muted">
        Kredite erkennt die App an Buchungstexten wie „Kreditrate Hauskredit“ oder „Sondertilgung
        Hauskredit“. Hier legst du fest, wie sie in der Statistik heißen und was zusammengefasst
        wird.
      </p>
      <h3>Anzeigenamen der Kredite</h3>
      @for (l of loans(); track l.key) {
        <mat-form-field appearance="outline">
          <mat-label>{{ l.name }} ({{ l.count }} Buchungen)</mat-label>
          <input
            matInput
            [attr.data-testid]="'loan-label-' + l.key"
            [value]="draft().loanLabels[l.key] ?? ''"
            placeholder="wie bisher"
            (input)="setLabel(l.key, val($event))"
          />
        </mat-form-field>
      } @empty {
        <p class="small muted">Noch keine Kreditraten erkannt.</p>
      }
      <h3>Eigene Gruppen</h3>
      <p class="small muted">
        Zum Beispiel „Hausfinanzierung“ = Rate Hauskredit + Sparrate Bausparvertrag. Die Gruppen
        sind eine zusätzliche Sicht; Konsum und Sparen bleiben in der Statistik getrennt gezählt.
      </p>
      @for (g of draft().groups; track g.id; let gi = $index) {
        <div class="grp">
          <div class="gh">
            <mat-form-field appearance="outline">
              <mat-label>Name der Gruppe</mat-label>
              <input
                matInput
                [attr.data-testid]="'group-name-' + gi"
                [value]="g.name"
                (input)="rename(g.id, val($event))"
              />
            </mat-form-field>
            <button mat-button type="button" class="danger" (click)="removeGroup(g.id)">
              Löschen
            </button>
          </div>
          @for (o of options(); track o.type + o.key) {
            <mat-checkbox
              [checked]="has(g, o)"
              [attr.data-testid]="'member-' + gi + '-' + o.label"
              (change)="toggle(g.id, o, $event.checked)"
              >{{ o.kind }}: {{ o.label }}</mat-checkbox
            >
          }
        </div>
      }
      <div class="actions">
        <button mat-stroked-button type="button" data-testid="group-add" (click)="addGroup()">
          Gruppe anlegen
        </button>
        <button
          mat-flat-button
          type="button"
          data-testid="groups-save"
          [disabled]="!dirty()"
          (click)="save()"
        >
          Speichern
        </button>
      </div>
      @if (msg()) {
        <p class="hint small" role="status">{{ msg() }}</p>
      }
    </div>
  `,
  styles: [
    `
      h3 {
        font-size: 15px;
        margin: 14px 0 6px;
      }
      .grp {
        border-top: 1px solid var(--hb-line);
        padding-top: 8px;
        margin-top: 8px;
      }
      .gh {
        display: grid;
        grid-template-columns: 1fr auto;
        gap: 8px;
        align-items: start;
      }
      mat-checkbox {
        display: block;
      }
      .danger {
        color: var(--hb-bad-ink);
      }
    `,
  ],
})
export class StatGroupsCard {
  private readonly prefs = inject(PrefsStore);
  private readonly bookings = inject(BookingsStore);
  private readonly accounts = inject(AccountsStore);
  protected readonly draft = signal<StatSettings>(structuredClone(this.prefs.statSettings()));
  protected readonly dirty = signal(false);
  protected readonly msg = signal('');
  protected readonly loans = computed(() => listLoans(this.bookings.bookings()));
  protected readonly options = computed(() => [
    ...this.loans().map((l) => ({
      type: 'kredit' as const,
      key: l.key,
      kind: 'Kredit',
      label: loanLabel(l.key, l.name, this.draft()),
    })),
    ...this.accounts
      .active()
      .filter((a) => a.type !== 'giro')
      .map((a) => ({
        type: 'konto' as const,
        key: a.id,
        kind: a.type === 'bauspar' ? 'Bausparvertrag' : 'Sparkonto',
        label: a.name,
      })),
  ]);

  protected val(ev: Event): string {
    return (ev.target as HTMLInputElement).value;
  }

  private update(fn: (s: StatSettings) => StatSettings): void {
    this.draft.set(fn(structuredClone(this.draft())));
    this.dirty.set(true);
    this.msg.set('');
  }

  protected setLabel(key: string, v: string): void {
    this.update((s) => ({ ...s, loanLabels: { ...s.loanLabels, [key]: v } }));
  }

  protected addGroup(): void {
    this.update((s) => ({
      ...s,
      groups: [
        ...s.groups,
        {
          id: crypto.randomUUID(),
          name: s.groups.length ? 'Neue Gruppe' : 'Hausfinanzierung',
          members: [],
        },
      ],
    }));
  }

  protected removeGroup(id: string): void {
    this.update((s) => ({ ...s, groups: s.groups.filter((g) => g.id !== id) }));
  }

  protected rename(id: string, name: string): void {
    this.update((s) => ({ ...s, groups: s.groups.map((g) => (g.id === id ? { ...g, name } : g)) }));
  }

  protected has(g: StatGroup, o: StatGroupMember): boolean {
    return g.members.some((m) => m.type === o.type && m.key === o.key);
  }

  protected toggle(id: string, o: StatGroupMember, on: boolean): void {
    this.update((s) => ({
      ...s,
      groups: s.groups.map((g) =>
        g.id !== id
          ? g
          : {
              ...g,
              members: on
                ? [...g.members, { type: o.type, key: o.key }]
                : g.members.filter((m) => !(m.type === o.type && m.key === o.key)),
            },
      ),
    }));
  }

  protected async save(): Promise<void> {
    const s = this.draft();
    await this.prefs.setStatSettings({
      loanLabels: Object.fromEntries(Object.entries(s.loanLabels).filter(([, v]) => v.trim())),
      groups: s.groups.map((g) => ({ ...g, name: g.name.trim() || 'Gruppe' })),
    });
    this.dirty.set(false);
    this.msg.set('Gespeichert. Die Statistik zeigt die Gruppen unter „Eigene Gruppen“.');
  }
}
