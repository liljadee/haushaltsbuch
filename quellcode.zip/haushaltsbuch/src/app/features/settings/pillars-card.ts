import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { forType } from '../../domain/categories/categories';
import { PILLARS, PILLAR_ORDER, Pillar, pillarOf } from '../../domain/stats/pillars';
import { CategoriesStore } from '../../data/stores/categories.store';
import { PrefsStore } from '../../data/stores/prefs.store';
import { SelectValue } from '../../shared/select-value';

/** Einstellungen → Statistik: jede Ausgabenkategorie (und auf Wunsch jede Unterkategorie) einer Säule zuordnen. */
@Component({
  selector: 'app-pillars-card',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatButtonModule, MatFormFieldModule, MatInputModule, SelectValue],
  template: `
    <div class="card" data-testid="pillars-card">
      <h2>Statistik: Säulen</h2>
      <p class="small muted">
        Fixkosten sind laufende, notwendige Kosten ohne Freizeit; Konsum ist alles andere, auch
        Anschaffungen wie ein neues Auto. Die Kategorie gilt für alle Unterkategorien ohne eigene
        Wahl.
      </p>
      @for (c of cats(); track c.id) {
        <div class="cat">
          <div class="line">
            <span class="name">{{ c.name }}</span>
            <select
              matNativeControl
              class="sel"
              [attr.data-testid]="'pillar-' + c.id"
              [appSelectValue]="eff(c.id, null)"
              (change)="set(c.id, val($event))"
            >
              @for (p of order; track p) {
                <option [value]="p">{{ names[p] }}</option>
              }
            </select>
          </div>
          @if (c.subs.length) {
            <button type="button" class="linkish small" (click)="toggle(c.id)">
              {{
                open() === c.id
                  ? 'Unterkategorien ausblenden'
                  : 'Unterkategorien einzeln (' + c.subs.length + ')'
              }}
            </button>
            @if (open() === c.id) {
              @for (s of c.subs; track s.name) {
                <div class="line sub">
                  <span class="name">{{ s.name }}</span>
                  <select
                    matNativeControl
                    class="sel"
                    [attr.data-testid]="'pillar-' + c.id + '|' + s.name"
                    [appSelectValue]="eff(c.id, s.name)"
                    (change)="set(c.id + '|' + s.name, val($event))"
                  >
                    @for (p of order; track p) {
                      <option [value]="p">{{ names[p] }}</option>
                    }
                  </select>
                </div>
              }
            }
          }
        </div>
      }
      <div class="actions">
        <button
          mat-flat-button
          type="button"
          data-testid="pillars-save"
          [disabled]="!dirty()"
          (click)="save()"
        >
          Speichern
        </button>
        <button mat-button type="button" (click)="reset()">Voreinstellung wiederherstellen</button>
      </div>
      @if (msg()) {
        <p class="hint small" role="status">{{ msg() }}</p>
      }
    </div>
  `,
  styles: [
    `
      .cat {
        border-top: 1px solid var(--hb-line);
        padding: 6px 0;
      }
      .line {
        display: grid;
        grid-template-columns: 1fr 9.5em;
        gap: 8px;
        align-items: center;
      }
      .line.sub {
        padding-left: 14px;
        font-size: 14px;
        margin-top: 4px;
      }
      .name {
        font-weight: 600;
      }
      .sub .name {
        font-weight: 400;
      }
      .sel {
        font: inherit;
        padding: 6px;
        border-radius: 8px;
        border: 1px solid var(--hb-line);
        background: var(--hb-surface);
        color: inherit;
      }
      .linkish {
        background: none;
        border: 0;
        color: var(--hb-primary);
        text-decoration: underline;
        padding: 2px 0;
        font: inherit;
        cursor: pointer;
      }
    `,
  ],
})
export class PillarsCard {
  private readonly prefs = inject(PrefsStore);
  private readonly catStore = inject(CategoriesStore);
  protected readonly order = PILLAR_ORDER;
  protected readonly names = PILLARS;
  protected readonly cats = computed(() => forType(this.catStore.categories(), 'ausgabe'));
  protected readonly draft = signal<Record<string, Pillar>>({
    ...(this.prefs.statSettings().pillars ?? {}),
  });
  protected readonly open = signal<string | null>(null);
  protected readonly dirty = signal(false);
  protected readonly msg = signal('');

  protected val(ev: Event): string {
    return (ev.target as HTMLSelectElement).value;
  }

  protected eff(cat: string, sub: string | null): Pillar {
    return pillarOf(cat, sub, this.draft());
  }

  protected set(key: string, v: string): void {
    this.draft.update((d) => ({ ...d, [key]: v as Pillar }));
    this.dirty.set(true);
    this.msg.set('');
  }

  protected toggle(id: string): void {
    this.open.set(this.open() === id ? null : id);
  }

  protected reset(): void {
    this.draft.set({});
    this.dirty.set(true);
  }

  protected async save(): Promise<void> {
    await this.prefs.setStatSettings({ ...this.prefs.statSettings(), pillars: this.draft() });
    this.dirty.set(false);
    this.msg.set('Gespeichert. Statistik und Übersicht rechnen mit der neuen Zuordnung.');
  }
}
