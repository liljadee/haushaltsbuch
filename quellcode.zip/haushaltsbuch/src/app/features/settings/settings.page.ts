import {
  generateRecoveryKey,
  normalizeGroup,
  normalizeRecoveryKey,
  splitRecoveryKey,
} from '../../domain/shared/recovery-key';
import { randomBytes } from '../../data/crypto/key-derivation';
import { TourService } from '../onboarding/tour';
import { MatButtonToggle, MatButtonToggleGroup } from '@angular/material/button-toggle';
import { coverage, monthLabel } from '../../domain/accounts/coverage';
import { EXPORT_KINDS, ExportKind } from '../../domain/export/export';
import { todayLocal } from '../../domain/shared/local-date';
import { ExportService } from '../../data/export.service';
import { AccountsStore } from '../../data/stores/accounts.store';
import { BookingsStore } from '../../data/stores/bookings.store';
import { shareOrDownload } from '../../shared/file-share';
import { MatCheckbox } from '@angular/material/checkbox';
import { MatInput } from '@angular/material/input';
import { MatFormField, MatLabel } from '@angular/material/form-field';
import { MatAnchor, MatButton } from '@angular/material/button';
import { ChangeDetectionStrategy, Component, inject, signal, computed } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { MIN_PASSWORD_LENGTH } from '../../data/crypto/key-derivation';
import { categoryLabel } from '../../domain/categories/categories';
import { formatEuro, parseEuro } from '../../domain/shared/money';
import { CategoriesStore } from '../../data/stores/categories.store';
import { RulesStore } from '../../data/stores/rules.store';
import { PrefsStore } from '../../data/stores/prefs.store';
import { SelectValue } from '../../shared/select-value';
import { StatGroupsCard } from './stat-groups-card';
import { PillarsCard } from './pillars-card';
import { LockService } from '../../data/session/lock.service';
import { UpdateService } from '../../data/session/update.service';
import { BackupService } from '../../data/backup.service';
import { MirrorService } from '../../data/mirror.service';
import { LoansService } from '../../data/loans.service';
import { SplitService } from '../../data/split.service';
import { SplitTemplate } from '../../domain/bookings/split-templates';
import { APP_VERSION, VaultService } from '../../data/vault.service';
import { Icon } from '../../shared/icon';

@Component({
  selector: 'app-settings-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    RouterLink,
    Icon,
    SelectValue,
    StatGroupsCard,
    PillarsCard,
    MatButton,
    MatAnchor,
    MatFormField,
    MatLabel,
    MatInput,
    MatCheckbox,
    MatButtonToggleGroup,
    MatButtonToggle,
  ],
  template: `
    <div class="page">
      <h1>Einstellungen</h1>

      <div class="card">
        <h2>Backup</h2>
        <p class="small">
          Das Backup ist eine verschlüsselte Datei (.hhb). Öffnen lässt sie sich nur mit deinem
          Wiederherstellungsschlüssel{{
            vault.meta()?.password ? ' oder deinem App-Passwort' : ''
          }}.
        </p>
        <p class="small" data-testid="backup-contents">
          Im Backup steckt alles: Konten mit Zweck, Notreserve und Überweisungsdauer, alle Buchungen
          und Kategorien, gelernte Regeln, wiederkehrende Zahlungen mit Vertragsdaten, Spartöpfe
          samt Verteilung, Statistik-Säulen, Kredit-Namen und eigene Gruppen, Puffer, Vorsichtsstufe
          und alle übrigen Einstellungen. Nur der Fingerabdruck gehört zum Gerät; den richtest du
          nach dem Einspielen neu ein.
        </p>
        <mat-form-field appearance="outline">
          <mat-label>Erinnerung an ein Backup</mat-label>
          <select
            matNativeControl
            data-testid="backup-interval"
            [appSelectValue]="'' + prefs.backupInterval()"
            (change)="setInterval($event)"
          >
            <option value="7">wöchentlich</option>
            <option value="14">alle zwei Wochen</option>
            <option value="30">monatlich</option>
          </select>
        </mat-form-field>
        <p class="small muted">
          Zusätzlich erinnert die App nach größeren Änderungen wie einem Import. Am sichersten ist
          „Backup teilen“ auf Google Drive: Dort bleibt die Datei, auch wenn Daten auf dem Handy
          gelöscht werden.
        </p>
        <div class="actions">
          <button
            mat-flat-button
            type="button"
            data-testid="backup-download"
            [disabled]="busy()"
            (click)="backup('download')"
          >
            <app-icon name="download" /> Backup herunterladen
          </button>
          <button mat-button type="button" data-testid="backup-restore" (click)="openRestore()">
            Backup einspielen
          </button>
          @if (canShare) {
            <button mat-stroked-button type="button" [disabled]="busy()" (click)="backup('share')">
              <app-icon name="share" /> Backup teilen
            </button>
          }
        </div>
        <p class="muted small">
          „Teilen“ schickt die Datei zum Beispiel an Google Drive oder per E-Mail an dich selbst.
          Für den Test: Datei auf dem zweiten Handy öffnen und dort „Backup einspielen“ wählen.
        </p>
        @if (backupMsg()) {
          <p class="hint" role="status">{{ backupMsg() }}</p>
        }
      </div>

      <div class="card">
        <h2>App-Passwort</h2>
        <p class="small">
          {{
            vault.meta()?.password
              ? 'Ein App-Passwort ist eingerichtet. Du kannst es hier ändern.'
              : 'Noch kein App-Passwort. Es ist ein Ersatzweg, falls der Fingerabdruck einmal nicht klappt.'
          }}
        </p>
        @if (!vault.meta()?.passkey && vault.meta()?.password) {
          <mat-form-field appearance="outline"
            ><mat-label>Bisheriges Passwort</mat-label
            ><input
              matInput
              type="password"
              autocomplete="current-password"
              [value]="oldPw"
              (input)="oldPw = val($event)"
          /></mat-form-field>
        }
        <mat-form-field appearance="outline"
          ><mat-label>Neues App-Passwort</mat-label
          ><input
            matInput
            type="password"
            autocomplete="new-password"
            [value]="pw1"
            (input)="pw1 = val($event)"
        /></mat-form-field>
        <mat-form-field appearance="outline"
          ><mat-label>Wiederholen</mat-label
          ><input
            matInput
            type="password"
            autocomplete="new-password"
            [value]="pw2"
            (input)="pw2 = val($event)"
        /></mat-form-field>
        @if (pwMsg()) {
          <p [class]="pwOk() ? 'hint' : 'bad'" role="status">{{ pwMsg() }}</p>
        }
        <p class="muted small">
          Mindestens {{ minPw }} Zeichen.{{
            vault.meta()?.passkey ? ' Zum Speichern fragt die App nach deinem Fingerabdruck.' : ''
          }}
        </p>
        <button mat-stroked-button type="button" [disabled]="busy()" (click)="setPassword()">
          Passwort speichern
        </button>
      </div>

      <div class="card">
        <h2>Prognose</h2>
        <p class="small">Wie vorsichtig sollen die variablen Ausgaben geschätzt werden?</p>
        <mat-form-field appearance="outline">
          <mat-label>Vorsichtsstufe</mat-label>
          <select
            matNativeControl
            data-testid="prudence"
            [appSelectValue]="prefs.prudence()"
            (change)="setPrudence($event)"
          >
            <option value="ausgewogen">Ausgewogen (Mittelwert der letzten 6 Monate)</option>
            <option value="vorsichtig">Vorsichtig (eher zu hoch geschätzt)</option>
          </select>
        </mat-form-field>
      </div>

      <div class="card" data-testid="liquidity-settings">
        <h2>Liquidität</h2>
        <p class="small muted">
          Der Puffer bleibt immer auf dem Girokonto. Liegt der tiefste Stand mehr als die
          Überschuss-Schwelle darüber, schlägt die App eine Umbuchung aufs Tagesgeld vor.
        </p>
        <div class="grid2">
          <mat-form-field appearance="outline">
            <mat-label>Puffer in €</mat-label>
            <input
              matInput
              inputmode="decimal"
              data-testid="buffer"
              [value]="euroIn(prefs.liquidity().buffer)"
              (change)="setLiq('buffer', $event)"
            />
          </mat-form-field>
          <mat-form-field appearance="outline">
            <mat-label>Überschuss ab in €</mat-label>
            <input
              matInput
              inputmode="decimal"
              data-testid="surplus"
              [value]="euroIn(prefs.liquidity().surplusThreshold)"
              (change)="setLiq('surplusThreshold', $event)"
            />
          </mat-form-field>
        </div>
      </div>

      @if (splitSvc.templates().length) {
        <div class="card" data-testid="split-templates">
          <h2>Aufteilungsvorlagen</h2>
          <p class="small muted">
            Gelernt aus von Hand aufgeteilten Sammelabbuchungen. Neue Abbuchungen dieser Empfänger
            teilt die App danach auf; steigen Beiträge, passt sie die Teile an und legt die Buchung
            unter „Zu prüfen“.
          </p>
          @for (t of splitSvc.templates(); track t.id) {
            <div class="tpl">
              <strong>{{ t.label }}</strong>
              <span class="small muted">{{ partsText(t) }}</span>
              <button mat-button type="button" (click)="splitSvc.remove(t.id)">Löschen</button>
            </div>
          }
        </div>
      }

      @if (loans.all().length) {
        <div class="card" id="kredite" data-testid="loan-settings">
          <h2>Kredite</h2>
          <p class="small muted">
            Annahmen für den Sondertilgungsplan; einmal einstellen, gilt für alle Kredite.
          </p>
          <mat-form-field appearance="outline">
            <mat-label>Monatlich in die Rücklage €</mat-label>
            <input
              matInput
              inputmode="decimal"
              data-testid="sp-monthly"
              [value]="spMonthly()"
              [placeholder]="'erkannt: ' + euro(loans.detectedMonthly().amount)"
              (change)="setSp('monthly', $event, 'euro')"
            />
          </mat-form-field>
          <p class="small muted">
            Leer lassen: Die App nimmt den erkannten Dauerauftrag bzw. den Durchschnitt der Eingänge
            der letzten 12 Monate ({{ euro(loans.detectedMonthly().amount) }}).
          </p>
          <p class="small">
            <strong>Lücke nach der Bauspar-Ablösung:</strong> Reichen Guthaben und Bauspardarlehen
            nicht, rechnet die App den Rest als Anschlussfinanzierung mit
          </p>
          <div class="pair">
            <mat-form-field appearance="outline"
              ><mat-label>Zins %</mat-label
              ><input
                matInput
                inputmode="decimal"
                data-testid="gap-zins"
                [value]="pctIn(prefs.specialPlan().gapMilli)"
                (change)="setSp('gapMilli', $event, 'pct')"
            /></mat-form-field>
            <mat-form-field appearance="outline"
              ><mat-label>Tilgung anfangs %</mat-label
              ><input
                matInput
                inputmode="decimal"
                data-testid="gap-tilg"
                [value]="pctIn(prefs.specialPlan().gapTilgungMilli)"
                (change)="setSp('gapTilgungMilli', $event, 'pct')"
            /></mat-form-field>
          </div>
          <p class="small">
            <strong>Lohnt sich eine Sondertilgung?</strong> Liegt der Kreditzins unter dem
            Tagesgeldzins nach Steuern, bringt das Geld auf dem Tagesgeld mehr.
          </p>
          <div class="pair">
            <mat-form-field appearance="outline"
              ><mat-label>Tagesgeldzins %</mat-label
              ><input
                matInput
                inputmode="decimal"
                data-testid="sp-savings"
                [value]="pctIn(prefs.specialPlan().savingsMilli ?? 0)"
                (change)="setSp('savingsMilli', $event, 'pct')"
            /></mat-form-field>
            <mat-form-field appearance="outline"
              ><mat-label>Steuer auf Zinsen %</mat-label
              ><input
                matInput
                inputmode="decimal"
                data-testid="sp-tax"
                [value]="pctIn(prefs.specialPlan().taxMilli)"
                (change)="setSp('taxMilli', $event, 'pct')"
            /></mat-form-field>
          </div>
          <mat-checkbox
            [checked]="prefs.specialPlan().bauSpecial"
            data-testid="bau-special"
            (change)="prefs.setSpecialPlan({ bauSpecial: $event.checked })"
            >Sondertilgungen beim Bauspardarlehen möglich (meist jederzeit kostenfrei)</mat-checkbox
          >
        </div>
      }

      <div class="card" data-testid="rk-card">
        <h2>Wiederherstellungsschlüssel</h2>
        @switch (rkStep()) {
          @case ('idle') {
            <p class="small">
              Mit dem Wiederherstellungsschlüssel öffnest du ein Backup, zum Beispiel auf einem
              neuen Handy. Die App zeigt ihn absichtlich nie wieder an: Sie speichert ihn nirgends,
              damit ihn niemand aus deinem Handy auslesen kann.
            </p>
            <p class="small">
              Ist der Zettel verloren oder nicht mehr sicher, erstellst du hier einen neuen. Der
              alte öffnet danach nur noch ältere Backups.
            </p>
            <button mat-stroked-button type="button" data-testid="rk-new" (click)="rkStart()">
              Neuen Schlüssel erstellen
            </button>
          }
          @case ('show') {
            <p class="small">
              Schreib den neuen Schlüssel auf Papier und bewahre ihn getrennt vom Handy auf.
              Gespeichert wird er erst nach der Kontrolle; bis dahin gilt der alte.
            </p>
            <p class="key" data-testid="rk-key">{{ rkGroups().join('-') }}</p>
            <div class="actions">
              <button
                mat-flat-button
                type="button"
                data-testid="rk-written"
                (click)="rkStep.set('check')"
              >
                Aufgeschrieben
              </button>
              <button mat-button type="button" (click)="rkCancel()">Abbrechen</button>
            </div>
          }
          @case ('check') {
            <p class="small">
              Kurze Kontrolle: Tippe Gruppe {{ rkA() + 1 }} und Gruppe {{ rkB() + 1 }} von deinem
              Zettel ab.
            </p>
            <div class="pair">
              <mat-form-field appearance="outline"
                ><mat-label>Gruppe {{ rkA() + 1 }}</mat-label
                ><input
                  matInput
                  autocomplete="off"
                  autocapitalize="characters"
                  spellcheck="false"
                  data-testid="rk-a"
                  [attr.data-group]="rkA()"
                  (input)="rkAnswerA = val($event)"
              /></mat-form-field>
              <mat-form-field appearance="outline"
                ><mat-label>Gruppe {{ rkB() + 1 }}</mat-label
                ><input
                  matInput
                  autocomplete="off"
                  autocapitalize="characters"
                  spellcheck="false"
                  data-testid="rk-b"
                  [attr.data-group]="rkB()"
                  (input)="rkAnswerB = val($event)"
              /></mat-form-field>
            </div>
            @if (rkError()) {
              <p class="warn small" data-testid="rk-error">{{ rkError() }}</p>
            }
            <div class="actions">
              <button
                mat-flat-button
                type="button"
                data-testid="rk-save"
                [disabled]="busy()"
                (click)="rkSave()"
              >
                Mit Fingerabdruck bestätigen und speichern
              </button>
              <button mat-button type="button" (click)="rkStep.set('show')">Zurück</button>
              <button mat-button type="button" (click)="rkCancel()">Abbrechen</button>
            </div>
          }
          @case ('done') {
            <p class="hint small" data-testid="rk-done">
              Der neue Schlüssel gilt ab sofort. Mach jetzt ein neues Backup: Ältere Backups öffnest
              du nur mit dem alten Schlüssel.
            </p>
            <button
              mat-flat-button
              type="button"
              data-testid="rk-backup"
              [disabled]="busy()"
              (click)="backup(canShare ? 'share' : 'download')"
            >
              Backup jetzt erstellen
            </button>
          }
        }
      </div>

      <div class="card" data-testid="help-card">
        <h2>Hilfe</h2>
        <p class="small muted">Eine kurze Führung zeigt dir auf dem Bildschirm, wo was ist.</p>
        <button mat-stroked-button type="button" data-testid="help-tour" (click)="tour.start()">
          Führung starten
        </button>
        <h3>Fragen und Antworten</h3>
        <div class="faq" data-testid="faq">
          <details>
            <summary>Wie spiele ich mein Backup auf einem neuen Handy ein?</summary>
            <p class="small">
              Auf dem alten Handy: Einstellungen → Backup → „Backup teilen“ (z. B. an Google Drive).
              Auf dem neuen Handy die Datei herunterladen, die App-Adresse in Chrome öffnen, „Backup
              einspielen“ wählen, Datei und Wiederherstellungsschlüssel eingeben, Fingerabdruck
              einrichten. Danach nur noch das neue Handy benutzen.
            </p>
          </details>
          <details>
            <summary>Was ist der Wiederherstellungsschlüssel, und wenn ich ihn verliere?</summary>
            <p class="small">
              30 Zeichen in sechs Gruppen; damit öffnest du jedes Backup. Die App speichert ihn
              nicht und kann ihn nicht anzeigen. Ist der Zettel weg: Einstellungen →
              Wiederherstellungsschlüssel → „Neuen Schlüssel erstellen“ und gleich ein neues Backup
              machen.
            </p>
          </details>
          <details>
            <summary>Wie lese ich Umsätze aus der Kontowecker-E-Mail ein?</summary>
            <p class="small">
              Text der E-Mail kopieren, in der App Plus → „Aus E-Mail“, einfügen. Die App erkennt
              die Umsätze, schlägt Kategorien vor und gleicht den Kontostand mit dem „Neuen Saldo“
              ab. Doppelte E-Mails erkennt sie.
            </p>
          </details>
          <details>
            <summary>Wie trage ich eine Umbuchung zwischen meinen Konten ein?</summary>
            <p class="small">
              Plus → „Umbuchung“: von welchem Konto, auf welches, Betrag. Beide Seiten entstehen
              verknüpft. Kommt die Buchung später aus der E-Mail, ordnet die App sie zu, statt sie
              doppelt anzulegen.
            </p>
          </details>
          <details>
            <summary>Was sagt mir die Empfehlung auf der Übersicht?</summary>
            <p class="small">
              Ob das Girokonto bis zum nächsten Gehalt reicht. Wird der Puffer unterschritten,
              empfiehlt die App eine Umbuchung vom Tagesgeld mit Betrag und spätestem Datum. Geld
              bewegt die App nie selbst; nach der Überweisung tippst du „Jetzt umgebucht“.
            </p>
          </details>
          <details>
            <summary>Wofür sind die Spartöpfe unter Rücklagen?</summary>
            <p class="small">
              Für Jahreszahlungen wie die Kfz-Versicherung und für Sparziele. Die App verteilt den
              Dauerauftrag auf die Töpfe und zeigt, ob genug für die nächste Fälligkeit da ist. Ein
              Topf kann auch für Sondertilgungen sein.
            </p>
          </details>
          <details>
            <summary>Wie trage ich einen Kredit oder Bausparvertrag ein?</summary>
            <p class="small">
              Kredite → „Kredit hinzufügen“: Restschuld laut Bank mit Datum, Rate, Sollzins (nicht
              den effektiven), Zinsbindung. Ein Vorausdarlehen verknüpfst du im Kredit mit dem
              Bausparvertrag; dann rechnet die App die Ablösung mit.
            </p>
          </details>
          <details>
            <summary>Was bedeuten Fahrplan und Sondertilgungsplan?</summary>
            <p class="small">
              Der Fahrplan zeigt, was wann kommt, vor allem wann wie viel anschlussfinanziert werden
              muss. Der Sondertilgungsplan verteilt deine Rücklage für Sondertilgungen so, dass du
              am frühesten schuldenfrei bist, und sagt den nächsten Schritt.
            </p>
          </details>
          <details>
            <summary>Was tun, wenn Daten auf dem Handy verloren gehen?</summary>
            <p class="small">
              Mit einem Backup außerhalb des Handys ist nichts verloren: App neu einrichten oder
              öffnen, „Backup einspielen“. Am sichersten: regelmäßig „Backup teilen“ und zusätzlich
              die Sicherungsdatei im Handyspeicher einrichten.
            </p>
          </details>
          <details>
            <summary>Wie exportiere ich meine Daten nach Excel?</summary>
            <p class="small">
              Einstellungen → Export: Ansicht wählen (z. B. Monatsübersicht oder Kredite mit
              Tilgungsplänen), Zeitraum, dann Excel oder CSV. Den Tilgungsplan eines Kredits gibt es
              auch direkt im Kredit.
            </p>
          </details>
        </div>
      </div>

      <div class="card" data-testid="coverage-card">
        <h2>Datenabdeckung</h2>
        @for (c of coverageList(); track c.accountId) {
          <p data-testid="coverage-row">
            <strong>{{ c.name }}:</strong>
            @if (c.first) {
              Daten seit {{ monthLabel(c.first) }};
              @if (c.gaps.length) {
                <span class="warn"
                  >es fehlen
                  {{
                    c.gaps.length === 1 ? 'Daten für' : 'Daten für ' + c.gaps.length + ' Monate:'
                  }}
                  {{ gapText(c.gaps) }}</span
                >.
              } @else {
                lückenlos.
              }
            } @else {
              noch keine Buchungen.
            }
          </p>
        } @empty {
          <p class="small muted">Noch kein Girokonto angelegt.</p>
        }
        <p class="small muted">
          Ein Monat ohne eine einzige Buchung auf dem Girokonto gilt als Lücke, nicht als Monat ohne
          Ausgaben. Prognose und Statistik rechnen Lücken nicht mit; schließen lässt sich eine
          Lücke, indem du die fehlenden Umsätze einliest.
        </p>
      </div>

      <div class="card" data-testid="export-card">
        <h2>Export</h2>
        <mat-form-field appearance="outline">
          <mat-label>Was exportieren?</mat-label>
          <select
            matNativeControl
            data-testid="exp-kind"
            [value]="expKind()"
            (change)="expKind.set(pickKind($event))"
          >
            @for (k of exportKinds; track k[0]) {
              <option [value]="k[0]">{{ k[1] }}</option>
            }
          </select>
        </mat-form-field>
        @if (expKind() === 'konto') {
          <mat-form-field appearance="outline">
            <mat-label>Konto</mat-label>
            <select
              matNativeControl
              data-testid="exp-account"
              [value]="expAccount()"
              (change)="expAccount.set(val($event))"
            >
              @for (a of accountsStore.accounts(); track a.id) {
                <option [value]="a.id">{{ a.name }}</option>
              }
            </select>
          </mat-form-field>
        }
        @if (expKind() === 'steuer') {
          <mat-form-field appearance="outline">
            <mat-label>Jahr</mat-label>
            <input
              matInput
              inputmode="numeric"
              data-testid="exp-year"
              [value]="expYear()"
              (change)="expYear.set(val($event))"
            />
          </mat-form-field>
        } @else if (expKind() !== 'gesamt') {
          <div class="pair">
            <mat-form-field appearance="outline"
              ><mat-label>von</mat-label
              ><input
                matInput
                type="month"
                data-testid="exp-from"
                [value]="expFrom()"
                (change)="expFrom.set(val($event))"
            /></mat-form-field>
            <mat-form-field appearance="outline"
              ><mat-label>bis</mat-label
              ><input
                matInput
                type="month"
                data-testid="exp-to"
                [value]="expTo()"
                (change)="expTo.set(val($event))"
            /></mat-form-field>
          </div>
        }
        <mat-button-toggle-group
          [value]="expFormat()"
          (change)="expFormat.set($event.value === 'csv' ? 'csv' : 'xlsx')"
          aria-label="Format"
        >
          <mat-button-toggle value="xlsx" data-testid="exp-xlsx">Excel</mat-button-toggle>
          <mat-button-toggle value="csv" data-testid="exp-csv">CSV</mat-button-toggle>
        </mat-button-toggle-group>
        <p class="small muted">
          Excel mit Datums- und Euro-Format; CSV für deutsches Excel (Semikolon, Dezimalkomma).
          Mehrere Tabellen als CSV kommen in einer ZIP-Datei. Das vollständige, verschlüsselte
          Backup steht oben.
        </p>
        <button
          mat-flat-button
          type="button"
          data-testid="exp-run"
          [disabled]="expBusy()"
          (click)="runExport()"
        >
          Exportieren
        </button>
        @if (expMsg()) {
          <p class="small" data-testid="exp-msg">{{ expMsg() }}</p>
        }
      </div>

      <app-pillars-card />

      <app-stat-groups-card />

      <div class="card">
        <h2>Daten importieren</h2>
        <p class="small">
          Buchungen aus der alten App übernehmen (Excel-Datei .xlsx). Die Kontostände bleiben dabei
          unverändert.
        </p>
        <a mat-stroked-button routerLink="/import" data-testid="to-import">Daten importieren</a>
      </div>

      <div class="card">
        <h2>Gelernte Regeln ({{ rules.rules().length }})</h2>
        <p class="small muted">
          Aus deinen Zuordnungen gelernt: Beginnt ein Buchungstext so, schlägt die App diese
          Kategorie vor. „± 10 %“ heißt, dass die Regel nur bei ähnlichem Betrag gilt.
        </p>
        @for (r of sortedRules(); track r.id) {
          <div class="rule">
            <span
              ><strong>{{ r.pattern }}</strong
              >{{ r.useAmount ? ' bei ' + euro(r.amount) + ' ± 10 %' : '' }} →
              {{ label(r.categoryId, r.subCategory) }}</span
            >
            <button
              mat-button
              type="button"
              [attr.aria-label]="'Regel löschen: ' + r.pattern"
              (click)="rules.remove(r.id)"
            >
              Löschen
            </button>
          </div>
        } @empty {
          <p class="muted small">Noch keine Regeln.</p>
        }
      </div>

      <div class="card" data-testid="mirror-card">
        <h2>Sicherungsdatei</h2>
        <p class="small muted">
          Eine verschlüsselte Kopie aller Daten im normalen Handyspeicher, zum Beispiel unter
          „Dokumente“. Die App aktualisiert sie nach jeder Änderung. Werden die Browserdaten
          gelöscht, stellst du alles damit wieder her: bei der Einrichtung „Backup einspielen“ und
          diese Datei wählen.
        </p>
        @switch (mirror.state()) {
          @case ('nicht-unterstuetzt') {
            <p class="small">Dieser Browser erlaubt keinen Dateizugriff. Nutze das Backup oben.</p>
          }
          @case ('aus') {
            <button
              mat-flat-button
              type="button"
              data-testid="mirror-setup"
              (click)="mirror.setup()"
            >
              Sicherungsdatei einrichten
            </button>
          }
          @case ('erlaubnis') {
            <p class="small warn">{{ mirror.fileName() }} wartet auf deine Erlaubnis.</p>
            <button mat-flat-button type="button" (click)="mirror.reconnect()">
              Sicherungsdatei verbinden
            </button>
          }
          @default {
            <p class="small" data-testid="mirror-status">
              {{ mirror.state() === 'verbunden' ? 'Aktiv' : 'Fehler beim Schreiben' }}:
              {{ mirror.fileName()
              }}{{
                mirror.lastWrite() ? ', zuletzt aktualisiert ' + whenText(mirror.lastWrite()!) : ''
              }}
            </p>
            <div class="actions">
              <button
                mat-stroked-button
                type="button"
                data-testid="mirror-write"
                (click)="mirror.writeNow()"
              >
                Jetzt aktualisieren
              </button>
              <button mat-button type="button" (click)="mirror.disconnect()">Trennen</button>
            </div>
          }
        }
        @if (mirror.error()) {
          <p class="bad small" role="alert">{{ mirror.error() }}</p>
        }
      </div>

      <div class="card">
        <h2>Gerät</h2>
        @if (storageText()) {
          <p class="small" data-testid="storage-info">{{ storageText() }}</p>
        }
        <div class="actions">
          <button
            mat-stroked-button
            type="button"
            data-testid="check-update"
            [disabled]="checking()"
            (click)="checkUpdate()"
          >
            Nach Updates suchen
          </button>
          @if (updateMsg()) {
            <span class="small" role="status" data-testid="update-msg">{{ updateMsg() }}</span>
          }
        </div>
        <p class="small">
          Version {{ version }}. Entsperren: {{ vault.meta()?.passkey ? 'Fingerabdruck' : ''
          }}{{ vault.meta()?.passkey && vault.meta()?.password ? ', ' : ''
          }}{{ vault.meta()?.password ? 'App-Passwort' : '' }}, Wiederherstellungsschlüssel.
        </p>
        <p class="small">Die App sperrt sich, wenn du sie länger als eine Minute verlässt.</p>
        <a mat-stroked-button routerLink="/pruefung">Machbarkeitsprüfung</a>
      </div>

      <div class="card">
        <h2>Alle Daten auf diesem Handy löschen</h2>
        <p class="small muted">
          Nur für Tests oder vor dem Einspielen eines Backups. Ohne Backup sind die Daten danach
          weg.
        </p>
        @if (!confirmDelete()) {
          <button mat-button type="button" class="danger" (click)="confirmDelete.set(true)">
            Löschen …
          </button>
        } @else {
          <mat-form-field appearance="outline"
            ><mat-label>Zur Bestätigung LÖSCHEN eintippen</mat-label
            ><input matInput autocomplete="off" [value]="del" (input)="del = val($event)"
          /></mat-form-field>
          <div class="actions">
            <button
              mat-flat-button
              type="button"
              class="danger-fill"
              [disabled]="del.trim().toUpperCase() !== 'LÖSCHEN'"
              (click)="deleteAll()"
            >
              Endgültig löschen
            </button>
            <button mat-button type="button" (click)="confirmDelete.set(false)">Abbrechen</button>
          </div>
        }
      </div>
    </div>
  `,
  styles: [
    '.faq details { border-top: 1px solid var(--hb-line); padding: 8px 0; } .faq summary { cursor: pointer; font-weight: 600; } .faq p { margin: 6px 0 0; } .key { font-family: ui-monospace, monospace; font-size: 18px; letter-spacing: 0.06em; text-align: center; background: var(--hb-bg); border-radius: 12px; padding: 12px; user-select: all; word-break: break-all; } .pair { display: grid; grid-template-columns: 1fr 1fr; gap: 0 10px; } .danger { color: var(--hb-bad-ink); } .danger-fill { background: var(--hb-bad-ink) !important; color: var(--hb-surface) !important; }',
  ],
})
export class SettingsPage {
  protected readonly vault = inject(VaultService);
  private readonly router = inject(Router);
  private readonly lock = inject(LockService);
  protected readonly version = APP_VERSION;
  protected readonly rules = inject(RulesStore);
  protected readonly prefs = inject(PrefsStore);
  private readonly updates = inject(UpdateService);
  protected readonly checking = signal(false);
  protected readonly updateMsg = signal('');
  protected async checkUpdate(): Promise<void> {
    this.checking.set(true);
    this.updateMsg.set('Suche …');
    const r = await this.updates.check();
    this.checking.set(false);
    this.updateMsg.set(
      {
        neu: 'Neue Version gefunden: oben auf „Jetzt aktualisieren“ tippen.',
        aktuell: `Du hast die neueste Version (${APP_VERSION}).`,
        offline: 'Ohne Internet lässt sich nicht nach Updates suchen.',
        fehler: 'Die Suche hat nicht geklappt. Später nochmal versuchen.',
      }[r],
    );
  }

  protected euroIn(c: number): string {
    return (c / 100).toLocaleString('de-DE', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  }
  protected setLiq(key: 'buffer' | 'surplusThreshold', ev: Event): void {
    const v = parseEuro((ev.target as HTMLInputElement).value);
    if (v !== null && v >= 0) void this.prefs.setLiquidity({ [key]: v });
  }
  protected setPrudence(ev: Event): void {
    void this.prefs.setPrudence(
      (ev.target as HTMLSelectElement).value as 'ausgewogen' | 'vorsichtig',
    );
  }
  private readonly cats = inject(CategoriesStore);
  protected readonly euro = formatEuro;
  protected sortedRules() {
    return [...this.rules.rules()].sort((a, b) => a.pattern.localeCompare(b.pattern));
  }
  protected label(id: string, sub: string | null): string {
    return categoryLabel(this.cats.categories(), id, sub);
  }
  protected readonly minPw = MIN_PASSWORD_LENGTH;
  protected readonly busy = signal(false);
  protected readonly backupMsg = signal('');
  protected readonly pwMsg = signal('');
  protected readonly pwOk = signal(false);
  protected readonly confirmDelete = signal(false);
  private readonly backupSvc = inject(BackupService);
  protected readonly canShare = this.backupSvc.canShare;
  protected pw1 = '';
  protected pw2 = '';
  protected oldPw = '';
  protected del = '';

  protected val(ev: Event): string {
    return (ev.target as HTMLInputElement).value;
  }

  protected openRestore(): void {
    void this.router.navigateByUrl('/backup-einspielen');
  }

  protected async backup(how: 'download' | 'share'): Promise<void> {
    this.busy.set(true);
    this.backupMsg.set('');
    const r = await this.backupSvc.run(how);
    this.backupMsg.set(r.message);
    this.busy.set(false);
  }

  protected readonly mirror = inject(MirrorService);
  protected readonly loans = inject(LoansService);
  // ---------- Datenabdeckung (11.2) und Export (12) ----------
  protected readonly tour = inject(TourService);
  // ---------- Neuer Wiederherstellungsschlüssel ----------
  protected readonly rkStep = signal<'idle' | 'show' | 'check' | 'done'>('idle');
  protected readonly rkGroups = signal<string[]>([]);
  protected readonly rkA = signal(0);
  protected readonly rkB = signal(1);
  protected readonly rkError = signal('');
  protected rkAnswerA = '';
  protected rkAnswerB = '';
  private rkKey = '';

  protected rkStart(): void {
    this.rkKey = generateRecoveryKey(randomBytes);
    this.rkGroups.set(splitRecoveryKey(this.rkKey));
    const [a, b] = [...randomBytes(2)].map((x) => x % 6);
    this.rkA.set(Math.min(a, b === a ? (a + 3) % 6 : b));
    this.rkB.set(Math.max(a, b === a ? (a + 3) % 6 : b));
    this.rkAnswerA = this.rkAnswerB = '';
    this.rkError.set('');
    this.rkStep.set('show');
  }

  protected rkCancel(): void {
    this.rkKey = '';
    this.rkGroups.set([]);
    this.rkError.set('');
    this.rkStep.set('idle');
  }

  protected async rkSave(): Promise<void> {
    const g = this.rkGroups();
    if (
      normalizeGroup(this.rkAnswerA) !== g[this.rkA()] ||
      normalizeGroup(this.rkAnswerB) !== g[this.rkB()]
    )
      return this.rkError.set(
        'Die Gruppen stimmen nicht mit dem neuen Schlüssel überein. Bitte mit dem Zettel vergleichen.',
      );
    const key = normalizeRecoveryKey(this.rkKey);
    if (!key) return this.rkError.set('Der neue Schlüssel ist ungültig; bitte neu erstellen.');
    this.busy.set(true);
    try {
      await this.vault.replaceRecoveryKey(key, { passkey: true });
      this.rkKey = '';
      this.rkStep.set('done');
    } catch (e) {
      this.rkError.set(
        `Nicht gespeichert, der alte Schlüssel gilt weiter: ${(e as Error).message}`,
      );
    } finally {
      this.busy.set(false);
    }
  }
  protected readonly accountsStore = inject(AccountsStore);
  private readonly bookingsStore = inject(BookingsStore);
  private readonly exporter = inject(ExportService);
  protected readonly coverageList = computed(() =>
    coverage(this.accountsStore.accounts(), this.bookingsStore.bookings(), todayLocal()),
  );
  protected readonly monthLabel = monthLabel;
  protected readonly exportKinds = Object.entries(EXPORT_KINDS) as [ExportKind, string][];
  protected readonly expKind = signal<ExportKind>('gesamt');
  protected readonly expFrom = signal(`${todayLocal().slice(0, 4)}-01`);
  protected readonly expTo = signal(todayLocal().slice(0, 7));
  protected readonly expAccount = signal('');
  protected readonly expYear = signal(String(Number(todayLocal().slice(0, 4)) - 1));
  protected readonly expFormat = signal<'xlsx' | 'csv'>('xlsx');
  protected readonly expBusy = signal(false);
  protected readonly expMsg = signal('');

  protected gapText(gaps: string[]): string {
    return gaps.length > 6
      ? `${gaps.slice(0, 6).map(monthLabel).join(', ')} und ${gaps.length - 6} weitere`
      : gaps.map(monthLabel).join(', ');
  }

  protected pickKind(ev: Event): ExportKind {
    const v = (ev.target as HTMLSelectElement).value;
    return v in EXPORT_KINDS ? (v as ExportKind) : 'gesamt';
  }

  protected async runExport(): Promise<void> {
    this.expBusy.set(true);
    this.expMsg.set('');
    try {
      const file = await this.exporter.file(
        this.expKind(),
        {
          from: this.expFrom(),
          to: this.expTo(),
          accountId: this.expAccount() || this.accountsStore.accounts()[0]?.id,
          year: Number(this.expYear()) || undefined,
        },
        this.expFormat(),
      );
      await shareOrDownload(file);
      this.expMsg.set(`Datei „${file.name}“ erstellt.`);
    } catch (e) {
      this.expMsg.set(`Der Export ist fehlgeschlagen: ${(e as Error).message}`);
    } finally {
      this.expBusy.set(false);
    }
  }
  protected readonly spMonthly = computed(() => {
    const m = this.prefs.specialPlan().monthly;
    return m === null
      ? ''
      : (m / 100).toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  });
  protected pctIn(m: number): string {
    return (m / 1000).toLocaleString('de-DE', { maximumFractionDigits: 3 });
  }
  protected setSp(
    key: 'monthly' | 'gapMilli' | 'gapTilgungMilli' | 'savingsMilli' | 'taxMilli',
    ev: Event,
    kind: 'euro' | 'pct',
  ): void {
    const raw = (ev.target as HTMLInputElement).value.trim();
    if (kind === 'euro') {
      void this.prefs.setSpecialPlan({ monthly: raw ? (parseEuro(raw) ?? null) : null });
      return;
    }
    const v = Number(raw.replace('%', '').replace(',', '.'));
    if (raw && Number.isFinite(v) && v >= 0 && v <= (key === 'taxMilli' ? 60 : 20))
      void this.prefs.setSpecialPlan({ [key]: Math.round(v * 1000) });
  }
  protected readonly splitSvc = inject(SplitService);
  private readonly catStore = inject(CategoriesStore);
  protected partsText(t: SplitTemplate): string {
    return t.parts
      .map(
        (p) =>
          `${categoryLabel(this.catStore.categories(), p.categoryId, p.subCategory)} ${formatEuro(p.amount)}`,
      )
      .join(', ');
  }
  /** belegter Speicher, aufgeteilt in App-Dateien und Daten (Chrome liefert die Aufteilung mit) */
  protected readonly storageText = signal('');
  private readonly loadStorage = (async () => {
    try {
      const e = (await navigator.storage.estimate()) as StorageEstimate & {
        usageDetails?: Record<string, number>;
      };
      const mb = (n: number) =>
        `${(n / 1048576).toLocaleString('de-DE', { maximumFractionDigits: 1, minimumFractionDigits: 1 })} MB`;
      const d = e.usageDetails;
      const app = (d?.['caches'] ?? 0) + (d?.['serviceWorkerRegistrations'] ?? 0);
      this.storageText.set(
        d
          ? `Belegter Speicher: ${mb(e.usage ?? 0)}, davon App-Dateien ${mb(app)} (damit die App ohne Internet läuft) und deine verschlüsselten Daten ${mb(d['indexedDB'] ?? 0)}. Zum Vergleich: Ein Handyfoto hat etwa 3 bis 5 MB.`
          : `Belegter Speicher: ${mb(e.usage ?? 0)}. Zum Vergleich: Ein Handyfoto hat etwa 3 bis 5 MB.`,
      );
    } catch {
      /* ohne Anzeige */
    }
  })();
  protected whenText(iso: string): string {
    const d = new Date(iso);
    return `${d.toLocaleDateString('de-DE')} um ${d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' })}`;
  }

  protected setInterval(ev: Event): void {
    void this.prefs.setBackupInterval(Number((ev.target as HTMLSelectElement).value));
  }

  protected async setPassword(): Promise<void> {
    this.pwOk.set(false);
    if (this.pw1.length < MIN_PASSWORD_LENGTH)
      return this.pwMsg.set(
        `Mindestens ${MIN_PASSWORD_LENGTH} Zeichen, z. B. ein Satz aus mehreren Wörtern.`,
      );
    if (this.pw1 !== this.pw2) return this.pwMsg.set('Die beiden Passwörter sind nicht gleich.');
    this.busy.set(true);
    try {
      await this.vault.setPassword(
        this.pw1,
        this.vault.meta()?.passkey ? { passkey: true } : { password: this.oldPw },
      );
      this.pw1 = this.pw2 = this.oldPw = '';
      this.pwOk.set(true);
      this.pwMsg.set('App-Passwort gespeichert.');
    } catch (e) {
      this.pwMsg.set(e instanceof Error ? e.message : String(e));
    } finally {
      this.busy.set(false);
    }
  }

  protected async deleteAll(): Promise<void> {
    this.lock.lockNow();
    await this.vault.deleteEverything();
    void this.router.navigateByUrl('/einrichtung');
  }
}
