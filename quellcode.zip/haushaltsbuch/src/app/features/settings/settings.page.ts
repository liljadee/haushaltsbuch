import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { Router, RouterLink } from '@angular/router';
import { MIN_PASSWORD_LENGTH } from '../../data/crypto/key-derivation';
import { categoryLabel } from '../../domain/categories/categories';
import { formatEuro, parseEuro } from '../../domain/shared/money';
import { CategoriesStore } from '../../data/stores/categories.store';
import { RulesStore } from '../../data/stores/rules.store';
import { PrefsStore } from '../../data/stores/prefs.store';
import { SelectValue } from '../../shared/select-value';
import { StatGroupsCard } from './stat-groups-card';
import { PillarsCard } from './pillars-card';
import { todayLocal } from '../../domain/shared/local-date';
import { LockService } from '../../data/session/lock.service';
import { UpdateService } from '../../data/session/update.service';
import { APP_VERSION, VaultService } from '../../data/vault.service';
import { Icon } from '../../shared/icon';

@Component({
  selector: 'app-settings-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    RouterLink,
    Icon,
    SelectValue,
    StatGroupsCard,
    PillarsCard,
  ],
  template: `
    <div class="page">
      <h1>Einstellungen</h1>

      <div class="card">
        <h2>Backup</h2>
        <p class="small">
          Das Backup ist eine verschlüsselte Datei (.hhb). Öffnen lässt sie sich nur mit deinem
          Wiederherstellungsschlüssel{{
            vault.meta()?.password ? ' oder deinem App-Passwort' : ''
          }}.
        </p>
        <div class="actions">
          <button
            mat-flat-button
            type="button"
            data-testid="backup-download"
            [disabled]="busy()"
            (click)="backup('download')"
          >
            <app-icon name="download" /> Backup herunterladen
          </button>
          @if (canShare) {
            <button mat-stroked-button type="button" [disabled]="busy()" (click)="backup('share')">
              <app-icon name="share" /> Backup teilen
            </button>
          }
        </div>
        <p class="muted small">
          „Teilen“ schickt die Datei zum Beispiel an Google Drive oder per E-Mail an dich selbst.
          Für den Test: Datei auf dem zweiten Handy öffnen und dort „Backup einspielen“ wählen.
        </p>
        @if (backupMsg()) {
          <p class="hint" role="status">{{ backupMsg() }}</p>
        }
      </div>

      <div class="card">
        <h2>App-Passwort</h2>
        <p class="small">
          {{
            vault.meta()?.password
              ? 'Ein App-Passwort ist eingerichtet. Du kannst es hier ändern.'
              : 'Noch kein App-Passwort. Es ist ein Ersatzweg, falls der Fingerabdruck einmal nicht klappt.'
          }}
        </p>
        @if (!vault.meta()?.passkey && vault.meta()?.password) {
          <mat-form-field appearance="outline"
            ><mat-label>Bisheriges Passwort</mat-label
            ><input
              matInput
              type="password"
              autocomplete="current-password"
              [value]="oldPw"
              (input)="oldPw = val($event)"
          /></mat-form-field>
        }
        <mat-form-field appearance="outline"
          ><mat-label>Neues App-Passwort</mat-label
          ><input
            matInput
            type="password"
            autocomplete="new-password"
            [value]="pw1"
            (input)="pw1 = val($event)"
        /></mat-form-field>
        <mat-form-field appearance="outline"
          ><mat-label>Wiederholen</mat-label
          ><input
            matInput
            type="password"
            autocomplete="new-password"
            [value]="pw2"
            (input)="pw2 = val($event)"
        /></mat-form-field>
        @if (pwMsg()) {
          <p [class]="pwOk() ? 'hint' : 'bad'" role="status">{{ pwMsg() }}</p>
        }
        <p class="muted small">
          Mindestens {{ minPw }} Zeichen.{{
            vault.meta()?.passkey ? ' Zum Speichern fragt die App nach deinem Fingerabdruck.' : ''
          }}
        </p>
        <button mat-stroked-button type="button" [disabled]="busy()" (click)="setPassword()">
          Passwort speichern
        </button>
      </div>

      <div class="card">
        <h2>Prognose</h2>
        <p class="small">Wie vorsichtig sollen die variablen Ausgaben geschätzt werden?</p>
        <mat-form-field appearance="outline">
          <mat-label>Vorsichtsstufe</mat-label>
          <select
            matNativeControl
            data-testid="prudence"
            [appSelectValue]="prefs.prudence()"
            (change)="setPrudence($event)"
          >
            <option value="ausgewogen">Ausgewogen (Mittelwert der letzten 6 Monate)</option>
            <option value="vorsichtig">Vorsichtig (eher zu hoch geschätzt)</option>
          </select>
        </mat-form-field>
      </div>

      <div class="card" data-testid="liquidity-settings">
        <h2>Liquidität</h2>
        <p class="small muted">
          Der Puffer bleibt immer auf dem Girokonto. Liegt der tiefste Stand mehr als die
          Überschuss-Schwelle darüber, schlägt die App eine Umbuchung aufs Tagesgeld vor.
        </p>
        <div class="grid2">
          <mat-form-field appearance="outline">
            <mat-label>Puffer in €</mat-label>
            <input
              matInput
              inputmode="decimal"
              data-testid="buffer"
              [value]="euroIn(prefs.liquidity().buffer)"
              (change)="setLiq('buffer', $event)"
            />
          </mat-form-field>
          <mat-form-field appearance="outline">
            <mat-label>Überschuss ab in €</mat-label>
            <input
              matInput
              inputmode="decimal"
              data-testid="surplus"
              [value]="euroIn(prefs.liquidity().surplusThreshold)"
              (change)="setLiq('surplusThreshold', $event)"
            />
          </mat-form-field>
        </div>
      </div>

      <app-pillars-card />

      <app-stat-groups-card />

      <div class="card">
        <h2>Daten importieren</h2>
        <p class="small">
          Buchungen aus der alten App übernehmen (Excel-Datei .xlsx). Die Kontostände bleiben dabei
          unverändert.
        </p>
        <a mat-stroked-button routerLink="/import" data-testid="to-import">Daten importieren</a>
      </div>

      <div class="card">
        <h2>Gelernte Regeln ({{ rules.rules().length }})</h2>
        <p class="small muted">
          Aus deinen Zuordnungen gelernt: Beginnt ein Buchungstext so, schlägt die App diese
          Kategorie vor. „± 10 %“ heißt, dass die Regel nur bei ähnlichem Betrag gilt.
        </p>
        @for (r of sortedRules(); track r.id) {
          <div class="rule">
            <span
              ><strong>{{ r.pattern }}</strong
              >{{ r.useAmount ? ' bei ' + euro(r.amount) + ' ± 10 %' : '' }} →
              {{ label(r.categoryId, r.subCategory) }}</span
            >
            <button
              mat-button
              type="button"
              [attr.aria-label]="'Regel löschen: ' + r.pattern"
              (click)="rules.remove(r.id)"
            >
              Löschen
            </button>
          </div>
        } @empty {
          <p class="muted small">Noch keine Regeln.</p>
        }
      </div>

      <div class="card">
        <h2>Gerät</h2>
        <div class="actions">
          <button
            mat-stroked-button
            type="button"
            data-testid="check-update"
            [disabled]="checking()"
            (click)="checkUpdate()"
          >
            Nach Updates suchen
          </button>
          @if (updateMsg()) {
            <span class="small" role="status" data-testid="update-msg">{{ updateMsg() }}</span>
          }
        </div>
        <p class="small">
          Version {{ version }}. Entsperren: {{ vault.meta()?.passkey ? 'Fingerabdruck' : ''
          }}{{ vault.meta()?.passkey && vault.meta()?.password ? ', ' : ''
          }}{{ vault.meta()?.password ? 'App-Passwort' : '' }}, Wiederherstellungsschlüssel.
        </p>
        <p class="small">Die App sperrt sich, wenn du sie länger als eine Minute verlässt.</p>
        <a mat-stroked-button routerLink="/pruefung">Machbarkeitsprüfung</a>
      </div>

      <div class="card">
        <h2>Alle Daten auf diesem Handy löschen</h2>
        <p class="small muted">
          Nur für Tests oder vor dem Einspielen eines Backups. Ohne Backup sind die Daten danach
          weg.
        </p>
        @if (!confirmDelete()) {
          <button mat-button type="button" class="danger" (click)="confirmDelete.set(true)">
            Löschen …
          </button>
        } @else {
          <mat-form-field appearance="outline"
            ><mat-label>Zur Bestätigung LÖSCHEN eintippen</mat-label
            ><input matInput autocomplete="off" [value]="del" (input)="del = val($event)"
          /></mat-form-field>
          <div class="actions">
            <button
              mat-flat-button
              type="button"
              class="danger-fill"
              [disabled]="del.trim().toUpperCase() !== 'LÖSCHEN'"
              (click)="deleteAll()"
            >
              Endgültig löschen
            </button>
            <button mat-button type="button" (click)="confirmDelete.set(false)">Abbrechen</button>
          </div>
        }
      </div>
    </div>
  `,
  styles: [
    '.danger { color: var(--hb-bad-ink); } .danger-fill { background: var(--hb-bad-ink) !important; color: var(--hb-surface) !important; }',
  ],
})
export class SettingsPage {
  protected readonly vault = inject(VaultService);
  private readonly router = inject(Router);
  private readonly lock = inject(LockService);
  protected readonly version = APP_VERSION;
  protected readonly rules = inject(RulesStore);
  protected readonly prefs = inject(PrefsStore);
  private readonly updates = inject(UpdateService);
  protected readonly checking = signal(false);
  protected readonly updateMsg = signal('');
  protected async checkUpdate(): Promise<void> {
    this.checking.set(true);
    this.updateMsg.set('Suche …');
    const r = await this.updates.check();
    this.checking.set(false);
    this.updateMsg.set(
      {
        neu: 'Neue Version gefunden: oben auf „Jetzt aktualisieren“ tippen.',
        aktuell: `Du hast die neueste Version (${APP_VERSION}).`,
        offline: 'Ohne Internet lässt sich nicht nach Updates suchen.',
        fehler: 'Die Suche hat nicht geklappt. Später nochmal versuchen.',
      }[r],
    );
  }

  protected euroIn(c: number): string {
    return (c / 100).toLocaleString('de-DE', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  }
  protected setLiq(key: 'buffer' | 'surplusThreshold', ev: Event): void {
    const v = parseEuro((ev.target as HTMLInputElement).value);
    if (v !== null && v >= 0) void this.prefs.setLiquidity({ [key]: v });
  }
  protected setPrudence(ev: Event): void {
    void this.prefs.setPrudence(
      (ev.target as HTMLSelectElement).value as 'ausgewogen' | 'vorsichtig',
    );
  }
  private readonly cats = inject(CategoriesStore);
  protected readonly euro = formatEuro;
  protected sortedRules() {
    return [...this.rules.rules()].sort((a, b) => a.pattern.localeCompare(b.pattern));
  }
  protected label(id: string, sub: string | null): string {
    return categoryLabel(this.cats.categories(), id, sub);
  }
  protected readonly minPw = MIN_PASSWORD_LENGTH;
  protected readonly busy = signal(false);
  protected readonly backupMsg = signal('');
  protected readonly pwMsg = signal('');
  protected readonly pwOk = signal(false);
  protected readonly confirmDelete = signal(false);
  protected readonly canShare = typeof navigator.canShare === 'function';
  protected pw1 = '';
  protected pw2 = '';
  protected oldPw = '';
  protected del = '';

  protected val(ev: Event): string {
    return (ev.target as HTMLInputElement).value;
  }

  protected async backup(how: 'download' | 'share'): Promise<void> {
    this.busy.set(true);
    this.backupMsg.set('');
    try {
      const { name, text, entries } = await this.vault.createBackupFile();
      await this.prefs.setLastBackup(todayLocal());
      const done = `Backup „${name}“ erstellt (${entries} ${entries === 1 ? 'Datensatz' : 'Datensätze'}).`;
      if (how === 'share') {
        const file = new File([text], name, { type: 'application/octet-stream' });
        if (navigator.canShare?.({ files: [file] })) {
          try {
            await navigator.share({ files: [file], title: name });
            this.backupMsg.set(done);
            return;
          } catch (e) {
            if ((e as Error).name === 'AbortError') return;
          }
        }
        this.backupMsg.set(
          'Teilen klappt auf diesem Gerät nicht, die Datei wird stattdessen heruntergeladen.',
        );
      }
      const url = URL.createObjectURL(new Blob([text], { type: 'application/octet-stream' }));
      const a = document.createElement('a');
      a.href = url;
      a.download = name;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 10000);
      this.backupMsg.set(`${done} Du findest es im Ordner „Downloads“.`);
    } catch (e) {
      this.backupMsg.set(`Backup fehlgeschlagen: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      this.busy.set(false);
    }
  }

  protected async setPassword(): Promise<void> {
    this.pwOk.set(false);
    if (this.pw1.length < MIN_PASSWORD_LENGTH)
      return this.pwMsg.set(
        `Mindestens ${MIN_PASSWORD_LENGTH} Zeichen, z. B. ein Satz aus mehreren Wörtern.`,
      );
    if (this.pw1 !== this.pw2) return this.pwMsg.set('Die beiden Passwörter sind nicht gleich.');
    this.busy.set(true);
    try {
      await this.vault.setPassword(
        this.pw1,
        this.vault.meta()?.passkey ? { passkey: true } : { password: this.oldPw },
      );
      this.pw1 = this.pw2 = this.oldPw = '';
      this.pwOk.set(true);
      this.pwMsg.set('App-Passwort gespeichert.');
    } catch (e) {
      this.pwMsg.set(e instanceof Error ? e.message : String(e));
    } finally {
      this.busy.set(false);
    }
  }

  protected async deleteAll(): Promise<void> {
    this.lock.lockNow();
    await this.vault.deleteEverything();
    void this.router.navigateByUrl('/einrichtung');
  }
}
