import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { Pot, potDueAmount, potNextDue, potRate, potWarning } from '../../domain/liquidity/pots';
import { formatDate, todayLocal } from '../../domain/shared/local-date';
import { formatEuro, parseEuro } from '../../domain/shared/money';
import { ForecastService } from '../../data/forecast.service';
import { LiquidityService } from '../../data/liquidity.service';
import { PrefsStore } from '../../data/stores/prefs.store';
import { SelectValue } from '../../shared/select-value';
import { CategoryPicker } from '../bookings/category-picker';

const euroIn = (c: number) =>
  (Math.abs(c) / 100).toLocaleString('de-DE', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

/** Rücklagen und Spartöpfe (Lastenheft 16a): ein Tagesgeldkonto, gedanklich aufgeteilt. */
@Component({
  selector: 'app-reserves-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    NgTemplateOutlet,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    SelectValue,
    CategoryPicker,
  ],
  templateUrl: './reserves.page.html',
  styles: [
    `
      .split {
        display: flex;
        height: 14px;
        border-radius: 7px;
        overflow: hidden;
        background: var(--hb-bg);
        margin: 8px 0 4px;
      }
      .split span {
        display: block;
        height: 100%;
      }
      .s-pots {
        background: #3f8f5f;
      }
      .s-res {
        background: #b9b9b9;
      }
      .s-free {
        background: #9cc9ae;
      }
      .kv {
        display: grid;
        grid-template-columns: 1fr auto;
        gap: 4px 12px;
        margin: 0;
        font-size: 14px;
      }
      .kv dt {
        color: var(--hb-muted);
      }
      .kv dd {
        margin: 0;
        text-align: right;
        font-weight: 600;
      }
      .pot {
        border-top: 1px solid var(--hb-line);
      }
      .pot.open {
        background: var(--hb-bg);
        border-radius: 12px;
        padding: 0 10px 10px;
        margin: 4px -10px;
        border: 0;
      }
      .row {
        display: flex;
        justify-content: space-between;
        gap: 10px;
        width: 100%;
        padding: 10px 0;
        background: none;
        border: 0;
        text-align: left;
        font: inherit;
        color: inherit;
        cursor: pointer;
      }
      .l {
        display: grid;
        gap: 2px;
      }
      .t {
        font-weight: 600;
      }
      .amt {
        font-weight: 650;
        white-space: nowrap;
      }
      .grid2 {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 0 10px;
      }
      .danger {
        color: var(--hb-bad-ink);
      }
    `,
  ],
})
export class ReservesPage {
  protected readonly svc = inject(LiquidityService);
  private readonly fc = inject(ForecastService);
  private readonly prefs = inject(PrefsStore);
  private readonly today = todayLocal();
  protected readonly euro = formatEuro;
  protected readonly de = formatDate;
  protected readonly open = signal<string | null>(null);
  protected readonly draft = signal<Pot | null>(null);
  protected readonly balanceIn = signal('');
  protected readonly targetIn = signal('');
  protected readonly error = signal('');
  protected readonly msg = signal('');
  protected readonly distributedThisMonth = computed(
    () => this.svc.settings().lastDistribution === this.today.slice(0, 7),
  );
  /** wiederkehrende Ausgaben, für die sich ein Jahreszahlungs-Topf lohnt (nicht monatlich) */
  protected readonly yearly = computed(() =>
    this.fc.refined().filter((i) => i.amount < 0 && i.interval !== 'monat'),
  );
  protected readonly rows = computed(() =>
    this.svc.pots().map((p) => ({
      p,
      rate: potRate(p, this.fc.refined(), this.today),
      due: potNextDue(p, this.fc.refined(), this.today),
      need: potDueAmount(p, this.fc.refined()),
      warn: potWarning(p, this.fc.refined(), this.today),
    })),
  );
  protected readonly shares = computed(() => {
    const pa = this.svc.potAccount();
    if (!pa || pa.balance <= 0) return { pots: 0, res: 0, free: 0 };
    const pots = this.svc.pots().reduce((s, p) => s + p.balance, 0),
      res = pa.account.reserve;
    return {
      pots: (pots / pa.balance) * 100,
      res: (res / pa.balance) * 100,
      free: Math.max(0, (this.svc.free() / pa.balance) * 100),
    };
  });

  protected val(ev: Event): string {
    return (ev.target as HTMLInputElement).value;
  }

  protected async setAccount(id: string): Promise<void> {
    await this.prefs.setLiquidity({ potAccountId: id });
  }

  protected async distribute(): Promise<void> {
    const n = await this.svc.distribute();
    this.msg.set(
      n
        ? `${formatEuro(n)} auf die Töpfe verteilt.`
        : 'Nichts verteilt: Der freie Teil des Kontos reicht nicht.',
    );
  }

  protected newPot(): void {
    const p: Pot = {
      id: crypto.randomUUID(),
      name: '',
      kind: this.yearly().length ? 'jahr' : 'ziel',
      balance: 0,
      recurringId: this.yearly()[0]?.id ?? null,
      target: null,
      due: null,
      link: null,
      order: this.svc.pots().length,
    };
    this.open.set('neu');
    this.edit(p);
  }

  protected edit(p: Pot | null): void {
    this.error.set('');
    this.msg.set('');
    if (!p || (this.open() === p.id && this.draft()?.id === p.id)) {
      this.open.set(null);
      this.draft.set(null);
      return;
    }
    if (this.open() !== 'neu') this.open.set(p.id);
    this.draft.set({ ...p });
    this.balanceIn.set(euroIn(p.balance));
    this.targetIn.set(p.target ? euroIn(p.target) : '');
  }

  protected patch(x: Partial<Pot>): void {
    const d = this.draft();
    if (d) this.draft.set({ ...d, ...x });
  }

  protected async save(): Promise<void> {
    const d = this.draft();
    if (!d) return;
    const balance = parseEuro(this.balanceIn() || '0') ?? -1;
    const old = this.svc.pots().find((x) => x.id === d.id)?.balance ?? 0;
    const it = this.fc.refined().find((i) => i.id === d.recurringId);
    const name = d.name.trim() || (d.kind === 'jahr' ? (it?.label ?? '') : '');
    if (!name)
      return this.error.set(
        'Bitte einen Namen eingeben, z. B. „Kfz-Versicherung“ oder „Urlaub 2027“.',
      );
    if (balance < 0) return this.error.set('Das Guthaben ist ein Betrag ab 0,00 €.');
    if (balance - old > this.svc.free())
      return this.error.set(
        `Es sind nur ${formatEuro(this.svc.free())} frei; mehr lässt sich nicht zuteilen.`,
      );
    if (d.kind === 'jahr' && !d.recurringId)
      return this.error.set(
        'Bitte die Jahreszahlung wählen. Sie muss unter Buchungen → Wiederkehrend eingeplant sein.',
      );
    const target = d.kind === 'ziel' ? parseEuro(this.targetIn()) : null;
    if (d.kind === 'ziel' && (!target || target <= 0 || !d.due))
      return this.error.set('Bitte Zielbetrag und Zieltermin eingeben.');
    await this.svc.savePot({
      ...d,
      name,
      balance,
      target,
      recurringId: d.kind === 'jahr' ? d.recurringId : null,
    });
    this.msg.set(`Topf „${name}“ gespeichert.`);
    this.open.set(null);
    this.draft.set(null);
  }

  protected async remove(): Promise<void> {
    const d = this.draft();
    if (!d) return;
    await this.svc.removePot(d.id);
    this.msg.set(`Topf „${d.name}“ aufgelöst; sein Guthaben ist wieder frei.`);
    this.open.set(null);
    this.draft.set(null);
  }
}
