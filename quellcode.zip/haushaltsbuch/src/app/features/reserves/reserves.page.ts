import { NgTemplateOutlet } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  computed,
  inject,
  signal,
} from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import {
  Pot,
  potDueAmount,
  potNextDue,
  potRate,
  potWarning,
  targetBalance,
} from '../../domain/liquidity/pots';
import { formatDate, todayLocal } from '../../domain/shared/local-date';
import { formatEuro, parseEuro } from '../../domain/shared/money';
import { ForecastService } from '../../data/forecast.service';
import { LiquidityService } from '../../data/liquidity.service';
import { PrefsStore } from '../../data/stores/prefs.store';
import { SelectValue } from '../../shared/select-value';
import { CategoryPicker } from '../bookings/category-picker';

const euroIn = (c: number) =>
  (Math.abs(c) / 100).toLocaleString('de-DE', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

/** Rücklagen und Spartöpfe (Lastenheft 16a): ein Tagesgeldkonto, gedanklich aufgeteilt; Dauerauftrag wird erkannt und verteilt. */
@Component({
  selector: 'app-reserves-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    NgTemplateOutlet,
    MatButtonModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatInputModule,
    SelectValue,
    CategoryPicker,
  ],
  templateUrl: './reserves.page.html',
  styleUrl: './reserves.page.scss',
})
export class ReservesPage implements OnInit {
  protected readonly svc = inject(LiquidityService);
  private readonly fc = inject(ForecastService);
  private readonly prefs = inject(PrefsStore);
  protected readonly today = todayLocal();
  protected readonly euro = formatEuro;
  protected readonly de = formatDate;
  protected readonly open = signal<string | null>(null);
  protected readonly draft = signal<Pot | null>(null);
  protected readonly balanceIn = signal('');
  protected readonly targetIn = signal('');
  protected readonly error = signal('');
  protected readonly msg = signal('');
  /** Startverteilung: neue Topfstände als Eingabe */
  protected readonly startIn = signal<Record<string, string>>({});
  /** Bearbeiten einer Verteilung */
  protected readonly editDist = signal<string | null>(null);
  protected readonly distIn = signal<Record<string, string>>({});
  /** Umschichten */
  protected readonly shiftFrom = signal('frei');
  protected readonly shiftTo = signal('');
  protected readonly shiftAmount = signal('');
  /** Dauerauftrag eintragen (Vorschlag: Summe der Monatsraten) */
  protected readonly soAmount = signal('');
  protected readonly soDay = signal('1');

  protected async saveSo(): Promise<void> {
    // ohne eigene Eingabe gilt der Vorschlag: die aktuelle Summe der Monatsraten
    const amount = this.soAmount().trim() ? (parseEuro(this.soAmount()) ?? 0) : this.svc.rateSum();
    const err = await this.svc.addStandingOrder(amount, Number(this.soDay()));
    if (err) return this.error.set(err);
    this.error.set('');
    this.msg.set(
      'Dauerauftrag eingetragen. Die Prognose rechnet damit, und jeder Eingang wird auf die Töpfe verteilt.',
    );
  }

  protected readonly yearly = computed(() =>
    this.fc.refined().filter((i) => i.amount < 0 && i.interval !== 'monat'),
  );
  protected readonly rows = computed(() =>
    this.svc.ordered().map((p) => ({
      p,
      rate: potRate(p, this.fc.refined(), this.today),
      due: potNextDue(p, this.fc.refined(), this.today),
      need: potDueAmount(p, this.fc.refined()),
      warn: potWarning(p, this.fc.refined(), this.today),
      soll: targetBalance(p, this.fc.refined(), this.today),
    })),
  );
  protected readonly shares = computed(() => {
    const pa = this.svc.potAccount();
    if (!pa || pa.balance <= 0) return { pots: 0, res: 0, free: 0 };
    const pots = this.svc.pots().reduce((s, p) => s + p.balance, 0),
      res = pa.account.reserve;
    return {
      pots: (pots / pa.balance) * 100,
      res: (res / pa.balance) * 100,
      free: Math.max(0, (this.svc.free() / pa.balance) * 100),
    };
  });
  protected readonly soDiff = computed(() => {
    const so = this.svc.standingOrder();
    return so ? so.amount - this.svc.rateSum() : null;
  });
  protected readonly history = computed(() =>
    Object.entries(this.svc.distribution().done)
      .filter(([, e]) => Object.keys(e.parts).length)
      .map(([id, e]) => ({ id, ...e }))
      .sort((a, b) => (a.date < b.date ? 1 : -1))
      .slice(0, 6),
  );
  protected readonly startSum = computed(() =>
    Object.values(this.startIn()).reduce((s, v) => s + (parseEuro(v || '0') ?? 0), 0),
  );

  async ngOnInit(): Promise<void> {
    const n = await this.svc.autoDistribute();
    if (n)
      this.msg.set(
        `${n} ${n === 1 ? 'Eingang' : 'Eingänge'} des Dauerauftrags auf die Töpfe verteilt.`,
      );
    this.resetStart();
  }

  protected euroIn(c: number): string {
    return euroIn(c);
  }

  protected val(ev: Event): string {
    return (ev.target as HTMLInputElement).value;
  }

  protected potName(id: string): string {
    return this.svc.pots().find((p) => p.id === id)?.name ?? 'Topf';
  }

  protected partsText(parts: Record<string, number>): string {
    return (
      Object.entries(parts)
        .map(([id, v]) => `${this.potName(id)} ${formatEuro(v)}`)
        .join(', ') || 'nichts verteilt'
    );
  }

  protected async setAccount(id: string): Promise<void> {
    await this.prefs.setLiquidity({ potAccountId: id });
  }

  // ---------- Startverteilung ----------
  protected resetStart(): void {
    const plan = this.svc.startPreview();
    this.startIn.set(
      Object.fromEntries(this.svc.pots().map((p) => [p.id, euroIn(plan[p.id] ?? p.balance)])),
    );
  }

  protected setStart(id: string, v: string): void {
    this.startIn.update((m) => ({ ...m, [id]: v }));
  }

  protected async applyStart(): Promise<void> {
    const balances = Object.fromEntries(
      Object.entries(this.startIn()).map(([id, v]) => [id, parseEuro(v || '0') ?? -1]),
    );
    if (Object.values(balances).some((v) => v < 0))
      return this.error.set('Bitte nur Beträge ab 0,00 € eintragen.');
    const err = await this.svc.applyStart(balances);
    if (err) return this.error.set(err);
    this.error.set('');
    this.msg.set(
      'Startverteilung übernommen. Ab jetzt verteilt die App jeden Eingang des Dauerauftrags automatisch.',
    );
  }

  // ---------- Verteilung ändern ----------
  protected startEditDist(id: string, parts: Record<string, number>): void {
    this.editDist.set(this.editDist() === id ? null : id);
    this.distIn.set(
      Object.fromEntries(this.svc.pots().map((p) => [p.id, euroIn(parts[p.id] ?? 0)])),
    );
  }

  protected setDist(id: string, v: string): void {
    this.distIn.update((m) => ({ ...m, [id]: v }));
  }

  protected async saveDist(id: string): Promise<void> {
    const parts = Object.fromEntries(
      Object.entries(this.distIn())
        .map(([k, v]) => [k, parseEuro(v || '0') ?? 0])
        .filter(([, v]) => (v as number) > 0),
    );
    const err = await this.svc.editDistribution(id, parts as Record<string, number>);
    if (err) return this.error.set(err);
    this.error.set('');
    this.editDist.set(null);
    this.msg.set('Verteilung geändert.');
  }

  // ---------- Umschichten ----------
  protected async doShift(): Promise<void> {
    const amount = parseEuro(this.shiftAmount());
    const err = await this.svc.shiftPots(this.shiftFrom(), this.shiftTo(), amount ?? 0);
    if (err) return this.error.set(err);
    this.error.set('');
    this.shiftAmount.set('');
    this.msg.set('Umgeschichtet. Echtes Geld wurde nicht bewegt, nur die Aufteilung.');
  }

  // ---------- Töpfe anlegen und bearbeiten ----------
  protected newPot(): void {
    const p: Pot = {
      id: crypto.randomUUID(),
      name: '',
      kind: this.yearly().length ? 'jahr' : 'ziel',
      balance: 0,
      recurringId: this.yearly()[0]?.id ?? null,
      target: null,
      due: null,
      link: null,
      order: this.svc.pots().length,
    };
    this.open.set('neu');
    this.edit(p);
  }

  protected edit(p: Pot | null): void {
    this.error.set('');
    this.msg.set('');
    if (!p || (this.open() === p.id && this.draft()?.id === p.id)) {
      this.open.set(null);
      this.draft.set(null);
      return;
    }
    if (this.open() !== 'neu') this.open.set(p.id);
    this.draft.set({ ...p });
    this.balanceIn.set(euroIn(p.balance));
    this.targetIn.set(p.target ? euroIn(p.target) : '');
  }

  protected patch(x: Partial<Pot>): void {
    const d = this.draft();
    if (d) this.draft.set({ ...d, ...x });
  }

  protected async save(): Promise<void> {
    const d = this.draft();
    if (!d) return;
    const balance = parseEuro(this.balanceIn() || '0') ?? -1;
    const old = this.svc.pots().find((x) => x.id === d.id)?.balance ?? 0;
    const it = this.fc.refined().find((i) => i.id === d.recurringId);
    const name = d.name.trim() || (d.kind === 'jahr' ? (it?.label ?? '') : '');
    if (!name)
      return this.error.set(
        'Bitte einen Namen eingeben, z. B. „Kfz-Versicherung“ oder „Urlaub 2027“.',
      );
    if (balance < 0) return this.error.set('Das Guthaben ist ein Betrag ab 0,00 €.');
    if (balance - old > this.svc.free())
      return this.error.set(
        `Es sind nur ${formatEuro(this.svc.free())} frei; mehr lässt sich nicht zuteilen.`,
      );
    if (d.kind === 'jahr' && !d.recurringId)
      return this.error.set(
        'Bitte die Jahreszahlung wählen. Sie muss unter Buchungen → Wiederkehrend eingeplant sein.',
      );
    const target = d.kind === 'ziel' ? parseEuro(this.targetIn()) : null;
    if (d.kind === 'ziel' && (!target || target <= 0 || !d.due))
      return this.error.set('Bitte Zielbetrag und Zieltermin eingeben.');
    await this.svc.savePot({
      ...d,
      name,
      balance,
      target,
      recurringId: d.kind === 'jahr' ? d.recurringId : null,
    });
    this.msg.set(`Topf „${name}“ gespeichert.`);
    this.open.set(null);
    this.draft.set(null);
    this.resetStart();
  }

  protected async remove(): Promise<void> {
    const d = this.draft();
    if (!d) return;
    await this.svc.removePot(d.id);
    this.msg.set(`Topf „${d.name}“ aufgelöst; sein Guthaben ist wieder frei.`);
    this.open.set(null);
    this.draft.set(null);
    this.resetStart();
  }
}
