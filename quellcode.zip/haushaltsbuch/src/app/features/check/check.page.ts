import { MatCheckbox } from '@angular/material/checkbox';
import { MatAnchor, MatButton } from '@angular/material/button';
import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CheckItem, checksAsText, runChecks } from '../../data/check/feasibility';
import { PasskeyService } from '../../data/crypto/passkey.service';
import { APP_VERSION, VaultService } from '../../data/vault.service';
import { MirrorService } from '../../data/mirror.service';

const MANUAL = [
  'App über „App installieren“ auf den Startbildschirm gebracht',
  'Mit Fingerabdruck entsperrt',
  'Schnellzugriff „Neue Buchung“ auf den Startbildschirm gezogen und benutzt',
  'App verlassen, nach über einer Minute zurück: wieder gesperrt',
  'Im Flugmodus geöffnet und eine Testbuchung erfasst',
  'Backup erstellt und auf dem zweiten Handy eingespielt, Testbuchungen sind da',
];

@Component({
  selector: 'app-check-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterLink, MatButton, MatAnchor, MatCheckbox],
  template: `
    <div class="page">
      <h1>Machbarkeitsprüfung</h1>
      <p class="muted">
        Das prüft die App selbst. Darunter kommt die Liste für die Tests von Hand. Am Ende „Ergebnis
        kopieren“ und im Chat bei mir einfügen.
      </p>
      <div class="card">
        @for (i of items(); track i.id) {
          <div class="row">
            <span class="mark" [class.ok]="i.ok === true" [class.no]="i.ok === false">{{
              i.ok === null ? '–' : i.ok ? '✓' : '✗'
            }}</span>
            <div>
              <div class="t">{{ i.label }}</div>
              <div class="muted small">{{ i.detail }}</div>
            </div>
          </div>
        } @empty {
          <p class="muted">Prüfe …</p>
        }
      </div>
      <div class="card">
        <h2>Von Hand prüfen</h2>
        @for (m of manual(); track m.label; let k = $index) {
          <mat-checkbox [checked]="m.done" (change)="toggle(k, $event.checked)">{{
            m.label
          }}</mat-checkbox>
        }
      </div>
      <div class="actions">
        <button mat-flat-button type="button" data-testid="copy" (click)="copy()">
          Ergebnis kopieren
        </button>
        <button mat-stroked-button type="button" (click)="refresh()">Neu prüfen</button>
        <a mat-button [routerLink]="vault.status() === 'entsperrt' ? '/start' : '/'">Zurück</a>
      </div>
      @if (copied()) {
        <p class="hint" role="status">{{ copied() }}</p>
      }
      @if (fallback()) {
        <textarea class="report" readonly aria-label="Ergebnis zum Kopieren">{{
          fallback()
        }}</textarea>
      }
    </div>
  `,
  styles: [
    `
      .row {
        display: grid;
        grid-template-columns: 28px 1fr;
        gap: 8px;
        padding: 6px 0;
        border-bottom: 1px solid var(--hb-line);
      }
      .mark {
        font-weight: 800;
        text-align: center;
        color: var(--hb-muted);
      }
      .ok {
        color: var(--hb-primary);
      }
      .no {
        color: var(--hb-bad-ink);
      }
      .t {
        font-weight: 600;
      }
      mat-checkbox {
        display: block;
        margin: 4px 0;
      }
      .report {
        width: 100%;
        min-height: 220px;
        margin-top: 8px;
        font:
          13px ui-monospace,
          monospace;
      }
    `,
  ],
})
export class CheckPage implements OnInit {
  protected readonly vault = inject(VaultService);
  private readonly passkeys = inject(PasskeyService);
  private readonly mirror = inject(MirrorService);
  protected readonly items = signal<CheckItem[]>([]);
  protected readonly manual = signal(MANUAL.map((label) => ({ label, done: false })));
  protected readonly copied = signal('');
  protected readonly fallback = signal('');

  ngOnInit(): void {
    try {
      const saved = JSON.parse(sessionStorage.getItem('hb-manual') ?? '[]') as boolean[];
      this.manual.update((l) => l.map((m, i) => ({ ...m, done: !!saved[i] })));
    } catch {
      /* ohne gespeicherte Häkchen */
    }
    void this.refresh();
  }

  protected async refresh(): Promise<void> {
    await this.vault.ready;
    this.items.set([
      ...(await runChecks(this.passkeys, this.vault.meta(), APP_VERSION)),
      ...this.mirror.checkItems(),
    ]);
  }

  protected toggle(i: number, done: boolean): void {
    this.manual.update((l) => l.map((m, k) => (k === i ? { ...m, done } : m)));
    try {
      sessionStorage.setItem('hb-manual', JSON.stringify(this.manual().map((m) => m.done)));
    } catch {
      /* egal */
    }
  }

  protected async copy(): Promise<void> {
    const text = checksAsText(this.items(), this.manual());
    try {
      await navigator.clipboard.writeText(text);
      this.copied.set('Kopiert. Jetzt im Chat bei Claude einfügen (lange tippen, „Einfügen“).');
      this.fallback.set('');
    } catch {
      this.copied.set(
        'Kopieren ging nicht automatisch. Bitte den Text unten markieren und kopieren.',
      );
      this.fallback.set(text);
    }
  }
}
