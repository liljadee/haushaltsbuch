import { MatCheckbox } from '@angular/material/checkbox';
import { MatInput } from '@angular/material/input';
import { MatFormField, MatLabel } from '@angular/material/form-field';
import { MatButton } from '@angular/material/button';
import { oneOf, keysOf, entriesOf } from '../../domain/shared/choice';
import { NgTemplateOutlet } from '@angular/common';
import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import {
  LOAN_KINDS,
  Loan,
  LoanKind,
  LoanState,
  SPECIAL_RHYTHMS,
  SpecialRhythm,
  DEFAULT_FOLLOW_MILLI,
  defaultSpecial,
  latestSnapshot,
  plan,
  specialPatternFor,
} from '../../domain/loans/loan';
import { formatDate, todayLocal } from '../../domain/shared/local-date';
import { formatEuro, parseEuro } from '../../domain/shared/money';
import { LoansService, LoanView } from '../../data/loans.service';
import { AccountsStore } from '../../data/stores/accounts.store';
import { SelectValue } from '../../shared/select-value';
import { followOptions, whatIf } from '../../domain/loans/whatif';
import { toIcs } from '../../domain/loans/alarms';
import { BausparSection } from './bauspar-section';
import { DebtChart } from './debt-chart';
import { RoadmapCard } from './roadmap-card';
import { SpecialPlanCard } from './special-plan-card';
import { euroInput, monthYear, parsePercent, percentInput } from '../../domain/shared/format';

/** Formularwerte als Text (Eingaben bleiben, wie getippt) */
interface Form {
  name: string;
  kind: LoanKind;
  bank: string;
  accountId: string;
  pattern: string;
  specialPattern: string;
  balance: string;
  date: string;
  rate: string;
  rateP: string;
  effP: string;
  day: string;
  fixedUntil: string;
  endDate: string;
  interestOnlyUntil: string;
  payoutDate: string;
  fwd: boolean;
  followP: string;
  finalPayment: string;
  principal: string;
  sAllowed: boolean;
  sRhythm: SpecialRhythm;
  sMax: string;
  sMaxP: string;
  sMin: string;
  sFee: string;
}

/** Kredite (Lastenheft 18.2a, 18.3, 18.4): anlegen, bearbeiten, Tilgungsplan, Stand laut Bank, abbezahlt. */
@Component({
  selector: 'app-loans-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    NgTemplateOutlet,
    DebtChart,
    RoadmapCard,
    BausparSection,
    SpecialPlanCard,
    SelectValue,
    MatButton,
    MatFormField,
    MatLabel,
    MatInput,
    MatCheckbox,
  ],
  templateUrl: './loans.page.html',
  styleUrl: './loans.page.scss',
})
export class LoansPage {
  protected readonly svc = inject(LoansService);
  private readonly accounts = inject(AccountsStore);
  protected readonly today = todayLocal();
  protected readonly euro = formatEuro;
  protected readonly de = formatDate;
  protected readonly monthYear = monthYear;
  protected readonly kinds = entriesOf(LOAN_KINDS);
  protected readonly rhythms = entriesOf(SPECIAL_RHYTHMS);
  protected readonly giros = computed(() =>
    this.accounts.active().filter((a) => a.type === 'giro'),
  );

  protected readonly open = signal<string | null>(null);
  /** 'neu' oder Kredit-ID im Bearbeiten */
  protected readonly editing = signal<string | null>(null);
  protected readonly form = signal<Form | null>(null);
  protected readonly error = signal('');
  protected readonly msg = signal('');
  protected readonly showPlan = signal<string | null>(null);
  protected readonly snapFor = signal<string | null>(null);
  protected readonly snapDate = signal(todayLocal());
  protected readonly snapAmount = signal('');
  protected readonly paidMonth = signal(todayLocal().slice(0, 7));

  /** Kredit aus dem Formular (für Vorschau und Speichern) */
  protected readonly draft = computed<Loan | null>(() => {
    const f = this.form();
    if (!f) return null;
    const old = this.svc.all().find((l) => l.id === this.editing());
    const snaps = old
      ? old.snapshots
      : [{ date: f.date || this.today, balance: parseEuro(f.balance || '0') ?? 0 }];
    return {
      id: old?.id ?? 'neu',
      name: f.name.trim(),
      kind: f.kind,
      bank: f.bank.trim(),
      accountId: f.accountId,
      pattern: f.pattern.trim(),
      specialPattern: f.specialPattern.trim() || specialPatternFor(f.pattern),
      rate: parseEuro(f.rate || '0') ?? 0,
      day: Number(f.day) || 0,
      rateMilli: parsePercent(f.rateP) ?? -1,
      effMilli: parsePercent(f.effP),
      fixedUntil: f.fixedUntil || null,
      endDate: f.endDate || null,
      interestOnlyUntil: f.interestOnlyUntil || null,
      payoutDate: f.payoutDate || null,
      forwardRate: f.fwd,
      followMilli: parsePercent(f.followP) ?? DEFAULT_FOLLOW_MILLI,
      finalPayment: parseEuro(f.finalPayment || '') ?? null,
      principal: parseEuro(f.principal || '') ?? null,
      special: {
        allowed: f.sAllowed,
        rhythm: f.sRhythm,
        maxAmount: parseEuro(f.sMax || '') ?? null,
        maxPercentMilli: parsePercent(f.sMaxP),
        min: parseEuro(f.sMin || '') ?? null,
        fee: parseEuro(f.sFee || '') ?? null,
      },
      snapshots: snaps,
      paidOff: old?.paidOff ?? null,
      recurringId: old?.recurringId ?? null,
      order: old?.order ?? this.svc.all().length,
    };
  });
  protected readonly preview = computed(() => {
    const d = this.draft();
    const s = d ? latestSnapshot(d) : null;
    if (!d || !s || s.balance <= 0 || d.rateMilli < 0 || (d.kind !== 'voraus' && d.rate <= 0))
      return '';
    const p = plan(d, s);
    if (p.error) return p.error;
    if (!p.payoff)
      return d.kind === 'voraus'
        ? 'Nur Zinsen: Die Restschuld bleibt gleich, bis der Bausparvertrag ablöst.'
        : 'Mit diesen Werten wird der Kredit in 50 Jahren nicht abbezahlt.';
    return `Ohne Sondertilgungen abbezahlt voraussichtlich im ${monthYear(p.payoff)}${d.fixedUntil ? ' (nach der Zinsbindung mit dem Anschlusszins)' : ''}; Zinsen bis dahin ${formatEuro(p.totalInterest)}.`;
  });
  protected linked(loanId: string): boolean {
    return this.svc.bauspar().some((b) => b.loanId === loanId);
  }

  // ---------- Was wäre wenn (18.7) ----------
  protected readonly wiFor = signal<string | null>(null);
  protected readonly wiAmount = signal('');
  protected readonly wiMonth = signal(`${todayLocal().slice(0, 4)}-12`);
  protected readonly wiInc = signal('');
  protected readonly followIn = signal('3; 4; 5');
  protected readonly wishYear = signal('');

  protected wi(v: LoanView) {
    const amount = parseEuro(this.wiAmount() || '0') ?? 0,
      inc = parseEuro(this.wiInc() || '0') ?? 0;
    return whatIf(v.loan, v.state, this.today, {
      extra: amount > 0 ? { date: `${this.wiMonth()}-15`, amount } : null,
      rateIncrease: inc > 0 ? inc : 0,
    });
  }

  protected follow(v: LoanView) {
    const millis = this.followIn()
      .split(/[;\s]+/)
      .map((x) => parsePercent(x))
      .filter((x): x is number => x !== null && x >= 0 && x <= 20000);
    return followOptions(v.loan, v.state, this.today, millis, Number(this.wishYear()) || null);
  }

  protected liquidityText(): string {
    const amount = parseEuro(this.wiAmount() || '0') ?? 0,
      inc = parseEuro(this.wiInc() || '0') ?? 0;
    const parts = [
      amount > 0 ? `einmalig ${formatEuro(amount)} aus der Rücklage` : '',
      inc > 0 ? `${formatEuro(inc)} weniger im Monat auf dem Girokonto` : '',
    ].filter((x) => x);
    return parts.join('; ') || 'unverändert';
  }

  protected async exportIcs(): Promise<void> {
    const stamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d+/, '');
    const text = toIcs(this.svc.events(), stamp);
    const file = new File([text], 'haushaltsbuch-termine.ics', { type: 'text/calendar' });
    if (navigator.canShare?.({ files: [file] })) {
      try {
        await navigator.share({ files: [file], title: 'Termine' });
        return;
      } catch (e) {
        if ((e as Error).name === 'AbortError') return;
      }
    }
    const url = URL.createObjectURL(file);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'haushaltsbuch-termine.ics';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 10000);
  }

  protected setKind(v: string): void {
    this.patch({ kind: oneOf(v, keysOf(LOAN_KINDS), 'annuitaet') });
  }

  protected setRhythm(v: string): void {
    this.patch({ sRhythm: oneOf(v, keysOf(SPECIAL_RHYTHMS), 'jahr') });
  }

  protected kindLabel(k: LoanKind): string {
    return LOAN_KINDS[k];
  }

  protected val(ev: Event): string {
    return (ev.target as HTMLInputElement).value;
  }

  protected patch(x: Partial<Form>): void {
    const f = this.form();
    if (!f) return;
    const next = { ...f, ...x };
    // übliche Sondertilgungsregeln je Kreditart vorschlagen (18.2a)
    if (x.kind && x.kind !== f.kind) {
      const sp = defaultSpecial(x.kind);
      Object.assign(next, {
        sAllowed: sp.allowed,
        sRhythm: sp.rhythm,
        sMax: euroInput(sp.maxAmount),
        sMaxP: percentInput(sp.maxPercentMilli),
        sMin: '',
        sFee: '',
      });
    }
    this.form.set(next);
  }

  protected newLoan(): void {
    const sp = defaultSpecial('annuitaet');
    this.error.set('');
    this.msg.set('');
    this.open.set(null);
    this.editing.set('neu');
    this.form.set({
      name: '',
      kind: 'annuitaet',
      bank: '',
      accountId: this.giros()[0]?.id ?? '',
      pattern: '',
      specialPattern: '',
      balance: '',
      date: this.today,
      rate: '',
      rateP: '',
      effP: '',
      day: '30',
      fixedUntil: '',
      endDate: '',
      interestOnlyUntil: '',
      payoutDate: '',
      fwd: false,
      followP: percentInput(DEFAULT_FOLLOW_MILLI),
      finalPayment: '',
      principal: '',
      sAllowed: sp.allowed,
      sRhythm: sp.rhythm,
      sMax: '',
      sMaxP: percentInput(sp.maxPercentMilli),
      sMin: '',
      sFee: '',
    });
  }

  protected edit(l: Loan): void {
    const s = latestSnapshot(l);
    this.error.set('');
    this.editing.set(l.id);
    this.form.set({
      name: l.name,
      kind: l.kind,
      bank: l.bank,
      accountId: l.accountId,
      pattern: l.pattern,
      specialPattern: l.specialPattern,
      balance: euroInput(s?.balance),
      date: s?.date ?? this.today,
      rate: euroInput(l.rate),
      rateP: percentInput(l.rateMilli),
      effP: percentInput(l.effMilli),
      day: String(l.day),
      fixedUntil: l.fixedUntil ?? '',
      endDate: l.endDate ?? '',
      interestOnlyUntil: l.interestOnlyUntil ?? '',
      payoutDate: l.payoutDate ?? '',
      fwd: !!l.forwardRate,
      followP: percentInput(l.followMilli),
      finalPayment: euroInput(l.finalPayment),
      principal: euroInput(l.principal),
      sAllowed: l.special.allowed,
      sRhythm: l.special.rhythm,
      sMax: euroInput(l.special.maxAmount),
      sMaxP: percentInput(l.special.maxPercentMilli),
      sMin: euroInput(l.special.min),
      sFee: euroInput(l.special.fee),
    });
  }

  protected cancel(): void {
    this.editing.set(null);
    this.form.set(null);
    this.error.set('');
  }

  protected async save(): Promise<void> {
    const d = this.draft();
    if (!d) return;
    if (!d.accountId)
      return this.error.set('Bitte das Konto wählen, von dem die Rate abgebucht wird.');
    const isNew = this.editing() === 'neu';
    const err = await this.svc.save(isNew ? { ...d, id: crypto.randomUUID() } : d);
    if (err) return this.error.set(err);
    this.msg.set(`Kredit „${d.name}“ gespeichert. Die Rate ist für die Prognose eingeplant.`);
    this.cancel();
  }

  protected toggle(id: string): void {
    this.open.set(this.open() === id ? null : id);
    this.showPlan.set(null);
    this.snapFor.set(null);
    this.error.set('');
  }

  protected years(v: LoanView) {
    const out: {
      year: string;
      interest: number;
      principal: number;
      extra: number;
      balance: number;
    }[] = [];
    for (const r of v.state.plan.rows) {
      const y = r.date.slice(0, 4);
      let row = out.at(-1);
      if (!row || row.year !== y)
        out.push((row = { year: y, interest: 0, principal: 0, extra: 0, balance: 0 }));
      row.interest += r.interest;
      row.principal += r.principal;
      row.extra += r.extra;
      row.balance = r.balance;
    }
    return out;
  }

  protected matched(l: Loan): number {
    return this.svc.bookingsOf(l).length;
  }

  protected deviationText(s: LoanState): string {
    const d = s.deviation;
    if (!d || d.bank === d.computed) return '';
    const diff = d.bank - d.computed;
    return `Stand laut Bank am ${formatDate(d.date)}: ${formatEuro(d.bank)}; gerechnet waren ${formatEuro(d.computed)} (${diff > 0 ? '+' : '−'}${formatEuro(Math.abs(diff))}). Die App rechnet mit dem Bankwert weiter.`;
  }

  protected async saveSnap(l: Loan): Promise<void> {
    const v = parseEuro(this.snapAmount());
    if (v == null || v < 0 || !this.snapDate())
      return this.error.set('Bitte Datum und Restschuld laut Bank eingeben.');
    await this.svc.addSnapshot(l, this.snapDate(), v);
    this.snapFor.set(null);
    this.snapAmount.set('');
    this.msg.set('Stand laut Bank übernommen.');
  }

  protected async paidOff(l: Loan, month: string | null): Promise<void> {
    await this.svc.setPaidOff(l, month);
    this.open.set(null);
    this.msg.set(
      month
        ? `„${l.name}“ ist als abbezahlt markiert. Herzlichen Glückwunsch!`
        : `„${l.name}“ ist wieder aktiv.`,
    );
  }

  protected async remove(l: Loan): Promise<void> {
    const err = await this.svc.remove(l);
    if (err) return this.error.set(err);
    this.open.set(null);
    this.msg.set(`„${l.name}“ gelöscht.`);
  }
}
