import { MatButton } from '@angular/material/button';
import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { monthYear } from '../../domain/shared/format';
import { formatEuro } from '../../domain/shared/money';
import { LoansService } from '../../data/loans.service';

/** Fahrplan: was wann auf dich zukommt; vor allem, wann wie viel Restschuld anschlussfinanziert werden muss. */
@Component({
  selector: 'app-roadmap-card',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatButton],
  template: `
    @if (svc.roadmap().length) {
      <section class="card" data-testid="roadmap">
        <h2>Fahrplan</h2>
        <p class="small muted">
          {{
            svc.special()
              ? 'Was wann auf dich zukommt, nach deinem Sondertilgungsplan.'
              : 'Was wann auf dich zukommt.'
          }}
        </p>
        @if (refinance(); as r) {
          <p class="total" data-testid="rm-total">
            Insgesamt anschlusszufinanzieren: <strong>{{ euro(r) }}</strong>
          </p>
        }
        <ol class="rm">
          @for (i of shown(); track i.kind + i.loanId + i.date) {
            <li data-testid="rm-item" [class.refi-item]="i.refinance">
              <span class="when">{{ my(i.date) }}</span>
              <span class="what">
                <strong>{{ i.title }}</strong>
                <span class="small">{{ i.text }}</span>
                @if (i.refinance) {
                  <span class="refi">nachzufinanzieren: {{ euro(i.refinance) }}</span>
                }
              </span>
            </li>
          }
        </ol>
        @if (svc.roadmap().length > limit) {
          <button mat-button type="button" (click)="all.set(!all())">
            {{
              all() ? 'Weniger anzeigen' : 'Alle ' + svc.roadmap().length + ' Ereignisse anzeigen'
            }}
          </button>
        }
      </section>
    }
  `,
  styles: [
    `
      .total {
        margin: 4px 0 8px;
      }
      .rm {
        list-style: none;
        margin: 0;
        padding: 0;
      }
      .rm li {
        display: grid;
        grid-template-columns: 6.6em 1fr;
        gap: 10px;
        padding: 8px 0;
        border-top: 1px solid var(--hb-line);
      }
      .when {
        color: var(--hb-muted);
        font-size: 13px;
        padding-top: 2px;
      }
      .what {
        display: grid;
        gap: 2px;
      }
      .refi {
        font-weight: 650;
        color: var(--hb-warn-ink);
      }
      .rm li.refi-item .when {
        color: var(--hb-warn-ink);
        font-weight: 600;
      }
    `,
  ],
})
export class RoadmapCard {
  protected readonly svc = inject(LoansService);
  protected readonly euro = formatEuro;
  protected readonly my = monthYear;
  protected readonly limit = 6;
  protected readonly all = signal(false);
  protected readonly shown = computed(() =>
    this.all() ? this.svc.roadmap() : this.svc.roadmap().slice(0, this.limit),
  );
  protected readonly refinance = computed(() =>
    this.svc.roadmap().reduce((s, i) => s + (i.refinance ?? 0), 0),
  );
}
