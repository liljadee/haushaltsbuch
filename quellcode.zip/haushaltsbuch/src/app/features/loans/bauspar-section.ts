import { MatInput } from '@angular/material/input';
import { MatFormField, MatLabel } from '@angular/material/form-field';
import { MatButton } from '@angular/material/button';
import { oneOf } from '../../domain/shared/choice';
import { NgTemplateOutlet } from '@angular/common';
import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
  effect,
  untracked,
} from '@angular/core';
import {
  Bauspar,
  BausparProjection,
  BausparType,
  compareContract,
  suggestType,
} from '../../domain/loans/bauspar';
import { findStandingOrder } from '../../domain/liquidity/pots';
import { todayLocal } from '../../domain/shared/local-date';
import { formatEuro, parseEuro } from '../../domain/shared/money';
import { ForecastService } from '../../data/forecast.service';
import { LoansService } from '../../data/loans.service';
import { AccountsStore } from '../../data/stores/accounts.store';
import { BookingsStore } from '../../data/stores/bookings.store';
import { RecurringStore } from '../../data/stores/recurring.store';
import { SelectValue } from '../../shared/select-value';
import { euroInput, monthYear, parsePercent, percentInput } from '../../domain/shared/format';

interface Form {
  name: string;
  accountId: string;
  loanId: string;
  type: '' | BausparType;
  until: 'ja' | 'nein' | 'unbekannt';
  sum: string;
  savingRate: string;
  savingsP: string;
  minP: string;
  allocation: string;
  loanP: string;
  loanRate: string;
  cBal: string;
  cLoan: string;
  cEnd: string;
  cInt: string;
}

/** Bausparverträge mit Darlehen (Lastenheft 18.10): verknüpfen, Phasen in Klartext, Abgleich, Jahresübersicht. */
/** Betrag für Eingabefelder; 0 wird als leeres Feld gezeigt (optionale Angaben) */
const euroIn = (c: number | null | undefined) => (c ? euroInput(c) : '');
/** Monat und Jahr; Strich, wenn kein Datum */
const my = (d: string | null) => monthYear(d) || '–';

@Component({
  selector: 'app-bauspar-section',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [NgTemplateOutlet, SelectValue, MatButton, MatFormField, MatLabel, MatInput],
  template: `
    <section class="card" data-testid="bauspar-section">
      <h2>Bausparverträge</h2>
      @if (editing() === 'neu') {
        <ng-container [ngTemplateOutlet]="editor" />
      }
      @for (v of svc.bausparViews(); track v.b.id) {
        <div class="bs" [attr.data-testid]="'bs-' + v.b.name">
          <div class="row">
            <span class="t">{{ v.b.name }}</span>
            <span class="num">Guthaben {{ euro(v.balance) }}</span>
          </div>
          @if (v.p.payoff) {
            <p class="sum" data-testid="bs-summary">
              Ablösung {{ my(v.p.payoff)
              }}{{
                v.p.bauLoan
                  ? ' · Bauspardarlehen ' + euro(v.p.bauLoan) + ' bis ' + my(v.p.bauLoanEnd)
                  : ''
              }}
              ·
              <span [class]="okCount(v) === v.p.checks.length ? 'good' : 'warnc'">{{
                okCount(v) === v.p.checks.length
                  ? 'alles stimmig'
                  : v.p.checks.length -
                    okCount(v) +
                    (v.p.checks.length - okCount(v) === 1 ? ' Punkt prüfen' : ' Punkte prüfen')
              }}</span>
            </p>
          }
          @if (v.p.mismatch) {
            <p class="warn small">{{ v.p.mismatch }}</p>
          }
          @if (v.p.error) {
            <p class="warn small">{{ v.p.error }}</p>
          }
          <div class="actions">
            <button
              mat-button
              type="button"
              data-testid="bs-details"
              (click)="toggleDetails(v.b.id)"
            >
              {{ details() === v.b.id ? 'Details ausblenden' : 'Details' }}
            </button>
            <button mat-button type="button" data-testid="bs-edit" (click)="edit(v.b)">
              Bearbeiten
            </button>
          </div>
          @if (details() === v.b.id) {
            <dl class="facts" data-testid="bs-facts">
              <dt>Löst ab</dt>
              <dd>{{ loanName(v.b.loanId) }}</dd>
              <dt>Bausparsumme</dt>
              <dd class="num">{{ euro(v.b.sum) }}</dd>
              <dt>Guthaben heute</dt>
              <dd class="num">{{ euro(v.balance) }}</dd>
              <dt>Sparrate</dt>
              <dd class="num">{{ euro(v.b.savingRate) }} im Monat</dd>
              <dt>Guthabenzins</dt>
              <dd>{{ pct(v.b.savingsMilli) }}</dd>
              <dt>Mindestsparguthaben</dt>
              <dd>
                {{ pct(v.b.minMilli) }} = {{ euro(Math.round((v.b.sum * v.b.minMilli) / 100000)) }}
              </dd>
              <dt>Zuteilung laut Bausparkasse</dt>
              <dd>{{ my(v.b.allocation) }}</dd>
              <dt>Bauart</dt>
              <dd>
                {{ v.p.type === 'zinsen' ? 'Nur Zinsen bis zur Zuteilung' : 'Zinsen und Tilgung' }}
              </dd>
              <dt>Bauspardarlehen</dt>
              <dd>{{ pct(v.b.loanMilli) }} Zins, {{ euro(v.b.loanRate) }} Rate im Monat</dd>
            </dl>
            @if (!v.b.type && v.p.suggested) {
              <p class="small muted">
                Bauart noch offen; die App rechnet mit „{{
                  v.p.suggested === 'zinsen' ? 'Nur Zinsen' : 'Zinsen und Tilgung'
                }}“, weil das zur Rate passt.
              </p>
            }
            @for (t of v.p.story; track $index) {
              <p class="story" data-testid="bs-story">{{ t }}</p>
            }
            @if (v.p.checks.length) {
              <h3>Passt das zusammen?</h3>
              <ul class="checks" data-testid="bs-checks">
                @for (c of v.p.checks; track c.label) {
                  <li [class]="c.status">
                    <span class="dot" aria-hidden="true"></span
                    ><span
                      ><strong>{{ c.label }}:</strong> {{ c.text }}</span
                    >
                  </li>
                }
              </ul>
            }
            @if (compare(v); as rows) {
              @if (rows.length) {
                <h3>Vergleich mit deinem Vertrag</h3>
                <div class="tbl-wrap">
                  <table class="tbl" data-testid="bs-compare">
                    <thead>
                      <tr>
                        <th></th>
                        <th>Vertrag</th>
                        <th>App</th>
                        <th>Abweichung</th>
                      </tr>
                    </thead>
                    <tbody>
                      @for (r of rows; track r.label) {
                        <tr [class.off]="!r.ok">
                          <td>{{ r.label }}</td>
                          <td class="num">{{ r.contract }}</td>
                          <td class="num">{{ r.app }}</td>
                          <td class="num">{{ r.diff }}</td>
                        </tr>
                      }
                    </tbody>
                  </table>
                </div>
                <p class="small" [class.warn]="!allOk(rows)">
                  {{
                    allOk(rows)
                      ? 'Die App rechnet wie die Bausparkasse. Kleine Abweichungen kommen von Rundungen und der genauen Zinsgutschrift; nach der Zuteilung rechnet die App mit den echten Werten.'
                      : 'Größere Abweichung: Prüfe Guthaben heute, Sparrate, Zuteilungstermin sowie Zins und Rate des Bauspardarlehens.'
                  }}
                </p>
              }
            }
            <button mat-button type="button" (click)="toggleYears(v.b.id)">
              {{ years() === v.b.id ? 'Jahresübersicht ausblenden' : 'Jahresübersicht' }}
            </button>
            @if (years() === v.b.id) {
              <div class="tbl-wrap">
                <table class="tbl">
                  <thead>
                    <tr>
                      <th>Jahr</th>
                      <th>Phase</th>
                      <th>Guthaben</th>
                      <th>Restschuld</th>
                      <th>Netto</th>
                    </tr>
                  </thead>
                  <tbody>
                    @for (y of v.p.years; track y.year) {
                      <tr>
                        <td>{{ y.year }}</td>
                        <td>{{ y.phase }}</td>
                        <td class="num">{{ euro(y.balance) }}</td>
                        <td class="num">{{ euro(y.debt) }}</td>
                        <td class="num">{{ euro(y.net) }}</td>
                      </tr>
                    }
                  </tbody>
                </table>
              </div>
              <p class="small muted">
                Netto = Restschuld minus Guthaben; das Guthaben ist zur Ablösung bestimmt.
              </p>
            }
          }
          @if (editing() === v.b.id) {
            <ng-container [ngTemplateOutlet]="editor" />
          }
        </div>
      } @empty {
        @if (editing() !== 'neu') {
          <p class="muted small">
            Hängt ein Darlehen an einem Bausparvertrag, verknüpfe beide hier. Die App zeigt dann,
            wann abgelöst wird, wie sich Restschuld und Guthaben entwickeln und ob alles
            zusammenpasst.
          </p>
        }
      }
      @if (editing() !== 'neu') {
        <button mat-button type="button" data-testid="bs-new" (click)="newOne()">
          + Bausparvertrag verknüpfen
        </button>
      }
    </section>

    <ng-template #editor>
      @if (form(); as f) {
        <div class="ed" data-testid="bs-form">
          @if (!bausparAccounts().length) {
            <p class="warn small">
              Es gibt noch kein Konto der Art „Bausparvertrag“. Leg es auf der Übersicht unter
              „Konto anlegen“ an (Art „Bausparvertrag“, Guthaben als Startsaldo).
            </p>
          }
          <div class="grid2">
            <mat-form-field appearance="outline"
              ><mat-label>Name</mat-label
              ><input
                matInput
                data-testid="bs-name"
                [value]="f.name"
                placeholder="z. B. LBS Bausparvertrag"
                (input)="patch({ name: val($event) })"
            /></mat-form-field>
            <mat-form-field appearance="outline">
              <mat-label>Konto (Guthaben)</mat-label>
              <select
                matNativeControl
                data-testid="bs-account"
                [appSelectValue]="f.accountId"
                (change)="patch({ accountId: val($event) })"
              >
                <option value="">bitte wählen</option>
                @for (a of bausparAccounts(); track a.id) {
                  <option [value]="a.id">{{ a.name }}</option>
                }
              </select>
            </mat-form-field>
          </div>
          <mat-form-field appearance="outline">
            <mat-label>Löst dieses Darlehen ab</mat-label>
            <select
              matNativeControl
              data-testid="bs-loan"
              [appSelectValue]="f.loanId"
              (change)="patch({ loanId: val($event) })"
            >
              <option value="">bitte wählen</option>
              @for (l of svc.active(); track l.loan.id) {
                <option [value]="l.loan.id">{{ l.loan.name }}</option>
              }
            </select>
          </mat-form-field>
          <mat-form-field appearance="outline">
            <mat-label>Was zahlt ihr jeden Monat auf das Darlehen?</mat-label>
            <select
              matNativeControl
              data-testid="bs-type"
              [appSelectValue]="f.type"
              (change)="setType(val($event))"
            >
              <option value="">weiß ich nicht</option>
              <option value="zinsen">Nur Zinsen (Restschuld bleibt gleich)</option>
              <option value="tilgung">Zinsen und Tilgung (Restschuld sinkt)</option>
            </select>
          </mat-form-field>
          @if (suggestion(); as sg) {
            <p class="small muted" data-testid="bs-suggest">
              Die Rate
              {{
                sg === 'zinsen'
                  ? 'entspricht genau den Zinsen; das spricht für „Nur Zinsen“'
                  : 'ist höher als die Zinsen; das spricht für „Zinsen und Tilgung“'
              }}.
            </p>
          }
          @if (f.type === 'zinsen') {
            <mat-form-field appearance="outline">
              <mat-label>Gilt der Zins laut Vertrag bis zur Zuteilung?</mat-label>
              <select matNativeControl [appSelectValue]="f.until" (change)="setUntil(val($event))">
                <option value="ja">ja</option>
                <option value="nein">nein, nur bis zu einem Datum</option>
                <option value="unbekannt">weiß ich nicht</option>
              </select>
            </mat-form-field>
          }
          <div class="grid2">
            <mat-form-field appearance="outline"
              ><mat-label>Bausparsumme €</mat-label
              ><input
                matInput
                inputmode="decimal"
                data-testid="bs-sum"
                [value]="f.sum"
                (input)="patch({ sum: val($event) })"
            /></mat-form-field>
            <mat-form-field appearance="outline"
              ><mat-label>Sparrate im Monat €</mat-label
              ><input
                matInput
                inputmode="decimal"
                data-testid="bs-rate"
                [value]="f.savingRate"
                (input)="patch({ savingRate: val($event) })"
            /></mat-form-field>
          </div>
          @if (detectedRate(); as r) {
            <p class="small muted">
              Erkannter Dauerauftrag auf dieses Konto: {{ euro(r) }} im Monat.
            </p>
          }
          <div class="grid2">
            <mat-form-field appearance="outline"
              ><mat-label>Guthabenzins %</mat-label
              ><input
                matInput
                inputmode="decimal"
                [value]="f.savingsP"
                (input)="patch({ savingsP: val($event) })"
            /></mat-form-field>
            <mat-form-field appearance="outline"
              ><mat-label>Mindestsparguthaben %</mat-label
              ><input
                matInput
                inputmode="decimal"
                data-testid="bs-min"
                [value]="f.minP"
                (input)="patch({ minP: val($event) })"
            /></mat-form-field>
          </div>
          <mat-form-field appearance="outline"
            ><mat-label>Voraussichtliche Zuteilung (laut Bausparkasse)</mat-label
            ><input
              matInput
              type="month"
              data-testid="bs-alloc"
              [value]="f.allocation"
              (input)="patch({ allocation: val($event) })"
          /></mat-form-field>
          <div class="grid2">
            <mat-form-field appearance="outline"
              ><mat-label>Zins Bauspardarlehen %</mat-label
              ><input
                matInput
                inputmode="decimal"
                data-testid="bs-loanP"
                [value]="f.loanP"
                (input)="patch({ loanP: val($event) })"
            /></mat-form-field>
            <mat-form-field appearance="outline"
              ><mat-label>Rate Bauspardarlehen €</mat-label
              ><input
                matInput
                inputmode="decimal"
                data-testid="bs-loanRate"
                [value]="f.loanRate"
                (input)="patch({ loanRate: val($event) })"
            /></mat-form-field>
          </div>
          <p class="small muted">
            Diese Angaben stehen im Bausparvertrag bzw. im Jahreskontoauszug der Bausparkasse.
          </p>
          <h3>Werte aus deiner Finanzierungsübersicht (freiwillig)</h3>
          <p class="small muted">
            Zum Vergleich mit der Rechnung der App; stehen in der Übersicht der Bausparkasse unter
            „Zum Zeitpunkt der Zuteilung“.
          </p>
          <div class="grid2">
            <mat-form-field appearance="outline"
              ><mat-label>Guthaben zur Zuteilung €</mat-label
              ><input
                matInput
                inputmode="decimal"
                data-testid="bs-c-bal"
                [value]="f.cBal"
                (input)="patch({ cBal: val($event) })"
            /></mat-form-field>
            <mat-form-field appearance="outline"
              ><mat-label>Darlehensbetrag €</mat-label
              ><input
                matInput
                inputmode="decimal"
                data-testid="bs-c-loan"
                [value]="f.cLoan"
                (input)="patch({ cLoan: val($event) })"
            /></mat-form-field>
          </div>
          <div class="grid2">
            <mat-form-field appearance="outline"
              ><mat-label>Tilgungsende</mat-label
              ><input
                matInput
                type="month"
                data-testid="bs-c-end"
                [value]="f.cEnd"
                (input)="patch({ cEnd: val($event) })"
            /></mat-form-field>
            <mat-form-field appearance="outline"
              ><mat-label>Darlehenszinsen gesamt €</mat-label
              ><input
                matInput
                inputmode="decimal"
                data-testid="bs-c-int"
                [value]="f.cInt"
                (input)="patch({ cInt: val($event) })"
            /></mat-form-field>
          </div>
          @if (error()) {
            <p class="bad" role="alert">{{ error() }}</p>
          }
          <div class="actions">
            <button mat-flat-button type="button" data-testid="bs-save" (click)="save()">
              Speichern
            </button>
            <button mat-button type="button" (click)="cancel()">Abbrechen</button>
            @if (editing() !== 'neu') {
              <button mat-button type="button" class="danger" (click)="remove()">
                Verknüpfung löschen
              </button>
            }
          </div>
        </div>
      }
    </ng-template>
  `,
  styles: [
    `
      .facts {
        display: grid;
        grid-template-columns: auto 1fr;
        gap: 3px 12px;
        font-size: 14px;
        margin: 6px 0 4px;
      }
      .facts dt {
        color: var(--hb-muted);
      }
      .facts dd {
        margin: 0;
        text-align: right;
      }
      .head {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 8px;
        flex-wrap: wrap;
      }
      .bs {
        border-top: 1px solid var(--hb-line);
        padding: 8px 0;
      }
      .row {
        display: flex;
        justify-content: space-between;
        gap: 8px;
      }
      .t {
        font-weight: 650;
      }
      .story {
        margin: 6px 0;
        line-height: 1.45;
      }
      h3 {
        font-size: 15px;
        margin: 10px 0 4px;
      }
      .checks {
        list-style: none;
        margin: 0;
        padding: 0;
        display: grid;
        gap: 6px;
        font-size: 14px;
      }
      .checks li {
        display: grid;
        grid-template-columns: 14px 1fr;
        gap: 8px;
        align-items: start;
      }
      .dot {
        width: 12px;
        height: 12px;
        border-radius: 50%;
        margin-top: 4px;
        background: #9a9a9a;
      }
      .gruen .dot {
        background: #2e8b57;
      }
      .gelb .dot {
        background: #d4a017;
      }
      .rot .dot {
        background: #c0392b;
      }
      .grid2 {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 0 10px;
      }
      .tbl-wrap {
        overflow-x: auto;
      }
      .tbl {
        border-collapse: collapse;
        width: 100%;
        font-size: 13px;
      }
      .tbl th,
      .tbl td {
        padding: 4px 6px;
        border-bottom: 1px solid var(--hb-line);
        text-align: right;
        white-space: nowrap;
      }
      .tbl th:nth-child(-n + 2),
      .tbl td:nth-child(-n + 2) {
        text-align: left;
      }
      .danger {
        color: var(--hb-bad-ink);
      }
    `,
  ],
})
export class BausparSection {
  protected readonly svc = inject(LoansService);
  private readonly accounts = inject(AccountsStore);
  private readonly bookings = inject(BookingsStore);
  private readonly recurring = inject(RecurringStore);
  private readonly fc = inject(ForecastService);
  protected readonly euro = formatEuro;
  protected readonly my = my;
  protected readonly bausparAccounts = computed(() =>
    this.accounts.active().filter((a) => a.type === 'bauspar'),
  );
  protected readonly editing = signal<string | null>(null);
  protected readonly form = signal<Form | null>(null);
  protected readonly error = signal('');
  protected readonly years = signal<string | null>(null);
  protected readonly details = signal<string | null>(null);
  protected readonly Math = Math;

  constructor() {
    // „Mit Bausparvertrag verknüpfen“ aus einem Kredit: Formular öffnen und das Darlehen vorbelegen
    effect(() => {
      const loanId = this.svc.linkRequest();
      if (!loanId) return;
      untracked(() => {
        this.newOne();
        this.patch({ loanId });
        this.svc.linkRequest.set(null);
      });
      setTimeout(() =>
        document
          .querySelector('[data-testid=bs-form]')
          ?.scrollIntoView({ behavior: 'smooth', block: 'start' }),
      );
    });
  }

  protected loanName(id: string | null): string {
    return this.svc.all().find((l) => l.id === id)?.name ?? '–';
  }

  protected pct(milli: number): string {
    return `${percentInput(milli)} %`;
  }

  protected toggleDetails(id: string): void {
    this.details.set(this.details() === id ? null : id);
  }

  protected okCount(v: { p: { checks: { status: string }[] } }): number {
    return v.p.checks.filter((c) => c.status === 'gruen').length;
  }

  /** Vergleich mit den Werten der Bausparkasse (Rechnung in der Fachlogik), hier nur formatiert */
  protected compare(v: { b: Bauspar; p: BausparProjection }) {
    return compareContract(v.b, v.p).map((r) => ({
      label: r.label,
      contract: r.unit === 'euro' ? formatEuro(r.contract as number) : my(r.contract as string),
      app: r.unit === 'euro' ? formatEuro(r.app as number) : my(r.app as string),
      diff:
        r.unit === 'euro'
          ? (r.diff >= 0 ? '+' : '−') + formatEuro(Math.abs(r.diff))
          : r.diff === 0
            ? 'gleich'
            : `${r.diff > 0 ? '+' : '−'}${Math.abs(r.diff)} ${Math.abs(r.diff) === 1 ? 'Monat' : 'Monate'}`,
      ok: r.ok,
    }));
  }

  protected allOk(rows: { ok: boolean }[]): boolean {
    return rows.every((r) => r.ok);
  }

  protected readonly suggestion = computed(() => {
    const f = this.form();
    const v = f ? this.svc.views().find((x) => x.loan.id === f.loanId) : null;
    return v ? suggestType(v.loan, v.state) : null;
  });
  protected readonly detectedRate = computed(() => {
    const f = this.form(),
      g = this.fc.giro();
    if (!f?.accountId || !g) return null;
    return (
      findStandingOrder(
        [...this.fc.refined(), ...this.recurring.suggestions()],
        this.bookings.bookings(),
        g.id,
        f.accountId,
      )?.amount ?? null
    );
  });

  protected setType(v: string): void {
    this.patch({ type: oneOf(v, ['', 'zinsen', 'tilgung'] as const, '') });
  }

  protected setUntil(v: string): void {
    this.patch({ until: oneOf(v, ['ja', 'nein', 'unbekannt'] as const, 'unbekannt') });
  }

  protected val(ev: Event): string {
    return (ev.target as HTMLInputElement).value;
  }

  protected patch(x: Partial<Form>): void {
    const f = this.form();
    if (f) this.form.set({ ...f, ...x });
  }

  protected newOne(): void {
    this.error.set('');
    this.editing.set('neu');
    this.form.set({
      name: '',
      accountId: this.bausparAccounts()[0]?.id ?? '',
      loanId: this.svc.active().find((v) => v.loan.kind === 'voraus')?.loan.id ?? '',
      type: '',
      until: 'unbekannt',
      sum: '',
      savingRate: '',
      savingsP: '0,1',
      minP: '40',
      allocation: '',
      loanP: '',
      loanRate: '',
      cBal: '',
      cLoan: '',
      cEnd: '',
      cInt: '',
    });
  }

  protected edit(b: Bauspar): void {
    this.error.set('');
    this.editing.set(this.editing() === b.id ? null : b.id);
    this.form.set({
      name: b.name,
      accountId: b.accountId,
      loanId: b.loanId ?? '',
      type: b.type ?? '',
      until: b.rateUntilAllocation,
      sum: euroIn(b.sum),
      savingRate: euroIn(b.savingRate),
      savingsP: percentInput(b.savingsMilli),
      minP: percentInput(b.minMilli),
      allocation: b.allocation?.slice(0, 7) ?? '',
      loanP: percentInput(b.loanMilli),
      loanRate: euroIn(b.loanRate),
      cBal: euroIn(b.contract?.balanceAt),
      cLoan: euroIn(b.contract?.bauLoan),
      cEnd: b.contract?.end?.slice(0, 7) ?? '',
      cInt: euroIn(b.contract?.interest),
    });
  }

  protected cancel(): void {
    this.editing.set(null);
    this.form.set(null);
  }

  protected toggleYears(id: string): void {
    this.years.set(this.years() === id ? null : id);
  }

  protected async save(): Promise<void> {
    const f = this.form();
    if (!f) return;
    const old = this.svc.bauspar().find((x) => x.id === this.editing());
    const b: Bauspar = {
      id: old?.id ?? crypto.randomUUID(),
      name: f.name.trim(),
      accountId: f.accountId,
      loanId: f.loanId || null,
      sum: parseEuro(f.sum || '0') ?? 0,
      savingRate: parseEuro(f.savingRate || '') ?? this.detectedRate() ?? 0,
      savingsMilli: parsePercent(f.savingsP) ?? 0,
      minMilli: parsePercent(f.minP) ?? 0,
      allocation: f.allocation ? `${f.allocation}-01` : null,
      loanMilli: parsePercent(f.loanP) ?? 0,
      loanRate: parseEuro(f.loanRate || '') ?? 0,
      type: f.type || null,
      rateUntilAllocation: f.until,
      contract:
        f.cBal || f.cLoan || f.cEnd || f.cInt
          ? {
              balanceAt: parseEuro(f.cBal || '') ?? null,
              bauLoan: parseEuro(f.cLoan || '') ?? null,
              end: f.cEnd ? `${f.cEnd}-01` : null,
              interest: parseEuro(f.cInt || '') ?? null,
            }
          : null,
      order: old?.order ?? this.svc.bauspar().length,
    };
    const err = await this.svc.saveBauspar(b);
    if (err) return this.error.set(err);
    this.cancel();
  }

  protected async remove(): Promise<void> {
    const id = this.editing();
    if (id && id !== 'neu') await this.svc.removeBauspar(id);
    this.cancel();
  }

  protected readonly today = todayLocal();
}
