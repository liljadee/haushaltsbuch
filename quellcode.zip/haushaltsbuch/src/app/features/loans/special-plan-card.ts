import { ChangeDetectionStrategy, Component, computed, inject, signal } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { RouterLink } from '@angular/router';
import { Strategy } from '../../domain/loans/special-plan';
import { formatEuro } from '../../domain/shared/money';
import { LoansService } from '../../data/loans.service';
import { PrefsStore } from '../../data/stores/prefs.store';
import { SelectValue } from '../../shared/select-value';

const MONTHS = [
  'Januar',
  'Februar',
  'März',
  'April',
  'Mai',
  'Juni',
  'Juli',
  'August',
  'September',
  'Oktober',
  'November',
  'Dezember',
];
const my = (d: string | null) =>
  d ? `${MONTHS[Number(d.slice(5, 7)) - 1]} ${d.slice(0, 4)}` : 'nicht absehbar';

/**
 * Sondertilgungsplan (Lastenheft 18.6), schlank: oben das Ergebnis und der nächste Schritt,
 * Reihenfolge, Ablösungen und Jahre hinter „Details“. Annahmen stehen in den Einstellungen → Kredite.
 */
@Component({
  selector: 'app-special-plan-card',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatButtonModule, MatFormFieldModule, MatInputModule, RouterLink, SelectValue],
  template: `
    @if (svc.special(); as sp) {
      <section class="card" data-testid="special-plan">
        <h2>Sondertilgungsplan</h2>
        <p class="lead" data-testid="sp-lead">
          Schuldenfrei im <strong data-testid="sp-free">{{ my(sp.result.debtFree) }}</strong> statt
          <span data-testid="sp-free-without">{{ my(sp.without.debtFree) }}</span>, mit
          <strong data-testid="sp-saving">{{
            euro(sp.without.interest - sp.result.interest - sp.result.fees)
          }}</strong>
          weniger Zinsen.
        </p>
        <p class="small muted" data-testid="sp-budget">
          Budget: {{ euro(svc.specialPool()) }} in der Rücklage, dazu
          {{ euro(svc.specialMonthly()) }} im Monat{{
            sp.forwarding ? ' und weitergeleitete Raten getilgter Kredite' : ''
          }}.
          <a routerLink="/einstellungen" fragment="kredite">Annahmen ändern</a>
        </p>
        @if (!svc.reserveAccounts().length) {
          <p class="warn small">
            Für das Budget fehlt eine Sondertilgungsrücklage: dein Tagesgeld für Sondertilgungen
            unter den Konten öffnen und als Zweck „Sondertilgungsrücklage“ wählen.
          </p>
        }
        @if (sp.result.payments[0]; as n) {
          <p class="hint" data-testid="sp-next">
            Nächster Schritt: im {{ my(n.date) }} {{ euro(n.amount) }} Sondertilgung auf „{{
              sp.names[n.loanId]
            }}“{{ n.fee ? ' (Gebühr ' + euro(n.fee) + ')' : '' }}.
          </p>
        }
        <button mat-button type="button" data-testid="sp-details" (click)="details.set(!details())">
          {{ details() ? 'Details ausblenden' : 'Details' }}
        </button>
        @if (details()) {
          <mat-form-field appearance="outline" class="full">
            <mat-label>Reihenfolge</mat-label>
            <select
              matNativeControl
              data-testid="sp-strategy"
              [appSelectValue]="sp.chosen"
              (change)="setStrategy($event)"
            >
              @for (k of keys; track k) {
                <option [value]="k">
                  {{ sp.labels[k] }}{{ k === sp.best ? ' (empfohlen)' : '' }}: schuldenfrei
                  {{ my(sp.results[k].debtFree) }}
                </option>
              }
            </select>
          </mat-form-field>
          @for (r of sp.result.replacements; track r.loanId) {
            <p class="small" data-testid="sp-replacement">
              {{ sp.names[r.loanId] }}: Ablösung durch den Bausparvertrag im {{ my(r.date) }};
              danach Bauspardarlehen über {{ euro(r.bauLoan)
              }}{{
                r.gap
                  ? ' und eine Anschlussfinanzierung über ' +
                    euro(r.gap) +
                    ' (Annahme: ' +
                    pct(prefs.specialPlan().gapMilli) +
                    ' Zins, ' +
                    pct(prefs.specialPlan().gapTilgungMilli) +
                    ' Tilgung)'
                  : ''
              }}.
            </p>
          }
          @if (years().length) {
            <div class="tbl-wrap">
              <table class="tbl" data-testid="sp-table">
                <thead>
                  <tr>
                    <th>Jahr</th>
                    @for (id of loanIds(); track id) {
                      <th>{{ sp.names[id] }}</th>
                    }
                    <th>Summe</th>
                  </tr>
                </thead>
                <tbody>
                  @for (y of years(); track y.year) {
                    <tr>
                      <td>{{ y.year }}</td>
                      @for (id of loanIds(); track id) {
                        <td class="num">{{ y.by[id] ? euro(y.by[id]) : '' }}</td>
                      }
                      <td class="num">{{ euro(y.sum) }}</td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          }
          @for (id of fixedIds(); track id) {
            <p class="small">
              {{ sp.names[id] }}: Restschuld zum Zinsbindungsende
              {{ euro(sp.result.atFixedEnd[id] ?? 0) }} statt
              {{ euro(sp.without.atFixedEnd[id] ?? 0) }}.
            </p>
          }
          @if (
            !sp.forwarding &&
            sp.freed.debtFree &&
            sp.result.debtFree &&
            sp.freed.debtFree < sp.result.debtFree
          ) {
            <p class="small" data-testid="sp-tip">
              Tipp: Leitest du die Raten getilgter Kredite in die Rücklage weiter, wärst du schon im
              {{ my(sp.freed.debtFree) }} schuldenfrei. Einstellbar je Kredit unter „Bearbeiten“.
            </p>
          }
          <p class="small muted">
            Rein rechnerisch nach euren Sondertilgungsrechten, ohne Gewähr; keine
            Finanzierungsberatung.
          </p>
        }
      </section>
    }
  `,
  styles: [
    `
      .lead {
        font-size: 16px;
        line-height: 1.45;
        margin: 0 0 6px;
      }
      .full {
        width: 100%;
      }
      .tbl-wrap {
        overflow-x: auto;
        margin: 8px 0;
      }
      .tbl {
        border-collapse: collapse;
        width: 100%;
        font-size: 13px;
      }
      .tbl th,
      .tbl td {
        padding: 4px 6px;
        border-bottom: 1px solid var(--hb-line);
        text-align: right;
        white-space: nowrap;
      }
      .tbl th:first-child,
      .tbl td:first-child {
        text-align: left;
      }
    `,
  ],
})
export class SpecialPlanCard {
  protected readonly svc = inject(LoansService);
  protected readonly prefs = inject(PrefsStore);
  protected readonly euro = formatEuro;
  protected readonly my = my;
  protected readonly keys: Strategy[] = ['zinsbindung', 'zins', 'restschuld'];
  protected readonly details = signal(false);
  protected readonly loanIds = computed(() => [
    ...new Set((this.svc.special()?.result.payments ?? []).map((p) => p.loanId)),
  ]);
  protected readonly fixedIds = computed(() =>
    this.svc
      .active()
      .filter(
        (v) =>
          v.loan.fixedUntil &&
          this.svc.special()?.result.atFixedEnd[v.loan.id] != null &&
          this.loanIds().includes(v.loan.id),
      )
      .map((v) => v.loan.id),
  );
  protected readonly years = computed(() => {
    const out = new Map<string, { year: string; by: Record<string, number>; sum: number }>();
    for (const p of this.svc.special()?.result.payments ?? []) {
      const y = p.date.slice(0, 4);
      const row = out.get(y) ?? { year: y, by: {}, sum: 0 };
      row.by[p.loanId] = (row.by[p.loanId] ?? 0) + p.amount;
      row.sum += p.amount;
      out.set(y, row);
    }
    return [...out.values()];
  });

  protected pct(milli: number): string {
    return `${(milli / 1000).toLocaleString('de-DE')} %`;
  }

  protected async setStrategy(ev: Event): Promise<void> {
    const v = (ev.target as HTMLSelectElement).value as Strategy;
    await this.prefs.setSpecialPlan({ strategy: v === this.svc.special()?.best ? null : v });
  }
}
