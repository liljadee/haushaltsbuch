import { ChangeDetectionStrategy, Component, computed, inject } from '@angular/core';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { Strategy } from '../../domain/loans/special-plan';
import { formatEuro, parseEuro } from '../../domain/shared/money';
import { LoansService } from '../../data/loans.service';
import { PrefsStore } from '../../data/stores/prefs.store';
import { SelectValue } from '../../shared/select-value';

const MONTHS = [
  'Januar',
  'Februar',
  'März',
  'April',
  'Mai',
  'Juni',
  'Juli',
  'August',
  'September',
  'Oktober',
  'November',
  'Dezember',
];
const my = (d: string | null) =>
  d ? `${MONTHS[Number(d.slice(5, 7)) - 1]} ${d.slice(0, 4)}` : 'nicht absehbar';
const euroIn = (c: number) =>
  (c / 100).toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/** Sondertilgungsplan (Lastenheft 18.6): Budget, Reihenfolge, Ergebnis, nächster Schritt, Jahre, Tipp. */
@Component({
  selector: 'app-special-plan-card',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatFormFieldModule, MatInputModule, SelectValue],
  template: `
    @if (svc.special(); as sp) {
      <section class="card" data-testid="special-plan">
        <h2>Sondertilgungsplan</h2>
        @if (!svc.reserveAccounts().length) {
          <p class="warn small">
            Für das Budget fehlt eine Sondertilgungsrücklage. Öffne dein Tagesgeld für
            Sondertilgungen unter den Konten und wähle als Zweck „Sondertilgungsrücklage“.
          </p>
        }
        <dl class="kv">
          <dt>Rücklage verfügbar (ohne Notreserve)</dt>
          <dd class="num" data-testid="sp-pool">{{ euro(svc.specialPool()) }}</dd>
        </dl>
        <div class="grid2">
          <mat-form-field appearance="outline">
            <mat-label>Monatlich in die Rücklage €</mat-label>
            <input
              matInput
              inputmode="decimal"
              data-testid="sp-monthly"
              [value]="monthlyIn()"
              (change)="setMonthly($event)"
            />
          </mat-form-field>
          <mat-form-field appearance="outline">
            <mat-label>Reihenfolge</mat-label>
            <select
              matNativeControl
              data-testid="sp-strategy"
              [appSelectValue]="sp.chosen"
              (change)="setStrategy($event)"
            >
              @for (k of keys; track k) {
                <option [value]="k">
                  {{ sp.labels[k] }}{{ k === sp.best ? ' (empfohlen)' : '' }}:
                  {{ my(sp.results[k].debtFree) }}
                </option>
              }
            </select>
          </mat-form-field>
        </div>
        <p class="small muted">
          {{
            prefs.specialPlan().monthly === null
              ? svc.detectedMonthly().amount
                ? 'Erkannt aus Dauerauftrag bzw. den Eingängen der letzten 12 Monate.'
                : 'Kein regelmäßiger Eingang erkannt; trag den Betrag ein, den du monatlich zurücklegst.'
              : 'Von dir eingetragen; leer lassen für den erkannten Wert.'
          }}
        </p>

        <dl class="kv big">
          <dt>Schuldenfrei mit Sondertilgungen</dt>
          <dd data-testid="sp-free">{{ my(sp.result.debtFree) }}</dd>
          <dt>ohne Sondertilgungen</dt>
          <dd data-testid="sp-free-without">{{ my(sp.without.debtFree) }}</dd>
          <dt>Zinsersparnis</dt>
          <dd class="num" data-testid="sp-saving">
            {{ euro(sp.without.interest - sp.result.interest - sp.result.fees) }}
          </dd>
        </dl>
        @if (sp.result.payments[0]; as n) {
          <p class="hint" data-testid="sp-next">
            Nächster Schritt: Im {{ my(n.date) }} {{ euro(n.amount) }} Sondertilgung auf „{{
              sp.names[n.loanId]
            }}“ aus der Sondertilgungsrücklage{{ n.fee ? ' (Gebühr ' + euro(n.fee) + ')' : '' }}.
          </p>
        } @else {
          <p class="small muted">
            Mit diesem Budget ist keine Sondertilgung möglich (Mindestbetrag oder
            Sondertilgungsrecht).
          </p>
        }
        @if (sp.freed.debtFree && sp.result.debtFree && sp.freed.debtFree < sp.result.debtFree) {
          <p class="small" data-testid="sp-tip">
            Tipp: Leitest du die Rate eines getilgten Kredits per Dauerauftrag in die Rücklage,
            wärst du schon im {{ my(sp.freed.debtFree) }} schuldenfrei.
          </p>
        }
        @if (years().length) {
          <div class="tbl-wrap">
            <table class="tbl" data-testid="sp-table">
              <thead>
                <tr>
                  <th>Jahr</th>
                  @for (id of loanIds(); track id) {
                    <th>{{ sp.names[id] }}</th>
                  }
                  <th>Summe</th>
                </tr>
              </thead>
              <tbody>
                @for (y of years(); track y.year) {
                  <tr>
                    <td>{{ y.year }}</td>
                    @for (id of loanIds(); track id) {
                      <td class="num">{{ y.by[id] ? euro(y.by[id]) : '' }}</td>
                    }
                    <td class="num">{{ euro(y.sum) }}</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        }
        @for (id of fixedIds(); track id) {
          <p class="small">
            {{ sp.names[id] }}: Restschuld zum Zinsbindungsende
            {{ euro(sp.result.atFixedEnd[id] ?? 0) }} statt
            {{ euro(sp.without.atFixedEnd[id] ?? 0) }}.
          </p>
        }
        <p class="small muted">
          Rein rechnerisch nach euren Sondertilgungsrechten, ohne Gewähr; keine Anlage- oder
          Finanzierungsberatung. Vom Bausparvertrag abgelöste Darlehen sind nicht Teil des Plans.
        </p>
      </section>
    }
  `,
  styles: [
    `
      .kv {
        display: grid;
        grid-template-columns: 1fr auto;
        gap: 4px 12px;
        margin: 0 0 8px;
        font-size: 14px;
      }
      .kv dt {
        color: var(--hb-muted);
      }
      .kv dd {
        margin: 0;
        text-align: right;
        font-weight: 600;
      }
      .kv.big dd {
        font-size: 15px;
      }
      .grid2 {
        display: grid;
        grid-template-columns: 1fr 1.4fr;
        gap: 0 10px;
      }
      .tbl-wrap {
        overflow-x: auto;
        margin: 8px 0;
      }
      .tbl {
        border-collapse: collapse;
        width: 100%;
        font-size: 13px;
      }
      .tbl th,
      .tbl td {
        padding: 4px 6px;
        border-bottom: 1px solid var(--hb-line);
        text-align: right;
        white-space: nowrap;
      }
      .tbl th:first-child,
      .tbl td:first-child {
        text-align: left;
      }
    `,
  ],
})
export class SpecialPlanCard {
  protected readonly svc = inject(LoansService);
  protected readonly prefs = inject(PrefsStore);
  protected readonly euro = formatEuro;
  protected readonly my = my;
  protected readonly keys: Strategy[] = ['zinsbindung', 'zins', 'restschuld'];
  protected readonly monthlyIn = computed(() => euroIn(this.svc.specialMonthly()));
  protected readonly loanIds = computed(() => [
    ...new Set((this.svc.special()?.result.payments ?? []).map((p) => p.loanId)),
  ]);
  protected readonly fixedIds = computed(() =>
    this.svc
      .active()
      .filter(
        (v) =>
          v.loan.fixedUntil &&
          this.svc.special()?.result.atFixedEnd[v.loan.id] != null &&
          this.loanIds().includes(v.loan.id),
      )
      .map((v) => v.loan.id),
  );
  protected readonly years = computed(() => {
    const out = new Map<string, { year: string; by: Record<string, number>; sum: number }>();
    for (const p of this.svc.special()?.result.payments ?? []) {
      const y = p.date.slice(0, 4);
      const row = out.get(y) ?? { year: y, by: {}, sum: 0 };
      row.by[p.loanId] = (row.by[p.loanId] ?? 0) + p.amount;
      row.sum += p.amount;
      out.set(y, row);
    }
    return [...out.values()];
  });

  protected async setMonthly(ev: Event): Promise<void> {
    const v = (ev.target as HTMLInputElement).value.trim();
    await this.prefs.setSpecialPlan({ monthly: v ? (parseEuro(v) ?? null) : null });
  }

  protected async setStrategy(ev: Event): Promise<void> {
    const v = (ev.target as HTMLSelectElement).value as Strategy;
    await this.prefs.setSpecialPlan({ strategy: v === this.svc.special()?.best ? null : v });
  }
}
