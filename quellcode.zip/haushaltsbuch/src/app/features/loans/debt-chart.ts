import { ChangeDetectionStrategy, Component, computed, input } from '@angular/core';

interface Point {
  year: number;
  balance: number;
}

const W = 320,
  H = 150,
  LEFT = 50,
  RIGHT = 8,
  TOP = 10,
  BOTTOM = 24;
const compact = (cents: number) => {
  const euro = cents / 100;
  return euro >= 1000
    ? `${Math.round(euro / 1000).toLocaleString('de-DE')} T€`
    : `${Math.round(euro).toLocaleString('de-DE')} €`;
};

/**
 * Schuldendiagramm: Restschuld zum Jahresende, durchgezogen ohne und gestrichelt mit Sondertilgungsplan.
 * Jahreszahlen alle 2, 5 oder 10 Jahre (je nach Zeitraum), Beträge bei 0, der Hälfte und dem Höchststand (in Tausend Euro, „T€“).
 */
@Component({
  selector: 'app-debt-chart',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    @if (geo(); as g) {
      <svg
        class="chart"
        [attr.viewBox]="'0 0 ' + w + ' ' + h"
        role="img"
        [attr.aria-label]="label()"
      >
        @for (t of g.yTicks; track t.y) {
          <line
            [attr.x1]="left"
            [attr.x2]="w - right"
            [attr.y1]="t.y"
            [attr.y2]="t.y"
            class="grid"
          />
          <text [attr.x]="left - 4" [attr.y]="t.y + 3" text-anchor="end" class="lbl">
            {{ t.text }}
          </text>
        }
        @for (t of g.xTicks; track t.year) {
          <line
            [attr.x1]="t.x"
            [attr.x2]="t.x"
            [attr.y1]="h - bottom"
            [attr.y2]="h - bottom + 4"
            class="axis"
          />
          <text [attr.x]="t.x" [attr.y]="h - 6" text-anchor="middle" class="lbl">{{ t.year }}</text>
        }
        <path [attr.d]="g.base" class="line" />
        @if (g.with) {
          <path [attr.d]="g.with" class="line with" />
        }
      </svg>
    }
  `,
  styles: [
    `
      .chart {
        width: 100%;
        height: auto;
        display: block;
      }
      .grid {
        stroke: var(--hb-line);
        stroke-width: 1;
      }
      .axis {
        stroke: var(--hb-muted);
        stroke-width: 1;
      }
      .lbl {
        font-size: 9.5px;
        fill: var(--hb-muted);
      }
      .line {
        fill: none;
        stroke: var(--hb-primary);
        stroke-width: 2.5;
      }
      .line.with {
        stroke-dasharray: 5 4;
        stroke: var(--hb-primary-ink);
        opacity: 0.85;
      }
    `,
  ],
})
export class DebtChart {
  readonly points = input.required<Point[]>();
  readonly pointsWith = input<Point[] | null>(null);
  readonly label = input('Restschuld über die Jahre');
  protected readonly w = W;
  protected readonly h = H;
  protected readonly left = LEFT;
  protected readonly right = RIGHT;
  protected readonly bottom = BOTTOM;

  protected readonly geo = computed(() => {
    const pts = trimTail(this.points()),
      withPts = this.pointsWith() ? trimTail(this.pointsWith()!) : null;
    if (pts.length < 2) return null;
    const first = pts[0].year,
      last = Math.max(pts.at(-1)!.year, withPts?.at(-1)?.year ?? first);
    const span = Math.max(1, last - first);
    const max = Math.max(1, ...pts.map((p) => p.balance), ...(withPts ?? []).map((p) => p.balance));
    const x = (year: number) => LEFT + ((year - first) / span) * (W - LEFT - RIGHT);
    const y = (v: number) => TOP + (1 - v / max) * (H - TOP - BOTTOM);
    const path = (l: Point[]) =>
      l
        .map((p, i) => `${i ? 'L' : 'M'}${x(p.year).toFixed(1)},${y(p.balance).toFixed(1)}`)
        .join(' ');
    const step = span <= 8 ? 2 : span <= 25 ? 5 : 10;
    const xTicks: { year: number; x: number }[] = [];
    for (let yr = Math.ceil(first / step) * step; yr <= last; yr += step)
      xTicks.push({ year: yr, x: x(yr) });
    if (!xTicks.length || xTicks[0].year - first >= step / 2)
      xTicks.unshift({ year: first, x: x(first) });
    return {
      base: path(pts),
      with: withPts && withPts.length > 1 ? path(withPts) : null,
      xTicks,
      yTicks: [0, max / 2, max].map((v) => ({ y: y(v), text: compact(v) })),
    };
  });
}

/** Nach der Tilgung nur ein Punkt mit 0 €, damit das Diagramm nicht in einer langen Nulllinie endet */
function trimTail(points: Point[]): Point[] {
  const firstZero = points.findIndex((p) => p.balance <= 0);
  return firstZero >= 0 ? points.slice(0, firstZero + 1) : points;
}
