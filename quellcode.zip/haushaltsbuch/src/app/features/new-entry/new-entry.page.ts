import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { Router, RouterLink } from '@angular/router';
import { formatEuro, parseEuro } from '../../domain/shared/money';
import { TestDataStore } from '../../data/stores/testdata.store';

const today = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};

/** Ziel des Schnellzugriffs „Neue Buchung“ (Bauplan 7). In v0.1 eine einfache Testbuchung. */
@Component({
  selector: 'app-new-entry-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatButtonModule, MatButtonToggleModule, MatFormFieldModule, MatInputModule, RouterLink],
  template: `
    <div class="page">
      <h1>Neue Buchung</h1>
      <p class="muted small">
        Testbuchung für Version 0.1. Wenn du hier über den Schnellzugriff gelandet bist: Der
        Schnellzugriff funktioniert.
      </p>
      <div class="card">
        <mat-button-toggle-group
          class="kind"
          [value]="kind()"
          (change)="kind.set($event.value)"
          aria-label="Art"
        >
          <mat-button-toggle value="aus">Ausgabe</mat-button-toggle>
          <mat-button-toggle value="ein">Einnahme</mat-button-toggle>
        </mat-button-toggle-group>
        <mat-form-field appearance="outline">
          <mat-label>Betrag in €</mat-label>
          <input
            matInput
            data-testid="amount"
            inputmode="decimal"
            autocomplete="off"
            placeholder="z. B. 12,50"
            [value]="amount"
            (input)="amount = val($event)"
          />
        </mat-form-field>
        <mat-form-field appearance="outline">
          <mat-label>Text</mat-label>
          <input
            matInput
            data-testid="text"
            autocomplete="off"
            placeholder="z. B. Bäckerei"
            [value]="text"
            (input)="text = val($event)"
          />
        </mat-form-field>
        <mat-form-field appearance="outline">
          <mat-label>Datum</mat-label>
          <input
            matInput
            type="date"
            data-testid="date"
            [value]="date"
            (input)="date = val($event)"
          />
        </mat-form-field>
        @if (error()) {
          <p class="bad" role="alert">{{ error() }}</p>
        }
        @if (saved()) {
          <p class="hint" role="status">{{ saved() }}</p>
        }
        <div class="actions">
          <button mat-flat-button type="button" data-testid="save" (click)="save(false)">
            Speichern
          </button>
          <button mat-stroked-button type="button" (click)="save(true)">
            Speichern und weitere
          </button>
          <a mat-button routerLink="/start">Abbrechen</a>
        </div>
      </div>
    </div>
  `,
  styles: ['.kind { margin: 0 0 16px; }'],
})
export class NewEntryPage {
  private readonly store = inject(TestDataStore);
  private readonly router = inject(Router);
  protected readonly kind = signal<'aus' | 'ein'>('aus');
  protected readonly error = signal('');
  protected readonly saved = signal('');
  protected amount = '';
  protected text = '';
  protected date = today();

  protected val(ev: Event): string {
    return (ev.target as HTMLInputElement).value;
  }

  protected async save(more: boolean): Promise<void> {
    this.error.set('');
    const c = parseEuro(this.amount);
    if (c === null || c === 0) return this.error.set('Bitte einen Betrag wie 12,50 eingeben.');
    if (!this.text.trim()) return this.error.set('Bitte einen kurzen Text eingeben.');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(this.date)) return this.error.set('Bitte ein Datum wählen.');
    const amount = this.kind() === 'aus' ? -Math.abs(c) : Math.abs(c);
    await this.store.add({ amount, text: this.text.trim(), date: this.date });
    if (more) {
      this.saved.set(`Gespeichert: ${this.text.trim()} ${formatEuro(amount)}`);
      this.amount = '';
      this.text = '';
    } else {
      void this.router.navigateByUrl('/start');
    }
  }
}
