import { MatButtonToggle, MatButtonToggleGroup } from '@angular/material/button-toggle';
import { MatAnchor } from '@angular/material/button';
import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AccountsStore } from '../../data/stores/accounts.store';
import { BookingEditor } from '../bookings/booking-editor';
import { EmailImport } from '../import/email-import';
import { TransferEditor } from '../bookings/transfer-editor';

/** Neue Buchung (Lastenheft 8.4); Ziel des Schnellzugriffs. Nach dem Speichern geht es zur Übersicht. */
@Component({
  selector: 'app-new-entry-page',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    RouterLink,
    BookingEditor,
    EmailImport,
    TransferEditor,
    MatAnchor,
    MatButtonToggleGroup,
    MatButtonToggle,
  ],
  template: `
    <div class="page">
      <h1>Neue Buchung</h1>
      @if (accounts.active().length) {
        <mat-button-toggle-group
          class="src"
          [value]="mode()"
          (change)="setMode($event.value)"
          aria-label="Erfassungsweg"
        >
          <mat-button-toggle value="manuell" data-testid="tab-manuell">Manuell</mat-button-toggle>
          <mat-button-toggle value="email" data-testid="tab-email">Aus E-Mail</mat-button-toggle>
          @if (accounts.active().length > 1) {
            <mat-button-toggle value="umbuchung" data-testid="tab-umbuchung"
              >Umbuchung</mat-button-toggle
            >
          }
        </mat-button-toggle-group>
        <div class="card">
          @if (mode() === 'manuell') {
            <app-booking-editor (done)="back($event)" />
          } @else if (mode() === 'email') {
            <app-email-import (done)="back($event)" />
          } @else {
            <app-transfer-editor (done)="back($event)" />
          }
        </div>
      } @else {
        <div class="card">
          <p>Lege zuerst ein Konto an, zum Beispiel dein Girokonto mit dem heutigen Kontostand.</p>
          <a mat-flat-button routerLink="/start">Zur Übersicht</a>
        </div>
      }
    </div>
  `,
  styles: ['.src { margin: 0 0 12px; }'],
})
export class NewEntryPage {
  protected readonly mode = signal<'manuell' | 'email' | 'umbuchung'>('manuell');

  protected setMode(value: string): void {
    this.mode.set(value === 'email' || value === 'umbuchung' ? value : 'manuell');
  }
  protected readonly accounts = inject(AccountsStore);
  private readonly router = inject(Router);

  protected back(msg: string): void {
    void this.router.navigate(['/start'], msg ? { state: { msg } } : {});
  }
}
