import { Directive, ElementRef, afterRenderEffect, inject, input } from '@angular/core';

/**
 * Setzt den Wert eines nativen Auswahlfelds erst, nachdem seine Optionen gerendert sind.
 * Eine direkte [value]-Bindung greift zu früh: Der Browser springt dann auf die erste Option.
 */
@Directive({ selector: 'select[appSelectValue]' })
export class SelectValue {
  readonly appSelectValue = input<string | null | undefined>(null);
  private readonly el = inject<ElementRef<HTMLSelectElement>>(ElementRef);

  constructor() {
    afterRenderEffect(() => {
      this.el.nativeElement.value = this.appSelectValue() ?? '';
    });
  }
}
