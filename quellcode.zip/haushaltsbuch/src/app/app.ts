import { BackupService } from './data/backup.service';
import { MirrorService } from './data/mirror.service';
import { TourOverlay } from './features/onboarding/tour';
import { Welcome } from './features/onboarding/welcome';
import { MatButton, MatIconAnchor, MatIconButton } from '@angular/material/button';
import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { NavigationEnd, Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { LockService } from './data/session/lock.service';
import { UpdateService } from './data/session/update.service';
import { APP_VERSION, VaultService } from './data/vault.service';
import { Icon } from './shared/icon';

@Component({
  selector: 'app-root',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    Welcome,
    TourOverlay,
    RouterOutlet,
    RouterLink,
    RouterLinkActive,
    Icon,
    MatButton,
    MatIconButton,
    MatIconAnchor,
  ],
  template: `
    @if (vault.status() === 'entsperrt') {
      <app-welcome />
      <app-tour />
    }
    @if (vault.status() === 'entsperrt') {
      <header class="bar">
        <a class="brand" routerLink="/start">Haushaltsbuch</a>
        <span class="ver">v{{ version }}</span>
        <a
          mat-icon-button
          routerLink="/einstellungen"
          aria-label="Einstellungen"
          data-testid="nav-settings"
          ><app-icon name="settings"
        /></a>
        <button
          mat-icon-button
          type="button"
          (click)="lock.lockNow('/start')"
          aria-label="Jetzt sperren"
          data-testid="lock-now"
        >
          <app-icon name="lock" />
        </button>
      </header>
    }
    @if (updates.ready()) {
      <div class="update" role="status">
        Neue Version verfügbar.
        <button mat-flat-button type="button" data-testid="upd-now" (click)="updateNow()">
          Jetzt aktualisieren
        </button>
        @if (preUpdate()) {
          <p class="small" data-testid="upd-ask">
            Vor dem Update sicherst du am besten deine Daten. Mit eingerichteter Sicherungsdatei
            geschieht das automatisch.
          </p>
          <button
            mat-flat-button
            type="button"
            data-testid="upd-backup"
            (click)="backupThenUpdate()"
          >
            Backup sichern und aktualisieren
          </button>
          <button mat-button type="button" data-testid="upd-skip" (click)="updates.apply()">
            Ohne Backup aktualisieren
          </button>
        }
      </div>
    }
    <main><router-outlet /></main>
    @if (vault.status() === 'entsperrt') {
      @if (url() !== '/neu') {
        <a class="fab" routerLink="/neu" aria-label="Neue Buchung" data-testid="fab"
          ><app-icon name="plus" [size]="28"
        /></a>
      }
      <nav class="nav" aria-label="Hauptbereiche">
        <a routerLink="/start" routerLinkActive="on">Übersicht</a>
        <a routerLink="/buchungen" routerLinkActive="on" data-testid="nav-buchungen">Buchungen</a>
        <a routerLink="/ruecklagen" routerLinkActive="on" data-testid="nav-ruecklagen">Rücklagen</a>
        <a routerLink="/kredite" routerLinkActive="on" data-testid="nav-kredite">Kredite</a>
        <a routerLink="/statistik" routerLinkActive="on" data-testid="nav-statistik">Statistik</a>
      </nav>
    }
  `,
  styles: [
    `
      .bar {
        position: sticky;
        top: 0;
        z-index: 5;
        display: flex;
        align-items: center;
        gap: 4px;
        padding: calc(env(safe-area-inset-top, 0px) + 6px) 8px 6px 16px;
        background: var(--hb-bg);
        border-bottom: 1px solid var(--hb-line);
      }
      .brand {
        font-weight: 700;
        font-size: 18px;
        color: var(--hb-ink);
        text-decoration: none;
      }
      .ver {
        flex: 1;
        color: var(--hb-muted);
        font-size: 13px;
        margin-left: 6px;
      }
      .nav {
        position: fixed;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 5;
        display: grid;
        grid-template-columns: repeat(5, 1fr);
        background: var(--hb-surface);
        border-top: 1px solid var(--hb-line);
        padding-bottom: env(safe-area-inset-bottom, 0px);
      }
      .nav a {
        text-align: center;
        padding: 14px 2px;
        font-size: 13px;
        color: var(--hb-muted);
        text-decoration: none;
        font-weight: 600;
      }
      .nav a.on {
        color: var(--hb-primary);
        box-shadow: inset 0 3px 0 var(--hb-primary);
      }
      .fab {
        position: fixed;
        right: 18px;
        bottom: calc(68px + env(safe-area-inset-bottom, 0px));
        z-index: 6;
        width: 58px;
        height: 58px;
        border-radius: 18px;
        display: grid;
        place-items: center;
        background: var(--hb-primary);
        color: var(--hb-on-primary);
        box-shadow: 0 4px 12px rgb(0 0 0 / 0.25);
      }
      .update {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        flex-wrap: wrap;
        background: var(--hb-primary-soft);
        color: var(--hb-primary-ink);
        padding: 8px 16px;
      }
    `,
  ],
})
export class App {
  protected readonly vault = inject(VaultService);
  protected readonly lock = inject(LockService);
  protected readonly updates = inject(UpdateService);
  protected readonly version = APP_VERSION.replace(/\.0$/, '');

  private readonly router = inject(Router);
  protected readonly url = signal('');

  /** Backup vor dem Update (Lastenheft 6): Sicherungsdatei automatisch, sonst Backup-Datei auf Nachfrage */
  protected readonly preUpdate = signal(false);
  private readonly mirrorUpd = inject(MirrorService);
  private readonly backupUpd = inject(BackupService);

  protected async updateNow(): Promise<void> {
    if (this.vault.status() === 'entsperrt') {
      const saved = this.mirrorUpd.state() === 'verbunden' && (await this.mirrorUpd.writeNow());
      if (!saved) return this.preUpdate.set(true);
    }
    this.updates.apply();
  }

  protected async backupThenUpdate(): Promise<void> {
    const r = await this.backupUpd.run('canShare' in navigator ? 'share' : 'download');
    if (r.ok) this.updates.apply();
  }

  constructor() {
    this.router.events.subscribe((e) => {
      if (e instanceof NavigationEnd) this.url.set(e.urlAfterRedirects.split('?')[0]);
    });
    this.lock.start();
    void this.updates.start();
  }
}
