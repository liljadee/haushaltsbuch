import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { RouterLink, RouterOutlet } from '@angular/router';
import { LockService } from './data/session/lock.service';
import { UpdateService } from './data/session/update.service';
import { VaultService } from './data/vault.service';
import { Icon } from './shared/icon';

@Component({
  selector: 'app-root',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [RouterOutlet, RouterLink, MatButtonModule, Icon],
  template: `
    @if (vault.status() === 'entsperrt') {
      <header class="bar">
        <a class="brand" routerLink="/start">Haushaltsbuch</a>
        <span class="ver">v0.1</span>
        <a mat-icon-button routerLink="/einstellungen" aria-label="Einstellungen"
          ><app-icon name="settings"
        /></a>
        <button
          mat-icon-button
          type="button"
          (click)="lock.lockNow('/start')"
          aria-label="Jetzt sperren"
        >
          <app-icon name="lock" />
        </button>
      </header>
    }
    @if (updates.ready()) {
      <div class="update" role="status">
        Neue Version verfügbar.
        <button mat-flat-button type="button" (click)="updates.apply()">Jetzt aktualisieren</button>
      </div>
    }
    <main><router-outlet /></main>
  `,
  styles: [
    `
      .bar {
        position: sticky;
        top: 0;
        z-index: 5;
        display: flex;
        align-items: center;
        gap: 4px;
        padding: calc(env(safe-area-inset-top, 0px) + 6px) 8px 6px 16px;
        background: var(--hb-bg);
        border-bottom: 1px solid var(--hb-line);
      }
      .brand {
        font-weight: 700;
        font-size: 18px;
        color: var(--hb-ink);
        text-decoration: none;
      }
      .ver {
        flex: 1;
        color: var(--hb-muted);
        font-size: 13px;
        margin-left: 6px;
      }
      .update {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        flex-wrap: wrap;
        background: var(--hb-primary-soft);
        color: var(--hb-primary-ink);
        padding: 8px 16px;
      }
    `,
  ],
})
export class App {
  protected readonly vault = inject(VaultService);
  protected readonly lock = inject(LockService);
  protected readonly updates = inject(UpdateService);

  constructor() {
    this.lock.start();
    void this.updates.start();
  }
}
