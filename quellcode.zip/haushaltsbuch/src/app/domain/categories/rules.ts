import { Cents } from '../shared/money';
import { Category } from './categories';

/**
 * Regeln (Lastenheft 9.4): Muster im Buchungstext → Kategorie, ohne KI. Jede bestätigte Zuordnung
 * wird zur Regel „beginnt mit“. Bekommt derselbe Text verschiedene Kategorien, unterscheidet die App
 * zusätzlich nach dem Betrag (± 10 %), etwa bei der Gemeinde: Wasser 160,24 €, Grundsteuer 120,00 €.
 * Der spezifischste Treffer gewinnt; bei Gleichstand entscheidet der Vorrang der Kategorie.
 */
export type MatchType = 'genau' | 'beginnt_mit' | 'enthaelt';

export interface Rule {
  id: string;
  pattern: string;
  matchType: MatchType;
  accountId: string | null;
  /** Betrag der Buchung, aus der die Regel gelernt wurde */
  amount: Cents;
  /** Betrag als Bedingung nutzen (± 10 %) */
  useAmount: boolean;
  categoryId: string;
  subCategory: string | null;
  hits: number;
}

export interface Suggestion {
  categoryId: string | null;
  subCategory: string | null;
  confidence: 'sicher' | 'unsicher' | 'nicht_zugeordnet';
  ruleId: string | null;
}

export function normalizeText(s: string): string {
  return s.toUpperCase().replace(/\s+/g, ' ').trim();
}

const near = (a: Cents, b: Cents) =>
  Math.sign(a) === Math.sign(b) && Math.abs(a - b) <= Math.abs(b) * 0.1;

function matches(r: Rule, text: string, amount: Cents, accountId: string | null): boolean {
  if (r.accountId && r.accountId !== accountId) return false;
  if (r.useAmount && !near(amount, r.amount)) return false;
  if (Math.sign(amount) !== Math.sign(r.amount)) return false;
  if (r.matchType === 'genau') return text === r.pattern;
  if (r.matchType === 'beginnt_mit') return text.startsWith(r.pattern);
  return text.includes(r.pattern);
}

function specificity(r: Rule): number {
  return (
    (r.useAmount ? 100 : 0) +
    { genau: 30, beginnt_mit: 20, enthaelt: 10 }[r.matchType] +
    (r.accountId ? 5 : 0)
  );
}

export function suggest(
  rawText: string,
  amount: Cents,
  accountId: string | null,
  rules: Rule[],
  cats: Category[],
): Suggestion {
  const text = normalizeText(rawText);
  const hits = rules.filter((r) => matches(r, text, amount, accountId));
  if (!hits.length)
    return { categoryId: null, subCategory: null, confidence: 'nicht_zugeordnet', ruleId: null };
  const best = Math.max(...hits.map(specificity));
  const top = hits
    .filter((r) => specificity(r) === best)
    .sort((a, b) => b.pattern.length - a.pattern.length || b.hits - a.hits);
  const targets = new Set(top.map((r) => `${r.categoryId}|${r.subCategory ?? ''}`));
  if (targets.size === 1)
    return {
      categoryId: top[0].categoryId,
      subCategory: top[0].subCategory,
      confidence: 'sicher',
      ruleId: top[0].id,
    };
  const prio = top.filter((r) => cats.find((c) => c.id === r.categoryId)?.priority === 'vorrang');
  const prioTargets = new Set(prio.map((r) => `${r.categoryId}|${r.subCategory ?? ''}`));
  if (prioTargets.size === 1)
    return {
      categoryId: prio[0].categoryId,
      subCategory: prio[0].subCategory,
      confidence: 'sicher',
      ruleId: prio[0].id,
    };
  return {
    categoryId: top[0].categoryId,
    subCategory: top[0].subCategory,
    confidence: 'unsicher',
    ruleId: top[0].id,
  };
}

/**
 * Lernt aus einer bestätigten Zuordnung und liefert die geänderten oder neuen Regeln.
 * newId erzeugt IDs (im Browser crypto.randomUUID).
 */
export function learn(
  rawText: string,
  amount: Cents,
  categoryId: string,
  subCategory: string | null,
  rules: Rule[],
  newId: () => string,
): Rule[] {
  const pattern = normalizeText(rawText);
  if (!pattern) return [];
  const same = rules.filter(
    (r) =>
      r.matchType === 'beginnt_mit' &&
      r.pattern === pattern &&
      Math.sign(r.amount) === Math.sign(amount),
  );
  const exact = same.find(
    (r) =>
      r.categoryId === categoryId &&
      r.subCategory === subCategory &&
      (!r.useAmount || near(amount, r.amount)),
  );
  if (exact) return [{ ...exact, hits: exact.hits + 1 }];
  const conflict = same.filter((r) => !r.useAmount || near(amount, r.amount));
  // gleicher Text, andere Kategorie bei anderem Betrag → ab jetzt nach Betrag unterscheiden
  const differentAmount = same.length > 0 && same.every((r) => !near(amount, r.amount));
  const changed: Rule[] = [];
  if (differentAmount)
    for (const r of same.filter((x) => !x.useAmount)) changed.push({ ...r, useAmount: true });
  else for (const r of conflict) changed.push({ ...r, categoryId, subCategory, amount, hits: 1 });
  if (!changed.some((r) => r.categoryId === categoryId && r.subCategory === subCategory))
    changed.push({
      id: newId(),
      pattern,
      matchType: 'beginnt_mit',
      accountId: null,
      amount,
      useAmount: differentAmount,
      categoryId,
      subCategory,
      hits: 1,
    });
  return changed;
}
