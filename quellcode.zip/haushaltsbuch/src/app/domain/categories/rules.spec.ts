import { describe, expect, it } from 'vitest';
import { DEFAULT_CATEGORIES as C } from './categories';
import { Rule, learn, normalizeText, suggest } from './rules';

let n = 0;
const id = () => `r${++n}`;
function teach(
  rules: Rule[],
  text: string,
  amount: number,
  cat: string,
  sub: string | null,
): Rule[] {
  const changed = learn(text, amount, cat, sub, rules, id);
  return [...rules.filter((r) => !changed.some((c) => c.id === r.id)), ...changed];
}

describe('Regeln', () => {
  it('normalisiert Texte', () => expect(normalizeText('  AGILA   Hau. ')).toBe('AGILA HAU.'));

  it('lernt aus einer Zuordnung und schlägt sie beim nächsten Mal sicher vor', () => {
    const rules = teach([], 'AGILA Hau.', -2959, 'a-versicherungen', 'Tierversicherung');
    expect(suggest('AGILA Hau.', -2959, 'g', rules, C)).toMatchObject({
      categoryId: 'a-versicherungen',
      subCategory: 'Tierversicherung',
      confidence: 'sicher',
    });
    expect(suggest('AGILA HAUSTIERVERSICHERUNG AG', -2959, 'g', rules, C).confidence).toBe(
      'nicht_zugeordnet',
    );
    expect(suggest('Unbekannt GmbH', -100, 'g', rules, C).confidence).toBe('nicht_zugeordnet');
  });

  it('Gemeinde-Fall: gleicher Text, andere Kategorie → Unterscheidung nach Betrag ± 10 %', () => {
    let rules = teach([], 'Markt Alt.', -16024, 'a-wasser-abwasser', null);
    rules = teach(rules, 'Markt Alt.', -12000, 'a-steuern-gebuehren', 'Grundsteuer');
    expect(rules.every((r) => r.useAmount)).toBe(true);
    expect(suggest('Markt Alt.', -16024, 'g', rules, C)).toMatchObject({
      categoryId: 'a-wasser-abwasser',
      confidence: 'sicher',
    });
    expect(suggest('Markt Alt.', -15800, 'g', rules, C).categoryId).toBe('a-wasser-abwasser');
    expect(suggest('Markt Alt.', -12000, 'g', rules, C)).toMatchObject({
      categoryId: 'a-steuern-gebuehren',
      subCategory: 'Grundsteuer',
    });
    expect(suggest('Markt Alt.', -9000, 'g', rules, C).confidence).toBe('nicht_zugeordnet');
  });

  it('eine Korrektur bei gleichem Betrag ersetzt die alte Zuordnung', () => {
    let rules = teach([], 'REWE', -3000, 'a-haushalt', 'Lebensmittel');
    rules = teach(rules, 'REWE', -3100, 'a-haushalt', 'Drogerie');
    expect(rules).toHaveLength(1);
    expect(suggest('REWE', -3000, 'g', rules, C).subCategory).toBe('Drogerie');
  });

  it('wiederholte Bestätigung zählt Treffer, statt neue Regeln anzulegen', () => {
    let rules = teach([], 'NETFLIX.COM', -1399, 'a-abos-streaming', 'Streaming');
    rules = teach(rules, 'netflix.com', -1399, 'a-abos-streaming', 'Streaming');
    expect(rules).toHaveLength(1);
    expect(rules[0].hits).toBe(2);
  });

  it('der spezifischste Treffer gewinnt; bei Gleichstand der Vorrang', () => {
    const base = { accountId: null, useAmount: false, hits: 1, subCategory: null };
    const rules: Rule[] = [
      {
        ...base,
        id: 'x1',
        pattern: 'SPARKASSE',
        matchType: 'enthaelt',
        amount: -1000,
        categoryId: 'a-andere',
      },
      {
        ...base,
        id: 'x2',
        pattern: 'SPARKASSE KONTO',
        matchType: 'beginnt_mit',
        amount: -1000,
        categoryId: 'a-steuern-gebuehren',
        subCategory: 'Kontogebühren',
      },
    ];
    expect(suggest('Sparkasse Kontoführung', -500, 'g', rules, C).ruleId).toBe('x2');
    const tie: Rule[] = [
      {
        ...base,
        id: 'y1',
        pattern: 'HUK',
        matchType: 'beginnt_mit',
        amount: -5000,
        categoryId: 'a-fahrzeuge',
      },
      {
        ...base,
        id: 'y2',
        pattern: 'HUK',
        matchType: 'beginnt_mit',
        amount: -5000,
        categoryId: 'a-versicherungen',
        subCategory: 'Kfz',
      },
    ];
    expect(suggest('HUK Coburg', -5000, 'g', tie, C)).toMatchObject({
      categoryId: 'a-versicherungen',
      confidence: 'sicher',
    });
    const unclear: Rule[] = [tie[0], { ...tie[0], id: 'y3', categoryId: 'a-andere' }];
    expect(suggest('HUK Coburg', -5000, 'g', unclear, C).confidence).toBe('unsicher');
  });

  it('Einnahmen-Regeln greifen nicht bei Ausgaben', () => {
    const rules = teach([], 'GEHALT SANDRA', 245000, 'e-gehalt', 'Gehalt Sandra');
    expect(suggest('GEHALT SANDRA', -245000, 'g', rules, C).confidence).toBe('nicht_zugeordnet');
  });
});
