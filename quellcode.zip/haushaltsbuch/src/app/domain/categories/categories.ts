/**
 * Kategorien (Lastenheft 9): zweistufig, Kategorie und Unterkategorie. Der Bezug (Haus, Hunde, …)
 * ergibt sich aus der Unterkategorie und wird nicht gewählt. Versicherungen und Steuern & Gebühren
 * haben Vorrang vor anderen Kategorien.
 */
export type CategoryType = 'ausgabe' | 'einnahme';
export type Scope = 'haus' | 'hunde' | 'fahrzeuge' | 'martin' | 'sandra' | 'nebenjob';
export const SCOPES: Record<Scope, string> = {
  haus: 'Haus',
  hunde: 'Hunde',
  fahrzeuge: 'Fahrzeuge',
  martin: 'Martin',
  sandra: 'Sandra',
  nebenjob: 'Nebenjob',
};

export interface SubCategory {
  name: string;
  scope?: Scope;
  taxRelevant?: boolean;
}

export interface Category {
  id: string;
  name: string;
  type: CategoryType;
  priority: 'normal' | 'vorrang';
  scope?: Scope;
  taxRelevant?: boolean;
  /** Sparen auf Konten außerhalb der App: zählt in der Statistik als Sparen, nicht als Konsum */
  savings?: boolean;
  subs: SubCategory[];
  order: number;
  archived: boolean;
}

type Def = [name: string, subs?: (string | SubCategory)[], extra?: Partial<Category>];
const AUSGABEN: Def[] = [
  ['Haushalt', ['Lebensmittel', 'Drogerie', 'Haushaltswaren', 'Kleidung']],
  [
    'Haus & Garten',
    [
      { name: 'Handwerker & Reparaturen', taxRelevant: true },
      'Einrichtung',
      'Garten',
      'Baumarkt',
      'Wartung & Schornsteinfeger',
    ],
    { scope: 'haus' },
  ],
  ['Holz', [], { scope: 'haus' }],
  ['Strom', [], { scope: 'haus' }],
  ['Wasser & Abwasser', [], { scope: 'haus' }],
  ['Internet & Telefon', ['Internet', 'Mobilfunk']],
  ['Abos & Streaming', ['Streaming', 'Apps & Software', 'Zeitschriften']],
  [
    'Versicherungen',
    [
      'Haftpflicht',
      { name: 'Hundehaftpflicht', scope: 'hunde' },
      { name: 'Tierversicherung', scope: 'hunde' },
      { name: 'Kfz', scope: 'fahrzeuge' },
      { name: 'Wohngebäude', scope: 'haus' },
      { name: 'Hausrat', scope: 'haus' },
      'Kranken- und Zusatzversicherung',
      'Leben/BU',
      'Rechtsschutz',
    ],
    { priority: 'vorrang' },
  ],
  [
    'Steuern & Gebühren',
    [
      { name: 'Grundsteuer', scope: 'haus' },
      { name: 'Kfz-Steuer', scope: 'fahrzeuge' },
      { name: 'Hundesteuer', scope: 'hunde' },
      { name: 'Müll', scope: 'haus' },
      'Rundfunkbeitrag',
      'Kontogebühren',
    ],
    { priority: 'vorrang' },
  ],
  ['Kredite', ['Zinsen', 'Gebühren']],
  ['Hunde', ['Futter', 'Tierarzt', 'Zubehör', 'Betreuung & Hundeschule'], { scope: 'hunde' }],
  ['Fahrzeuge', ['Tanken', 'Werkstatt & TÜV', 'Parken & Maut', 'Zubehör'], { scope: 'fahrzeuge' }],
  ['Gesundheit', []],
  ['Urlaub', ['Unterkunft', 'Anreise', 'vor Ort']],
  ['Freizeit Martin', [], { scope: 'martin' }],
  ['Freizeit Sandra', [], { scope: 'sandra' }],
  ['Vereine & Spenden', ['Mitgliedsbeiträge', { name: 'Spenden', taxRelevant: true }]],
  ['Nebenjob', ['Arbeitsmittel', 'Fahrtkosten'], { scope: 'nebenjob', taxRelevant: true }],
  [
    'Sparen',
    ['Sparkonto andere Bank', 'Depot & Sparplan', 'Für andere, z. B. Kinder'],
    { savings: true },
  ],
  ['Bargeld', ['Abhebungen']],
  ['Andere', []],
];
const EINNAHMEN: Def[] = [
  [
    'Gehalt',
    [
      { name: 'Gehalt Sandra', scope: 'sandra' },
      { name: 'Gehalt Martin', scope: 'martin' },
    ],
  ],
  ['Sonderzahlungen', ['Urlaubsgeld', 'Weihnachtsgeld']],
  ['Nebenjob', [], { scope: 'nebenjob' }],
  ['Kapitalerträge', ['Tagesgeldzinsen']],
  ['Steuererstattung', []],
  ['Sonstige Einnahmen', ['Verkäufe', 'Geschenke']],
];

const slug = (s: string) =>
  s
    .toLowerCase()
    .replace(/ä/g, 'ae')
    .replace(/ö/g, 'oe')
    .replace(/ü/g, 'ue')
    .replace(/ß/g, 'ss')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '');

function build(defs: Def[], type: CategoryType, offset: number): Category[] {
  return defs.map(([name, subs = [], extra = {}], i) => ({
    id: `${type === 'ausgabe' ? 'a' : 'e'}-${slug(name)}`,
    name,
    type,
    priority: 'normal',
    subs: subs.map((s) => (typeof s === 'string' ? { name: s } : s)),
    order: offset + i,
    archived: false,
    ...extra,
  }));
}

/** Abgestimmter Startbestand (Lastenheft 9.1); in der App frei änderbar. */
export const DEFAULT_CATEGORIES: Category[] = [
  ...build(AUSGABEN, 'ausgabe', 0),
  ...build(EINNAHMEN, 'einnahme', 100),
];

export function categoryLabel(
  cats: Category[],
  categoryId: string | null,
  sub: string | null,
): string {
  const c = cats.find((x) => x.id === categoryId);
  if (!c) return 'Nicht zugeordnet';
  return sub ? `${c.name} › ${sub}` : c.name;
}

/** Bezug aus Unterkategorie, sonst aus der Kategorie. */
export function scopeOf(
  cats: Category[],
  categoryId: string | null,
  sub: string | null,
): Scope | null {
  const c = cats.find((x) => x.id === categoryId);
  if (!c) return null;
  return c.subs.find((s) => s.name === sub)?.scope ?? c.scope ?? null;
}

export function isTaxRelevant(
  cats: Category[],
  categoryId: string | null,
  sub: string | null,
): boolean {
  const c = cats.find((x) => x.id === categoryId);
  if (!c) return false;
  return !!(c.subs.find((s) => s.name === sub)?.taxRelevant ?? c.taxRelevant);
}

export function forType(cats: Category[], type: CategoryType): Category[] {
  return cats.filter((c) => c.type === type && !c.archived).sort((a, b) => a.order - b.order);
}

/** Erkennt unsere Kategorienamen im Text, auch „Kategorie › Unterkategorie“ oder „Kategorie/Unterkategorie“. */
export function guessCategory(
  text: string,
  type: CategoryType,
  cats: Category[],
): { categoryId: string; subCategory: string | null } | null {
  const norm = (s: string) => s.toLowerCase().replace(/\s+/g, ' ').trim();
  // zuerst am „›“ trennen (Unterkategorien wie „Leben/BU“ enthalten selbst einen Schrägstrich), sonst an > / : oder „ - “
  const parts = text.includes('›') ? text.split('›') : text.split(/\s*(?:>|\/|\s-\s|:)\s*/);
  const [main, sub] = [parts[0], parts.slice(1).join(text.includes('›') ? '›' : '/')].map(norm);
  const c = forType(cats, type).find((x) => norm(x.name) === main);
  if (!c) return null;
  const s = sub ? c.subs.find((x) => norm(x.name) === sub) : undefined;
  if (sub && !s) return null;
  return { categoryId: c.id, subCategory: s?.name ?? null };
}
