import { Account } from '../accounts/account';
import { Forecast, ForecastPoint } from '../forecast/forecast';
import { subBankDays } from '../shared/bank-days';
import { Cents } from '../shared/money';
import { LocalDate } from '../shared/local-date';

/**
 * Liquiditätsabgleich und Umbuchungsempfehlung (Lastenheft 16). Die App bewegt nie selbst Geld; sie sagt,
 * ob, wie viel, von welchem Konto und bis wann umgebucht werden sollte.
 */
export interface AdviceSettings {
  /** Sicherheitspuffer auf dem Girokonto (Standard 200 €) */
  buffer: Cents;
  /** ab diesem Überschuss über dem Puffer wird eine Umbuchung aufs Tagesgeld vorgeschlagen (Standard 500 €) */
  surplusThreshold: Cents;
}
export const DEFAULT_ADVICE: AdviceSettings = { buffer: 20000, surplusThreshold: 50000 };

export interface SourceAccount {
  account: Account;
  balance: Cents;
}

/** Geld aus einem Spartopf aufs Girokonto (16.8): Jahreszahlung oder schon bezahlte Topf-Ausgabe. */
export interface PotItem {
  potId: string;
  label: string;
  amount: Cents;
  due: LocalDate;
  gap: Cents;
  key?: string;
  bookingId?: string;
}

export interface Advice {
  type: 'jetzt' | 'umbuchen' | 'ueberschuss' | 'ok';
  /** empfohlener Betrag (Umbuchung aufs Girokonto bzw. Überschuss aufs Tagesgeld) */
  amount: Cents;
  deadline: LocalDate | null;
  /** erster Tag unter dem Puffer (ohne Umbuchung) */
  breach: LocalDate | null;
  /** tiefster Stand ohne Umbuchung */
  low: ForecastPoint;
  /** Fehlbetrag zum Puffer (ohne Topf-Anteile) */
  residual: Cents;
  potItems: PotItem[];
  source: SourceAccount | null;
  /** verfügbar auf dem Quellkonto: Kontostand minus Notreserve */
  avail: Cents;
  /** was das Quellkonto nicht decken kann */
  uncovered: Cents;
  surplus: Cents;
}

const ceil10 = (c: Cents) => Math.ceil(c / 1000) * 1000;
const floor10 = (c: Cents) => Math.floor(c / 1000) * 1000;

/** Quellkonto (16.3): Tagesgeld mit Zweck „Allgemeine Rücklage“; andere nur auf ausdrücklichen Wunsch. */
export function defaultSource(
  sources: SourceAccount[],
  preferredId?: string | null,
): SourceAccount | null {
  return (
    (preferredId && sources.find((s) => s.account.id === preferredId)) ||
    sources.find((s) => s.account.type === 'tagesgeld' && s.account.purpose === 'allgemein') ||
    null
  );
}

export function advise(
  fc: Forecast,
  today: LocalDate,
  settings: AdviceSettings,
  sources: SourceAccount[],
  potItems: PotItem[] = [],
  preferredSourceId?: string | null,
): Advice {
  const source = defaultSource(sources, preferredSourceId);
  const avail = source ? Math.max(0, source.balance - source.account.reserve) : 0;
  const lead = source?.account.leadDays ?? 2;
  const start: ForecastPoint = { date: today, balance: fc.startBalance };
  const all = [start, ...fc.series];
  const low = all.reduce((lo, p) => (p.balance < lo.balance ? p : lo), start);
  // Topf-Anteile kommen zu ihren Terminen aufs Girokonto; danach zählt nur noch der Rest unter dem Puffer
  const items = potItems.filter((i) => i.amount > 0);
  const withPots = all.map((p) => ({
    date: p.date,
    balance: p.balance + items.filter((i) => i.due <= p.date).reduce((s, i) => s + i.amount, 0),
  }));
  const lowAfter = withPots.reduce((lo, p) => (p.balance < lo.balance ? p : lo), withPots[0]);
  const breachPoint = withPots.find((p) => p.balance < settings.buffer) ?? null;
  const residual = breachPoint ? ceil10(settings.buffer - lowAfter.balance) : 0;
  const potSum = items.reduce((s, i) => s + i.amount, 0);
  const base = {
    low,
    residual,
    potItems: items,
    source,
    avail,
    breach: all.find((p) => p.balance < settings.buffer)?.date ?? null,
  };
  if (potSum > 0 || residual > 0) {
    const amount = potSum + residual;
    const dls = items.map((i) => subBankDays(i.due, lead));
    if (residual && breachPoint) dls.push(subBankDays(breachPoint.date, lead));
    const first = dls.sort()[0];
    const deadline = !first || first < today ? today : first;
    const urgent =
      residual > 0 && !!breachPoint && breachPoint.date <= fc.cur.end && deadline === today;
    return {
      ...base,
      type: urgent ? 'jetzt' : 'umbuchen',
      amount,
      deadline,
      uncovered: Math.max(0, amount - avail),
      surplus: 0,
    };
  }
  const surplus = low.balance - settings.buffer;
  if (surplus > settings.surplusThreshold)
    return {
      ...base,
      type: 'ueberschuss',
      amount: floor10(surplus),
      deadline: null,
      uncovered: 0,
      surplus,
    };
  return { ...base, type: 'ok', amount: 0, deadline: null, uncovered: 0, surplus };
}
