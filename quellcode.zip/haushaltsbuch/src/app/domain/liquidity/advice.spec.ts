import { describe, expect, it } from 'vitest';
import { Account } from '../accounts/account';
import { balanceAt, gapReport } from '../accounts/balances';
import { Booking } from '../bookings/booking';
import { Forecast } from '../forecast/forecast';
import { DEFAULT_ADVICE, SourceAccount, advise } from './advice';

const acc = (
  id: string,
  type: Account['type'],
  purpose: Account['purpose'] = 'allgemein',
  reserve = 1000,
): Account => ({
  id,
  name: id === 't' ? 'Tagesgeld Rücklagen' : id === 's' ? 'Tagesgeld Sondertilgung' : 'Girokonto',
  type,
  identifier: null,
  purpose,
  reserve,
  leadDays: 2,
  archived: false,
  order: 0,
  snapshots: [{ id: 's' + id, date: '2026-11-01', seq: 1, balance: 100000, source: 'start' }],
});
const sources: SourceAccount[] = [
  { account: acc('s', 'tagesgeld', 'sondertilgung'), balance: 900000 },
  { account: acc('t', 'tagesgeld'), balance: 485000 },
];
const fc = (points: [string, number][], start = 150000): Forecast => ({
  cur: { start: '2026-10-30', end: '2026-11-30' },
  next: { start: '2026-12-01', end: '2026-12-29' },
  anchor: null,
  events: [],
  estimates: [],
  varMonthly: 0,
  curVarRest: 0,
  seasonal: [],
  series: points.map(([date, balance]) => ({ date, balance })),
  low: { date: '2026-11-18', balance: 0 },
  firstNegative: null,
  startBalance: start,
});
const TODAY = '2026-11-18';

describe('Umbuchungsempfehlung (Lastenheft 16)', () => {
  it('Fehlbetrag zum Puffer, aufgerundet auf 10 €, vom Tagesgeld „Allgemeine Rücklage“, 2 Bankarbeitstage vor dem Engpass', () => {
    const a = advise(
      fc([
        ['2026-11-19', 120000],
        ['2026-12-10', 15000],
        ['2026-12-11', 4520],
        ['2026-12-20', 30000],
      ]),
      TODAY,
      DEFAULT_ADVICE,
      sources,
    );
    expect([a.type, a.amount, a.residual, a.breach, a.deadline, a.source?.account.id]).toEqual([
      'umbuchen',
      16000,
      16000,
      '2026-12-10',
      '2026-12-08',
      't',
    ]);
    expect([a.avail, a.uncovered]).toEqual([484000, 0]);
  });
  it('Engpass noch im laufenden Zyklus mit Termin heute: sofort umbuchen', () => {
    const a = advise(
      fc([
        ['2026-11-19', 5000],
        ['2026-11-30', 8000],
      ]),
      TODAY,
      DEFAULT_ADVICE,
      sources,
    );
    expect([a.type, a.amount, a.deadline]).toEqual(['jetzt', 15000, TODAY]);
  });
  it('Spartopf-Anteile kommen dazu und verringern den Rest', () => {
    const pts: [string, number][] = [
      ['2026-11-19', 120000],
      ['2026-12-01', 60000],
      ['2026-12-02', 0],
      ['2026-12-20', 10000],
    ];
    const a = advise(fc(pts), TODAY, DEFAULT_ADVICE, sources, [
      {
        potId: 'kfz',
        label: 'für Kfz-Versicherung am 02.12.',
        amount: 60000,
        due: '2026-12-02',
        gap: 0,
      },
    ]);
    expect([a.amount, a.residual, a.deadline]).toEqual([60000, 0, '2026-11-30']);
  });
  it('Überschuss über 500 € aufs Tagesgeld', () => {
    const a = advise(
      fc([
        ['2026-11-19', 140000],
        ['2026-12-15', 95000],
      ]),
      TODAY,
      DEFAULT_ADVICE,
      sources,
    );
    expect([a.type, a.amount]).toEqual(['ueberschuss', 75000]);
    expect(advise(fc([['2026-12-15', 60000]]), TODAY, DEFAULT_ADVICE, sources).type).toBe('ok');
  });
  it('warnt, wenn das Quellkonto nicht reicht; die Notreserve bleibt', () => {
    const small: SourceAccount[] = [{ account: acc('t', 'tagesgeld'), balance: 10000 }];
    const a = advise(fc([['2026-12-10', -50000]]), TODAY, DEFAULT_ADVICE, small);
    expect([a.amount, a.avail, a.uncovered]).toEqual([70000, 9000, 61000]);
  });
  it('ohne Tagesgeld mit Zweck „Allgemeine Rücklage“ kein Quellvorschlag; Sondertilgung nur auf Wunsch', () => {
    expect(advise(fc([['2026-12-10', 0]]), TODAY, DEFAULT_ADVICE, [sources[0]]).source).toBeNull();
    expect(
      advise(fc([['2026-12-10', 0]]), TODAY, DEFAULT_ADVICE, sources, [], 's').source?.account.id,
    ).toBe('s');
  });
});

describe('Bestätigte Umbuchung (16.5, 16.7)', () => {
  const g = acc('g', 'giro');
  const conf: Booking = {
    id: 'c',
    accountId: 'g',
    kind: 'umbuchung',
    status: 'bestaetigt',
    amount: 16000,
    date: '2026-11-18',
    seq: 9,
    text: 'Umbuchung von Tagesgeld',
    splits: [],
    confidence: 'sicher',
    transferGroupId: 'x',
    source: { type: 'manuell' },
  };
  it('zählt sofort im Kontostand, aber nicht im Abgleich mit dem Stand laut Bank', () => {
    const withMail = {
      ...g,
      snapshots: [
        ...g.snapshots,
        { id: 'm', date: '2026-11-19', seq: 10, balance: 100000, source: 'email' as const },
      ],
    };
    expect(balanceAt(g, [conf], '2026-11-30')).toBe(116000);
    expect(balanceAt(withMail, [conf], '2026-11-30')).toBe(116000);
    expect(gapReport(withMail, [conf]).open).toBe(0);
  });
});
