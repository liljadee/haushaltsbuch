import { describe, expect, it } from 'vitest';
import { Booking } from '../bookings/booking';
import { Forecast } from '../forecast/forecast';
import { RecurringItem } from '../recurring/recurring';
import {
  Pot,
  distributeRates,
  monthStartsBetween,
  potForCategory,
  potFree,
  potItems,
  potNextDue,
  potRate,
  potWarning,
  withdraw,
  allocate,
  findStandingOrder,
  pendingInflows,
  potOrder,
  shift,
  startPlan,
  targetBalance,
} from './pots';

const TODAY = '2026-11-18';
const kfzItem: RecurringItem = {
  id: 'kfz',
  label: 'HUK Kfz',
  accountId: 'g',
  amount: -60000,
  categoryId: 'a-versicherungen',
  subCategory: 'Kfz',
  pattern: 'HUK',
  interval: 'jahr',
  months: [12],
  day: 1,
  variable: false,
  active: true,
};
const kfz: Pot = {
  id: 'p1',
  name: 'Kfz-Versicherung',
  kind: 'jahr',
  balance: 50000,
  recurringId: 'kfz',
  order: 0,
};
const urlaub: Pot = {
  id: 'p2',
  name: 'Urlaub 2027',
  kind: 'ziel',
  balance: 30000,
  target: 180000,
  due: '2027-06-30',
  link: { categoryId: 'a-urlaub', subCategory: null },
  order: 1,
};
const fc: Forecast = {
  cur: { start: '2026-10-30', end: '2026-11-30' },
  next: { start: '2026-12-01', end: '2026-12-29' },
  anchor: null,
  events: [{ date: '2026-12-01', amount: -60000, label: 'HUK Kfz', overdue: false, itemId: 'kfz' }],
  estimates: [],
  varMonthly: 0,
  curVarRest: 0,
  seasonal: [],
  series: [],
  low: { date: TODAY, balance: 0 },
  firstNegative: null,
  startBalance: 0,
};

describe('Spartöpfe (Lastenheft 16a)', () => {
  it('Monatsraten: Jahresbetrag ÷ 12 bzw. fehlender Betrag ÷ Monate, auf 5 € aufgerundet', () => {
    expect(potRate(kfz, [kfzItem], TODAY)).toBe(5000);
    expect(monthStartsBetween(TODAY, '2027-06-30')).toBe(7);
    expect(potRate(urlaub, [], TODAY)).toBe(21500);
    expect(potNextDue(kfz, [kfzItem], TODAY)).toBe('2026-12-01');
  });
  it('verteilt höchstens den freien Teil des Kontos', () => {
    expect(potFree(485000, 1000, [kfz, urlaub])).toBe(485000 - 1000 - 80000);
    const r = distributeRates([kfz, urlaub], [kfzItem], 10000, TODAY);
    expect([r.distributed, r.pots.map((p) => p.balance)]).toEqual([10000, [55000, 35000]]);
  });
  it('fällige Jahreszahlung und schon bezahlte Topf-Ausgabe gehen in die Umbuchung', () => {
    const paid: Booking = {
      id: 'b',
      accountId: 'g',
      kind: 'ausgabe',
      status: 'gebucht',
      amount: -20000,
      date: '2026-11-10',
      seq: 1,
      text: 'Ferienwohnung Anzahlung',
      splits: [],
      confidence: 'sicher',
      source: { type: 'manuell' },
      potId: 'p2',
    };
    const items = potItems([kfz, urlaub], [kfzItem], [paid], fc, TODAY);
    expect(items.map((i) => [i.potId, i.amount, i.gap, i.due])).toEqual([
      ['p2', 20000, 0, '2026-11-30'],
      ['p1', 50000, 10000, '2026-12-01'],
    ]);
    const after = withdraw([kfz, urlaub], items);
    expect(after.map((p) => p.balance)).toEqual([0, 10000]);
    expect(
      potItems(after, [kfzItem], [{ ...paid, potSettled: true }], fc, TODAY).find(
        (i) => i.potId === 'p1',
      ),
    ).toMatchObject({ amount: 0, gap: 10000 });
  });
  it('Budgetwarnung, wenn der Topf bis zum Termin nicht reicht', () => {
    expect(potWarning({ ...kfz, balance: 10000 }, [kfzItem], TODAY)).toContain(
      'fehlen voraussichtlich',
    );
    expect(potWarning(kfz, [kfzItem], TODAY)).toContain('50,00');
    expect(potWarning({ ...kfz, balance: 55000 }, [kfzItem], TODAY)).toBeNull();
  });
  it('schlägt den Topf zur Kategorie vor', () => {
    expect(potForCategory([kfz, urlaub], 'a-urlaub', 'Unterkunft')?.id).toBe('p2');
    expect(potForCategory([kfz, urlaub], 'a-haushalt', null)).toBeNull();
  });
});

describe('Dauerauftrag, Startverteilung, automatische Verteilung', () => {
  const winter: Pot = {
    id: 'p3',
    name: 'Winterreifen',
    kind: 'ziel',
    balance: 0,
    target: 60000,
    due: '2027-10-01',
    order: 2,
  };
  it('Reihenfolge: Vorrang, dann frühester Termin', () => {
    expect(potOrder([urlaub, winter, kfz], [kfzItem], TODAY).map((p) => p.id)).toEqual([
      'p1',
      'p2',
      'p3',
    ]);
    expect(
      potOrder(
        [urlaub, winter, { ...kfz }].map((p) => (p.id === 'p3' ? { ...p, priority: true } : p)),
        [kfzItem],
        TODAY,
      ).map((p) => p.id),
    ).toEqual(['p3', 'p1', 'p2']);
  });
  it('verteilt nach Monatsraten; reicht es nicht, bekommt der früheste Termin zuerst', () => {
    expect(allocate(30000, [urlaub, kfz], [kfzItem], TODAY)).toEqual({ p1: 5000, p2: 21500 });
    expect(allocate(10000, [urlaub, kfz], [kfzItem], TODAY)).toEqual({ p1: 5000, p2: 5000 });
  });
  it('erkennt den Dauerauftrag aufs Topfkonto und findet unverteilte Eingänge', () => {
    const so: RecurringItem = {
      ...kfzItem,
      id: 'so',
      label: 'Dauerauftrag Rücklagen',
      amount: -15000,
      categoryId: null,
      subCategory: null,
      pattern: 'DAUERAUFTRAG RÜCKLAGEN',
      interval: 'monat',
      months: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
    };
    const pair = (id: string, date: string): Booking[] => [
      {
        id: `${id}g`,
        accountId: 'g',
        kind: 'umbuchung',
        status: 'gebucht',
        amount: -15000,
        date,
        seq: 1,
        text: 'Dauerauftrag Rücklagen',
        splits: [],
        confidence: 'sicher',
        transferGroupId: id,
        source: { type: 'email' },
      },
      {
        id: `${id}t`,
        accountId: 't',
        kind: 'umbuchung',
        status: 'gebucht',
        amount: 15000,
        date,
        seq: 2,
        text: 'Umbuchung von Girokonto',
        splits: [],
        confidence: 'sicher',
        transferGroupId: id,
        source: { type: 'email' },
      },
    ];
    const bookings = [...pair('a', '2026-10-01'), ...pair('b', '2026-11-02')];
    const found = findStandingOrder([so], bookings, 'g', 't');
    expect(found).toMatchObject({ amount: 15000, day: 1 });
    expect(findStandingOrder([so], bookings, 'g', 'x')).toBeNull();
    expect(pendingInflows(bookings, found, 't', '2026-10-15', {}).map((b) => b.id)).toEqual(['bt']);
    expect(pendingInflows(bookings, found, 't', '2026-10-15', { bt: true })).toEqual([]);
    expect(pendingInflows(bookings, found, 't', null, {})).toEqual([]);
  });
  it('Startverteilung füllt Jahreszahlungs-Töpfe auf ihren Soll-Stand', () => {
    const empty = { ...kfz, balance: 0 };
    expect(targetBalance(empty, [kfzItem], TODAY)).toBe(55000);
    expect(targetBalance(empty, [kfzItem], '2027-08-20')).toBe(40000);
    expect(startPlan([empty, urlaub], [kfzItem], 100000, '2027-08-20')).toEqual({
      p1: 40000,
      p2: 30000,
    });
    expect(startPlan([empty], [kfzItem], 10000, '2027-08-20')).toEqual({ p1: 10000 });
  });
  it('Umschichten zwischen Töpfen und dem freien Teil', () => {
    expect(shift([kfz, urlaub], 'p2', 'p1', 10000, 0).pots.map((p) => p.balance)).toEqual([
      60000, 20000,
    ]);
    expect(shift([kfz, urlaub], 'frei', 'p2', 5000, 4000).error).toContain('40,00');
    expect(shift([kfz, urlaub], 'p1', 'frei', 5000, 0).pots.map((p) => p.balance)).toEqual([
      45000, 30000,
    ]);
  });
});
