import { Booking } from '../bookings/booking';
import { Forecast } from '../forecast/forecast';
import { RecurringItem, matches, occurrences } from '../recurring/recurring';
import { addDays } from '../shared/bank-days';
import { Cents, formatEuro } from '../shared/money';
import { LocalDate, formatDate } from '../shared/local-date';
import { PotItem } from './advice';

/**
 * Spartöpfe (Lastenheft 16a): Das Guthaben eines Tagesgeldkontos wird gedanklich aufgeteilt; es bleibt ein Konto.
 * Ein Topf schmilzt erst, wenn sein Geld per bestätigter Umbuchung aufs Girokonto zurückgeholt wird (16.8).
 */
export interface Pot {
  id: string;
  name: string;
  kind: 'jahr' | 'ziel';
  /** dem Topf zugeteiltes Guthaben */
  balance: Cents;
  /** Jahreszahlungs-Topf: zugehörige wiederkehrende Zahlung */
  recurringId?: string | null;
  /** Sparziel-Topf */
  target?: Cents | null;
  due?: LocalDate | null;
  /** Ausgaben dieser Kategorie schlägt die App „aus dem Topf“ vor */
  link?: { categoryId: string; subCategory: string | null } | null;
  /** schon zurückgeholte Beträge je Fälligkeit („Topf@Datum“) */
  withdrawn?: Record<string, Cents>;
  /** wird vor allen anderen bedient */
  priority?: boolean;
  /** Rücklage für Sondertilgungen: Guthaben und Monatsrate zählen als Budget im Sondertilgungsplan (18.6) */
  forSpecial?: boolean;
  order: number;
}

const ceil5 = (c: Cents) => Math.ceil(c / 500) * 500;
/** Monatsersten zwischen heute (ausschließlich) und dem Datum (einschließlich) */
export function monthStartsBetween(from: LocalDate, to: LocalDate): number {
  let n = 0,
    y = Number(from.slice(0, 4)),
    m = Number(from.slice(5, 7));
  for (;;) {
    m++;
    if (m > 12) [y, m] = [y + 1, 1];
    if (`${y}-${String(m).padStart(2, '0')}-01` > to) return n;
    n++;
  }
}

export function potItem(p: Pot, items: RecurringItem[]): RecurringItem | null {
  return p.kind === 'jahr' && p.recurringId
    ? (items.find((i) => i.id === p.recurringId) ?? null)
    : null;
}

export function potNextDue(p: Pot, items: RecurringItem[], today: LocalDate): LocalDate | null {
  if (p.kind === 'ziel') return p.due ?? null;
  const it = potItem(p, items);
  return it ? (occurrences(it, addDays(today, 1), addDays(today, 400))[0]?.date ?? null) : null;
}

export function potDueAmount(p: Pot, items: RecurringItem[]): Cents {
  const it = potItem(p, items);
  return it ? Math.abs(it.amount) : (p.target ?? 0);
}

/** Monatsrate: Jahresbetrag ÷ 12 bzw. fehlender Betrag ÷ Monate bis zum Termin, aufgerundet auf 5 €. */
export function potRate(p: Pot, items: RecurringItem[], today: LocalDate): Cents {
  if (p.kind === 'jahr') {
    const it = potItem(p, items);
    return it ? ceil5(Math.round((Math.abs(it.amount) * it.months.length) / 12)) : 0;
  }
  const need = Math.max(0, (p.target ?? 0) - p.balance);
  const n = p.due ? monthStartsBetween(today, p.due) : 0;
  return n > 0 ? ceil5(Math.ceil(need / n)) : need;
}

/** Freier Teil des Topfkontos = Kontostand − Notreserve − Töpfe; mehr lässt sich nicht verteilen. */
export function potFree(accountBalance: Cents, reserve: Cents, pots: Pot[]): Cents {
  return accountBalance - reserve - pots.reduce((s, p) => s + p.balance, 0);
}

/** Monatsraten auf die Töpfe verteilen, der Reihe nach, höchstens bis zum freien Teil. */
export function distributeRates(
  pots: Pot[],
  items: RecurringItem[],
  free: Cents,
  today: LocalDate,
): { pots: Pot[]; distributed: Cents } {
  let left = Math.max(0, free),
    distributed = 0;
  const out = [...pots]
    .sort((a, b) => a.order - b.order)
    .map((p) => {
      const add = Math.min(potRate(p, items, today), left);
      left -= add;
      distributed += add;
      return add ? { ...p, balance: p.balance + add } : p;
    });
  return { pots: out, distributed };
}

/** Was aus den Töpfen aufs Girokonto muss (16.8): schon bezahlte Topf-Ausgaben und fällige Jahreszahlungen im Prognosezeitraum. */
export function potItems(
  pots: Pot[],
  items: RecurringItem[],
  bookings: Booking[],
  fc: Forecast | null,
  today: LocalDate,
): PotItem[] {
  const out: PotItem[] = [];
  const left = new Map(pots.map((p) => [p.id, p.balance]));
  for (const b of bookings) {
    if (!b.potId || b.potSettled || b.amount >= 0) continue;
    const p = pots.find((x) => x.id === b.potId);
    if (!p) continue;
    const need = -b.amount,
      have = left.get(p.id) ?? 0,
      amount = Math.min(need, Math.max(0, have));
    left.set(p.id, have - amount);
    out.push({
      potId: p.id,
      label: `${p.name}: Erstattung für ${b.text} vom ${formatDate(b.date)}`,
      amount,
      due: fc?.cur.end ?? today,
      gap: need - amount,
      bookingId: b.id,
    });
  }
  for (const p of pots.filter((x) => x.kind === 'jahr' && x.recurringId)) {
    const ev = fc?.events.find((e) => e.itemId === p.recurringId && e.date > today);
    if (!ev) continue;
    const key = `${p.id}@${ev.date}`,
      need = Math.abs(ev.amount) - (p.withdrawn?.[key] ?? 0);
    if (need <= 0) continue;
    const have = left.get(p.id) ?? 0,
      amount = Math.min(need, Math.max(0, have));
    left.set(p.id, have - amount);
    out.push({
      potId: p.id,
      label: `${p.name}: für ${ev.label} am ${formatDate(ev.date)}`,
      amount,
      due: ev.date,
      gap: need - amount,
      key,
    });
  }
  return out;
}

/** Budgetwarnung (nur an Töpfen): reicht der Topf samt Raten bis zum Termin nicht? */
export function potWarning(p: Pot, items: RecurringItem[], today: LocalDate): string | null {
  const due = potNextDue(p, items, today);
  if (!due) return null;
  // Guthaben plus Raten, die bis zum Termin noch eingehen (je Monatserster)
  const projected = p.balance + potRate(p, items, today) * monthStartsBetween(today, due);
  const need = potDueAmount(p, items);
  return projected < need
    ? `Bis ${formatDate(due)} fehlen voraussichtlich ${formatEuro(need - projected)}.`
    : null;
}

/** „Jetzt umgebucht“ (16.5, 16.8): Töpfe werden um die zurückgeholten Beträge kleiner. */
export function withdraw(pots: Pot[], taken: PotItem[]): Pot[] {
  return pots.map((p) => {
    const mine = taken.filter((t) => t.potId === p.id && t.amount > 0);
    if (!mine.length) return p;
    const withdrawn = { ...(p.withdrawn ?? {}) };
    for (const t of mine) if (t.key) withdrawn[t.key] = (withdrawn[t.key] ?? 0) + t.amount;
    return { ...p, balance: p.balance - mine.reduce((s, t) => s + t.amount, 0), withdrawn };
  });
}

/** Topf, aus dem eine Ausgabe dieser Kategorie vorgeschlagen wird */
export function potForCategory(
  pots: Pot[],
  categoryId: string | null,
  sub: string | null,
): Pot | null {
  if (!categoryId) return null;
  return (
    pots.find(
      (p) =>
        p.link?.categoryId === categoryId && (!p.link.subCategory || p.link.subCategory === sub),
    ) ?? null
  );
}

// ---------- Dauerauftrag, Startverteilung, automatische Verteilung (Wunsch 18.11.2026) ----------

/** Reihenfolge beim Verteilen: Töpfe mit Vorrang, dann der früheste Termin, dann die Anlagereihenfolge. */
export function potOrder(pots: Pot[], items: RecurringItem[], today: LocalDate): Pot[] {
  const due = (p: Pot) => potNextDue(p, items, today) ?? '9999-12-31';
  return [...pots].sort(
    (a, b) =>
      Number(!!b.priority) - Number(!!a.priority) ||
      due(a).localeCompare(due(b)) ||
      a.order - b.order,
  );
}

/** Verteilt einen Eingang nach den Monatsraten in der Reihenfolge von potOrder(); der Rest bleibt frei. */
export function allocate(
  amount: Cents,
  pots: Pot[],
  items: RecurringItem[],
  today: LocalDate,
): Record<string, Cents> {
  const out: Record<string, Cents> = {};
  let left = Math.max(0, amount);
  for (const p of potOrder(pots, items, today)) {
    const give = Math.min(potRate(p, items, today), left);
    if (give > 0) out[p.id] = give;
    left -= give;
  }
  return out;
}

export interface StandingOrder {
  item: RecurringItem;
  amount: Cents;
  day: number;
  /** selbst eingetragen (sonst aus der Historie erkannt) */
  planned: boolean;
}

/** Dauerauftrag vom Girokonto aufs Topfkonto: eingeplante oder erkannte monatliche Umbuchung, deren Gegenseite das Topfkonto ist. */
export function findStandingOrder(
  items: RecurringItem[],
  bookings: Booking[],
  giroId: string,
  potAccountId: string,
): StandingOrder | null {
  // eingetragene regelmäßige Umbuchung aufs Topfkonto geht vor
  const planned = items.find(
    (i) =>
      i.active &&
      i.transferTo === potAccountId &&
      i.accountId === giroId &&
      i.amount < 0 &&
      i.interval === 'monat',
  );
  if (planned)
    return { item: planned, amount: Math.abs(planned.amount), day: planned.day, planned: true };
  for (const item of items.filter(
    (i) => i.active && i.accountId === giroId && i.amount < 0 && i.interval === 'monat',
  )) {
    const hits = bookings
      .filter((b) => b.kind === 'umbuchung' && b.accountId === giroId && matches(item, b))
      .sort((a, b) => (a.date < b.date ? 1 : -1));
    const last = hits[0];
    const other = last
      ? bookings.find(
          (x) =>
            x.transferGroupId && x.transferGroupId === last.transferGroupId && x.id !== last.id,
        )
      : null;
    if (other?.accountId === potAccountId)
      return { item, amount: Math.abs(item.amount), day: item.day, planned: false };
  }
  return null;
}

/** Eingänge des Dauerauftrags auf dem Topfkonto seit dem Start, die noch nicht verteilt sind. */
export function pendingInflows(
  bookings: Booking[],
  so: StandingOrder | null,
  potAccountId: string,
  startedAt: LocalDate | null,
  done: Record<string, unknown>,
): Booking[] {
  if (!so || !startedAt) return [];
  return bookings
    .filter(
      (b) =>
        b.accountId === potAccountId &&
        b.kind === 'umbuchung' &&
        b.amount > 0 &&
        b.status !== 'geplant' &&
        b.date >= startedAt &&
        !(b.id in done),
    )
    .filter((b) => {
      const giroSide = bookings.find(
        (x) => x.transferGroupId && x.transferGroupId === b.transferGroupId && x.id !== b.id,
      );
      return !!giroSide && matches(so.item, giroSide);
    })
    .sort((a, b) => (a.date < b.date ? -1 : 1));
}

/** Soll-Stand: Jahreszahlungs-Topf = Raten seit der letzten Zahlung (höchstens der fällige Betrag); Sparziel = wie bisher. */
export function targetBalance(p: Pot, items: RecurringItem[], today: LocalDate): Cents {
  const it = potItem(p, items);
  if (!it) return p.balance;
  const last = occurrences(it, addDays(today, -400), today).at(-1)?.date;
  if (!last) return p.balance;
  return Math.min(
    potDueAmount(p, items),
    potRate(p, items, today) * monthStartsBetween(last, today),
  );
}

/** Startverteilung: freier Teil in Vorrang-Reihenfolge, bis jeder Topf seinen Soll-Stand hat. Liefert neue Topfstände. */
export function startPlan(
  pots: Pot[],
  items: RecurringItem[],
  free: Cents,
  today: LocalDate,
): Record<string, Cents> {
  const out: Record<string, Cents> = Object.fromEntries(pots.map((p) => [p.id, p.balance]));
  let left = Math.max(0, free);
  for (const p of potOrder(pots, items, today)) {
    const add = Math.min(Math.max(0, targetBalance(p, items, today) - p.balance), left);
    out[p.id] += add;
    left -= add;
  }
  return out;
}

/** Umschichten zwischen Töpfen oder vom bzw. in den freien Teil ('frei'); ändert nur die gedankliche Aufteilung. */
export function shift(
  pots: Pot[],
  from: string,
  to: string,
  amount: Cents,
  free: Cents,
): { pots: Pot[]; error: string | null } {
  if (amount <= 0 || from === to)
    return { pots, error: 'Bitte einen Betrag und zwei verschiedene Ziele wählen.' };
  const have = from === 'frei' ? free : (pots.find((p) => p.id === from)?.balance ?? 0);
  if (amount > have) return { pots, error: `Dort sind nur ${formatEuro(have)}.` };
  return {
    pots: pots.map((p) =>
      p.id === from
        ? { ...p, balance: p.balance - amount }
        : p.id === to
          ? { ...p, balance: p.balance + amount }
          : p,
    ),
    error: null,
  };
}
