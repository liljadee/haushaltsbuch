import { Booking } from '../bookings/booking';
import { Forecast } from '../forecast/forecast';
import { RecurringItem, occurrences } from '../recurring/recurring';
import { addDays } from '../shared/bank-days';
import { Cents, formatEuro } from '../shared/money';
import { LocalDate, formatDate } from '../shared/local-date';
import { PotItem } from './advice';

/**
 * Spartöpfe (Lastenheft 16a): Das Guthaben eines Tagesgeldkontos wird gedanklich aufgeteilt; es bleibt ein Konto.
 * Ein Topf schmilzt erst, wenn sein Geld per bestätigter Umbuchung aufs Girokonto zurückgeholt wird (16.8).
 */
export interface Pot {
  id: string;
  name: string;
  kind: 'jahr' | 'ziel';
  /** dem Topf zugeteiltes Guthaben */
  balance: Cents;
  /** Jahreszahlungs-Topf: zugehörige wiederkehrende Zahlung */
  recurringId?: string | null;
  /** Sparziel-Topf */
  target?: Cents | null;
  due?: LocalDate | null;
  /** Ausgaben dieser Kategorie schlägt die App „aus dem Topf“ vor */
  link?: { categoryId: string; subCategory: string | null } | null;
  /** schon zurückgeholte Beträge je Fälligkeit („Topf@Datum“) */
  withdrawn?: Record<string, Cents>;
  order: number;
}

const ceil5 = (c: Cents) => Math.ceil(c / 500) * 500;
/** Monatsersten zwischen heute (ausschließlich) und dem Datum (einschließlich) */
export function monthStartsBetween(from: LocalDate, to: LocalDate): number {
  let n = 0,
    y = Number(from.slice(0, 4)),
    m = Number(from.slice(5, 7));
  for (;;) {
    m++;
    if (m > 12) [y, m] = [y + 1, 1];
    if (`${y}-${String(m).padStart(2, '0')}-01` > to) return n;
    n++;
  }
}

export function potItem(p: Pot, items: RecurringItem[]): RecurringItem | null {
  return p.kind === 'jahr' && p.recurringId
    ? (items.find((i) => i.id === p.recurringId) ?? null)
    : null;
}

export function potNextDue(p: Pot, items: RecurringItem[], today: LocalDate): LocalDate | null {
  if (p.kind === 'ziel') return p.due ?? null;
  const it = potItem(p, items);
  return it ? (occurrences(it, addDays(today, 1), addDays(today, 400))[0]?.date ?? null) : null;
}

export function potDueAmount(p: Pot, items: RecurringItem[]): Cents {
  const it = potItem(p, items);
  return it ? Math.abs(it.amount) : (p.target ?? 0);
}

/** Monatsrate: Jahresbetrag ÷ 12 bzw. fehlender Betrag ÷ Monate bis zum Termin, aufgerundet auf 5 €. */
export function potRate(p: Pot, items: RecurringItem[], today: LocalDate): Cents {
  if (p.kind === 'jahr') {
    const it = potItem(p, items);
    return it ? ceil5(Math.round((Math.abs(it.amount) * it.months.length) / 12)) : 0;
  }
  const need = Math.max(0, (p.target ?? 0) - p.balance);
  const n = p.due ? monthStartsBetween(today, p.due) : 0;
  return n > 0 ? ceil5(Math.ceil(need / n)) : need;
}

/** Freier Teil des Topfkontos = Kontostand − Notreserve − Töpfe; mehr lässt sich nicht verteilen. */
export function potFree(accountBalance: Cents, reserve: Cents, pots: Pot[]): Cents {
  return accountBalance - reserve - pots.reduce((s, p) => s + p.balance, 0);
}

/** Monatsraten auf die Töpfe verteilen, der Reihe nach, höchstens bis zum freien Teil. */
export function distributeRates(
  pots: Pot[],
  items: RecurringItem[],
  free: Cents,
  today: LocalDate,
): { pots: Pot[]; distributed: Cents } {
  let left = Math.max(0, free),
    distributed = 0;
  const out = [...pots]
    .sort((a, b) => a.order - b.order)
    .map((p) => {
      const add = Math.min(potRate(p, items, today), left);
      left -= add;
      distributed += add;
      return add ? { ...p, balance: p.balance + add } : p;
    });
  return { pots: out, distributed };
}

/** Was aus den Töpfen aufs Girokonto muss (16.8): schon bezahlte Topf-Ausgaben und fällige Jahreszahlungen im Prognosezeitraum. */
export function potItems(
  pots: Pot[],
  items: RecurringItem[],
  bookings: Booking[],
  fc: Forecast | null,
  today: LocalDate,
): PotItem[] {
  const out: PotItem[] = [];
  const left = new Map(pots.map((p) => [p.id, p.balance]));
  for (const b of bookings) {
    if (!b.potId || b.potSettled || b.amount >= 0) continue;
    const p = pots.find((x) => x.id === b.potId);
    if (!p) continue;
    const need = -b.amount,
      have = left.get(p.id) ?? 0,
      amount = Math.min(need, Math.max(0, have));
    left.set(p.id, have - amount);
    out.push({
      potId: p.id,
      label: `${p.name}: Erstattung für ${b.text} vom ${formatDate(b.date)}`,
      amount,
      due: fc?.cur.end ?? today,
      gap: need - amount,
      bookingId: b.id,
    });
  }
  for (const p of pots.filter((x) => x.kind === 'jahr' && x.recurringId)) {
    const ev = fc?.events.find((e) => e.itemId === p.recurringId && e.date > today);
    if (!ev) continue;
    const key = `${p.id}@${ev.date}`,
      need = Math.abs(ev.amount) - (p.withdrawn?.[key] ?? 0);
    if (need <= 0) continue;
    const have = left.get(p.id) ?? 0,
      amount = Math.min(need, Math.max(0, have));
    left.set(p.id, have - amount);
    out.push({
      potId: p.id,
      label: `${p.name}: für ${ev.label} am ${formatDate(ev.date)}`,
      amount,
      due: ev.date,
      gap: need - amount,
      key,
    });
  }
  return out;
}

/** Budgetwarnung (nur an Töpfen): reicht der Topf samt Raten bis zum Termin nicht? */
export function potWarning(p: Pot, items: RecurringItem[], today: LocalDate): string | null {
  const due = potNextDue(p, items, today);
  if (!due) return null;
  // Guthaben plus Raten, die bis zum Termin noch eingehen (je Monatserster)
  const projected = p.balance + potRate(p, items, today) * monthStartsBetween(today, due);
  const need = potDueAmount(p, items);
  return projected < need
    ? `Bis ${formatDate(due)} fehlen voraussichtlich ${formatEuro(need - projected)}.`
    : null;
}

/** „Jetzt umgebucht“ (16.5, 16.8): Töpfe werden um die zurückgeholten Beträge kleiner. */
export function withdraw(pots: Pot[], taken: PotItem[]): Pot[] {
  return pots.map((p) => {
    const mine = taken.filter((t) => t.potId === p.id && t.amount > 0);
    if (!mine.length) return p;
    const withdrawn = { ...(p.withdrawn ?? {}) };
    for (const t of mine) if (t.key) withdrawn[t.key] = (withdrawn[t.key] ?? 0) + t.amount;
    return { ...p, balance: p.balance - mine.reduce((s, t) => s + t.amount, 0), withdrawn };
  });
}

/** Topf, aus dem eine Ausgabe dieser Kategorie vorgeschlagen wird */
export function potForCategory(
  pots: Pot[],
  categoryId: string | null,
  sub: string | null,
): Pot | null {
  if (!categoryId) return null;
  return (
    pots.find(
      (p) =>
        p.link?.categoryId === categoryId && (!p.link.subCategory || p.link.subCategory === sub),
    ) ?? null
  );
}
