import { Booking } from '../bookings/booking';
import { RecurringItem } from '../recurring/recurring';
import { LocalDate } from '../shared/local-date';
import { Bauspar, projectBauspar } from './bauspar';
import { Loan, loanState, plan } from './loan';

/**
 * Kreditraten termingenau in der Liquiditätsprognose (Lastenheft 18.3): Die wiederkehrende Zahlung eines Kredits
 * folgt seinem Tilgungsplan (nur Zinsen in der tilgungsfreien Zeit, Schlussrate, Ende nach der letzten Rate).
 * Bei einem vom Bausparvertrag abgelösten Darlehen enden Zinsen und Sparrate mit der Ablösung; ab dann ist die
 * Rate des Bauspardarlehens eingeplant.
 */
export function withLoanSchedules(
  items: RecurringItem[],
  loans: Loan[],
  bauspar: { b: Bauspar; balance: number }[],
  bookings: Booking[],
  today: LocalDate,
  horizonDays = 400,
): RecurringItem[] {
  const until = new Date(Date.parse(today) + horizonDays * 86400000).toISOString().slice(0, 10);
  const extra: RecurringItem[] = [];
  const endMonths = new Map<string, string>();
  const schedules = new Map<string, { date: LocalDate; amount: number }[]>();
  for (const loan of loans) {
    if (loan.paidOff || !loan.recurringId) continue;
    const state = loanState(loan, bookings, today);
    let rows = state.plan.rows.filter((r) => r.date <= until);
    const link = bauspar.find((x) => x.b.loanId === loan.id && !x.b.settled);
    if (link) {
      const p = projectBauspar(link.b, loan, state, link.balance, today);
      if (p.payoff) {
        const payoff = p.payoff;
        rows = rows.filter((r) => r.date <= payoff);
        endMonths.set(link.b.accountId, payoff.slice(0, 7));
        if (p.bauLoan > 0) {
          const bau = plan(
            {
              ...loan,
              kind: 'annuitaet',
              rate: link.b.loanRate,
              rateMilli: link.b.loanMilli,
              fixedUntil: null,
              endDate: null,
              interestOnlyUntil: null,
            },
            { date: payoff, balance: p.bauLoan },
          );
          extra.push({
            id: `bauspardarlehen-${link.b.id}`,
            label: `Rate Bauspardarlehen ${link.b.name} (geplant)`,
            accountId: loan.accountId,
            amount: -link.b.loanRate,
            categoryId: 'a-kredite',
            subCategory: null,
            pattern: '',
            interval: 'monat',
            day: loan.day,
            months: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
            variable: false,
            active: true,
            transferTo: null,
            schedule: bau.rows
              .filter((r) => r.date <= until)
              .map((r) => ({ date: r.date, amount: -r.payment })),
          } as RecurringItem);
        }
      }
    }
    schedules.set(
      loan.recurringId,
      rows.map((r) => ({ date: r.date, amount: -r.payment })),
    );
  }
  return [
    ...items.map((i) => {
      if (schedules.has(i.id)) return { ...i, schedule: schedules.get(i.id) };
      // Sparrate in den Bausparvertrag endet mit der Ablösung
      const end = i.transferTo ? endMonths.get(i.transferTo) : undefined;
      return end ? { ...i, endMonth: end } : i;
    }),
    ...extra,
  ];
}
