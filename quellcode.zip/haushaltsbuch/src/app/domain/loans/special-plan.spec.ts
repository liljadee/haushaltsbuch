import { describe, expect, it } from 'vitest';
import { Loan, defaultSpecial, loanState } from './loan';
import { roadmap } from './roadmap';
import { SpecialInput, allowance, recommend, simulate } from './special-plan';

const TODAY = '2026-11-19';
const mk = (x: Partial<Loan>): Loan => ({
  id: 'a',
  name: 'Hauskredit',
  kind: 'annuitaet',
  bank: '',
  accountId: 'g',
  pattern: 'x',
  specialPattern: '',
  rate: 50000,
  day: 30,
  rateMilli: 3000,
  effMilli: null,
  fixedUntil: '2028-12-31',
  endDate: null,
  followMilli: 4000,
  finalPayment: null,
  principal: 10000000,
  special: defaultSpecial('annuitaet'),
  snapshots: [{ date: TODAY, balance: 10000000 }],
  paidOff: null,
  recurringId: null,
  order: 0,
  ...x,
});
const A = mk({});
const B = mk({
  id: 'b',
  name: 'Autokredit',
  kind: 'raten',
  rate: 30000,
  rateMilli: 6000,
  fixedUntil: null,
  endDate: '2030-06-30',
  principal: 1200000,
  special: defaultSpecial('raten'),
  snapshots: [{ date: TODAY, balance: 1000000 }],
});
const input = (pool: number, monthly = 0, loans = [A, B]): SpecialInput => ({
  loans: loans.map((l) => ({ loan: l, state: loanState(l, [], TODAY) })),
  pool,
  monthly,
  today: TODAY,
});

describe('Sondertilgungsplan (Lastenheft 18.6)', () => {
  it('ohne Budget entspricht er genau den Tilgungsplänen', () => {
    const inp = input(0);
    const r = simulate(inp, 'zins');
    for (const x of inp.loans) expect(r.payoffs[x.loan.id]).toBe(x.state.payoff);
    expect(r.interest).toBe(inp.loans.reduce((s, x) => s + x.state.futureInterest, 0));
    expect(r.payments).toEqual([]);
  });
  it('Höchstbetrag je Jahr: 5 % des Darlehensbetrags; das Budget wartet beim vordersten Kredit bis zum erlaubten Monat', () => {
    expect(allowance(A, 10000000)).toBe(500000);
    const r = simulate(input(2000000), 'zinsbindung');
    // Juni 2027: Hauskredit (vorne) erst im Dezember erlaubt → nichts an den Autokredit; Dezember 2026: 5.000 € Hauskredit, Rest Autokredit
    expect(r.payments.slice(0, 2).map((p) => [p.date, p.loanId, p.amount])).toEqual([
      ['2026-12-30', 'a', 500000],
      // Autokredit nach den Raten vom 30.11. und 30.12.: 10.000 − 250,00 − 251,25 = 9.498,75 €
      ['2026-12-30', 'b', 949875],
    ]);
    expect(r.payments.some((p) => p.date.startsWith('2027-06'))).toBe(false);
  });
  it('höchster Zins zuerst: der Autokredit mit 6 % bekommt das Budget zuerst', () => {
    const r = simulate(input(500000), 'zins');
    expect(r.payments[0]).toMatchObject({ loanId: 'b', amount: 500000, date: '2026-12-30' });
  });
  it('Sondertilgungen machen früher schuldenfrei und sparen Zinsen; empfohlen wird die früheste Schuldenfreiheit', () => {
    const inp = input(1000000, 50000);
    const without = simulate(input(0), 'zins');
    const { best, results } = recommend(inp);
    expect(results[best].debtFree! < without.debtFree!).toBe(true);
    expect(results[best].interest).toBeLessThan(without.interest);
    for (const r of Object.values(results))
      expect(results[best].debtFree! <= r.debtFree!).toBe(true);
  });
  it('Gebühr und Mindestbetrag werden beachtet', () => {
    const withFee = mk({ special: { ...defaultSpecial('annuitaet'), fee: 5000, min: 100000 } });
    const r = simulate(input(80000, 0, [withFee]), 'zins');
    expect(r.payments.filter((p) => !p.atFixedEnd)).toEqual([]);
    const r2 = simulate(input(300000, 0, [withFee]), 'zins');
    expect(r2.payments[0]).toMatchObject({ amount: 295000, fee: 5000 });
  });
  it('frei werdende Raten ins Budget: noch früher schuldenfrei', () => {
    const base = simulate(input(1000000, 20000), 'zins');
    const freed = simulate({ ...input(1000000, 20000), freedRates: true }, 'zins');
    expect(freed.debtFree! <= base.debtFree!).toBe(true);
    expect(freed.interest).toBeLessThanOrEqual(base.interest);
  });
});

describe('Sondertilgungsplan mit Bausparvertrag und weitergeleiteten Raten', () => {
  const V = mk({
    id: 'v',
    name: 'Vorfinanzierung',
    kind: 'voraus',
    rate: 0,
    rateMilli: 3600,
    fixedUntil: null,
    principal: null,
    special: defaultSpecial('voraus'),
    snapshots: [{ date: TODAY, balance: 3890000 }],
  });
  const link = {
    loanId: 'v',
    payoff: '2027-10-01',
    balanceAt: 1221000,
    sum: 3000000,
    bauMilli: 2500,
    bauRate: 24000,
    bauSpecial: defaultSpecial('raten'),
    gapMilli: 4000,
    gapTilgungMilli: 2000,
  };
  const inp = (pool: number, withLink = true): SpecialInput => ({
    ...input(pool, 20000, [A, V]),
    bauspar: withLink ? [link] : [],
  });
  it('Ablösung: Bauspardarlehen und Anschlussfinanzierung für die Lücke, beide im Plan', () => {
    const r = simulate(inp(0), 'zins');
    expect(r.replacements).toEqual([
      { loanId: 'v', date: '2027-10-01', bauLoan: 1779000, gap: 890000 },
    ]);
    expect(Object.values(r.names)).toEqual([
      'Hauskredit',
      'Vorfinanzierung',
      'Bauspardarlehen (Vorfinanzierung)',
      'Anschlussfinanzierung (Vorfinanzierung)',
    ]);
    expect(r.payoffs['v-bau']).not.toBeNull();
    expect(r.payoffs['v-anschluss']).not.toBeNull();
    expect(r.debtFree).toBe(
      [r.payoffs['a'], r.payoffs['v-bau'], r.payoffs['v-anschluss']].sort().at(-1),
    );
  });
  it('ohne Verknüpfung endet das Vorausdarlehen nie: nicht „zu schön gerechnet“', () => {
    expect(simulate(inp(0, false), 'zins').debtFree).toBeNull();
  });
  it('Nachfolger bekommen nach der Ablösung Sondertilgungen', () => {
    const r = simulate(inp(500000), 'zins');
    expect(r.payments.some((p) => p.loanId === 'v-bau' || p.loanId === 'v-anschluss')).toBe(true);
  });
  it('Rate eines getilgten Kredits weiterleiten (je Kredit einstellbar) macht früher schuldenfrei', () => {
    const base = simulate(input(1000000, 0), 'zins');
    const fwd = simulate(input(1000000, 0, [A, { ...B, forwardRate: true }]), 'zins');
    expect(fwd.debtFree! < base.debtFree!).toBe(true);
  });
});

describe('Zinsbindungsende: Rücklage mindert, was nachzufinanzieren ist', () => {
  const A2 = mk({ fixedUntil: '2028-12-31' });
  it('Restschuld Y − Rücklage = nachzufinanzieren Z; ohne Höchstgrenze', () => {
    const r = simulate(input(3000000, 0, [A2]), 'zinsbindung');
    const fe = r.fixedEnds[0];
    expect(fe).toMatchObject({ loanId: 'a', date: '2028-12-31' });
    // 30.000 € Rücklage, davon je 5.000 € Sondertilgung im Dezember 2026 und 2027; Rest 20.000 € zum Zinsbindungsende
    expect(fe.fromReserve).toBe(2000000);
    expect(fe.remaining).toBe(fe.debt - 2000000);
    expect(r.payments.find((p) => p.atFixedEnd)).toMatchObject({
      date: '2028-12-31',
      amount: 2000000,
    });
  });
  it('ohne Rücklage bleibt die volle Restschuld', () => {
    const fe = simulate(input(0, 0, [A2]), 'zinsbindung').fixedEnds[0];
    expect([fe.fromReserve, fe.remaining]).toEqual([0, fe.debt]);
  });
});

describe('Verlauf je Kredit und Fahrplan', () => {
  it('Restschuld je Kredit zum Jahresende; Nachfolger zählen zum abgelösten Darlehen', () => {
    const V = mk({
      id: 'v',
      name: 'Vorfinanzierung',
      kind: 'voraus',
      rate: 0,
      rateMilli: 3600,
      fixedUntil: null,
      principal: null,
      special: defaultSpecial('voraus'),
      snapshots: [{ date: TODAY, balance: 3890000 }],
    });
    const link = {
      loanId: 'v',
      payoff: '2027-10-01',
      balanceAt: 1221000,
      sum: 3000000,
      bauMilli: 2500,
      bauRate: 24000,
      bauSpecial: defaultSpecial('raten'),
      gapMilli: 4000,
      gapTilgungMilli: 2000,
    };
    const r = simulate({ ...input(0, 0, [A, V]), bauspar: [link] }, 'zins');
    expect(Object.keys(r.loanYearEnds).sort()).toEqual(['a', 'v']);
    expect(r.loanYearEnds['v'][0]).toEqual({ year: 2026, balance: 3890000 });
    // Ende 2027: nach der Ablösung im Oktober Bauspardarlehen plus Lücke, abzüglich der Tilgung bis Dezember
    const v27 = r.loanYearEnds['v'].find((x) => x.year === 2027)!.balance;
    expect(v27).toBeLessThan(1779000 + 890000);
    expect(v27).toBeGreaterThan(1779000 + 890000 - 200000);
    const sumLast = Object.values(r.loanYearEnds).reduce(
      (t, l) => t + (l.find((x) => x.year === 2030)?.balance ?? 0),
      0,
    );
    expect(sumLast).toBe(r.yearEnds.find((y) => y.year === 2030)!.balance);
  });
  it('Fahrplan: Zinsbindungsende mit nachzufinanzierendem Betrag, Ablösung mit Lücke, getilgte Kredite, zeitlich sortiert', () => {
    const V = mk({
      id: 'v',
      name: 'Vorfinanzierung',
      kind: 'voraus',
      rate: 0,
      rateMilli: 3600,
      fixedUntil: null,
      principal: null,
      special: defaultSpecial('voraus'),
      snapshots: [{ date: TODAY, balance: 3890000 }],
    });
    const link = {
      loanId: 'v',
      payoff: '2027-10-01',
      balanceAt: 1221000,
      sum: 3000000,
      bauMilli: 2500,
      bauRate: 24000,
      bauSpecial: defaultSpecial('raten'),
      gapMilli: 4000,
      gapTilgungMilli: 2000,
    };
    const A2 = mk({ fixedUntil: '2028-12-31' });
    const r = simulate(
      { ...input(1000000, 0, [A2, V, { ...B, forwardRate: true }]), bauspar: [link] },
      'zinsbindung',
    );
    const items = roadmap(r, [A2, V, { ...B, forwardRate: true }], TODAY);
    expect(items.map((i) => i.date)).toEqual([...items.map((i) => i.date)].sort());
    expect(items.find((i) => i.kind === 'abloesung')).toMatchObject({
      loanId: 'v',
      refinance: 890000,
    });
    expect(items.find((i) => i.kind === 'zinsbindung')!.refinance).toBe(r.fixedEnds[0].remaining);
    expect(items.find((i) => i.loanId === 'b' && i.kind === 'getilgt')!.text).toContain(
      'fließt in die Sondertilgungsrücklage',
    );
  });
});
