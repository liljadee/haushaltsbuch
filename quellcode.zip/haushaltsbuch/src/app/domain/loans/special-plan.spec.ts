import { describe, expect, it } from 'vitest';
import { Loan, defaultSpecial, loanState } from './loan';
import { SpecialInput, allowance, recommend, simulate } from './special-plan';

const TODAY = '2026-11-19';
const mk = (x: Partial<Loan>): Loan => ({
  id: 'a',
  name: 'Hauskredit',
  kind: 'annuitaet',
  bank: '',
  accountId: 'g',
  pattern: 'x',
  specialPattern: '',
  rate: 50000,
  day: 30,
  rateMilli: 3000,
  effMilli: null,
  fixedUntil: '2028-12-31',
  endDate: null,
  followMilli: 4000,
  finalPayment: null,
  principal: 10000000,
  special: defaultSpecial('annuitaet'),
  snapshots: [{ date: TODAY, balance: 10000000 }],
  paidOff: null,
  recurringId: null,
  order: 0,
  ...x,
});
const A = mk({});
const B = mk({
  id: 'b',
  name: 'Autokredit',
  kind: 'raten',
  rate: 30000,
  rateMilli: 6000,
  fixedUntil: null,
  endDate: '2030-06-30',
  principal: 1200000,
  special: defaultSpecial('raten'),
  snapshots: [{ date: TODAY, balance: 1000000 }],
});
const input = (pool: number, monthly = 0, loans = [A, B]): SpecialInput => ({
  loans: loans.map((l) => ({ loan: l, state: loanState(l, [], TODAY) })),
  pool,
  monthly,
  today: TODAY,
});

describe('Sondertilgungsplan (Lastenheft 18.6)', () => {
  it('ohne Budget entspricht er genau den Tilgungsplänen', () => {
    const inp = input(0);
    const r = simulate(inp, 'zins');
    for (const x of inp.loans) expect(r.payoffs[x.loan.id]).toBe(x.state.payoff);
    expect(r.interest).toBe(inp.loans.reduce((s, x) => s + x.state.futureInterest, 0));
    expect(r.payments).toEqual([]);
  });
  it('Höchstbetrag je Jahr: 5 % des Darlehensbetrags; das Budget wartet beim vordersten Kredit bis zum erlaubten Monat', () => {
    expect(allowance(A, 10000000)).toBe(500000);
    const r = simulate(input(2000000), 'zinsbindung');
    // Juni 2027: Hauskredit (vorne) erst im Dezember erlaubt → nichts an den Autokredit; Dezember 2026: 5.000 € Hauskredit, Rest Autokredit
    expect(r.payments.slice(0, 2).map((p) => [p.date, p.loanId, p.amount])).toEqual([
      ['2026-12-30', 'a', 500000],
      // Autokredit nach den Raten vom 30.11. und 30.12.: 10.000 − 250,00 − 251,25 = 9.498,75 €
      ['2026-12-30', 'b', 949875],
    ]);
    expect(r.payments.some((p) => p.date.startsWith('2027-06'))).toBe(false);
  });
  it('höchster Zins zuerst: der Autokredit mit 6 % bekommt das Budget zuerst', () => {
    const r = simulate(input(500000), 'zins');
    expect(r.payments[0]).toMatchObject({ loanId: 'b', amount: 500000, date: '2026-12-30' });
  });
  it('Sondertilgungen machen früher schuldenfrei und sparen Zinsen; empfohlen wird die früheste Schuldenfreiheit', () => {
    const inp = input(1000000, 50000);
    const without = simulate(input(0), 'zins');
    const { best, results } = recommend(inp);
    expect(results[best].debtFree! < without.debtFree!).toBe(true);
    expect(results[best].interest).toBeLessThan(without.interest);
    for (const r of Object.values(results))
      expect(results[best].debtFree! <= r.debtFree!).toBe(true);
  });
  it('Gebühr und Mindestbetrag werden beachtet', () => {
    const withFee = mk({ special: { ...defaultSpecial('annuitaet'), fee: 5000, min: 100000 } });
    const r = simulate(input(80000, 0, [withFee]), 'zins');
    expect(r.payments).toEqual([]);
    const r2 = simulate(input(300000, 0, [withFee]), 'zins');
    expect(r2.payments[0]).toMatchObject({ amount: 295000, fee: 5000 });
  });
  it('frei werdende Raten ins Budget: noch früher schuldenfrei', () => {
    const base = simulate(input(1000000, 20000), 'zins');
    const freed = simulate({ ...input(1000000, 20000), freedRates: true }, 'zins');
    expect(freed.debtFree! <= base.debtFree!).toBe(true);
    expect(freed.interest).toBeLessThanOrEqual(base.interest);
  });
});
