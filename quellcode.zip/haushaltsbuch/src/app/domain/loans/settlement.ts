import { Booking } from '../bookings/booking';
import { Cents, formatEuro } from '../shared/money';
import { LocalDate } from '../shared/local-date';
import { Bauspar } from './bauspar';
import { Loan, SpecialRight, defaultSpecial } from './loan';

/**
 * Ablösung durch den Bausparvertrag in einem Schritt (Lastenheft 18.10): Guthaben und neu angelegtes
 * Bauspardarlehen gehen auf das Darlehen. Steht es danach auf 0 €, wird es archiviert; ein Rest läuft
 * als Anschlussfinanzierung weiter. Die Auszahlung des Guthabens ist eine Korrekturbuchung auf dem
 * Bausparkonto: Umschichten von Erspartem auf Schulden ist weder Ausgabe noch Einnahme.
 */
export interface SettlementInput {
  date: LocalDate;
  /** ausgezahltes Guthaben, Bauspardarlehen und Restschuld des Darlehens am Ablösetag */
  balancePaid: Cents;
  bauLoan: Cents;
  debt: Cents;
  bauRate: Cents;
  bauMilli: number;
  bauDay: number;
  bauSpecial: SpecialRight;
  /** für einen Rest: neue Rate, Zins und Zinsbindung der Anschlussfinanzierung */
  follow: { rate: Cents; milli: number; fixedUntil: LocalDate | null } | null;
}

export interface SettlementPlan {
  remaining: Cents;
  archived: boolean;
  loan: Loan;
  bauLoan: Loan | null;
  bauspar: Bauspar;
  booking: Booking | null;
}

export function planSettlement(
  loan: Loan,
  b: Bauspar,
  bausparAccountId: string,
  input: SettlementInput,
  ids: { bauLoanId: string; bookingId: string; seq: number },
): SettlementPlan | { error: string } {
  const { balancePaid, bauLoan, debt } = input;
  if ([balancePaid, bauLoan, debt].some((x) => !Number.isFinite(x) || x < 0))
    return { error: 'Bitte alle Beträge eintragen (0 € ist erlaubt).' };
  const remaining = debt - balancePaid - bauLoan;
  if (remaining < 0)
    return {
      error: `Guthaben und Bauspardarlehen sind zusammen ${formatEuro(-remaining)} höher als die Restschuld des Darlehens. Bitte die Beträge prüfen.`,
    };
  if (bauLoan > 0 && input.bauRate <= Math.round((bauLoan * input.bauMilli) / 1200000))
    return {
      error:
        'Die Rate des Bauspardarlehens deckt nicht einmal die Zinsen. Bitte Rate und Zins prüfen.',
    };
  if (remaining > 0 && !input.follow)
    return {
      error: `Für den Rest von ${formatEuro(remaining)} braucht es die Angaben der Anschlussfinanzierung (Rate und Zins).`,
    };
  if (
    remaining > 0 &&
    input.follow &&
    input.follow.rate <= Math.round((remaining * input.follow.milli) / 1200000)
  )
    return {
      error:
        'Die Rate der Anschlussfinanzierung deckt nicht einmal die Zinsen. Bitte Rate und Zins prüfen.',
    };
  const snapshots = [
    ...loan.snapshots.filter((s) => s.date !== input.date),
    { date: input.date, balance: remaining },
  ];
  const updated: Loan =
    remaining === 0
      ? { ...loan, snapshots, paidOff: input.date.slice(0, 7) }
      : {
          ...loan,
          snapshots,
          kind: 'annuitaet',
          rate: input.follow!.rate,
          rateMilli: input.follow!.milli,
          fixedUntil: input.follow!.fixedUntil,
          interestOnlyUntil: null,
          endDate: null,
          principal: remaining,
          special: defaultSpecial('annuitaet'),
        };
  const bau: Loan | null =
    bauLoan > 0
      ? {
          id: ids.bauLoanId,
          name: `Bauspardarlehen ${b.name}`,
          kind: 'annuitaet',
          bank: loan.bank,
          accountId: loan.accountId,
          pattern: `Kreditrate Bauspardarlehen ${b.name}`,
          specialPattern: `Sondertilgung Bauspardarlehen ${b.name}`,
          rate: input.bauRate,
          day: input.bauDay,
          rateMilli: input.bauMilli,
          effMilli: null,
          fixedUntil: null,
          endDate: null,
          followMilli: input.bauMilli,
          finalPayment: null,
          principal: bauLoan,
          special: input.bauSpecial,
          snapshots: [{ date: input.date, balance: bauLoan }],
          paidOff: null,
          recurringId: null,
          order: loan.order,
          forwardRate: loan.forwardRate,
        }
      : null;
  const booking: Booking | null =
    balancePaid > 0
      ? {
          id: ids.bookingId,
          accountId: bausparAccountId,
          kind: 'korrektur',
          status: 'gebucht',
          amount: -balancePaid,
          date: input.date,
          seq: ids.seq,
          text: `Ablösung ${loan.name}: Guthaben an das Darlehen`,
          splits: [],
          confidence: 'sicher',
          source: { type: 'manuell' },
          note: 'Erfasst mit dem Ablösungs-Assistenten. Zählt nicht in der Statistik: Erspartes wurde zur Tilgung umgeschichtet.',
        }
      : null;
  return {
    remaining,
    archived: remaining === 0,
    loan: updated,
    bauLoan: bau,
    bauspar: {
      ...b,
      settled: { date: input.date, balancePaid, bauLoan, remaining, bauLoanId: bau?.id ?? null },
    },
    booking,
  };
}
