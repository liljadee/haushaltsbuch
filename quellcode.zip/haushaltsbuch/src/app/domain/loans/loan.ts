import { Booking } from '../bookings/booking';
import { normalizeText } from '../categories/rules';
import { addDays } from '../shared/bank-days';
import { Cents } from '../shared/money';
import { LocalDate } from '../shared/local-date';

/**
 * Kredite (Lastenheft 18). Geld in Cent, Zinssätze in Tausendstel-Prozent (3,25 % = 3250),
 * Zinsrechnung 30/360: Monatszins = Restschuld × Sollzins ÷ 12.
 */
export type LoanKind = 'annuitaet' | 'raten' | 'foerder' | 'null' | 'schlussrate' | 'voraus';
export const LOAN_KINDS: Record<LoanKind, string> = {
  annuitaet: 'Baufinanzierung (Annuitätendarlehen)',
  raten: 'Ratenkredit',
  foerder: 'Förderkredit (z. B. KfW)',
  null: '0-%-Finanzierung',
  schlussrate: 'Kredit mit Schlussrate',
  voraus: 'Vorausdarlehen (nur Zinsen, Bausparvertrag löst ab)',
};

export type SpecialRhythm = 'jederzeit' | 'monatlich' | 'quartal' | 'halbjahr' | 'jahr';
export const SPECIAL_RHYTHMS: Record<SpecialRhythm, string> = {
  jederzeit: 'jederzeit',
  monatlich: 'monatlich',
  quartal: 'zum Quartalsende',
  halbjahr: 'halbjährlich',
  jahr: 'jährlich',
};

export interface SpecialRight {
  allowed: boolean;
  rhythm: SpecialRhythm;
  /** Höchstbetrag je Zeitraum in Cent oder in Tausendstel-Prozent des Darlehensbetrags */
  maxAmount: Cents | null;
  maxPercentMilli: number | null;
  min: Cents | null;
  fee: Cents | null;
}

/** Restschuld laut Bank zu einem Stichtag (nach den Zahlungen dieses Tages) */
export interface LoanSnapshot {
  date: LocalDate;
  balance: Cents;
}

export interface Loan {
  id: string;
  name: string;
  kind: LoanKind;
  bank: string;
  /** Belastungskonto der Rate */
  accountId: string;
  /** Erkennung der Rate: Buchungstext beginnt mit … (z. B. „Kreditrate Hauskredit“) */
  pattern: string;
  /** Erkennung von Sondertilgungen (z. B. „Sondertilgung Hauskredit“) */
  specialPattern: string;
  rate: Cents;
  day: number;
  rateMilli: number;
  effMilli: number | null;
  fixedUntil: LocalDate | null;
  endDate: LocalDate | null;
  /** angenommener Anschlusszins nach der Zinsbindung (Standard 4 %) */
  followMilli: number;
  /** Schlussrate am Laufzeitende (Kredit mit Schlussrate) */
  finalPayment: Cents | null;
  /** Darlehensbetrag (optional, für Prozent-Sondertilgungsrechte und Auswertungen) */
  principal: Cents | null;
  special: SpecialRight;
  snapshots: LoanSnapshot[];
  /** abbezahlt im Monat JJJJ-MM */
  paidOff: string | null;
  /** zugehörige wiederkehrende Zahlung (die Rate in der Prognose) */
  recurringId: string | null;
  /** tilgungsfreie Anlaufjahre (z. B. KfW): bis zu diesem Datum nur Zinsen */
  interestOnlyUntil?: LocalDate | null;
  /** vollständig ausgezahlt am (für das Kündigungsrecht nach 10 Jahren, § 489 BGB) */
  payoutDate?: LocalDate | null;
  /** nach der Tilgung die Rate in die Sondertilgungsrücklage weiterleiten (Sondertilgungsplan) */
  forwardRate?: boolean;
  order: number;
}

export const DEFAULT_FOLLOW_MILLI = 4000;

/** übliche Sondertilgungsregeln je Kreditart (Lastenheft 18.2a); bleiben änderbar */
export function defaultSpecial(kind: LoanKind): SpecialRight {
  if (kind === 'raten' || kind === 'foerder' || kind === 'null')
    return {
      allowed: true,
      rhythm: 'jederzeit',
      maxAmount: null,
      maxPercentMilli: null,
      min: null,
      fee: null,
    };
  if (kind === 'annuitaet')
    return {
      allowed: true,
      rhythm: 'jahr',
      maxAmount: null,
      maxPercentMilli: 5000,
      min: null,
      fee: null,
    };
  return {
    allowed: false,
    rhythm: 'jahr',
    maxAmount: null,
    maxPercentMilli: null,
    min: null,
    fee: null,
  };
}

const monthInterest = (balance: Cents, milli: number) => Math.round((balance * milli) / 1200000);
const ym = (d: LocalDate) => d.slice(0, 7);
function dueIn(month: string, day: number): LocalDate {
  const [y, m] = month.split('-').map(Number);
  const last = new Date(Date.UTC(y, m, 0)).getUTCDate();
  return `${month}-${String(Math.min(day, last)).padStart(2, '0')}`;
}
function nextMonth(month: string): string {
  const [y, m] = month.split('-').map(Number);
  return m === 12 ? `${y + 1}-01` : `${y}-${String(m + 1).padStart(2, '0')}`;
}

export function latestSnapshot(loan: Loan, upTo: LocalDate = '9999-12-31'): LoanSnapshot | null {
  return (
    [...loan.snapshots]
      .filter((s) => s.date <= upTo)
      .sort((a, b) => (a.date < b.date ? 1 : -1))[0] ?? null
  );
}

export interface PlanRow {
  date: LocalDate;
  payment: Cents;
  interest: Cents;
  principal: Cents;
  extra: Cents;
  balance: Cents;
}
export interface Plan {
  rows: PlanRow[];
  payoff: LocalDate | null;
  totalInterest: Cents;
  error: string | null;
}

/** tilgungsfreie Anlaufzeit: bis einschließlich diesem Datum nur Zinsen */
export function isInterestOnly(loan: Loan, date: LocalDate): boolean {
  return !!loan.interestOnlyUntil && date <= loan.interestOnlyUntil;
}

/** Zinssatz in einem Monat: Sollzins bis zum Zinsbindungsende, danach der Anschlusszins */
export function milliAt(loan: Loan, date: LocalDate): number {
  return loan.fixedUntil && date > loan.fixedUntil ? loan.followMilli : loan.rateMilli;
}

/**
 * Tilgungsplan ab einem Stand (Restschuld nach dem Stichtag), Monat für Monat bis zur Tilgung.
 * extras: Sondertilgungen je Datum. Vorausdarlehen: nur Zinsen, Restschuld bleibt (bis Laufzeitende).
 */
export function plan(
  loan: Loan,
  from: LoanSnapshot,
  extras: { date: LocalDate; amount: Cents }[] = [],
  maxMonths = 600,
): Plan {
  const rows: PlanRow[] = [];
  let balance = from.balance,
    total = 0,
    month = ym(from.date);
  let due = dueIn(month, loan.day);
  if (due <= from.date) {
    month = nextMonth(month);
    due = dueIn(month, loan.day);
  }
  for (let i = 0; i < maxMonths && balance > 0; i++) {
    const milli = milliAt(loan, due);
    const interest = monthInterest(balance, milli);
    const interestOnly = loan.kind === 'voraus' || isInterestOnly(loan, due);
    let payment = interestOnly ? interest : loan.rate;
    if (!interestOnly && payment <= interest && balance > 0)
      return {
        rows,
        payoff: null,
        totalInterest: total,
        error: `Die Rate von ${(payment / 100).toFixed(2).replace('.', ',')} € deckt die Zinsen von ${(interest / 100).toFixed(2).replace('.', ',')} € nicht${milli !== loan.rateMilli ? ' (nach der Zinsbindung mit dem Anschlusszins)' : ''}; der Kredit würde nie abbezahlt.`,
      };
    let principal = interestOnly ? 0 : Math.min(balance, payment - interest);
    // Schlussrate bzw. Ende der Laufzeit eines Vorausdarlehens: Rest auf einmal
    const last = loan.endDate && ym(due) === ym(loan.endDate);
    if (last && (loan.kind === 'schlussrate' || loan.kind === 'voraus')) principal = balance;
    payment = interest + principal;
    let extra = extras
      .filter((e) => ym(e.date) === ym(due) && e.date >= from.date)
      .reduce((s, e) => s + e.amount, 0);
    extra = Math.min(extra, balance - principal);
    balance -= principal + extra;
    total += interest;
    rows.push({ date: due, payment, interest, principal, extra, balance });
    if (loan.endDate && due >= loan.endDate && loan.kind === 'voraus') break;
    month = nextMonth(month);
    due = dueIn(month, loan.day);
  }
  const payoff = balance <= 0 ? (rows.at(-1)?.date ?? null) : null;
  return { rows, payoff, totalInterest: total, error: null };
}

/** Prüfung vor dem Speichern (18.2a); liefert eine Erklärung oder null */
export function validate(loan: Loan): string | null {
  if (!loan.name.trim()) return 'Bitte einen Namen eingeben, z. B. „Hauskredit“.';
  const s = latestSnapshot(loan);
  if (!s || s.balance <= 0) return 'Bitte die Restschuld eingeben.';
  if (loan.kind !== 'voraus' && loan.rate <= 0) return 'Bitte die monatliche Rate eingeben.';
  if (loan.rateMilli < 0 || loan.rateMilli > 30000)
    return 'Bitte einen Sollzins zwischen 0 und 30 % eingeben.';
  if (!(loan.day >= 1 && loan.day <= 31)) return 'Bitte den Abbuchungstag (1 bis 31) eingeben.';
  const p = plan(loan, s);
  if (p.error) return p.error;
  if (loan.kind === 'raten' && loan.endDate && p.payoff && p.payoff > addDays(loan.endDate, 31))
    return 'Mit dieser Rate ist der Kredit zum Laufzeitende nicht abbezahlt. Bitte Rate oder Laufzeitende prüfen oder als „Kredit mit Schlussrate“ erfassen.';
  return null;
}

// ---------- Buchungen zuordnen ----------
const starts = (text: string, pattern: string) =>
  !!pattern.trim() && normalizeText(text).startsWith(normalizeText(pattern));
/** Raten dieses Kredits: Abbuchungen vom Belastungskonto, deren Text mit dem Erkennungsmerkmal beginnt */
export function isRate(loan: Loan, b: Booking): boolean {
  return (
    b.accountId === loan.accountId &&
    b.amount < 0 &&
    b.status !== 'geplant' &&
    b.kind !== 'korrektur' &&
    starts(b.text, loan.pattern) &&
    !starts(b.text, loan.specialPattern)
  );
}
export function isSpecial(loan: Loan, b: Booking): boolean {
  return (
    b.amount < 0 &&
    b.status !== 'geplant' &&
    b.kind !== 'korrektur' &&
    starts(b.text, loan.specialPattern)
  );
}
/** „Kreditrate X“ → „Sondertilgung X“ als Vorschlag */
export function specialPatternFor(pattern: string): string {
  const m = /^kreditrate\s+(.+)$/i.exec(pattern.trim());
  return m ? `Sondertilgung ${m[1]}` : '';
}

export interface Split {
  interest: Cents;
  principal: Cents;
}
export interface LoanState {
  /** Restschuld heute nach Plan (ab dem letzten Stand laut Bank, mit gebuchten Sondertilgungen) */
  balance: Cents;
  plan: Plan;
  /** Plan ohne künftige Sondertilgungen: „schuldenfrei am“ */
  payoff: LocalDate | null;
  /** Aufteilung jeder gebuchten Rate in Zinsen und Tilgung */
  splits: Record<string, Split>;
  paidInterest: Cents;
  paidPrincipal: Cents;
  specialPaid: Cents;
  futureInterest: Cents;
  /** Restschuld zum Zinsbindungsende */
  atFixedEnd: Cents | null;
  /** Abweichung des letzten Stands laut Bank gegenüber dem gerechneten Wert (positiv: Bank höher) */
  deviation: { date: LocalDate; bank: Cents; computed: Cents } | null;
}

/**
 * Zustand eines Kredits: Rückwärts vom ersten Stand laut Bank durch die gebuchten Raten (Aufteilung früherer Raten),
 * vorwärts nach Plan bis heute und weiter bis zur Tilgung.
 */
export function loanState(loan: Loan, bookings: Booking[], today: LocalDate): LoanState {
  const snaps = [...loan.snapshots].sort((a, b) => (a.date < b.date ? -1 : 1));
  const rates = bookings.filter((b) => isRate(loan, b)).sort((a, b) => (a.date < b.date ? -1 : 1));
  const specials = bookings
    .filter((b) => isSpecial(loan, b))
    .sort((a, b) => (a.date < b.date ? -1 : 1));
  const splits: Record<string, Split> = {};
  const first = snaps[0];
  // rückwärts: Raten und Sondertilgungen vor dem ersten Stand laut Bank
  if (first) {
    let after = first.balance;
    const before = [
      ...rates.filter((b) => b.date <= first.date).map((b) => ({ b, special: false })),
      ...specials.filter((b) => b.date <= first.date).map((b) => ({ b, special: true })),
    ].sort((x, y) => (x.b.date < y.b.date ? 1 : -1));
    for (const { b, special } of before) {
      const pay = -b.amount;
      if (special) {
        after += pay;
        continue;
      }
      const milli = milliAt(loan, b.date);
      const prev =
        loan.kind === 'voraus' || isInterestOnly(loan, b.date)
          ? after
          : Math.round((after + pay) / (1 + milli / 1200000));
      const principal = Math.max(0, prev - after);
      splits[b.id] = { interest: pay - principal, principal };
      after = prev;
    }
  }
  // vorwärts ab jedem Stand laut Bank: Raten nach Plan aufteilen (Zinsen aus der Restschuld, Rest Tilgung)
  let deviation: LoanState['deviation'] = null;
  let cur = first ? { ...first } : { date: today, balance: 0 };
  const events = [
    ...rates.filter((b) => first && b.date > first.date).map((b) => ({ b, special: false })),
    ...specials.filter((b) => first && b.date > first.date).map((b) => ({ b, special: true })),
  ].sort((x, y) => (x.b.date < y.b.date ? -1 : 1));
  let si = 1;
  for (const { b, special } of events) {
    while (si < snaps.length && snaps[si].date < b.date) {
      deviation = { date: snaps[si].date, bank: snaps[si].balance, computed: cur.balance };
      cur = { ...snaps[si] };
      si++;
    }
    const pay = -b.amount;
    if (special) {
      cur = { date: b.date, balance: Math.max(0, cur.balance - pay) };
      continue;
    }
    const interest = monthInterest(cur.balance, milliAt(loan, b.date));
    const principal =
      loan.kind === 'voraus' || isInterestOnly(loan, b.date)
        ? 0
        : Math.max(0, Math.min(cur.balance, pay - interest));
    splits[b.id] = { interest: pay - principal, principal };
    cur = { date: b.date, balance: cur.balance - principal };
  }
  while (si < snaps.length && snaps[si].date <= today) {
    deviation = { date: snaps[si].date, bank: snaps[si].balance, computed: cur.balance };
    cur = { ...snaps[si] };
    si++;
  }
  // bis heute fällige Raten ohne Buchung (z. B. noch nicht importiert) nach Plan abziehen
  const sinceLast = cur.date < today ? plan(loan, cur).rows.filter((r) => r.date <= today) : [];
  const nowBalance = sinceLast.length ? sinceLast.at(-1)!.balance : cur.balance;
  const fromNow = plan(loan, { date: sinceLast.at(-1)?.date ?? cur.date, balance: nowBalance });
  const paid = Object.values(splits);
  const atFixedEnd = loan.fixedUntil
    ? ([...fromNow.rows].reverse().find((r) => r.date <= loan.fixedUntil!)?.balance ?? nowBalance)
    : null;
  return {
    balance: nowBalance,
    plan: fromNow,
    payoff: fromNow.payoff,
    splits,
    paidInterest: paid.reduce((s, x) => s + x.interest, 0),
    paidPrincipal: paid.reduce((s, x) => s + x.principal, 0),
    specialPaid: specials.reduce((s, b) => s - b.amount, 0),
    futureInterest: fromNow.totalInterest,
    atFixedEnd,
    deviation,
  };
}

/** Restschuld je Jahresende aus einem Plan (für das Schuldendiagramm) */
export function yearEnds(
  p: Plan,
  startBalance: Cents,
  today: LocalDate,
): { year: number; balance: Cents }[] {
  const out: { year: number; balance: Cents }[] = [
    { year: Number(today.slice(0, 4)), balance: startBalance },
  ];
  let y = Number(today.slice(0, 4));
  for (const r of p.rows) {
    const ry = Number(r.date.slice(0, 4));
    if (ry > y) y = ry;
    const last = out.at(-1)!;
    if (last.year === ry) last.balance = r.balance;
    else out.push({ year: ry, balance: r.balance });
  }
  return out;
}
