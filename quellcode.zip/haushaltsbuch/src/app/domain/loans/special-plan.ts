import { Cents } from '../shared/money';
import { LocalDate } from '../shared/local-date';
import {
  Loan,
  LoanState,
  SpecialRhythm,
  SpecialRight,
  defaultSpecial,
  isInterestOnly,
  milliAt,
} from './loan';

/**
 * Sondertilgungsplan (Lastenheft 18.6), rein rechnerisch: ein gemeinsames Budget aus der Sondertilgungsrücklage,
 * drei Reihenfolgen, empfohlen die mit der frühesten Schuldenfreiheit.
 */
export type Strategy = 'zinsbindung' | 'zins' | 'restschuld';
export const STRATEGIES: Record<Strategy, string> = {
  zinsbindung: 'Zinsbindungsende zuerst',
  zins: 'höchster Zins zuerst',
  restschuld: 'kleinste Restschuld zuerst',
};

export interface SpecialPayment {
  date: LocalDate;
  loanId: string;
  amount: Cents;
  fee: Cents;
  /** Tilgung aus der Rücklage zum Zinsbindungsende (ohne Höchstgrenze) */
  atFixedEnd?: boolean;
}
/** Zum Zinsbindungsende: Restschuld, Betrag aus der Rücklage, nachzufinanzieren */
export interface FixedEnd {
  loanId: string;
  date: LocalDate;
  debt: Cents;
  fromReserve: Cents;
  remaining: Cents;
}
export interface SpecialResult {
  strategy: Strategy;
  /** Namen aller Kredite im Plan, auch der Nachfolger nach der Ablösung durch einen Bausparvertrag */
  names: Record<string, string>;
  /** Ablösungen: Darlehen → Bauspardarlehen und Lücke (Anschlussfinanzierung) */
  replacements: { loanId: string; date: LocalDate; bauLoan: Cents; gap: Cents }[];
  /** Gesamtschuld zum Jahresende (Diagramm), beginnend mit heute */
  yearEnds: { year: number; balance: Cents }[];
  fixedEnds: FixedEnd[];
  /** Restschuld je Kredit zum Jahresende; Nachfolger (Bauspardarlehen, Anschlussfinanzierung) zählen zum abgelösten Darlehen */
  loanYearEnds: Record<string, { year: number; balance: Cents }[]>;
  /** Monatsrate je Kredit im Plan, auch der Nachfolger */
  rates: Record<string, Cents>;
  payments: SpecialPayment[];
  payoffs: Record<string, LocalDate | null>;
  debtFree: LocalDate | null;
  interest: Cents;
  fees: Cents;
  /** Restschuld je Kredit zum Zinsbindungsende mit Sondertilgungen */
  atFixedEnd: Record<string, Cents | null>;
}
export interface BausparLink {
  loanId: string;
  /** Ablösetermin und Guthaben dann (aus der Prognose des Bausparvertrags) */
  payoff: LocalDate;
  balanceAt: Cents;
  /** Name des Bausparvertrags und Restschuld des Darlehens zur Ablösung (Prognose) */
  name?: string;
  debtAt?: Cents;
  /** Sonderzahlungen in den Bausparvertrag bis zur Ablösung einplanen (18.10) */
  extraPayments?: boolean;
  sum: Cents;
  bauMilli: number;
  bauRate: Cents;
  bauSpecial: SpecialRight;
  /** Annahmen für die Lücke: Zins und anfängliche Tilgung (Tausendstel-Prozent) */
  gapMilli: number;
  gapTilgungMilli: number;
}

export interface SpecialInput {
  loans: { loan: Loan; state: LoanState }[];
  /** verfügbar heute (Sondertilgungsrücklage minus Notreserve) */
  pool: Cents;
  /** monatlich dort eingehend */
  monthly: Cents;
  today: LocalDate;
  /** frei werdende Raten aller getilgten Kredite fließen ins Budget (für den Tipp); sonst je Kredit „forwardRate“ */
  freedRates?: boolean;
  /** vom Bausparvertrag abgelöste Darlehen: zur Ablösung Bauspardarlehen und ggf. Anschlussfinanzierung (Lücke) */
  bauspar?: BausparLink[];
  /** Szenario B: feste jährliche Sondertilgung je Kredit (Median der Vorjahre), jeweils im Dezember, ohne Budget */
  yearlyExtras?: Record<string, Cents>;
}

/** Monate, in denen eine Sondertilgung angesetzt wird (zum Ende des erlaubten Zeitraums) */
const PAY_MONTHS: Record<SpecialRhythm, number[]> = {
  jahr: [12],
  halbjahr: [6, 12],
  quartal: [3, 6, 9, 12],
  monatlich: [6, 12],
  jederzeit: [6, 12],
};
function periodKey(r: SpecialRhythm, month: string): string {
  const y = month.slice(0, 4),
    m = Number(month.slice(5, 7));
  return r === 'jahr'
    ? y
    : r === 'halbjahr'
      ? `${y}-H${m <= 6 ? 1 : 2}`
      : r === 'quartal'
        ? `${y}-Q${Math.ceil(m / 3)}`
        : r === 'monatlich'
          ? month
          : 'immer';
}
function dueIn(month: string, day: number): LocalDate {
  const [y, m] = month.split('-').map(Number);
  const last = new Date(Date.UTC(y, m, 0)).getUTCDate();
  return `${month}-${String(Math.min(day, last)).padStart(2, '0')}`;
}
const nextMonth = (month: string) => {
  const [y, m] = month.split('-').map(Number);
  return m === 12 ? `${y + 1}-01` : `${y}-${String(m + 1).padStart(2, '0')}`;
};
/** Höchstbetrag je Zeitraum (Betrag oder Prozent des Darlehensbetrags, ersatzweise der Restschuld heute) */
export function allowance(loan: Loan, startBalance: Cents): Cents {
  const s = loan.special;
  if (s.maxAmount) return s.maxAmount;
  if (s.maxPercentMilli)
    return Math.round(((loan.principal ?? startBalance) * s.maxPercentMilli) / 100000);
  return Number.POSITIVE_INFINITY;
}

function order(
  strategy: Strategy,
  items: { loan: Loan; balance: Cents }[],
  month: string,
): { loan: Loan; balance: Cents }[] {
  const by = [...items];
  if (strategy === 'zinsbindung')
    by.sort((a, b) =>
      (a.loan.fixedUntil ?? a.loan.endDate ?? '9999').localeCompare(
        b.loan.fixedUntil ?? b.loan.endDate ?? '9999',
      ),
    );
  else if (strategy === 'zins')
    by.sort((a, b) => milliAt(b.loan, `${month}-15`) - milliAt(a.loan, `${month}-15`));
  else by.sort((a, b) => a.balance - b.balance);
  return by;
}

interface Live {
  loan: Loan;
  start: Cents;
}

export function simulate(input: SpecialInput, strategy: Strategy, maxMonths = 600): SpecialResult {
  const live: Live[] = input.loans
    .filter((x) => !x.loan.paidOff && x.state.balance > 0)
    .map((x) => ({ loan: x.loan, start: x.state.balance }));
  const bal = new Map(live.map((x) => [x.loan.id, x.start]));
  const used = new Map<string, Cents>();
  const names: Record<string, string> = Object.fromEntries(
    live.map((x) => [x.loan.id, x.loan.name]),
  );
  const payoffs: Record<string, LocalDate | null> = Object.fromEntries(
    live.map((x) => [x.loan.id, null]),
  );
  const atFixedEnd: Record<string, Cents | null> = Object.fromEntries(
    live.map((x) => [x.loan.id, x.loan.fixedUntil ? x.start : null]),
  );
  const replaced = new Set<string>();
  const replacements: SpecialResult['replacements'] = [];
  const payments: SpecialPayment[] = [];
  const fixedEnds: FixedEnd[] = [];
  const rootOf = (id: string) => id.replace(/-(bau|anschluss)$/, '');
  const loanYearEnds: Record<string, { year: number; balance: Cents }[]> = {};
  const recordLoans = (year: number) => {
    const sums = new Map<string, Cents>();
    for (const [id, b] of bal) sums.set(rootOf(id), (sums.get(rootOf(id)) ?? 0) + Math.max(0, b));
    for (const [id, b] of sums) {
      const list = (loanYearEnds[id] ??= []);
      if (list.at(-1)?.year === year) list.at(-1)!.balance = b;
      else list.push({ year, balance: b });
    }
  };
  recordLoans(Number(input.today.slice(0, 4)));
  const yearEnds: { year: number; balance: Cents }[] = [
    {
      year: Number(input.today.slice(0, 4)),
      balance: [...bal.values()].reduce((t, b) => t + b, 0),
    },
  ];
  let pool = input.pool,
    monthly = input.monthly,
    interest = 0,
    fees = 0;
  const forwards = (loan: Loan) => !!input.freedRates || !!loan.forwardRate;
  const done = (loan: Loan, date: LocalDate) => {
    if (payoffs[loan.id]) return;
    payoffs[loan.id] = date;
    if (forwards(loan)) monthly += loan.rate;
  };
  // Sonderzahlungen in den Bausparvertrag (bis zur Ablösung): eigenes Ziel, eingeordnet nach dem Zins des Bauspardarlehens
  const bsPaid = new Map<string, Cents>();
  const bsTargets = (input.bauspar ?? [])
    .filter((l) => l.extraPayments && live.some((x) => x.loan.id === l.loanId))
    .map((l) => {
      const base = live.find((x) => x.loan.id === l.loanId)!.loan;
      const target: Loan = {
        ...base,
        id: `${l.loanId}-sz`,
        name: `Sonderzahlung ${l.name ?? 'Bausparvertrag'}`,
        kind: 'annuitaet',
        rateMilli: l.bauMilli,
        followMilli: l.bauMilli,
        fixedUntil: null,
        endDate: l.payoff,
        interestOnlyUntil: null,
        special: {
          allowed: true,
          rhythm: 'jederzeit',
          maxAmount: null,
          maxPercentMilli: null,
          min: null,
          fee: null,
        },
      };
      names[target.id] = target.name;
      return { link: l, target };
    });
  const bsRoom = (t: (typeof bsTargets)[number]) =>
    Math.max(
      0,
      (t.link.debtAt ?? t.link.sum) - t.link.balanceAt - (bsPaid.get(t.link.loanId) ?? 0),
    );
  // Beginn im laufenden Monat mit den Raten, die nach heute fällig sind; das Budget wächst ab dem nächsten Monat
  let month = input.today.slice(0, 7);
  for (let i = 0; i < maxMonths && [...bal.values()].some((b) => b > 0); i++) {
    if (i > 0) pool += monthly;
    // reguläre Raten (wie im Tilgungsplan)
    for (const { loan } of [...live]) {
      let b = bal.get(loan.id)!;
      if (b <= 0) continue;
      const due = dueIn(month, loan.day);
      if (due <= input.today) continue;
      const it = Math.round((b * milliAt(loan, due)) / 1200000);
      let principal =
        loan.kind === 'voraus' || isInterestOnly(loan, due)
          ? 0
          : Math.min(b, Math.max(0, loan.rate - it));
      if (
        loan.endDate &&
        month === loan.endDate.slice(0, 7) &&
        (loan.kind === 'schlussrate' || loan.kind === 'voraus')
      )
        principal = b;
      b -= principal;
      interest += it;
      bal.set(loan.id, b);
      if (loan.fixedUntil && due <= loan.fixedUntil) atFixedEnd[loan.id] = b;
      if (b <= 0) done(loan, due);
      // Ablösung durch den Bausparvertrag: Guthaben + Bauspardarlehen, Rest als Anschlussfinanzierung
      const link = input.bauspar?.find(
        (x) => x.loanId === loan.id && x.payoff.slice(0, 7) === month,
      );
      if (link && b > 0) {
        const balanceAt = link.balanceAt + (bsPaid.get(link.loanId) ?? 0);
        const bauLoan = Math.max(0, Math.min(b - balanceAt, link.sum - balanceAt));
        const gap = Math.max(0, b - balanceAt - bauLoan);
        bal.set(loan.id, 0);
        payoffs[loan.id] = link.payoff;
        replaced.add(loan.id);
        replacements.push({ loanId: loan.id, date: link.payoff, bauLoan, gap });
        const base = {
          ...loan,
          kind: 'annuitaet' as const,
          fixedUntil: null,
          endDate: null,
          interestOnlyUntil: null,
          snapshots: [],
          recurringId: null,
        };
        if (bauLoan > 0) {
          const l: Loan = {
            ...base,
            id: `${loan.id}-bau`,
            name: `Bauspardarlehen (${loan.name})`,
            rate: link.bauRate,
            rateMilli: link.bauMilli,
            special: link.bauSpecial,
            principal: bauLoan,
          };
          live.push({ loan: l, start: bauLoan });
          bal.set(l.id, bauLoan);
          names[l.id] = l.name;
          payoffs[l.id] = null;
        }
        if (gap > 0) {
          const rate = Math.ceil((gap * (link.gapMilli + link.gapTilgungMilli)) / 1200000);
          const l: Loan = {
            ...base,
            id: `${loan.id}-anschluss`,
            name: `Anschlussfinanzierung (${loan.name})`,
            rate,
            rateMilli: link.gapMilli,
            followMilli: link.gapMilli,
            special: defaultSpecial('annuitaet'),
            principal: gap,
          };
          live.push({ loan: l, start: gap });
          bal.set(l.id, gap);
          names[l.id] = l.name;
          payoffs[l.id] = null;
        }
        if (!bauLoan && !gap) done(loan, link.payoff);
      }
    }
    // Zinsbindungsende: Tilgung ohne Höchstgrenze möglich; was in der Rücklage liegt, muss nicht nachfinanziert werden
    for (const { loan } of order(
      strategy,
      live.map((x) => ({ loan: x.loan, balance: bal.get(x.loan.id)! })),
      month,
    )) {
      if (
        !loan.fixedUntil ||
        loan.fixedUntil.slice(0, 7) !== month ||
        fixedEnds.some((f) => f.loanId === loan.id)
      )
        continue;
      const debt = bal.get(loan.id)!;
      if (debt <= 0) continue;
      const fromReserve = Math.max(0, Math.min(pool, debt));
      if (fromReserve > 0) {
        pool -= fromReserve;
        bal.set(loan.id, debt - fromReserve);
        payments.push({
          date: loan.fixedUntil,
          loanId: loan.id,
          amount: fromReserve,
          fee: 0,
          atFixedEnd: true,
        });
      }
      fixedEnds.push({
        loanId: loan.id,
        date: loan.fixedUntil,
        debt,
        fromReserve,
        remaining: debt - fromReserve,
      });
      if (debt - fromReserve <= 0) done(loan, loan.fixedUntil);
    }
    // Sondertilgungen nach Priorität; das Budget wartet beim vordersten Kredit, bis dort eine Zahlung erlaubt ist
    const m = Number(month.slice(5, 7));
    if (m === 12 && input.yearlyExtras)
      for (const { loan } of live) {
        const extra = input.yearlyExtras[loan.id] ?? 0,
          b = bal.get(loan.id)!;
        if (extra <= 0 || b <= 0) continue;
        const key = `${loan.id}|${periodKey(loan.special.rhythm, month)}`;
        const amount = Math.min(
          extra,
          b,
          allowance(loan, live.find((x) => x.loan.id === loan.id)!.start) - (used.get(key) ?? 0),
        );
        if (amount <= 0) continue;
        used.set(key, (used.get(key) ?? 0) + amount);
        bal.set(loan.id, b - amount);
        payments.push({ date: dueIn(month, loan.day), loanId: loan.id, amount, fee: 0 });
        if (b - amount <= 0) done(loan, dueIn(month, loan.day));
      }
    const openTargets = bsTargets.filter((t) => month < t.link.payoff.slice(0, 7) && bsRoom(t) > 0);
    const candidates = [
      ...live.map((x) => ({ loan: x.loan, balance: bal.get(x.loan.id)! })),
      ...openTargets.map((t) => ({ loan: t.target, balance: bsRoom(t) })),
    ];
    for (const { loan } of order(strategy, candidates, month)) {
      const bsTarget = openTargets.find((t) => t.target.id === loan.id);
      if (bsTarget) {
        if (!PAY_MONTHS.jederzeit.includes(m)) break;
        const amount = Math.min(pool, bsRoom(bsTarget));
        if (amount <= 0) break;
        pool -= amount;
        bsPaid.set(bsTarget.link.loanId, (bsPaid.get(bsTarget.link.loanId) ?? 0) + amount);
        payments.push({ date: dueIn(month, loan.day), loanId: loan.id, amount, fee: 0 });
        if (bsRoom(bsTarget) > 0) break;
        continue;
      }
      const b = bal.get(loan.id)!;
      if (b <= 0 || !loan.special.allowed) continue;
      const key = `${loan.id}|${periodKey(loan.special.rhythm, month)}`;
      const left =
        allowance(loan, live.find((x) => x.loan.id === loan.id)!.start) - (used.get(key) ?? 0);
      if (left <= 0) continue;
      if (!PAY_MONTHS[loan.special.rhythm].includes(m)) break;
      const fee = loan.special.fee ?? 0;
      const amount = Math.min(pool - fee, left, b);
      if (amount <= 0 || amount < (loan.special.min ?? 1)) break;
      pool -= amount + fee;
      fees += fee;
      used.set(key, (used.get(key) ?? 0) + amount);
      bal.set(loan.id, b - amount);
      payments.push({ date: dueIn(month, loan.day), loanId: loan.id, amount, fee });
      if (loan.fixedUntil && dueIn(month, loan.day) <= loan.fixedUntil)
        atFixedEnd[loan.id] = b - amount;
      if (b - amount <= 0) done(loan, dueIn(month, loan.day));
      if (amount < left) break;
    }
    if (month.endsWith('-12')) {
      const total = [...bal.values()].reduce((t, b) => t + Math.max(0, b), 0);
      const y = Number(month.slice(0, 4));
      if (yearEnds.at(-1)!.year === y) yearEnds.at(-1)!.balance = total;
      else yearEnds.push({ year: y, balance: total });
      recordLoans(y);
    }
    month = nextMonth(month);
  }
  // schuldenfrei: alle Kredite getilgt; ein abgelöstes Darlehen zählt über seine Nachfolger
  const ends = Object.entries(payoffs)
    .filter(
      ([id]) => !replaced.has(id) || !Object.keys(payoffs).some((x) => x.startsWith(`${id}-`)),
    )
    .map(([, d]) => d);
  return {
    strategy,
    names,
    replacements,
    yearEnds,
    fixedEnds,
    loanYearEnds,
    rates: Object.fromEntries(live.map((x) => [x.loan.id, x.loan.rate])),
    payments,
    payoffs,
    debtFree: ends.length && ends.every((e) => !!e) ? [...(ends as string[])].sort().at(-1)! : null,
    interest,
    fees,
    atFixedEnd,
  };
}

/** Alle drei Reihenfolgen; empfohlen die mit der frühesten Schuldenfreiheit, bei Gleichstand die mit weniger Zinsen. */
export function recommend(input: SpecialInput): {
  best: Strategy;
  results: Record<Strategy, SpecialResult>;
} {
  const results = {
    zinsbindung: simulate(input, 'zinsbindung'),
    zins: simulate(input, 'zins'),
    restschuld: simulate(input, 'restschuld'),
  };
  const rank = (r: SpecialResult) => [r.debtFree ?? '9999-12-31', r.interest + r.fees] as const;
  const best = (Object.keys(results) as Strategy[]).sort((a, b) => {
    const [da, ia] = rank(results[a]),
      [db, ib] = rank(results[b]);
    return da.localeCompare(db) || ia - ib;
  })[0];
  return { best, results };
}
