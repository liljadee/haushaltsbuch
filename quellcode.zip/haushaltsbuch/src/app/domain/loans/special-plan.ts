import { Cents } from '../shared/money';
import { LocalDate } from '../shared/local-date';
import { Loan, LoanState, SpecialRhythm, milliAt } from './loan';

/**
 * Sondertilgungsplan (Lastenheft 18.6), rein rechnerisch: ein gemeinsames Budget aus der Sondertilgungsrücklage,
 * drei Reihenfolgen, empfohlen die mit der frühesten Schuldenfreiheit.
 */
export type Strategy = 'zinsbindung' | 'zins' | 'restschuld';
export const STRATEGIES: Record<Strategy, string> = {
  zinsbindung: 'Zinsbindungsende zuerst',
  zins: 'höchster Zins zuerst',
  restschuld: 'kleinste Restschuld zuerst',
};

export interface SpecialPayment {
  date: LocalDate;
  loanId: string;
  amount: Cents;
  fee: Cents;
}
export interface SpecialResult {
  strategy: Strategy;
  payments: SpecialPayment[];
  payoffs: Record<string, LocalDate | null>;
  debtFree: LocalDate | null;
  interest: Cents;
  fees: Cents;
  /** Restschuld je Kredit zum Zinsbindungsende mit Sondertilgungen */
  atFixedEnd: Record<string, Cents | null>;
}
export interface SpecialInput {
  loans: { loan: Loan; state: LoanState }[];
  /** verfügbar heute (Sondertilgungsrücklage minus Notreserve) */
  pool: Cents;
  /** monatlich dort eingehend */
  monthly: Cents;
  today: LocalDate;
  /** frei werdende Raten getilgter Kredite fließen ins Budget (Tipp, 18.6 Punkt 6) */
  freedRates?: boolean;
}

/** Monate, in denen eine Sondertilgung angesetzt wird (zum Ende des erlaubten Zeitraums) */
const PAY_MONTHS: Record<SpecialRhythm, number[]> = {
  jahr: [12],
  halbjahr: [6, 12],
  quartal: [3, 6, 9, 12],
  monatlich: [6, 12],
  jederzeit: [6, 12],
};
function periodKey(r: SpecialRhythm, month: string): string {
  const y = month.slice(0, 4),
    m = Number(month.slice(5, 7));
  return r === 'jahr'
    ? y
    : r === 'halbjahr'
      ? `${y}-H${m <= 6 ? 1 : 2}`
      : r === 'quartal'
        ? `${y}-Q${Math.ceil(m / 3)}`
        : r === 'monatlich'
          ? month
          : 'immer';
}
function dueIn(month: string, day: number): LocalDate {
  const [y, m] = month.split('-').map(Number);
  const last = new Date(Date.UTC(y, m, 0)).getUTCDate();
  return `${month}-${String(Math.min(day, last)).padStart(2, '0')}`;
}
const nextMonth = (month: string) => {
  const [y, m] = month.split('-').map(Number);
  return m === 12 ? `${y + 1}-01` : `${y}-${String(m + 1).padStart(2, '0')}`;
};
/** Höchstbetrag je Zeitraum (Betrag oder Prozent des Darlehensbetrags, ersatzweise der Restschuld heute) */
export function allowance(loan: Loan, startBalance: Cents): Cents {
  const s = loan.special;
  if (s.maxAmount) return s.maxAmount;
  if (s.maxPercentMilli)
    return Math.round(((loan.principal ?? startBalance) * s.maxPercentMilli) / 100000);
  return Number.POSITIVE_INFINITY;
}

function order(
  strategy: Strategy,
  items: { loan: Loan; balance: Cents }[],
  month: string,
): { loan: Loan; balance: Cents }[] {
  const by = [...items];
  if (strategy === 'zinsbindung')
    by.sort((a, b) =>
      (a.loan.fixedUntil ?? a.loan.endDate ?? '9999').localeCompare(
        b.loan.fixedUntil ?? b.loan.endDate ?? '9999',
      ),
    );
  else if (strategy === 'zins')
    by.sort((a, b) => milliAt(b.loan, `${month}-15`) - milliAt(a.loan, `${month}-15`));
  else by.sort((a, b) => a.balance - b.balance);
  return by;
}

export function simulate(input: SpecialInput, strategy: Strategy, maxMonths = 600): SpecialResult {
  const live = input.loans.filter((x) => !x.loan.paidOff && x.state.balance > 0);
  const bal = new Map(live.map((x) => [x.loan.id, x.state.balance]));
  const used = new Map<string, Cents>();
  const payoffs: Record<string, LocalDate | null> = Object.fromEntries(
    live.map((x) => [x.loan.id, null]),
  );
  const atFixedEnd: Record<string, Cents | null> = Object.fromEntries(
    live.map((x) => [x.loan.id, x.loan.fixedUntil ? x.state.balance : null]),
  );
  const payments: SpecialPayment[] = [];
  let pool = input.pool,
    monthly = input.monthly,
    interest = 0,
    fees = 0;
  // Beginn im laufenden Monat mit den Raten, die nach heute fällig sind; das Budget wächst ab dem nächsten Monat
  let month = input.today.slice(0, 7);
  for (let i = 0; i < maxMonths && [...bal.values()].some((b) => b > 0); i++) {
    if (i > 0) pool += monthly;
    // reguläre Raten (wie im Tilgungsplan)
    for (const { loan } of live) {
      let b = bal.get(loan.id)!;
      if (b <= 0) continue;
      const due = dueIn(month, loan.day);
      if (due <= input.today) continue;
      const it = Math.round((b * milliAt(loan, due)) / 1200000);
      let principal = loan.kind === 'voraus' ? 0 : Math.min(b, Math.max(0, loan.rate - it));
      if (
        loan.endDate &&
        month === loan.endDate.slice(0, 7) &&
        (loan.kind === 'schlussrate' || loan.kind === 'voraus')
      )
        principal = b;
      b -= principal;
      interest += it;
      bal.set(loan.id, b);
      if (loan.fixedUntil && due <= loan.fixedUntil) atFixedEnd[loan.id] = b;
      if (b <= 0 && !payoffs[loan.id]) {
        payoffs[loan.id] = due;
        if (input.freedRates) monthly += loan.rate;
      }
    }
    // Sondertilgungen nach Priorität; das Budget wartet beim vordersten Kredit, bis dort eine Zahlung erlaubt ist
    const m = Number(month.slice(5, 7));
    for (const { loan } of order(
      strategy,
      live.map((x) => ({ loan: x.loan, balance: bal.get(x.loan.id)! })),
      month,
    )) {
      const b = bal.get(loan.id)!;
      if (b <= 0 || !loan.special.allowed) continue;
      const key = `${loan.id}|${periodKey(loan.special.rhythm, month)}`;
      const left =
        allowance(loan, input.loans.find((x) => x.loan.id === loan.id)!.state.balance) -
        (used.get(key) ?? 0);
      if (left <= 0) continue;
      if (!PAY_MONTHS[loan.special.rhythm].includes(m)) break;
      const fee = loan.special.fee ?? 0;
      const amount = Math.min(pool - fee, left, b);
      if (amount <= 0 || amount < (loan.special.min ?? 1)) break;
      pool -= amount + fee;
      fees += fee;
      used.set(key, (used.get(key) ?? 0) + amount);
      bal.set(loan.id, b - amount);
      payments.push({ date: dueIn(month, loan.day), loanId: loan.id, amount, fee });
      if (loan.fixedUntil && dueIn(month, loan.day) <= loan.fixedUntil)
        atFixedEnd[loan.id] = b - amount;
      if (b - amount <= 0 && !payoffs[loan.id]) {
        payoffs[loan.id] = dueIn(month, loan.day);
        if (input.freedRates) monthly += loan.rate;
      }
      if (amount < left) break;
    }
    month = nextMonth(month);
  }
  const ends = Object.values(payoffs);
  return {
    strategy,
    payments,
    payoffs,
    debtFree: ends.length && ends.every((e) => !!e) ? [...(ends as string[])].sort().at(-1)! : null,
    interest,
    fees,
    atFixedEnd,
  };
}

/** Alle drei Reihenfolgen; empfohlen die mit der frühesten Schuldenfreiheit, bei Gleichstand die mit weniger Zinsen. */
export function recommend(input: SpecialInput): {
  best: Strategy;
  results: Record<Strategy, SpecialResult>;
} {
  const results = {
    zinsbindung: simulate(input, 'zinsbindung'),
    zins: simulate(input, 'zins'),
    restschuld: simulate(input, 'restschuld'),
  };
  const rank = (r: SpecialResult) => [r.debtFree ?? '9999-12-31', r.interest + r.fees] as const;
  const best = (Object.keys(results) as Strategy[]).sort((a, b) => {
    const [da, ia] = rank(results[a]),
      [db, ib] = rank(results[b]);
    return da.localeCompare(db) || ia - ib;
  })[0];
  return { best, results };
}
