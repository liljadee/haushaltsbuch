import { Booking } from '../bookings/booking';
import { Cents, formatEuro } from '../shared/money';
import { LocalDate, formatDate } from '../shared/local-date';
import { Bauspar, BausparProjection } from './bauspar';
import { Loan, LoanState, isRate, isSpecial } from './loan';
import { FixedEnd, allowance } from './special-plan';

/** Alarme und Fristen (Lastenheft 18.5): erscheinen ab „showFrom“ bis zum Termin. */
export interface Alarm {
  id: string;
  due: LocalDate;
  showFrom: LocalDate;
  title: string;
  text: string;
  loanId?: string;
}
/** Termin für den Kalender (.ics), ohne Beträge */
export interface CalendarEvent {
  id: string;
  date: LocalDate;
  title: string;
}

export function addMonths(d: LocalDate, n: number): LocalDate {
  const [y, m, day] = d.split('-').map(Number);
  const t = new Date(Date.UTC(y, m - 1 + n, 1));
  const last = new Date(Date.UTC(t.getUTCFullYear(), t.getUTCMonth() + 1, 0)).getUTCDate();
  return `${t.getUTCFullYear()}-${String(t.getUTCMonth() + 1).padStart(2, '0')}-${String(Math.min(day, last)).padStart(2, '0')}`;
}
const addDaysISO = (d: LocalDate, n: number) =>
  new Date(Date.parse(d) + n * 86400000).toISOString().slice(0, 10);

/** Ende des laufenden Sondertilgungszeitraums (Kalenderjahr, Halbjahr, Quartal) */
function periodEnd(
  rhythm: Loan['special']['rhythm'],
  today: LocalDate,
): { start: LocalDate; end: LocalDate; label: string } | null {
  const y = Number(today.slice(0, 4)),
    m = Number(today.slice(5, 7));
  if (rhythm === 'jahr') return { start: `${y}-01-01`, end: `${y}-12-31`, label: String(y) };
  if (rhythm === 'halbjahr')
    return m <= 6
      ? { start: `${y}-01-01`, end: `${y}-06-30`, label: `1. Halbjahr ${y}` }
      : { start: `${y}-07-01`, end: `${y}-12-31`, label: `2. Halbjahr ${y}` };
  if (rhythm === 'quartal') {
    const q = Math.ceil(m / 3),
      em = q * 3;
    const last = new Date(Date.UTC(y, em, 0)).getUTCDate();
    return {
      start: `${y}-${String(em - 2).padStart(2, '0')}-01`,
      end: `${y}-${String(em).padStart(2, '0')}-${last}`,
      label: `${q}. Quartal ${y}`,
    };
  }
  return null;
}

export function loanAlarms(
  views: { loan: Loan; state: LoanState }[],
  bauspar: { b: Bauspar; p: BausparProjection }[],
  bookings: Booking[],
  today: LocalDate,
  fixedEnds: FixedEnd[] = [],
  /** Szenario B (bisherige Sondertilgungen): Restschuld zum Zinsbindungsende */
  fixedEndsB: FixedEnd[] = [],
): Alarm[] {
  const out: Alarm[] = [];
  for (const { loan, state } of views) {
    if (loan.paidOff) continue;
    const n = loan.name;
    if (loan.fixedUntil) {
      const atEnd = state.atFixedEnd ?? state.balance;
      out.push({
        id: `${loan.id}-zb`,
        loanId: loan.id,
        due: loan.fixedUntil,
        showFrom: addMonths(loan.fixedUntil, -12),
        title: `${n}: Zinsbindung endet am ${formatDate(loan.fixedUntil)}`,
        text: fixedEndText(
          atEnd,
          fixedEnds.find((f) => f.loanId === loan.id),
          fixedEndsB.find((f) => f.loanId === loan.id),
        ),
      });
      // Vorinformation: 36 bis 12 Monate vorher
      if (today < addMonths(loan.fixedUntil, -12))
        out.push({
          id: `${loan.id}-fw`,
          loanId: loan.id,
          due: addMonths(loan.fixedUntil, -12),
          showFrom: addMonths(loan.fixedUntil, -36),
          title: `${n}: Zinsbindung endet in weniger als 3 Jahren`,
          text: `Ab jetzt ist ein Forward-Darlehen möglich, mit dem du dir den Zins für die Zeit ab ${formatDate(loan.fixedUntil)} sicherst.`,
        });
      // Kündigungsrecht nach 10 Jahren ab vollständiger Auszahlung (§ 489 BGB)
      if (loan.payoutDate) {
        const ten = addMonths(loan.payoutDate, 120);
        if (loan.fixedUntil > ten)
          out.push({
            id: `${loan.id}-489`,
            loanId: loan.id,
            due: ten,
            showFrom: addMonths(ten, -6),
            title: `${n}: Kündigungsrecht nach 10 Jahren`,
            text: `Ab ${formatDate(ten)} kannst du den Kredit mit 6 Monaten Frist kündigen (§ 489 BGB), obwohl die Zinsbindung bis ${formatDate(loan.fixedUntil)} läuft. Interessant, wenn die Zinsen heute niedriger sind.`,
          });
      }
    }
    if (loan.interestOnlyUntil) {
      const interest = Math.round((state.balance * loan.rateMilli) / 1200000);
      out.push({
        id: `${loan.id}-tf`,
        loanId: loan.id,
        due: loan.interestOnlyUntil,
        showFrom: addMonths(loan.interestOnlyUntil, -3),
        title: `${n}: tilgungsfreie Zeit endet am ${formatDate(loan.interestOnlyUntil)}`,
        text: `Danach zahlst du ${formatEuro(loan.rate)} statt ${formatEuro(interest)} im Monat (${formatEuro(loan.rate - interest)} mehr). Die Prognose rechnet schon damit.`,
      });
    }
    if ((loan.kind === 'raten' || loan.kind === 'schlussrate') && loan.endDate)
      out.push({
        id: `${loan.id}-end`,
        loanId: loan.id,
        due: loan.endDate,
        showFrom: addMonths(loan.endDate, -3),
        title: `${n}: Laufzeit endet am ${formatDate(loan.endDate)}`,
        text:
          loan.kind === 'schlussrate'
            ? `Dann ist die Schlussrate über ${formatEuro(state.plan.rows.at(-1)?.payment ?? 0)} fällig; sie ist in der Prognose eingeplant.`
            : `Die letzte Rate: ${formatEuro(state.plan.rows.at(-1)?.payment ?? loan.rate)}.`,
      });
    // ungenutztes Sondertilgungsrecht, 2 Monate vor Ende des Zeitraums
    const pe = loan.special.allowed ? periodEnd(loan.special.rhythm, today) : null;
    const lim = allowance(loan, state.balance);
    if (pe && Number.isFinite(lim)) {
      const used = bookings
        .filter((b) => isSpecial(loan, b) && b.date >= pe.start && b.date <= pe.end)
        .reduce((s, b) => s - b.amount, 0);
      const left = Math.min(lim - used, state.balance);
      if (left > 0)
        out.push({
          id: `${loan.id}-st-${pe.label}`,
          loanId: loan.id,
          due: pe.end,
          showFrom: addMonths(pe.end, -2),
          title: `${n}: Sondertilgungsrecht ${pe.label} noch ${formatEuro(left)} offen`,
          text: `Es läuft am ${formatDate(pe.end)} ab; ob ungenutzte Rechte verfallen, steht im Vertrag. Der Sondertilgungsplan zeigt, ob sich eine Sondertilgung lohnt.`,
        });
    }
    // abweichende Rate (letzte zugeordnete Rate der letzten 45 Tage)
    const last = bookings
      .filter((b) => isRate(loan, b))
      .sort((a, b) => (a.date < b.date ? 1 : -1))[0];
    if (
      last &&
      loan.kind !== 'voraus' &&
      !(loan.interestOnlyUntil && last.date <= loan.interestOnlyUntil) &&
      Math.abs(-last.amount - loan.rate) > 100
    )
      out.push({
        id: `${loan.id}-rate-${last.id}`,
        loanId: loan.id,
        due: addDaysISO(last.date, 45),
        showFrom: last.date,
        title: `${n}: Rate weicht ab`,
        text: `Gebucht am ${formatDate(last.date)}: ${formatEuro(-last.amount)}, hinterlegt sind ${formatEuro(loan.rate)}. Hat sich die Rate geändert, passe sie unter „Bearbeiten“ an.`,
      });
  }
  for (const { b, p } of bauspar) {
    if (!b.allocation) continue;
    out.push({
      id: `${b.id}-zt`,
      due: b.allocation,
      showFrom: addMonths(b.allocation, -6),
      title: `${b.name}: Zuteilung voraussichtlich ${formatDate(b.allocation)}`,
      text: `Erwartetes Guthaben ${formatEuro(p.balanceAt)}, Bauspardarlehen ${formatEuro(p.bauLoan)}, Restschuld des Darlehens ${formatEuro(p.debtAt)}${p.gap ? `; es bleibt eine Lücke von ${formatEuro(p.gap)}` : ''}. Die Zuteilung muss meist aktiv angenommen werden.`,
    });
  }
  return out
    .filter((a) => a.showFrom <= today && today <= a.due)
    .sort((a, b) => a.due.localeCompare(b.due));
}

/** Alle künftigen Termine für den Kalender, ohne Beträge */
export function calendarEvents(
  views: { loan: Loan }[],
  bauspar: { b: Bauspar }[],
  today: LocalDate,
): CalendarEvent[] {
  const ev: CalendarEvent[] = [];
  for (const { loan } of views) {
    if (loan.paidOff) continue;
    if (loan.fixedUntil)
      ev.push({
        id: `${loan.id}-zb`,
        date: loan.fixedUntil,
        title: `${loan.name}: Ende der Zinsbindung`,
      });
    if (loan.fixedUntil)
      ev.push({
        id: `${loan.id}-zb12`,
        date: addMonths(loan.fixedUntil, -12),
        title: `${loan.name}: Anschlussfinanzierung vorbereiten (Zinsbindung endet in 12 Monaten)`,
      });
    if (loan.payoutDate && loan.fixedUntil && loan.fixedUntil > addMonths(loan.payoutDate, 120))
      ev.push({
        id: `${loan.id}-489`,
        date: addMonths(loan.payoutDate, 120),
        title: `${loan.name}: Kündigungsrecht nach 10 Jahren (§ 489 BGB)`,
      });
    if (loan.interestOnlyUntil)
      ev.push({
        id: `${loan.id}-tf`,
        date: loan.interestOnlyUntil,
        title: `${loan.name}: Ende der tilgungsfreien Zeit`,
      });
    if ((loan.kind === 'raten' || loan.kind === 'schlussrate') && loan.endDate)
      ev.push({ id: `${loan.id}-end`, date: loan.endDate, title: `${loan.name}: Laufzeitende` });
  }
  for (const { b } of bauspar)
    if (b.allocation)
      ev.push({
        id: `${b.id}-zt`,
        date: b.allocation,
        title: `${b.name}: voraussichtliche Zuteilung`,
      });
  return ev.filter((e) => e.date >= today).sort((a, b) => a.date.localeCompare(b.date));
}

const esc = (t: string) =>
  t.replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\n/g, '\\n');
/** Kalenderdatei (RFC 5545), ganztägige Termine ohne Beträge */
export function toIcs(events: CalendarEvent[], stamp: string): string {
  const lines = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//Haushaltsbuch//Kredite//DE',
    'CALSCALE:GREGORIAN',
  ];
  for (const e of events) {
    const d = e.date.replace(/-/g, '');
    const next = addDaysISO(e.date, 1).replace(/-/g, '');
    lines.push(
      'BEGIN:VEVENT',
      `UID:${e.id}@haushaltsbuch`,
      `DTSTAMP:${stamp}`,
      `DTSTART;VALUE=DATE:${d}`,
      `DTEND;VALUE=DATE:${next}`,
      `SUMMARY:${esc(e.title)}`,
      'END:VEVENT',
    );
  }
  lines.push('END:VCALENDAR');
  return lines.join('\r\n') + '\r\n';
}

export type { Cents };

/**
 * Text zum Zinsbindungsende, durchgängig mit derselben Rechnung wie der Fahrplan: zuerst mit Sondertilgungsplan
 * (falls vorhanden), zum Vergleich ohne Sondertilgungen und nach Szenario B; dann Rücklage und Nachfinanzierung.
 */
export function fixedEndText(
  withoutSpecials: Cents,
  plan: FixedEnd | undefined,
  scenarioB: FixedEnd | undefined,
): string {
  const parts = [
    plan
      ? `Restschuld dann voraussichtlich ${formatEuro(plan.debt)} mit deinem Sondertilgungsplan (ohne Sondertilgungen ${formatEuro(withoutSpecials)})`
      : `Restschuld dann voraussichtlich ${formatEuro(withoutSpecials)} ohne Sondertilgungen`,
  ];
  if (scenarioB)
    parts.push(`mit euren bisherigen Sondertilgungen (Szenario B) ${formatEuro(scenarioB.debt)}`);
  let text = parts.join('; ') + '.';
  if (plan && plan.fromReserve > 0)
    text += ` Davon kommen ${formatEuro(plan.fromReserve)} aus der Sondertilgungsrücklage; nachzufinanzieren sind ${formatEuro(plan.remaining)}.`;
  return `${text} Zeit, Angebote für die Anschlussfinanzierung einzuholen; im Kredit unter „Was wäre wenn“ siehst du die Raten für verschiedene Zinssätze.`;
}
