import { describe, expect, it } from 'vitest';
import { Booking } from '../bookings/booking';
import { addMonths, calendarEvents, loanAlarms, toIcs } from './alarms';
import { Loan, defaultSpecial, loanState } from './loan';
import { annuity, followOptions, whatIf } from './whatif';

const TODAY = '2026-11-19';
const mk = (x: Partial<Loan>): Loan => ({
  id: 'h',
  name: 'Hauskredit',
  kind: 'annuitaet',
  bank: '',
  accountId: 'g',
  pattern: 'Kreditrate Hauskredit',
  specialPattern: 'Sondertilgung Hauskredit',
  rate: 50000,
  day: 30,
  rateMilli: 3000,
  effMilli: null,
  fixedUntil: '2027-08-31',
  endDate: null,
  followMilli: 4000,
  finalPayment: null,
  principal: 10000000,
  special: defaultSpecial('annuitaet'),
  snapshots: [{ date: TODAY, balance: 10000000 }],
  paidOff: null,
  recurringId: null,
  order: 0,
  ...x,
});
const v = (l: Loan, b: Booking[] = []) => ({ loan: l, state: loanState(l, b, TODAY) });
const bk = (id: string, date: string, amount: number, text: string): Booking => ({
  id,
  accountId: 'g',
  kind: 'ausgabe',
  status: 'gebucht',
  amount,
  date,
  seq: 1,
  text,
  splits: [],
  confidence: 'sicher',
  source: { type: 'email' },
});

describe('Alarme und Fristen (Lastenheft 18.5)', () => {
  it('Zinsbindungsende ab 12 Monate vorher mit Restschuld; Vorinformation 36 bis 12 Monate vorher', () => {
    const a = loanAlarms([v(mk({}))], [], [], TODAY);
    expect(a.map((x) => x.id)).toContain('h-zb');
    expect(a.find((x) => x.id === 'h-zb')!.text).toContain('Restschuld dann voraussichtlich');
    const later = loanAlarms([v(mk({ fixedUntil: '2028-12-31' }))], [], [], TODAY);
    expect(later.map((x) => x.id)).toEqual(['h-st-2026', 'h-fw']);
  });
  it('Kündigungsrecht nach 10 Jahren (§ 489 BGB), tilgungsfreie Zeit, Laufzeitende Ratenkredit', () => {
    const a = loanAlarms(
      [
        v(
          mk({
            fixedUntil: '2035-12-31',
            payoutDate: '2017-03-15',
            interestOnlyUntil: '2027-01-31',
          }),
        ),
        v(
          mk({
            id: 'r',
            name: 'Auto',
            kind: 'raten',
            fixedUntil: null,
            endDate: '2027-01-01',
            rate: 30000,
            snapshots: [{ date: TODAY, balance: 89000 }],
          }),
        ),
      ],
      [],
      [],
      TODAY,
    );
    expect(a.map((x) => x.id).filter((id) => !id.includes('-st-'))).toEqual([
      'r-end',
      'h-tf',
      'h-489',
    ]);
    expect(a.find((x) => x.id === 'h-489')!.text).toContain('15.03.2027');
  });
  it('ungenutztes Sondertilgungsrecht 2 Monate vor Jahresende; genutzt = kein Alarm', () => {
    const l = mk({ fixedUntil: null });
    expect(loanAlarms([v(l)], [], [], TODAY)[0]).toMatchObject({
      id: 'h-st-2026',
      due: '2026-12-31',
    });
    expect(
      loanAlarms([v(l)], [], [bk('s', '2026-06-01', -500000, 'Sondertilgung Hauskredit')], TODAY),
    ).toEqual([]);
    expect(loanAlarms([v(l)], [], [], '2026-09-01')).toEqual([]);
  });
  it('abweichende Rate', () => {
    const l = mk({ fixedUntil: null, special: { ...defaultSpecial('annuitaet'), allowed: false } });
    const a = loanAlarms(
      [v(l, [bk('r', '2026-11-02', -52000, 'Kreditrate Hauskredit')])],
      [],
      [bk('r', '2026-11-02', -52000, 'Kreditrate Hauskredit')],
      TODAY,
    );
    expect(a.map((x) => x.title)).toEqual(['Hauskredit: Rate weicht ab']);
  });
  it('Kalenderdatei ohne Beträge', () => {
    const ics = toIcs(calendarEvents([{ loan: mk({}) }], [], TODAY), '20261119T120000Z');
    expect(ics).toContain('BEGIN:VCALENDAR\r\n');
    expect(ics).toContain('DTSTART;VALUE=DATE:20270831');
    expect(ics).toContain('SUMMARY:Hauskredit: Ende der Zinsbindung');
    expect(ics).not.toMatch(/€/);
    expect(addMonths('2027-08-31', -12)).toBe('2026-08-31');
  });
});

describe('Was-wäre-wenn (Lastenheft 18.7)', () => {
  const l = mk({ fixedUntil: '2031-12-31' });
  const st = loanState(l, [], TODAY);
  it('Sondertilgung: früher fertig, weniger Zinsen, niedrigere Restschuld zum Zinsbindungsende', () => {
    const r = whatIf(l, st, TODAY, { extra: { date: '2026-12-15', amount: 1000000 } });
    expect(r.payoff! < r.basePayoff!).toBe(true);
    expect(r.interest).toBeLessThan(r.baseInterest);
    expect(r.atFixedEnd!).toBeLessThan(r.baseAtFixedEnd!);
  });
  it('Ratenerhöhung wirkt ebenso', () => {
    const r = whatIf(l, st, TODAY, { rateIncrease: 10000 });
    expect(r.payoff! < r.basePayoff!).toBe(true);
  });
  it('Annuität: 100.000 € zu 4 % in 10 Jahren = 1.012,46 € Rate', () => {
    expect(annuity(10000000, 4000, 120)).toBe(101246);
    expect(annuity(120000, 0, 12)).toBe(10000);
  });
  it('Anschlusszinssätze: höherer Zins = höhere Rate fürs gleiche Ziel, späteres Ende bei gleicher Rate', () => {
    const opts = followOptions(l, st, TODAY, [3000, 4000, 5000], 2045);
    expect(opts[0].rateForWish!).toBeLessThan(opts[2].rateForWish!);
    expect(opts[0].payoffSameRate! <= opts[2].payoffSameRate!).toBe(true);
  });
});
