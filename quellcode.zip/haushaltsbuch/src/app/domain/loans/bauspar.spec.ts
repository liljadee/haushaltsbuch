import { describe, expect, it } from 'vitest';
import { Bauspar, compareContract, projectBauspar, suggestType } from './bauspar';
import { Loan, defaultSpecial, loanState } from './loan';

const TODAY = '2026-11-19';
const loan = (x: Partial<Loan>): Loan => ({
  id: 'l',
  name: 'Vorfinanzierung',
  kind: 'voraus',
  bank: 'LBS',
  accountId: 'g',
  pattern: 'Zinsen LBS',
  specialPattern: '',
  rate: 0,
  day: 30,
  rateMilli: 3600,
  effMilli: null,
  fixedUntil: null,
  endDate: null,
  followMilli: 4000,
  finalPayment: null,
  principal: null,
  special: defaultSpecial('voraus'),
  snapshots: [{ date: TODAY, balance: 3890000 }],
  paidOff: null,
  recurringId: null,
  order: 0,
  ...x,
});
const bs = (x: Partial<Bauspar> = {}): Bauspar => ({
  id: 'b',
  name: 'LBS Bausparvertrag',
  accountId: 'bs',
  loanId: 'l',
  sum: 3890000,
  savingRate: 20000,
  savingsMilli: 100,
  minMilli: 40000,
  allocation: '2027-10-01',
  loanMilli: 2500,
  loanRate: 24000,
  type: 'zinsen',
  rateUntilAllocation: 'ja',
  order: 0,
  ...x,
});

describe('Bausparvertrag „Nur Zinsen“ (Lastenheft 18.10)', () => {
  const l = loan({});
  const st = loanState(l, [], TODAY);
  const p = projectBauspar(bs(), l, st, 1000000, TODAY);
  it('Ablösung zur Zuteilung: Guthaben plus Bauspardarlehen decken die konstante Restschuld', () => {
    expect([p.type, p.payoff, p.debtAt, p.gap]).toEqual(['zinsen', '2027-10-01', 3890000, 0]);
    expect(p.balanceAt).toBeGreaterThan(1000000 + 10 * 20000);
    expect(p.bauLoan).toBe(3890000 - p.balanceAt);
    expect(p.bauLoanEnd! > '2037-01-01').toBe(true);
  });
  it('Klartext wie im Lastenheft', () => {
    expect(p.story[0]).toContain('zahlst du monatlich 116,70\u00a0€ Zinsen');
    expect(p.story[1]).toContain('Dann wird der Bausparvertrag zugeteilt');
    expect(p.story[2]).toContain('nur noch 240,00\u00a0€ Rate für das Bauspardarlehen');
  });
  it('Abgleich: Zeitpunkt grün, Betrag grün, Zuteilungsreife gelb (Mindestsparguthaben erst nach dem genannten Termin)', () => {
    expect(p.checks.map((c) => [c.label, c.status])).toEqual([
      ['Zeitpunkt', 'gruen'],
      ['Betrag', 'gruen'],
      ['Zuteilungsreife', 'gelb'],
    ]);
    expect(p.minReached! > '2027-10-01').toBe(true);
  });
  it('Jahresübersicht mit Nettoschuld = Restschuld − Guthaben', () => {
    expect(p.years[0]).toMatchObject({ year: 2026, phase: 'Ansparen', debt: 3890000 });
    expect(p.years[0].net).toBe(p.years[0].debt - p.years[0].balance);
    expect(p.years.find((y) => y.year === 2028)!.phase).toBe('Bauspardarlehen');
  });
  it('ohne Zuteilungstermin: Ablösung, sobald das Mindestsparguthaben erreicht ist', () => {
    const q = projectBauspar(bs({ allocation: null }), l, st, 1000000, TODAY);
    expect(q.payoff).toBe(q.minReached);
  });
});

describe('Bausparvertrag „Zinsen und Tilgung“', () => {
  const l = loan({
    kind: 'annuitaet',
    rate: 50000,
    rateMilli: 3000,
    fixedUntil: '2030-12-31',
    snapshots: [{ date: TODAY, balance: 10000000 }],
  });
  const st = loanState(l, [], TODAY);
  it('Ablösung zum Zinsbindungsende, frühestens zur Zuteilung; Lücke wird benannt', () => {
    const p = projectBauspar(
      bs({ type: 'tilgung', sum: 6000000, allocation: '2029-06-01', loanRate: 40000 }),
      l,
      st,
      2000000,
      TODAY,
    );
    expect(p.payoff).toBe('2030-12-31');
    expect(p.debtAt).toBeLessThan(10000000);
    expect(p.gap).toBe(p.debtAt - p.balanceAt - p.bauLoan);
    expect(p.checks.find((c) => c.label === 'Betrag')!.status).toBe(p.gap > 0 ? 'gelb' : 'gruen');
    expect(p.checks[0].status).toBe('gruen');
  });
  it('Zuteilung nach dem Zinsbindungsende: rot, Zwischenlösung nötig', () => {
    const p = projectBauspar(
      bs({ type: 'tilgung', allocation: '2031-06-01' }),
      l,
      st,
      2000000,
      TODAY,
    );
    expect(p.checks[0]).toMatchObject({ status: 'rot' });
    expect(p.payoff).toBe('2031-06-01');
  });
  it('Erkennungshilfe: Rate = Zinsen → „Nur Zinsen“; abweichende Wahl wird benannt', () => {
    expect(suggestType(l, st)).toBe('tilgung');
    const zinsOnly = loan({
      kind: 'annuitaet',
      rate: 25000,
      rateMilli: 3000,
      snapshots: [{ date: TODAY, balance: 10000000 }],
    });
    expect(suggestType(zinsOnly, loanState({ ...zinsOnly, kind: 'voraus' }, [], TODAY))).toBe(
      'zinsen',
    );
    expect(projectBauspar(bs({ type: 'zinsen' }), l, st, 2000000, TODAY).mismatch).toContain(
      'Zinsen und Tilgung',
    );
  });
});

describe('Bausparvertrag: Kosten und Vergleich mit der Übersicht der Bausparkasse', () => {
  it('Beispiel der Nutzerin: 200.000 €, 600 € Sparrate, Zuteilung 12/2028, 2,35 %, 800 € Rate', () => {
    const v = loan({ snapshots: [{ date: TODAY, balance: 20000000 }], rateMilli: 3000 });
    const p = projectBauspar(
      bs({
        sum: 20000000,
        savingRate: 60000,
        minMilli: 30000,
        allocation: '2028-12-01',
        loanMilli: 2350,
        loanRate: 80000,
      }),
      v,
      loanState(v, [], TODAY),
      6500000,
      TODAY,
    );
    expect(Math.round(p.balanceAt / 100000)).toBe(80);
    expect(p.bauLoanEnd!.slice(0, 7)).toBe('2043-10');
    expect(Math.round(p.bauInterest / 100000)).toBe(22);
    expect(p.story.join(' ')).toContain('kostet insgesamt voraussichtlich');
  });
});

describe('Vergleich mit der Finanzierungsübersicht', () => {
  const p = {
    balanceAt: 8015175,
    bauLoan: 11984825,
    bauLoanEnd: '2043-10-01',
    bauInterest: 2215029,
  };
  it('kleine Abweichungen sind stimmig, größere werden markiert', () => {
    const rows = compareContract(
      bs({
        contract: { balanceAt: 8000000, bauLoan: 11970000, end: '2043-10-01', interest: 2200000 },
      }),
      p,
    );
    expect(rows.map((r) => [r.label, r.diff, r.ok])).toEqual([
      ['Guthaben zur Zuteilung', 15175, true],
      ['Bauspardarlehen', 14825, true],
      ['Tilgungsende', 0, true],
      ['Darlehenszinsen gesamt', 15029, true],
    ]);
    const off = compareContract(
      bs({ contract: { balanceAt: null, bauLoan: null, end: '2040-01-01', interest: 100 } }),
      p,
    );
    expect(off.map((r) => [r.label, r.diff, r.ok])).toEqual([
      ['Tilgungsende', 45, false],
      ['Darlehenszinsen gesamt', 2214929, false],
    ]);
    expect(compareContract(bs({ contract: null }), p)).toEqual([]);
  });
});
