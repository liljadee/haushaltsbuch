import { describe, expect, it } from 'vitest';
import { RecurringItem, occurrences } from '../recurring/recurring';
import { Bauspar } from './bauspar';
import { withLoanSchedules } from './forecast-schedules';
import { Loan, defaultSpecial } from './loan';

const TODAY = '2026-11-19';
const item = (x: Partial<RecurringItem>): RecurringItem =>
  ({
    id: 'r',
    label: 'Kreditrate',
    accountId: 'g',
    amount: -30000,
    categoryId: 'a-kredite',
    subCategory: null,
    pattern: 'kreditrate auto',
    interval: 'monat',
    day: 1,
    months: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
    variable: false,
    active: true,
    transferTo: null,
    ...x,
  }) as RecurringItem;
const loan = (x: Partial<Loan>): Loan => ({
  id: 'a',
  name: 'Autokredit',
  kind: 'raten',
  bank: '',
  accountId: 'g',
  pattern: 'Kreditrate Autokredit',
  specialPattern: '',
  rate: 30000,
  day: 1,
  rateMilli: 6000,
  effMilli: null,
  fixedUntil: null,
  endDate: '2027-03-01',
  followMilli: 4000,
  finalPayment: null,
  principal: null,
  special: defaultSpecial('raten'),
  snapshots: [{ date: TODAY, balance: 100000 }],
  paidOff: null,
  recurringId: 'r',
  order: 0,
  ...x,
});

describe('Kreditraten termingenau in der Prognose (18.3)', () => {
  it('Zahlungsplan und letzter Monat werden bei den Terminen beachtet', () => {
    expect(
      occurrences(
        item({
          schedule: [
            { date: '2026-12-01', amount: -30000 },
            { date: '2027-01-01', amount: -12345 },
          ],
        }),
        TODAY,
        '2027-06-30',
      ).map((o) => [o.nominal, o.amount]),
    ).toEqual([
      ['2026-12-01', -30000],
      ['2027-01-01', -12345],
    ]);
    expect(
      occurrences(item({ endMonth: '2027-01' }), TODAY, '2027-06-30').map((o) => o.nominal),
    ).toEqual(['2026-12-01', '2027-01-01']);
  });
  it('Ratenkredit: nach der letzten Rate keine Rate mehr; die letzte ist kleiner', () => {
    const [r] = withLoanSchedules([item({})], [loan({})], [], [], TODAY);
    expect(r.schedule!.map((e) => e.date)).toEqual([
      '2026-12-01',
      '2027-01-01',
      '2027-02-01',
      '2027-03-01',
    ]);
    expect(-r.schedule!.at(-1)!.amount).toBeLessThan(30000);
  });
  it('tilgungsfreie Zeit: zuerst nur Zinsen, danach die volle Rate', () => {
    const k = loan({
      kind: 'foerder',
      rate: 60000,
      rateMilli: 1450,
      endDate: null,
      interestOnlyUntil: '2027-02-28',
      snapshots: [{ date: TODAY, balance: 5000000 }],
    });
    const [r] = withLoanSchedules([item({ amount: -60000 })], [k], [], [], TODAY);
    expect(r.schedule!.slice(0, 5).map((e) => e.amount)).toEqual([
      -6042, -6042, -6042, -60000, -60000,
    ]);
  });
  it('Vorausdarlehen mit Bausparvertrag: Zinsen und Sparrate enden mit der Ablösung, danach Rate des Bauspardarlehens', () => {
    const v = loan({
      id: 'v',
      kind: 'voraus',
      rate: 0,
      rateMilli: 3600,
      endDate: null,
      day: 30,
      snapshots: [{ date: TODAY, balance: 3890000 }],
    });
    const b: Bauspar = {
      id: 'b',
      name: 'LBS',
      accountId: 'bs',
      loanId: 'v',
      sum: 3890000,
      savingRate: 20000,
      savingsMilli: 100,
      minMilli: 0,
      allocation: '2027-03-01',
      loanMilli: 2500,
      loanRate: 24000,
      type: 'zinsen',
      rateUntilAllocation: 'ja',
      order: 0,
    };
    const spar = item({ id: 's', amount: -20000, transferTo: 'bs', pattern: 'sparen lbs' });
    const out = withLoanSchedules(
      [item({ amount: -11670 }), spar],
      [v],
      [{ b, balance: 1000000 }],
      [],
      TODAY,
    );
    expect(out[0].schedule!.at(-1)!.date <= '2027-03-01').toBe(true);
    expect(out[1].endMonth).toBe('2027-03');
    expect(out[2]).toMatchObject({ label: 'Rate Bauspardarlehen LBS (geplant)', accountId: 'g' });
    expect(out[2].schedule![0]).toEqual({ date: '2027-03-30', amount: -24000 });
  });
});
