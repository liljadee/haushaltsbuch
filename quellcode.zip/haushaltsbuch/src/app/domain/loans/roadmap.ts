import { Cents, formatEuro } from '../shared/money';
import { LocalDate } from '../shared/local-date';
import { Loan } from './loan';
import { SpecialResult } from './special-plan';

/**
 * Fahrplan der Kredite: was wann auf dich zukommt, nach dem gewählten Sondertilgungsplan.
 * Vor allem: wann wie viel Restschuld anschlussfinanziert werden muss.
 */
export interface RoadmapItem {
  date: LocalDate;
  kind: 'zinsbindung' | 'abloesung' | 'tilgungsfrei' | 'getilgt';
  loanId: string;
  title: string;
  text: string;
  /** nachzufinanzierender Betrag (Zinsbindungsende, Lücke nach der Bauspar-Ablösung) */
  refinance: Cents | null;
}

export function roadmap(result: SpecialResult, loans: Loan[], today: LocalDate): RoadmapItem[] {
  const out: RoadmapItem[] = [];
  const name = (id: string) => result.names[id] ?? loans.find((l) => l.id === id)?.name ?? 'Kredit';
  const replaced = new Set(result.replacements.map((r) => r.loanId));
  for (const f of result.fixedEnds)
    out.push({
      date: f.date,
      kind: 'zinsbindung',
      loanId: f.loanId,
      title: `${name(f.loanId)}: Zinsbindung endet`,
      text: f.fromReserve
        ? `Restschuld ${formatEuro(f.debt)}, davon ${formatEuro(f.fromReserve)} aus der Sondertilgungsrücklage.`
        : `Restschuld ${formatEuro(f.debt)}.`,
      refinance: f.remaining,
    });
  for (const r of result.replacements)
    out.push({
      date: r.date,
      kind: 'abloesung',
      loanId: r.loanId,
      title: `${name(r.loanId)}: Ablösung durch den Bausparvertrag`,
      text: `Bauspardarlehen ${formatEuro(r.bauLoan)}${r.gap ? '; der Rest braucht eine Anschlussfinanzierung' : '; Guthaben und Bauspardarlehen reichen'}.`,
      refinance: r.gap || null,
    });
  for (const l of loans)
    if (l.interestOnlyUntil && l.interestOnlyUntil >= today)
      out.push({
        date: l.interestOnlyUntil,
        kind: 'tilgungsfrei',
        loanId: l.id,
        title: `${l.name}: tilgungsfreie Zeit endet`,
        text: `Ab dann ${formatEuro(l.rate)} Rate im Monat mit Tilgung.`,
        refinance: null,
      });
  for (const [id, d] of Object.entries(result.payoffs)) {
    if (!d || replaced.has(id)) continue;
    const rootLoan = loans.find((l) => l.id === id.replace(/-(bau|anschluss)$/, ''));
    out.push({
      date: d,
      kind: 'getilgt',
      loanId: id,
      title: `${name(id)} getilgt`,
      text: `Die Rate von ${formatEuro(result.rates[id] ?? 0)} entfällt${rootLoan?.forwardRate ? ' und fließt in die Sondertilgungsrücklage' : ''}.`,
      refinance: null,
    });
  }
  return out.filter((x) => x.date >= today).sort((a, b) => a.date.localeCompare(b.date));
}
