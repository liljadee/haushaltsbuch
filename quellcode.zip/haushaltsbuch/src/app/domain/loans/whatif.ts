import { Cents } from '../shared/money';
import { LocalDate } from '../shared/local-date';
import { Loan, LoanState, plan } from './loan';

/** Was-wäre-wenn (Lastenheft 18.7): einmalige Sondertilgung oder dauerhafte Ratenerhöhung. */
export interface WhatIfResult {
  payoff: LocalDate | null;
  interest: Cents;
  atFixedEnd: Cents | null;
  basePayoff: LocalDate | null;
  baseInterest: Cents;
  baseAtFixedEnd: Cents | null;
  error: string | null;
}

function fixedEnd(
  loan: Loan,
  rows: { date: LocalDate; balance: Cents }[],
  start: Cents,
): Cents | null {
  if (!loan.fixedUntil) return null;
  return [...rows].reverse().find((r) => r.date <= loan.fixedUntil!)?.balance ?? start;
}

export function whatIf(
  loan: Loan,
  state: LoanState,
  today: LocalDate,
  opt: { extra?: { date: LocalDate; amount: Cents } | null; rateIncrease?: Cents },
): WhatIfResult {
  const start = { date: today, balance: state.balance };
  const base = plan(loan, start);
  const changed = plan(
    { ...loan, rate: loan.rate + (opt.rateIncrease ?? 0) },
    start,
    opt.extra ? [opt.extra] : [],
  );
  return {
    payoff: changed.payoff,
    interest: changed.totalInterest,
    atFixedEnd: fixedEnd(loan, changed.rows, state.balance),
    basePayoff: base.payoff,
    baseInterest: base.totalInterest,
    baseAtFixedEnd: fixedEnd(loan, base.rows, state.balance),
    error: changed.error,
  };
}

/** Annuitätenrate, mit der eine Restschuld in n Monaten getilgt ist (aufgerundet auf den Cent) */
export function annuity(balance: Cents, milli: number, months: number): Cents {
  if (months <= 0) return balance;
  const i = milli / 1200000;
  return Math.ceil(i === 0 ? balance / months : (balance * i) / (1 - Math.pow(1 + i, -months)));
}

export interface FollowOption {
  milli: number;
  rateForWish: Cents | null;
  payoffSameRate: LocalDate | null;
  interest: Cents;
}
/** Anschlusszinssätze: Rate für ein Wunsch-Tilgungsende und Tilgungsende bei gleicher Rate */
export function followOptions(
  loan: Loan,
  state: LoanState,
  today: LocalDate,
  millis: number[],
  wishYear: number | null,
): FollowOption[] {
  if (!loan.fixedUntil) return [];
  const atEnd = state.atFixedEnd ?? state.balance;
  const [fy, fm] = [Number(loan.fixedUntil.slice(0, 4)), Number(loan.fixedUntil.slice(5, 7))];
  const months = wishYear ? (wishYear - fy) * 12 + (12 - fm) : 0;
  return millis.map((milli) => {
    const p = plan({ ...loan, followMilli: milli }, { date: today, balance: state.balance });
    return {
      milli,
      rateForWish: wishYear && months > 0 ? annuity(atEnd, milli, months) : null,
      payoffSameRate: p.error ? null : p.payoff,
      interest: p.totalInterest,
    };
  });
}
