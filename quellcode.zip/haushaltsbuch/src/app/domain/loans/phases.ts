import { monthYear } from '../shared/format';
import { Cents, formatEuro } from '../shared/money';
import { LocalDate, formatDate } from '../shared/local-date';
import { Bauspar, BausparProjection } from './bauspar';
import { Loan, LoanState } from './loan';

/** Phasen eines Kredits als Zeitstrahl (Lastenheft 18.4), Klartext aus festen Textbausteinen und den Vertragsdaten. */
export interface Phase {
  from: LocalDate;
  title: string;
  text: string;
}

const pct = (milli: number) =>
  `${(milli / 1000).toLocaleString('de-DE', { maximumFractionDigits: 3 })} %`;
const nextDay = (d: LocalDate) => new Date(Date.parse(d) + 86400000).toISOString().slice(0, 10);
const interestOf = (balance: Cents, milli: number) => Math.round((balance * milli) / 1200000);

export function phases(
  loan: Loan,
  state: LoanState,
  today: LocalDate,
  bauspar: { b: Bauspar; p: BausparProjection } | null = null,
): Phase[] {
  if (loan.paidOff)
    return [
      { from: today, title: 'Abbezahlt', text: `Seit ${monthYear(loan.paidOff)} abbezahlt.` },
    ];
  const out: Phase[] = [];
  const balance = state.balance;
  if (loan.kind === 'voraus') {
    const interest = interestOf(balance, loan.rateMilli);
    const payoff = bauspar?.p.payoff;
    if (bauspar && payoff) {
      const { b, p } = bauspar;
      out.push({
        from: today,
        title: 'Ansparen, nur Zinsen fürs Darlehen',
        text: `Bis ${monthYear(payoff)} zahlst du monatlich ${formatEuro(interest)} Zinsen; die Restschuld bleibt bei ${formatEuro(balance)}. Dazu gehen ${formatEuro(b.savingRate)} im Monat in den Bausparvertrag.`,
      });
      out.push({
        from: payoff,
        title: 'Zuteilung und Ablösung',
        text: `Guthaben von voraussichtlich ${formatEuro(p.balanceAt)} und Bauspardarlehen über ${formatEuro(p.bauLoan)} lösen das Darlehen ab${p.gap ? `; für die übrigen ${formatEuro(p.gap)} braucht es eine Anschlussfinanzierung` : ''}.`,
      });
      if (p.bauLoan)
        out.push({
          from: nextDay(payoff),
          title: 'Bauspardarlehen',
          text: `${formatEuro(b.loanRate)} Rate im Monat zu ${pct(b.loanMilli)}${p.bauLoanEnd ? `, getilgt voraussichtlich ${monthYear(p.bauLoanEnd)}` : ''}.`,
        });
      if (p.bauLoanEnd)
        out.push({
          from: p.bauLoanEnd,
          title: 'Getilgt',
          text: `Danach entfällt die Rate von ${formatEuro(b.loanRate)}${p.gap ? '; die Anschlussfinanzierung für die Lücke läuft getrennt weiter' : ''}.`,
        });
      return out;
    }
    out.push({
      from: today,
      title: 'Nur Zinsen',
      text: `Du zahlst monatlich ${formatEuro(interest)} Zinsen; die Restschuld bleibt bei ${formatEuro(balance)}.${loan.endDate ? ` Am ${formatDate(loan.endDate)} ist sie auf einmal fällig.` : ''} Wird das Darlehen durch einen Bausparvertrag abgelöst, verknüpfe ihn, dann zeigt der Zeitstrahl den ganzen Ablauf.`,
    });
    return out;
  }
  if (loan.interestOnlyUntil && loan.interestOnlyUntil >= today)
    out.push({
      from: today,
      title: 'Tilgungsfreie Zeit',
      text: `Bis ${formatDate(loan.interestOnlyUntil)} zahlst du nur Zinsen, rund ${formatEuro(interestOf(balance, loan.rateMilli))} im Monat; die Restschuld bleibt bei ${formatEuro(balance)}.`,
    });
  const start =
    loan.interestOnlyUntil && loan.interestOnlyUntil >= today
      ? nextDay(loan.interestOnlyUntil)
      : today;
  if (loan.fixedUntil && loan.fixedUntil >= today) {
    out.push({
      from: start,
      title: 'Zinsbindung',
      text: `Bis ${formatDate(loan.fixedUntil)}: ${formatEuro(loan.rate)} Rate im Monat zu ${pct(loan.rateMilli)}; Restschuld dann voraussichtlich ${formatEuro(state.atFixedEnd ?? balance)}.`,
    });
    if (state.payoff && state.payoff > loan.fixedUntil)
      out.push({
        from: nextDay(loan.fixedUntil),
        title: 'Anschlussfinanzierung',
        text: `Angenommen ${pct(loan.followMilli)} Zins bei gleicher Rate; getilgt voraussichtlich ${monthYear(state.payoff)}. Den echten Zins kennst du erst mit dem Angebot; „Was wäre wenn“ zeigt andere Sätze.`,
      });
  } else if ((loan.kind === 'raten' || loan.kind === 'schlussrate') && loan.endDate) {
    const last = state.plan.rows.at(-1);
    out.push({
      from: start,
      title: 'Laufzeit',
      text: `Bis ${formatDate(loan.endDate)}: ${formatEuro(loan.rate)} Rate im Monat zu ${pct(loan.rateMilli)}${loan.kind === 'schlussrate' && last ? `; am Ende Schlussrate ${formatEuro(last.payment)}` : ''}.`,
    });
  } else {
    out.push({
      from: start,
      title: 'Tilgung',
      text: `${formatEuro(loan.rate)} Rate im Monat zu ${pct(loan.rateMilli)}${state.payoff ? `; getilgt voraussichtlich ${monthYear(state.payoff)}` : ''}.`,
    });
  }
  if (state.payoff)
    out.push({
      from: state.payoff,
      title: 'Getilgt',
      text: `Danach entfällt die Rate von ${formatEuro(loan.rate)}.`,
    });
  return out;
}
