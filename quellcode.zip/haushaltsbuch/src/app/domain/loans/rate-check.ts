import { Booking } from '../bookings/booking';
import { normalizeText } from '../categories/rules';
import { Cents, formatEuro } from '../shared/money';
import { LocalDate, formatDate } from '../shared/local-date';
import { Loan, isRate, isSpecial } from './loan';

/**
 * Prüfung der Raten (Lastenheft 18.3): ausgebliebene und doppelte Raten der letzten Monate,
 * unerwartete Zahlungen an die Bank als mögliche Sondertilgung.
 */
export interface RateIssue {
  kind: 'ausgeblieben' | 'doppelt' | 'unerwartet';
  date: LocalDate;
  title: string;
  text: string;
  bookingIds: string[];
  amount: Cents | null;
}

const day = 86400000;
const shift = (d: LocalDate, days: number) =>
  new Date(Date.parse(d) + days * day).toISOString().slice(0, 10);
function dueIn(month: string, dayOfMonth: number): LocalDate {
  const [y, m] = month.split('-').map(Number);
  return `${month}-${String(Math.min(dayOfMonth, new Date(Date.UTC(y, m, 0)).getUTCDate())).padStart(2, '0')}`;
}
const prevMonth = (month: string) => {
  const [y, m] = month.split('-').map(Number);
  return m === 1 ? `${y - 1}-12` : `${y}-${String(m - 1).padStart(2, '0')}`;
};

export function rateIssues(
  loan: Loan,
  bookings: Booking[],
  today: LocalDate,
  months = 6,
): RateIssue[] {
  if (loan.paidOff) return [];
  const out: RateIssue[] = [];
  const since = loan.snapshots.map((s) => s.date).sort()[0] ?? today;
  const onAccount = bookings.filter(
    (b) => b.accountId === loan.accountId && b.status !== 'geplant',
  );
  const rates = bookings.filter((b) => isRate(loan, b));
  // Fälligkeiten der letzten Monate; erst 7 Tage nach Fälligkeit und nur, wenn danach schon Umsätze eingelesen sind
  let month = today.slice(0, 7);
  for (let i = 0; i < months + 1; i++, month = prevMonth(month)) {
    const due = dueIn(month, loan.day);
    if (due < since || shift(due, 7) > today || (loan.endDate && due > loan.endDate)) continue;
    if (!onAccount.some((b) => b.date >= shift(due, 7))) continue;
    const near = rates.filter((b) => Math.abs(Date.parse(b.date) - Date.parse(due)) <= 10 * day);
    if (!near.length)
      out.push({
        kind: 'ausgeblieben',
        date: due,
        title: `${loan.name}: Rate zum ${formatDate(due)} nicht gefunden`,
        text: 'Prüfe den Kontoauszug: Fehlt die Buchung im Import, oder wurde die Rate nicht abgebucht?',
        bookingIds: [],
        amount: null,
      });
    else if (near.length >= 2 && near.filter((b) => b.amount === near[0].amount).length >= 2)
      out.push({
        kind: 'doppelt',
        date: due,
        title: `${loan.name}: Rate zum ${formatDate(due)} doppelt`,
        text: `Zweimal ${formatEuro(-near[0].amount)} gebucht. Doppelt eingelesen oder doppelt abgebucht?`,
        bookingIds: near.map((b) => b.id),
        amount: -near[0].amount,
      });
  }
  // unerwartete Zahlungen an die Bank: Text nennt Bank oder Kredit, ist aber weder Rate noch Sondertilgung
  const keys = [loan.bank, loan.name]
    .map((k) => normalizeText(k ?? ''))
    .filter((k) => k.length >= 3);
  const yearAgo = shift(today, -365);
  for (const b of bookings) {
    if (
      b.amount >= -5000 ||
      b.kind !== 'ausgabe' ||
      b.status === 'geplant' ||
      b.date < yearAgo ||
      b.date < since
    )
      continue;
    if (isRate(loan, b) || isSpecial(loan, b) || loan.dismissedPayments?.includes(b.id)) continue;
    const text = normalizeText(b.text);
    if (!keys.some((k) => text.includes(k))) continue;
    out.push({
      kind: 'unerwartet',
      date: b.date,
      title: `${loan.name}: mögliche Sondertilgung über ${formatEuro(-b.amount)}`,
      text: `Zahlung am ${formatDate(b.date)} („${b.text}“). Ist das eine Sondertilgung? Dann zählt sie für Restschuld und Sondertilgungsrecht.`,
      bookingIds: [b.id],
      amount: -b.amount,
    });
  }
  return out.sort((a, b) => b.date.localeCompare(a.date));
}
