import { Booking } from '../bookings/booking';
import { Cents } from '../shared/money';
import { LocalDate } from '../shared/local-date';
import { Loan, isRate, isSpecial } from './loan';

/**
 * Bisherige Sondertilgungen je Kalenderjahr (Szenario B, Lastenheft 18.4): Median der abgeschlossenen Jahre,
 * ohne einmalige Ausreißer. Ein Jahr zählt, wenn darin Raten gebucht sind (sonst fehlen die Daten).
 */
export interface SpecialHistory {
  years: { year: number; amount: Cents; outlier: boolean }[];
  median: Cents;
  /** weniger als zwei Jahre Historie */
  uncertain: boolean;
}

export function specialHistory(loan: Loan, bookings: Booking[], today: LocalDate): SpecialHistory {
  const lastYear = Number(today.slice(0, 4)) - 1;
  const covered = new Set(
    bookings.filter((b) => isRate(loan, b)).map((b) => Number(b.date.slice(0, 4))),
  );
  const sums = new Map<number, Cents>();
  for (const b of bookings)
    if (isSpecial(loan, b))
      sums.set(Number(b.date.slice(0, 4)), (sums.get(Number(b.date.slice(0, 4))) ?? 0) - b.amount);
  const years = [...new Set([...covered, ...sums.keys()])]
    .filter((y) => y <= lastYear)
    .sort((a, b) => a - b);
  const amounts = years.map((y) => sums.get(y) ?? 0);
  // einmaliger Ausreißer: genau ein Jahr mit mehr als dem Doppelten des Medians der übrigen (ab drei Jahren)
  let outlierYear: number | null = null;
  if (years.length >= 3) {
    const max = Math.max(...amounts),
      i = amounts.indexOf(max);
    const others = amounts.filter((_, k) => k !== i);
    if (max > 2 * median(others) && amounts.filter((a) => a === max).length === 1)
      outlierYear = years[i];
  }
  const kept = years.filter((y) => y !== outlierYear).map((y) => sums.get(y) ?? 0);
  return {
    years: years.map((y) => ({ year: y, amount: sums.get(y) ?? 0, outlier: y === outlierYear })),
    median: kept.length ? median(kept) : 0,
    uncertain: years.length < 2,
  };
}

function median(values: Cents[]): Cents {
  if (!values.length) return 0;
  const s = [...values].sort((a, b) => a - b),
    m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m] : Math.round((s[m - 1] + s[m]) / 2);
}
