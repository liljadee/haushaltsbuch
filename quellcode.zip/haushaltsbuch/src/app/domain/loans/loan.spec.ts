import { describe, expect, it } from 'vitest';
import { Booking } from '../bookings/booking';
import {
  Loan,
  defaultSpecial,
  isRate,
  isSpecial,
  loanState,
  plan,
  specialPatternFor,
  validate,
  yearEnds,
} from './loan';

const TODAY = '2026-11-19';
const base: Loan = {
  id: 'h',
  name: 'Hauskredit',
  kind: 'annuitaet',
  bank: 'Sparkasse',
  accountId: 'g',
  pattern: 'Kreditrate Hauskredit',
  specialPattern: 'Sondertilgung Hauskredit',
  rate: 50000,
  day: 30,
  rateMilli: 3000,
  effMilli: 3040,
  fixedUntil: '2031-12-31',
  endDate: null,
  followMilli: 4000,
  finalPayment: null,
  principal: 12000000,
  special: defaultSpecial('annuitaet'),
  snapshots: [{ date: TODAY, balance: 10000000 }],
  paidOff: null,
  recurringId: null,
  order: 0,
};
const bk = (id: string, date: string, amount: number, text = 'Kreditrate Hauskredit'): Booking => ({
  id,
  accountId: 'g',
  kind: 'ausgabe',
  status: 'gebucht',
  amount,
  date,
  seq: 1,
  text,
  splits: [{ categoryId: 'a-kredite', subCategory: null, amount }],
  confidence: 'sicher',
  source: { type: 'xlsx' },
});

describe('Tilgungsplan (Lastenheft 18.3, 18.4)', () => {
  it('Annuität: Zinsen = Restschuld × Sollzins ÷ 12, Tilgung = Rate − Zinsen', () => {
    const p = plan(base, base.snapshots[0]);
    expect(p.rows[0]).toEqual({
      date: '2026-11-30',
      payment: 50000,
      interest: 25000,
      principal: 25000,
      extra: 0,
      balance: 9975000,
    });
    expect(p.rows[1].interest).toBe(24938);
    expect(p.error).toBeNull();
    expect(p.payoff! > '2040-01-01').toBe(true);
  });
  it('nach der Zinsbindung rechnet der Plan mit dem Anschlusszins', () => {
    const p = plan(base, base.snapshots[0]);
    const before = p.rows.find((r) => r.date === '2031-12-30')!,
      after = p.rows.find((r) => r.date === '2032-01-30')!;
    expect(after.interest).toBe(Math.round((before.balance * 4000) / 1200000));
  });
  it('0-%-Kredit: 1.000 € mit 100 € Rate in 10 Monaten abbezahlt', () => {
    const p = plan(
      { ...base, kind: 'null', rateMilli: 0, rate: 10000 },
      { date: TODAY, balance: 100000 },
    );
    expect([p.rows.length, p.payoff, p.totalInterest]).toEqual([10, '2027-08-30', 0]);
  });
  it('Sondertilgung verkürzt die Laufzeit', () => {
    const p0 = plan(base, base.snapshots[0]),
      p1 = plan(base, base.snapshots[0], [{ date: '2027-06-15', amount: 500000 }]);
    expect(p1.payoff! < p0.payoff!).toBe(true);
    expect(p1.rows.find((r) => r.date === '2027-06-30')!.extra).toBe(500000);
  });
  it('Vorausdarlehen: nur Zinsen, Restschuld bleibt bis zum Laufzeitende', () => {
    const v = { ...base, kind: 'voraus' as const, rate: 0, endDate: '2027-10-30', rateMilli: 3600 };
    const p = plan(v, { date: TODAY, balance: 3890000 });
    expect(p.rows[0]).toMatchObject({ interest: 11670, principal: 0, balance: 3890000 });
    expect(p.rows.at(-1)).toMatchObject({ date: '2027-10-30', principal: 3890000, balance: 0 });
  });
  it('Plausibilität: Rate unter den Zinsen wird nicht gespeichert', () => {
    expect(validate({ ...base, rate: 20000 })).toContain('deckt die Zinsen');
    expect(validate(base)).toBeNull();
    expect(validate({ ...base, kind: 'raten', endDate: '2028-01-31' })).toContain('Laufzeitende');
  });
});

describe('Raten zuordnen und aufteilen', () => {
  it('erkennt Raten und Sondertilgungen am Buchungstext', () => {
    expect(isRate(base, bk('a', '2026-10-30', -50000))).toBe(true);
    expect(isRate(base, bk('b', '2026-10-30', -50000, 'Kreditrate Autokredit'))).toBe(false);
    expect(isSpecial(base, bk('c', '2026-10-30', -500000, 'Sondertilgung Hauskredit'))).toBe(true);
    expect(isRate(base, bk('c', '2026-10-30', -500000, 'Sondertilgung Hauskredit'))).toBe(false);
    expect(specialPatternFor('Kreditrate Hauskredit')).toBe('Sondertilgung Hauskredit');
  });
  it('teilt frühere Raten rückwärts vom Stand laut Bank auf, spätere vorwärts', () => {
    const loan = { ...base, snapshots: [{ date: '2026-10-31', balance: 9950000 }] };
    const data = [
      bk('aug', '2026-08-30', -50000),
      bk('sep', '2026-09-30', -50000),
      bk('okt', '2026-10-30', -50000),
      bk('nov', '2026-11-30', -50000),
    ];
    const s = loanState(loan, data, '2026-12-05');
    expect(s.splits['okt']).toEqual({ interest: 24938, principal: 25062 });
    expect(s.splits['nov']).toEqual({ interest: 24875, principal: 25125 });
    expect(s.splits['aug'].interest).toBeGreaterThan(s.splits['okt'].interest);
    expect(s.balance).toBe(9950000 - 25125);
    expect(s.paidInterest).toBe(Object.values(s.splits).reduce((t, x) => t + x.interest, 0));
  });
  it('zeigt die Abweichung zum neuen Stand laut Bank und übernimmt den Bankwert', () => {
    const loan = {
      ...base,
      snapshots: [
        { date: '2026-10-31', balance: 9950000 },
        { date: '2026-12-01', balance: 9920000 },
      ],
    };
    const s = loanState(loan, [bk('nov', '2026-11-30', -50000)], '2026-12-05');
    expect(s.deviation).toEqual({ date: '2026-12-01', bank: 9920000, computed: 9924875 });
    expect(s.balance).toBe(9920000);
  });
  it('Sondertilgungen senken die Restschuld; ohne Buchung zieht der Plan fällige Raten ab', () => {
    const loan = { ...base, snapshots: [{ date: '2026-09-30', balance: 10000000 }] };
    const s = loanState(
      loan,
      [bk('st', '2026-10-15', -1000000, 'Sondertilgung Hauskredit')],
      '2026-11-19',
    );
    expect(s.specialPaid).toBe(1000000);
    expect(s.balance).toBe(9000000 - (50000 - 22500));
  });
  it('Jahresenden für das Schuldendiagramm', () => {
    const p = plan(
      { ...base, kind: 'null', rateMilli: 0, rate: 10000 },
      { date: TODAY, balance: 100000 },
    );
    expect(yearEnds(p, 100000, TODAY)).toEqual([
      { year: 2026, balance: 80000 },
      { year: 2027, balance: 0 },
    ]);
  });
});

describe('Tilgungsfreie Anlaufjahre (KfW)', () => {
  const kfw: Loan = {
    ...base,
    id: 'k',
    name: 'KfW',
    kind: 'foerder',
    rate: 60000,
    rateMilli: 1450,
    interestOnlyUntil: '2027-12-31',
    fixedUntil: '2036-12-31',
    snapshots: [{ date: TODAY, balance: 5000000 }],
  };
  it('bis zum Ende der tilgungsfreien Zeit nur Zinsen, danach die volle Rate', () => {
    const p = plan(kfw, kfw.snapshots[0]);
    expect(p.rows[0]).toMatchObject({
      payment: 6042,
      interest: 6042,
      principal: 0,
      balance: 5000000,
    });
    const jan = p.rows.find((r) => r.date === '2028-01-30')!;
    expect(jan).toMatchObject({ payment: 60000, interest: 6042, principal: 53958 });
    expect(validate(kfw)).toBeNull();
  });
  it('gebuchte Zinszahlungen in der tilgungsfreien Zeit werden ganz als Zinsen gezählt', () => {
    const s = loanState(
      { ...kfw, snapshots: [{ date: '2026-10-31', balance: 5000000 }] },
      [bk('z', '2026-11-30', -6042, 'Kreditrate Hauskredit')],
      '2026-12-05',
    );
    expect(s.splits['z']).toEqual({ interest: 6042, principal: 0 });
  });
});

describe('Abnahme: Ratenkredit und Tilgungsplan wie bei der Bank (AK-29, AK-27)', () => {
  it('Ratenkredit, dessen Plan zum Laufzeitende nicht bei 0 € endet: Eingabe wird beanstandet', () => {
    const r = {
      ...base,
      id: 'r',
      kind: 'raten' as const,
      rate: 10000,
      rateMilli: 6000,
      fixedUntil: null,
      endDate: '2027-06-30',
      snapshots: [{ date: TODAY, balance: 1000000 }],
    };
    expect(validate(r)).toContain('zum Laufzeitende nicht abbezahlt');
  });
  it('Tilgungsplan wie bei der Bank: je Jahr höchstens 1 € Abweichung von der Annuitätenformel', () => {
    const l = {
      ...base,
      id: 'a',
      kind: 'annuitaet' as const,
      rate: 100000,
      rateMilli: 3000,
      fixedUntil: null,
      endDate: null,
      snapshots: [{ date: '2026-01-01', balance: 10000000 }],
    };
    const p = plan(l, l.snapshots[0]);
    const i = 0.03 / 12;
    for (let year = 1; year <= 5; year++) {
      const n = year * 12;
      const formula = 100000 * Math.pow(1 + i, n) - 1000 * ((Math.pow(1 + i, n) - 1) / i);
      expect(Math.abs(p.rows[n - 1].balance / 100 - formula)).toBeLessThanOrEqual(1);
    }
  });
});
