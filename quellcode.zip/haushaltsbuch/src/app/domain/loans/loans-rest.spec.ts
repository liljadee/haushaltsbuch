import { describe, expect, it } from 'vitest';
import { Booking } from '../bookings/booking';
import { Bauspar, extraPaymentEffect, projectBauspar } from './bauspar';
import { specialHistory } from './history';
import { Loan, defaultSpecial, isRate, isSpecial, loanState } from './loan';
import { phases } from './phases';
import { rateIssues } from './rate-check';
import { planSettlement } from './settlement';
import { simulate } from './special-plan';

const TODAY = '2026-11-19';
const loan = (x: Partial<Loan> = {}): Loan => ({
  id: 'h',
  name: 'Hauskredit',
  kind: 'annuitaet',
  bank: 'Sparkasse',
  accountId: 'g',
  pattern: 'Kreditrate Hauskredit',
  specialPattern: 'Sondertilgung Hauskredit',
  rate: 98000,
  day: 30,
  rateMilli: 2850,
  effMilli: null,
  fixedUntil: '2032-06-30',
  endDate: null,
  followMilli: 4000,
  finalPayment: null,
  principal: 25000000,
  special: defaultSpecial('annuitaet'),
  snapshots: [{ date: '2022-01-01', balance: 20000000 }],
  paidOff: null,
  recurringId: null,
  order: 0,
  ...x,
});
let seq = 0;
const bk = (date: string, amount: number, text: string, x: Partial<Booking> = {}): Booking => ({
  id: `b${++seq}`,
  accountId: 'g',
  kind: 'ausgabe',
  status: 'gebucht',
  amount,
  date,
  seq,
  text,
  splits: [],
  confidence: 'sicher',
  source: { type: 'email' },
  ...x,
});
const bs = (x: Partial<Bauspar> = {}): Bauspar => ({
  id: 'bs',
  name: 'LBS',
  accountId: 'bsk',
  loanId: 'v',
  sum: 20000000,
  savingRate: 60000,
  savingsMilli: 100,
  minMilli: 30000,
  allocation: '2028-12-01',
  loanMilli: 2350,
  loanRate: 80000,
  type: 'zinsen',
  rateUntilAllocation: 'ja',
  order: 0,
  ...x,
});
const V = loan({
  id: 'v',
  name: 'Vorfinanzierung',
  kind: 'voraus',
  rate: 0,
  rateMilli: 3000,
  fixedUntil: null,
  principal: null,
  special: defaultSpecial('voraus'),
  snapshots: [{ date: TODAY, balance: 20000000 }],
});

describe('Szenario B: bisherige Sondertilgungen (18.4)', () => {
  const rates = (y: number) => bk(`${y}-03-30`, -98000, 'Kreditrate Hauskredit');
  it('Median der abgeschlossenen Jahre ohne einmaligen Ausreißer', () => {
    const b = [
      rates(2022),
      rates(2023),
      rates(2024),
      rates(2025),
      bk('2022-12-15', -300000, 'Sondertilgung Hauskredit'),
      bk('2023-12-15', -500000, 'Sondertilgung Hauskredit'),
      bk('2024-12-15', -2500000, 'Sondertilgung Hauskredit'),
      bk('2025-12-15', -400000, 'Sondertilgung Hauskredit'),
      bk('2026-06-15', -900000, 'Sondertilgung Hauskredit'),
    ];
    const h = specialHistory(loan(), b, TODAY);
    expect(h.years.map((y) => [y.year, y.amount, y.outlier])).toEqual([
      [2022, 300000, false],
      [2023, 500000, false],
      [2024, 2500000, true],
      [2025, 400000, false],
    ]);
    expect([h.median, h.uncertain]).toEqual([400000, false]);
  });
  it('Jahre mit Raten, aber ohne Sondertilgung zählen mit 0 €; unter zwei Jahren unsicher', () => {
    expect(
      specialHistory(
        loan(),
        [rates(2024), rates(2025), bk('2025-12-15', -400000, 'Sondertilgung Hauskredit')],
        TODAY,
      ),
    ).toMatchObject({ median: 200000, uncertain: false });
    expect(specialHistory(loan(), [rates(2025)], TODAY)).toMatchObject({
      median: 0,
      uncertain: true,
    });
  });
  it('Szenario B in der Simulation: feste jährliche Sondertilgung im Dezember, ohne Budget', () => {
    const l = loan({ snapshots: [{ date: TODAY, balance: 20000000 }] });
    const inp = {
      loans: [{ loan: l, state: loanState(l, [], TODAY) }],
      pool: 0,
      monthly: 0,
      today: TODAY,
    };
    const a = simulate(inp, 'zins'),
      b = simulate({ ...inp, yearlyExtras: { h: 400000 } }, 'zins');
    expect(b.payments[0]).toMatchObject({ date: '2026-12-30', amount: 400000 });
    expect(b.debtFree! < a.debtFree!).toBe(true);
  });
});

describe('Phasen als Zeitstrahl (18.4)', () => {
  it('Zinsbindung, Anschlussfinanzierung, getilgt', () => {
    const l = loan({ snapshots: [{ date: TODAY, balance: 18240000 }] });
    const ph = phases(l, loanState(l, [], TODAY), TODAY);
    expect(ph.map((p) => p.title)).toEqual(['Zinsbindung', 'Anschlussfinanzierung', 'Getilgt']);
    expect(ph[0].text.replace(/\u00a0/g, ' ')).toContain(
      'Bis 30.06.2032: 980,00 € Rate im Monat zu 2,85 %',
    );
  });
  it('tilgungsfreie Zeit zuerst; Vorausdarlehen mit Bausparvertrag: Ansparen, Ablösung, Bauspardarlehen', () => {
    const k = loan({
      kind: 'foerder',
      interestOnlyUntil: '2027-12-31',
      fixedUntil: '2036-12-31',
      snapshots: [{ date: TODAY, balance: 5000000 }],
      rate: 60000,
      rateMilli: 1450,
    });
    expect(phases(k, loanState(k, [], TODAY), TODAY)[0].title).toBe('Tilgungsfreie Zeit');
    const st = loanState(V, [], TODAY);
    const p = projectBauspar(bs(), V, st, 6500000, TODAY);
    const ph = phases(V, st, TODAY, { b: bs(), p });
    expect(ph.map((x) => x.title)).toEqual([
      'Ansparen, nur Zinsen fürs Darlehen',
      'Zuteilung und Ablösung',
      'Bauspardarlehen',
      'Getilgt',
    ]);
    expect(ph[1].text).toContain('lösen das Darlehen ab');
  });
});

describe('Erkennung von Sondertilgungen ohne eigenen Erkennungstext', () => {
  it('leerer Text für Sondertilgungen: abgeleitet aus dem Ratentext', () => {
    const l = loan({ specialPattern: '' });
    expect([
      isSpecial(l, bk('2025-12-15', -400000, 'Sondertilgung Hauskredit')),
      isRate(l, bk('2025-12-15', -400000, 'Sondertilgung Hauskredit')),
    ]).toEqual([true, false]);
  });
});

describe('Raten prüfen (18.3)', () => {
  const l = loan({ snapshots: [{ date: '2026-01-01', balance: 20000000 }] });
  const months = [
    '2026-05-30',
    '2026-06-30',
    '2026-07-30',
    '2026-08-30',
    '2026-09-30',
    '2026-10-30',
  ];
  it('ausgebliebene und doppelte Raten; ohne eingelesene Umsätze danach keine Meldung', () => {
    const b = [
      ...months
        .filter((d) => d !== '2026-08-30')
        .map((d) => bk(d, -98000, 'Kreditrate Hauskredit')),
      bk('2026-10-30', -98000, 'Kreditrate Hauskredit'),
      bk('2026-11-15', -2000, 'Bäcker'),
    ];
    const issues = rateIssues(l, b, TODAY);
    expect(issues.map((i) => [i.kind, i.date])).toEqual([
      ['doppelt', '2026-10-30'],
      ['ausgeblieben', '2026-08-30'],
    ]);
    expect(
      rateIssues(
        l,
        b.filter((x) => x.text !== 'Bäcker' && x.date < '2026-10-01'),
        TODAY,
      ).map((i) => i.kind),
    ).toEqual(['ausgeblieben']);
  });
  it('unerwartete Zahlung an die Bank: mögliche Sondertilgung; bestätigt zählt sie als Sondertilgung, abgehakt verschwindet sie', () => {
    const pay = bk('2026-09-12', -500000, 'Sparkasse Darlehen 1234');
    const b = [
      ...months.map((d) => bk(d, -98000, 'Kreditrate Hauskredit')),
      pay,
      bk('2026-11-15', -2000, 'Bäcker'),
    ];
    const u = rateIssues(l, b, TODAY).filter((i) => i.kind === 'unerwartet');
    expect(u).toMatchObject([{ bookingIds: [pay.id], amount: 500000 }]);
    const confirmed = { ...l, confirmedSpecials: [pay.id] };
    expect([
      isSpecial(confirmed, pay),
      isRate(confirmed, pay),
      rateIssues(confirmed, b, TODAY).some((i) => i.kind === 'unerwartet'),
    ]).toEqual([true, false, false]);
    expect(
      rateIssues({ ...l, dismissedPayments: [pay.id] }, b, TODAY).some(
        (i) => i.kind === 'unerwartet',
      ),
    ).toBe(false);
    // Umbuchungen auf eigene Konten sind keine Zahlung an die Bank
    expect(
      rateIssues(l, [...b.filter((x) => x !== pay), { ...pay, kind: 'umbuchung' }], TODAY).some(
        (i) => i.kind === 'unerwartet',
      ),
    ).toBe(false);
  });
});

describe('Ablösung durch den Bausparvertrag (18.10)', () => {
  const input = {
    date: '2028-12-31',
    balancePaid: 8015000,
    bauLoan: 11985000,
    debt: 20000000,
    bauRate: 80000,
    bauMilli: 2350,
    bauDay: 30,
    bauSpecial: defaultSpecial('raten'),
    follow: null,
  };
  const ids = { bauLoanId: 'neu', bookingId: 'bk', seq: 1 };
  it('ohne Rest: Bauspardarlehen angelegt, Darlehen archiviert, Guthaben als Korrektur ausgebucht', () => {
    const r = planSettlement(V, bs(), 'bsk', input, ids);
    if ('error' in r) throw new Error(r.error);
    expect([r.remaining, r.archived, r.loan.paidOff, r.loan.snapshots.at(-1)]).toEqual([
      0,
      true,
      '2028-12',
      { date: '2028-12-31', balance: 0 },
    ]);
    expect(r.bauLoan).toMatchObject({
      name: 'Bauspardarlehen LBS',
      rate: 80000,
      rateMilli: 2350,
      snapshots: [{ date: '2028-12-31', balance: 11985000 }],
    });
    expect(r.booking).toMatchObject({ accountId: 'bsk', kind: 'korrektur', amount: -8015000 });
    expect(r.bauspar.settled).toMatchObject({ remaining: 0, bauLoanId: 'neu' });
  });
  it('mit Rest: läuft als Anschlussfinanzierung weiter; ohne deren Angaben oder bei zu hohen Beträgen abgewiesen', () => {
    const missing = planSettlement(V, bs(), 'bsk', { ...input, debt: 21000000 }, ids);
    expect('error' in missing && missing.error.replace(/\u00a0/g, ' ')).toBe(
      'Für den Rest von 10.000,00 € braucht es die Angaben der Anschlussfinanzierung (Rate und Zins).',
    );
    const r = planSettlement(
      V,
      bs(),
      'bsk',
      { ...input, debt: 21000000, follow: { rate: 50000, milli: 4000, fixedUntil: '2038-12-31' } },
      ids,
    );
    if ('error' in r) throw new Error(r.error);
    expect(r.loan).toMatchObject({
      kind: 'annuitaet',
      rate: 50000,
      rateMilli: 4000,
      paidOff: null,
      principal: 1000000,
    });
    expect('error' in planSettlement(V, bs(), 'bsk', { ...input, debt: 19000000 }, ids)).toBe(true);
  });
});

describe('Sonderzahlung in den Bausparvertrag (18.10)', () => {
  const st = loanState(V, [], TODAY);
  it('mehr Guthaben, kleineres Bauspardarlehen, weniger Zinsen, früher zuteilungsreif', () => {
    const e = extraPaymentEffect(bs({ minMilli: 40000 }), V, st, 6500000, TODAY, {
      date: '2027-01-15',
      amount: 500000,
    });
    expect(e.balanceAt.after - e.balanceAt.before).toBeGreaterThanOrEqual(500000);
    expect(e.bauLoan.before - e.bauLoan.after).toBeGreaterThanOrEqual(500000);
    expect(e.bauInterest.after).toBeLessThan(e.bauInterest.before);
    expect(e.minReached.after! < e.minReached.before!).toBe(true);
  });
  it('im Sondertilgungsplan: eingeordnet als eigenes Ziel; verkleinert die Lücke bei der Ablösung', () => {
    const link = {
      loanId: 'v',
      name: 'LBS',
      payoff: '2028-12-01',
      balanceAt: 8000000,
      sum: 20000000,
      debtAt: 20000000,
      bauMilli: 2350,
      bauRate: 80000,
      bauSpecial: defaultSpecial('raten'),
      gapMilli: 4000,
      gapTilgungMilli: 2000,
    };
    const inp = { loans: [{ loan: V, state: st }], pool: 300000, monthly: 0, today: TODAY };
    const off = simulate({ ...inp, bauspar: [link] }, 'zins');
    const on = simulate({ ...inp, bauspar: [{ ...link, extraPayments: true }] }, 'zins');
    expect(on.payments[0]).toMatchObject({ loanId: 'v-sz', amount: 300000 });
    expect(on.names['v-sz']).toBe('Sonderzahlung LBS');
    expect(on.replacements[0].bauLoan).toBe(off.replacements[0].bauLoan - 300000);
  });
});
