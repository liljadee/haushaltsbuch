import { Cents, formatEuro } from '../shared/money';
import { LocalDate } from '../shared/local-date';
import { Loan, LoanState, defaultSpecial, plan } from './loan';

/**
 * Bausparvertrag mit Darlehen (Lastenheft 18.10): zwei Bauarten.
 * „Nur Zinsen“ (Vorausdarlehen): Restschuld bleibt, Ablösung zur Zuteilung.
 * „Zinsen und Tilgung“ (Annuitätendarlehen): Restschuld sinkt, Ablösung zum Zinsbindungsende, frühestens zur Zuteilung.
 */
export type BausparType = 'zinsen' | 'tilgung';
export const BAUSPAR_TYPES: Record<BausparType, string> = {
  zinsen: 'Nur Zinsen (Vorausdarlehen)',
  tilgung: 'Zinsen und Tilgung (Annuitätendarlehen)',
};

export interface Bauspar {
  id: string;
  name: string;
  /** Konto der Art „Bausparvertrag“ (Guthaben) */
  accountId: string;
  /** Darlehen, das der Bausparvertrag ablöst */
  loanId: string | null;
  /** Bausparsumme */
  sum: Cents;
  /** monatliche Sparrate */
  savingRate: Cents;
  /** Guthabenzins in Tausendstel-Prozent */
  savingsMilli: number;
  /** Mindestsparguthaben in Tausendstel-Prozent der Bausparsumme (z. B. 40 % = 40000) */
  minMilli: number;
  /** voraussichtliche Zuteilung laut Bausparkasse */
  allocation: LocalDate | null;
  /** Zins und Rate des Bauspardarlehens */
  loanMilli: number;
  loanRate: Cents;
  /** Bauart (null = noch offen; die App rechnet dann mit der Bauart, die zur Rate passt) */
  type: BausparType | null;
  /** nur „Nur Zinsen“: gilt der Zins bis zur Zuteilung? */
  rateUntilAllocation: 'ja' | 'nein' | 'unbekannt';
  order: number;
}

export interface Check {
  label: string;
  status: 'gruen' | 'gelb' | 'rot';
  text: string;
}
export interface BausparYear {
  year: number;
  phase: string;
  balance: Cents;
  debt: Cents;
  net: Cents;
}
export interface BausparProjection {
  type: BausparType;
  suggested: BausparType | null;
  mismatch: string | null;
  minReached: LocalDate | null;
  payoff: LocalDate | null;
  balanceAt: Cents;
  debtAt: Cents;
  bauLoan: Cents;
  gap: Cents;
  bauLoanEnd: LocalDate | null;
  checks: Check[];
  years: BausparYear[];
  story: string[];
  error: string | null;
}

const MONTHS = [
  'Januar',
  'Februar',
  'März',
  'April',
  'Mai',
  'Juni',
  'Juli',
  'August',
  'September',
  'Oktober',
  'November',
  'Dezember',
];
const my = (d: LocalDate) => `${MONTHS[Number(d.slice(5, 7)) - 1]} ${d.slice(0, 4)}`;
const nextMonthStart = (d: LocalDate) => {
  const [y, m] = [Number(d.slice(0, 4)), Number(d.slice(5, 7))];
  return m === 12 ? `${y + 1}-01-01` : `${y}-${String(m + 1).padStart(2, '0')}-01`;
};

/** Erkennungshilfe: Entspricht die Rate den Zinsen (auf 1 € genau), „Nur Zinsen“, sonst „Zinsen und Tilgung“. */
export function suggestType(loan: Loan, state: LoanState): BausparType {
  if (loan.kind === 'voraus') return 'zinsen';
  const interest = Math.round((state.balance * loan.rateMilli) / 1200000);
  return Math.abs(loan.rate - interest) <= 100 ? 'zinsen' : 'tilgung';
}

/** Restschuld des Darlehens zu einem Datum nach Plan */
function debtAtDate(state: LoanState, date: LocalDate): Cents {
  const rows = state.plan.rows.filter((r) => r.date <= date);
  return rows.length ? rows.at(-1)!.balance : state.balance;
}

export function projectBauspar(
  b: Bauspar,
  loan: Loan | null,
  state: LoanState | null,
  balance: Cents,
  today: LocalDate,
): BausparProjection {
  const suggested = loan && state ? suggestType(loan, state) : null;
  const type: BausparType = b.type ?? suggested ?? 'zinsen';
  const mismatch =
    b.type && suggested && b.type !== suggested
      ? b.type === 'zinsen'
        ? 'Die Rate ist höher als die Zinsen; das spricht für „Zinsen und Tilgung“. Bitte die Bauart prüfen.'
        : 'Die Rate entspricht genau den Zinsen; das spricht für „Nur Zinsen“. Bitte die Bauart prüfen.'
      : null;
  // Ansparphase Monat für Monat: Sparrate zum Monatsanfang, Zinsen jährlich gutgeschrieben
  const minTarget = Math.round((b.sum * b.minMilli) / 100000);
  let g = balance,
    accrued = 0,
    minReached: LocalDate | null = balance >= minTarget && minTarget > 0 ? today : null;
  const fixedUntil = loan?.fixedUntil ?? null;
  const target =
    type === 'zinsen'
      ? (b.allocation ?? null)
      : fixedUntil && b.allocation
        ? fixedUntil > b.allocation
          ? fixedUntil
          : b.allocation
        : (fixedUntil ?? b.allocation);
  // Sparverlauf, bis Ablösetermin und Zuteilungsreife bekannt sind (höchstens 50 Jahre)
  const path: { date: LocalDate; value: Cents }[] = [];
  let d = nextMonthStart(today);
  for (let i = 0; i < 600; i++) {
    g += b.savingRate;
    accrued += Math.round((g * b.savingsMilli) / 1200000);
    if (d.slice(5, 7) === '12') {
      g += accrued;
      accrued = 0;
    }
    path.push({ date: d, value: g + accrued });
    if (!minReached && minTarget > 0 && g + accrued >= minTarget) minReached = d;
    if ((minReached || minTarget <= 0) && (!target || d > target)) break;
    d = nextMonthStart(d);
  }
  // ohne Termin laut Bausparkasse: bei „Nur Zinsen“ Ablösung mit Erreichen des Mindestsparguthabens (Zuteilungsreife)
  const payoff: LocalDate | null = target ?? (type === 'zinsen' ? minReached : null);
  const valueAt = (date: LocalDate) =>
    [...path].reverse().find((x) => x.date <= date)?.value ?? balance;
  const balanceAt = payoff ? valueAt(payoff) : 0;
  const savingsAt = new Map<number, Cents>();
  for (const x of path) savingsAt.set(Number(x.date.slice(0, 4)), x.value);
  const error =
    !loan || !state
      ? null
      : !payoff
        ? 'Für die Ablösung fehlt ein Termin: Bitte die voraussichtliche Zuteilung eintragen (Jahreskontoauszug der Bausparkasse).'
        : null;
  const debtAt = state && payoff ? debtAtDate(state, payoff) : 0;
  const bauLoan = payoff ? Math.max(0, Math.min(debtAt - balanceAt, b.sum - balanceAt)) : 0;
  const gap = payoff ? Math.max(0, debtAt - balanceAt - bauLoan) : 0;
  // Darlehensphase: Bauspardarlehen mit festem Zins und fester Rate bis zur Tilgung
  let bauLoanEnd: LocalDate | null = null,
    bauPlanError: string | null = null;
  const bauYears = new Map<number, Cents>();
  if (payoff && bauLoan > 0) {
    const pseudo: Loan = {
      ...(loan as Loan),
      id: 'bau',
      kind: 'annuitaet',
      rate: b.loanRate,
      rateMilli: b.loanMilli,
      fixedUntil: null,
      endDate: null,
      day: 1,
      special: defaultSpecial('annuitaet'),
      snapshots: [],
    };
    const p = plan(pseudo, { date: payoff, balance: bauLoan });
    bauLoanEnd = p.payoff;
    bauPlanError = p.error;
    for (const r of p.rows) bauYears.set(Number(r.date.slice(0, 4)), r.balance);
  } else if (payoff) bauLoanEnd = payoff;
  // Jahresübersicht: Phase, Guthaben, Restschuld, Nettoschuld
  const years: BausparYear[] = [];
  if (state) {
    const endYear = Number((bauLoanEnd ?? payoff ?? today).slice(0, 4));
    for (
      let y = Number(today.slice(0, 4));
      y <= Math.min(endYear, Number(today.slice(0, 4)) + 40);
      y++
    ) {
      const ye = `${y}-12-31`;
      const before = !payoff || ye < payoff;
      const debt = before
        ? debtAtDate(state, ye)
        : (bauYears.get(y) ?? (y < Number((bauLoanEnd ?? ye).slice(0, 4)) ? bauLoan : 0)) + gap;
      const bal = before ? (savingsAt.get(y) ?? balance) : 0;
      years.push({
        year: y,
        phase: before ? 'Ansparen' : debt > 0 ? 'Bauspardarlehen' : 'getilgt',
        balance: bal,
        debt,
        net: debt - bal,
      });
    }
  }
  // Abgleich „Passt das zusammen?“
  const checks: Check[] = [];
  if (loan) {
    if (type === 'zinsen') {
      if (b.rateUntilAllocation === 'ja')
        checks.push({
          label: 'Zeitpunkt',
          status: 'gruen',
          text: 'Der Zins gilt laut Vertrag bis zur Zuteilung.',
        });
      else if (!b.allocation)
        checks.push({
          label: 'Zeitpunkt',
          status: 'gelb',
          text: 'Die voraussichtliche Zuteilung fehlt.',
        });
      else if (fixedUntil && b.allocation > fixedUntil)
        checks.push({
          label: 'Zeitpunkt',
          status: 'rot',
          text: `Die Zuteilung (${my(b.allocation)}) liegt nach dem Zinsbindungsende (${my(fixedUntil)}); bis dahin braucht es eine Zwischenlösung.`,
        });
      else
        checks.push({
          label: 'Zeitpunkt',
          status: b.rateUntilAllocation === 'nein' || !fixedUntil ? 'gelb' : 'gruen',
          text: fixedUntil
            ? `Die Zuteilung (${my(b.allocation)}) liegt vor dem Zinsbindungsende (${my(fixedUntil)}).`
            : 'Ob der Zins bis zur Zuteilung gilt, ist offen; bitte im Vertrag nachsehen.',
        });
    } else if (!fixedUntil)
      checks.push({
        label: 'Zeitpunkt',
        status: 'gelb',
        text: 'Beim Darlehen fehlt das Zinsbindungsende.',
      });
    else if (!b.allocation)
      checks.push({
        label: 'Zeitpunkt',
        status: 'gelb',
        text: 'Die voraussichtliche Zuteilung fehlt.',
      });
    else if (b.allocation > fixedUntil)
      checks.push({
        label: 'Zeitpunkt',
        status: 'rot',
        text: `Die Zuteilung (${my(b.allocation)}) liegt nach dem Zinsbindungsende (${my(fixedUntil)}); für die Zeit dazwischen braucht es eine Zwischenlösung.`,
      });
    else
      checks.push({
        label: 'Zeitpunkt',
        status: 'gruen',
        text: `Zuteilung ${my(b.allocation)}, Ablösung zum Zinsbindungsende ${my(fixedUntil)}; eine frühere Zuteilung ruht meist bis dahin.`,
      });
    if (payoff)
      checks.push(
        gap > 0
          ? {
              label: 'Betrag',
              status: 'gelb',
              text: `Zur Ablösung fehlen voraussichtlich ${formatEuro(gap)}: Restschuld ${formatEuro(debtAt)}, Guthaben ${formatEuro(balanceAt)} und Bauspardarlehen ${formatEuro(bauLoan)}. Für den Rest braucht es eine Anschlussfinanzierung.`,
            }
          : {
              label: 'Betrag',
              status: 'gruen',
              text: `Guthaben ${formatEuro(balanceAt)} und Bauspardarlehen ${formatEuro(bauLoan)} decken die Restschuld von ${formatEuro(debtAt)}.`,
            },
      );
    if (minTarget > 0)
      checks.push(
        !minReached
          ? {
              label: 'Zuteilungsreife',
              status: 'rot',
              text: `Das Mindestsparguthaben von ${formatEuro(minTarget)} wird mit dieser Sparrate nicht erreicht.`,
            }
          : b.allocation && minReached > b.allocation
            ? {
                label: 'Zuteilungsreife',
                status: 'gelb',
                text: `Das Mindestsparguthaben (${formatEuro(minTarget)}) ist voraussichtlich erst im ${my(minReached)} erreicht, die Bausparkasse nennt ${my(b.allocation)}. Bitte nachfragen.`,
              }
            : {
                label: 'Zuteilungsreife',
                status: 'gruen',
                text: `Mindestsparguthaben von ${formatEuro(minTarget)} voraussichtlich im ${my(minReached)} erreicht.`,
              },
      );
  }
  // Klartext aus festen Textbausteinen
  const story: string[] = [];
  if (loan && state && payoff) {
    const interest = Math.round((state.balance * loan.rateMilli) / 1200000);
    story.push(
      type === 'zinsen'
        ? `Bis voraussichtlich ${my(payoff)} zahlst du monatlich ${formatEuro(interest)} Zinsen für das Darlehen, die Restschuld bleibt bei ${formatEuro(debtAt)}. Dazu gehen ${formatEuro(b.savingRate)} in den Bausparvertrag.`
        : `Bis ${my(payoff)} zahlst du ${formatEuro(loan.rate)} Rate für das Darlehen; die Restschuld sinkt auf voraussichtlich ${formatEuro(debtAt)}. Dazu gehen ${formatEuro(b.savingRate)} in den Bausparvertrag.`,
    );
    story.push(
      `Dann ${type === 'zinsen' ? 'wird der Bausparvertrag zugeteilt' : 'löst der Bausparvertrag ab'}: Dein Guthaben von voraussichtlich ${formatEuro(balanceAt)}${bauLoan ? ` und ein Bauspardarlehen über ${formatEuro(bauLoan)}` : ''} lösen das Darlehen ab${gap ? `; für die übrigen ${formatEuro(gap)} braucht es eine Anschlussfinanzierung` : ''}.`,
    );
    if (bauLoan > 0)
      story.push(
        bauPlanError
          ? `Achtung: ${bauPlanError}`
          : `Ab ${my(nextMonthStart(payoff))} zahlst du nur noch ${formatEuro(b.loanRate)} Rate für das Bauspardarlehen${bauLoanEnd ? `, bis voraussichtlich ${my(bauLoanEnd)}` : ''}.`,
      );
  }
  return {
    type,
    suggested,
    mismatch,
    minReached,
    payoff,
    balanceAt,
    debtAt,
    bauLoan,
    gap,
    bauLoanEnd,
    checks,
    years,
    story,
    error: error ?? bauPlanError,
  };
}
