import { describe, expect, it } from 'vitest';
import { isOneOf, keysOf, oneOf } from './choice';

describe('Feste Auswahl', () => {
  const KINDS = { jahr: 'Jahreszahlung', ziel: 'Sparziel' } as const;
  it('übernimmt nur erlaubte Werte, sonst den Standard', () => {
    expect([oneOf('ziel', keysOf(KINDS), 'jahr'), oneOf('quatsch', keysOf(KINDS), 'jahr')]).toEqual(
      ['ziel', 'jahr'],
    );
    expect([isOneOf('jahr', ['jahr'] as const), isOneOf('', ['jahr'] as const)]).toEqual([
      true,
      false,
    ]);
    expect(keysOf(KINDS)).toEqual(['jahr', 'ziel']);
  });
});
