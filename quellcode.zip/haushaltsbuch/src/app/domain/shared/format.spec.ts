import { describe, expect, it } from 'vitest';
import { euroInput, monthYear, parsePercent, percentInput, shortLabel } from './format';

describe('Formate', () => {
  it('Monat und Jahr', () => {
    expect([monthYear('2027-01-31'), monthYear('2043-10'), monthYear(null)]).toEqual([
      'Januar 2027',
      'Oktober 2043',
      '',
    ]);
  });
  it('Beträge und Prozente für Eingabefelder', () => {
    expect([euroInput(123450), euroInput(-5), euroInput(null)]).toEqual(['1.234,50', '0,05', '']);
    expect([percentInput(3250), percentInput(1450), percentInput(null)]).toEqual([
      '3,25',
      '1,45',
      '',
    ]);
    expect([
      parsePercent('3,25'),
      parsePercent('2,35 %'),
      parsePercent(''),
      parsePercent('x'),
    ]).toEqual([3250, 2350, null, null]);
  });
  it('kurze Namen für Tabellenköpfe', () => {
    expect([
      shortLabel('Hauskredit'),
      shortLabel('Anschlussfinanzierung (Vorfinanzierung)'),
      shortLabel('Bauspardarlehen (LBS)'),
      shortLabel('Modernisierungskredit'),
    ]).toEqual(['Hauskredit', 'Anschluss', 'Bausparkredit', 'Modernisie…']);
  });
});
