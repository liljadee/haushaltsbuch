import { LocalDate } from './local-date';

/** Bankarbeitstage in Bayern (Lastenheft 15): ohne Wochenenden und Feiertage; 24.12. und 31.12. sind bankfrei. */
const toUtc = (d: LocalDate) => Date.parse(d + 'T00:00:00Z');
const fromUtc = (t: number): LocalDate => new Date(t).toISOString().slice(0, 10);
export const addDays = (d: LocalDate, n: number): LocalDate => fromUtc(toUtc(d) + n * 86400000);
export const daysBetween = (a: LocalDate, b: LocalDate) =>
  Math.round((toUtc(b) - toUtc(a)) / 86400000);
export const weekday = (d: LocalDate) => new Date(toUtc(d)).getUTCDay();
export const daysInMonth = (y: number, m: number) => new Date(Date.UTC(y, m, 0)).getUTCDate();

export function easterSunday(y: number): LocalDate {
  const a = y % 19,
    b = Math.floor(y / 100),
    c = y % 100,
    d = Math.floor(b / 4),
    e = b % 4;
  const f = Math.floor((b + 8) / 25),
    g = Math.floor((b - f + 1) / 3),
    h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4),
    k = c % 4,
    l = (32 + 2 * e + 2 * i - h - k) % 7,
    m = Math.floor((a + 11 * h + 22 * l) / 451);
  const month = Math.floor((h + l - 7 * m + 114) / 31),
    day = ((h + l - 7 * m + 114) % 31) + 1;
  return `${y}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
}

const cache = new Map<number, Set<LocalDate>>();
/** Neujahr, Heilige Drei Könige, Karfreitag, Ostermontag, 1. Mai, Christi Himmelfahrt, Pfingstmontag, Fronleichnam,
 *  Mariä Himmelfahrt, Tag der Deutschen Einheit, Allerheiligen, 24.12., 1. und 2. Weihnachtstag, 31.12. */
export function holidaysBavaria(y: number): Set<LocalDate> {
  let s = cache.get(y);
  if (!s) {
    const e = easterSunday(y);
    s = new Set([
      ...[
        '01-01',
        '01-06',
        '05-01',
        '08-15',
        '10-03',
        '11-01',
        '12-24',
        '12-25',
        '12-26',
        '12-31',
      ].map((x) => `${y}-${x}`),
      addDays(e, -2),
      addDays(e, 1),
      addDays(e, 39),
      addDays(e, 50),
      addDays(e, 60),
    ]);
    cache.set(y, s);
  }
  return s;
}

export const isBankDay = (d: LocalDate) => {
  const w = weekday(d);
  return w !== 0 && w !== 6 && !holidaysBavaria(Number(d.slice(0, 4))).has(d);
};
export function nextBankDay(d: LocalDate): LocalDate {
  while (!isBankDay(d)) d = addDays(d, 1);
  return d;
}
export function prevBankDay(d: LocalDate): LocalDate {
  while (!isBankDay(d)) d = addDays(d, -1);
  return d;
}
/** n Bankarbeitstage vor d (für Überweisungsdauer). */
export function subBankDays(d: LocalDate, n: number): LocalDate {
  let k = 0;
  while (k < n) {
    d = addDays(d, -1);
    if (isBankDay(d)) k++;
  }
  return d;
}
