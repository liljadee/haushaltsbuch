/** Datum ohne Uhrzeit als Text JJJJ-MM-TT (Bauplan 4): keine Zeitzonenfehler. */
export type LocalDate = string;

const RE = /^(\d{4})-(\d{2})-(\d{2})$/;

export function isLocalDate(s: string): boolean {
  const m = RE.exec(s);
  if (!m) return false;
  const d = new Date(Date.UTC(+m[1], +m[2] - 1, +m[3]));
  return d.getUTCFullYear() === +m[1] && d.getUTCMonth() === +m[2] - 1 && d.getUTCDate() === +m[3];
}

/** Heutiges Datum des Geräts (nur in der Datenschicht aufrufen; die Fachlogik bekommt es übergeben). */
export function todayLocal(now = new Date()): LocalDate {
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
}

export function formatDate(d: LocalDate): string {
  const m = RE.exec(d);
  return m ? `${m[3]}.${m[2]}.${m[1]}` : d;
}

export function monthOf(d: LocalDate): string {
  return d.slice(0, 7);
}
