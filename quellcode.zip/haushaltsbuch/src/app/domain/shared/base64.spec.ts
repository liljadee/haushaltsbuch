import { describe, expect, it } from 'vitest';
import { fromBase64, fromBase64Url, toBase64, toBase64Url } from './base64';

describe('Base64', () => {
  it('kodiert und dekodiert beliebige Bytes verlustfrei', () => {
    for (const n of [0, 1, 2, 3, 31, 32, 33, 70000]) {
      const b = Uint8Array.from({ length: n }, (_, i) => (i * 131 + 7) % 256);
      expect(fromBase64(toBase64(b))).toEqual(b);
      expect(fromBase64Url(toBase64Url(b))).toEqual(b);
    }
  });
  it('base64url enthält keine Sonderzeichen für Adressen', () => {
    expect(toBase64Url(Uint8Array.from([251, 255, 254]))).toMatch(/^[A-Za-z0-9_-]+$/);
  });
});
