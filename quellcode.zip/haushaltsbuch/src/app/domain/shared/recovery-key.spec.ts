import { describe, expect, it } from 'vitest';
import {
  RECOVERY_ALPHABET,
  formatRecoveryKey,
  generateRecoveryKey,
  normalizeGroup,
  normalizeRecoveryKey,
  splitRecoveryKey,
  cleanRecoveryInput,
  recoveryKeyProblem,
} from './recovery-key';

const fixed = (n: number) => Uint8Array.from({ length: n }, (_, i) => (i * 7 + 3) % 256);

describe('Wiederherstellungsschlüssel', () => {
  it('hat 30 Zeichen aus dem Crockford-Alphabet', () => {
    const k = generateRecoveryKey(fixed);
    expect(k).toHaveLength(30);
    for (const c of k) expect(RECOVERY_ALPHABET).toContain(c);
  });
  it('enthält keine verwechselbaren Buchstaben', () => {
    expect(RECOVERY_ALPHABET).not.toMatch(/[ILOU]/);
    expect(new Set(RECOVERY_ALPHABET).size).toBe(32);
  });
  it('nutzt alle 32 Zeichen bei echtem Zufall', () => {
    const seen = new Set<string>();
    for (let i = 0; i < 200; i++)
      for (const c of generateRecoveryKey((n) => crypto.getRandomValues(new Uint8Array(n))))
        seen.add(c);
    expect(seen.size).toBe(32);
  });
  it('wird in sechs Gruppen zu fünf Zeichen angezeigt', () => {
    const k = generateRecoveryKey(fixed);
    expect(splitRecoveryKey(k)).toHaveLength(6);
    expect(formatRecoveryKey(k)).toMatch(/^([0-9A-Z]{5}-){5}[0-9A-Z]{5}$/);
  });
  it('akzeptiert Eingaben mit Leerzeichen, Bindestrichen und Kleinbuchstaben', () => {
    const k = generateRecoveryKey(fixed);
    expect(normalizeRecoveryKey(formatRecoveryKey(k).toLowerCase().replace(/-/g, ' '))).toBe(k);
  });
  it('liest O als 0 und I oder L als 1', () => {
    const k = '0123456789ABCDEFGHJKMNPQRSTVWX';
    expect(normalizeRecoveryKey(k.replace('0', 'O').replace('1', 'l'))).toBe(k);
    expect(normalizeGroup('o1i-L')).toBe('0111');
  });
  it('lehnt falsche Länge ab; U gilt als V, Satzzeichen zählen nicht', () => {
    expect(normalizeRecoveryKey('ABC')).toBeNull();
    expect(normalizeRecoveryKey('A'.repeat(29) + '!')).toBeNull();
    expect(normalizeRecoveryKey('U'.repeat(30))).toBe('V'.repeat(30));
  });
});

describe('Großzügige Eingabe des Schlüssels', () => {
  const key = '7K2QX0ABCDEFGH1JKMNPQRSTVWXYZ9';
  it('ignoriert Leerzeichen, Striche aller Art, Punkte; Kleinbuchstaben, O, I, L und U werden umgedeutet', () => {
    expect(normalizeRecoveryKey('7k2qx – 0abcd·efgh1 - jkmnp. qrstv—wxyz9.')).toBe(key);
    expect(normalizeRecoveryKey('7K2QX-OABCD-EFGHI-JKMNP-QRSTU-WXYZ9')).toBe(
      '7K2QX0ABCDEFGH1JKMNPQRSTVWXYZ9',
    );
    expect(cleanRecoveryInput('a l i o u')).toBe('A110V');
  });
  it('genaue Meldung mit der Zahl der Zeichen; null, wenn das Format stimmt', () => {
    expect(recoveryKeyProblem('7K2QX-0ABCD-EFGH1-JKMNP-QRSTV-WXY')).toContain('28 von 30 Zeichen');
    expect(recoveryKeyProblem(key)).toBeNull();
  });
});
