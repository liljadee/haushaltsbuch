import { Cents } from './money';

/** Gemeinsame Anzeige- und Eingabeformate (deutsch). */
export const MONTH_NAMES = [
  'Januar',
  'Februar',
  'März',
  'April',
  'Mai',
  'Juni',
  'Juli',
  'August',
  'September',
  'Oktober',
  'November',
  'Dezember',
];
export const MONTH_SHORT = [
  'Jan',
  'Feb',
  'Mär',
  'Apr',
  'Mai',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Okt',
  'Nov',
  'Dez',
];

/** „Januar 2027“ aus JJJJ-MM-TT oder JJJJ-MM; leer, wenn kein Datum */
export function monthYear(date: string | null | undefined): string {
  return date ? `${MONTH_NAMES[Number(date.slice(5, 7)) - 1]} ${date.slice(0, 4)}` : '';
}

/** Cent als Text für ein Eingabefeld, ohne Vorzeichen und Währung („1.234,50“); leer, wenn kein Betrag */
export function euroInput(cents: Cents | null | undefined): string {
  return cents == null
    ? ''
    : (Math.abs(cents) / 100).toLocaleString('de-DE', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      });
}

/** Tausendstel-Prozent als Text für ein Eingabefeld („3,25“) */
export function percentInput(milli: number | null | undefined): string {
  return milli == null ? '' : (milli / 1000).toLocaleString('de-DE', { maximumFractionDigits: 3 });
}

/** „3,25“ oder „3,25 %“ → 3250 (Tausendstel-Prozent); null bei leerer oder ungültiger Eingabe */
export function parsePercent(text: string): number | null {
  const v = Number(text.replace(/\s|%/g, '').replace(',', '.'));
  return text.trim() && Number.isFinite(v) ? Math.round(v * 1000) : null;
}

/** Kurzer Name für enge Tabellenköpfe: „Bauspardarlehen (X)“ → „Bausparkredit“, „Anschlussfinanzierung (X)“ → „Anschluss“, sonst höchstens 11 Zeichen */
export function shortLabel(name: string, max = 11): string {
  if (name.startsWith('Bauspardarlehen')) return 'Bausparkredit';
  if (name.startsWith('Anschlussfinanzierung')) return 'Anschluss';
  return name.length <= max ? name : `${name.slice(0, max - 1).trimEnd()}…`;
}
