/** Geld als ganze Cent (Bauplan 4). */
export type Cents = number;

const FORMAT = new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' });

export function formatEuro(cents: Cents): string {
  return FORMAT.format(cents / 100);
}

/**
 * Liest deutsche Betragseingaben: „12,34“, „1.234,50“, „-5“, „7,5“.
 * Liefert null bei ungültiger Eingabe oder mehr als zwei Nachkommastellen.
 */
export function parseEuro(input: string): Cents | null {
  const s = input.trim().replace(/\s|€/g, '');
  if (!/^[-+]?\d{1,3}(\.\d{3})*(,\d{1,2})?$|^[-+]?\d+(,\d{1,2})?$/.test(s)) return null;
  const neg = s.startsWith('-');
  const [int, frac = ''] = s.replace(/^[-+]/, '').replace(/\./g, '').split(',');
  const cents = Number(int) * 100 + Number(frac.padEnd(2, '0'));
  if (!Number.isSafeInteger(cents)) return null;
  return neg ? -cents : cents;
}
