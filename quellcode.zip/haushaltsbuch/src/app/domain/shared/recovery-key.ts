/**
 * Wiederherstellungsschlüssel (Bauplan 5.2): 30 Zeichen Base32, also 150 Bit Zufall.
 * Alphabet nach Crockford: ohne I, L, O und U, damit sich nichts verwechseln lässt.
 * Bei der Eingabe werden Kleinbuchstaben, Leerzeichen und Bindestriche toleriert,
 * O wird als 0 und I oder L als 1 gelesen.
 */
export const RECOVERY_ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
export const RECOVERY_LENGTH = 30;
export const RECOVERY_GROUP = 5;

/** Erzeugt einen neuen Schlüssel aus einer Zufallsquelle (im Browser crypto.getRandomValues). */
export function generateRecoveryKey(random: (n: number) => Uint8Array): string {
  const bytes = random(RECOVERY_LENGTH);
  let out = '';
  for (let i = 0; i < RECOVERY_LENGTH; i++) out += RECOVERY_ALPHABET[bytes[i] & 31];
  return out;
}

/** Zur Anzeige in Gruppen zu fünf Zeichen, z. B. „7K2QX-…“. */
export function formatRecoveryKey(key: string): string {
  return splitRecoveryKey(key).join('-');
}

export function splitRecoveryKey(key: string): string[] {
  const groups: string[] = [];
  for (let i = 0; i < key.length; i += RECOVERY_GROUP)
    groups.push(key.slice(i, i + RECOVERY_GROUP));
  return groups;
}

/**
 * Bereinigt eine Eingabe großzügig: Groß-/Kleinschreibung egal; Leerzeichen, Bindestriche, lange Striche, Punkte und
 * andere Satzzeichen werden ignoriert (z. B. Punkt nach doppeltem Leerzeichen der Handytastatur, „–“ aus Dokumenten);
 * O → 0, I und L → 1, U → V (U kommt im Schlüssel nie vor).
 */
export function cleanRecoveryInput(input: string): string {
  return input
    .toUpperCase()
    .replace(/[^0-9A-Z]/g, '')
    .replace(/O/g, '0')
    .replace(/[IL]/g, '1')
    .replace(/U/g, 'V');
}

/** Normalisiert eine Eingabe; liefert null, wenn sie kein gültiger Schlüssel ist. */
export function normalizeRecoveryKey(input: string): string | null {
  const s = cleanRecoveryInput(input);
  if (s.length !== RECOVERY_LENGTH) return null;
  for (const c of s) if (!RECOVERY_ALPHABET.includes(c)) return null;
  return s;
}

/** Genaue Meldung, wenn die Eingabe kein Schlüssel sein kann; null, wenn das Format stimmt */
export function recoveryKeyProblem(input: string): string | null {
  const n = cleanRecoveryInput(input).length;
  if (n === RECOVERY_LENGTH) return null;
  return `Du hast ${n} von ${RECOVERY_LENGTH} Zeichen eingegeben. Der Schlüssel hat sechs Gruppen zu je fünf Zeichen; Leerzeichen, Striche und Punkte zählen nicht mit.`;
}

/** Normalisiert eine einzelne Gruppe (für die Abschreib-Kontrolle). */
export function normalizeGroup(input: string): string {
  return cleanRecoveryInput(input);
}
