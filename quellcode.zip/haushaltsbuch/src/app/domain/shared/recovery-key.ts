/**
 * Wiederherstellungsschlüssel (Bauplan 5.2): 30 Zeichen Base32, also 150 Bit Zufall.
 * Alphabet nach Crockford: ohne I, L, O und U, damit sich nichts verwechseln lässt.
 * Bei der Eingabe werden Kleinbuchstaben, Leerzeichen und Bindestriche toleriert,
 * O wird als 0 und I oder L als 1 gelesen.
 */
export const RECOVERY_ALPHABET = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
export const RECOVERY_LENGTH = 30;
export const RECOVERY_GROUP = 5;

/** Erzeugt einen neuen Schlüssel aus einer Zufallsquelle (im Browser crypto.getRandomValues). */
export function generateRecoveryKey(random: (n: number) => Uint8Array): string {
  const bytes = random(RECOVERY_LENGTH);
  let out = '';
  for (let i = 0; i < RECOVERY_LENGTH; i++) out += RECOVERY_ALPHABET[bytes[i] & 31];
  return out;
}

/** Zur Anzeige in Gruppen zu fünf Zeichen, z. B. „7K2QX-…“. */
export function formatRecoveryKey(key: string): string {
  return splitRecoveryKey(key).join('-');
}

export function splitRecoveryKey(key: string): string[] {
  const groups: string[] = [];
  for (let i = 0; i < key.length; i += RECOVERY_GROUP)
    groups.push(key.slice(i, i + RECOVERY_GROUP));
  return groups;
}

/** Normalisiert eine Eingabe; liefert null, wenn sie kein gültiger Schlüssel ist. */
export function normalizeRecoveryKey(input: string): string | null {
  const s = input.toUpperCase().replace(/[\s-]/g, '').replace(/O/g, '0').replace(/[IL]/g, '1');
  if (s.length !== RECOVERY_LENGTH) return null;
  for (const c of s) if (!RECOVERY_ALPHABET.includes(c)) return null;
  return s;
}

/** Normalisiert eine einzelne Gruppe (für die Abschreib-Kontrolle). */
export function normalizeGroup(input: string): string {
  return input.toUpperCase().replace(/[\s-]/g, '').replace(/O/g, '0').replace(/[IL]/g, '1');
}
