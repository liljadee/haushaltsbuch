import { describe, expect, it } from 'vitest';
import { formatEuro, parseEuro } from './money';

describe('Geldbeträge', () => {
  it.each([
    ['12,34', 1234],
    ['1.234,50', 123450],
    ['7,5', 750],
    ['-5', -500],
    ['0,01', 1],
    ['1234', 123400],
    [' 3,00 € ', 300],
  ])('liest „%s“', (input, cents) => expect(parseEuro(input)).toBe(cents));
  it.each(['', 'abc', '1,234', '12.34', '1.23,00', '--1'])('lehnt „%s“ ab', (input) =>
    expect(parseEuro(input)).toBeNull(),
  );
  it('formatiert deutsch', () => {
    expect(formatEuro(123450).replace(/\u00a0/g, ' ')).toBe('1.234,50 €');
    expect(formatEuro(-1).replace(/\u00a0/g, ' ')).toBe('-0,01 €');
  });
  it('rechnet Ein- und Ausgabe ohne Rundungsfehler zurück', () => {
    for (let c = -100000; c <= 100000; c += 777)
      expect(parseEuro((c / 100).toFixed(2).replace('.', ','))).toBe(c);
  });
});
