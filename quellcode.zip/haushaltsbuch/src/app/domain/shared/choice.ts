/** Feste Auswahlmöglichkeiten (z. B. aus einem Auswahlfeld) typsicher übernehmen. */

/** Prüft, ob ein Text zu einer festen Auswahl gehört. */
export function isOneOf<T extends string>(value: string, allowed: readonly T[]): value is T {
  return (allowed as readonly string[]).includes(value);
}

/** Wert aus einer festen Auswahl; unbekannte Werte fallen auf den Standard zurück. */
export function oneOf<T extends string>(value: string, allowed: readonly T[], fallback: T): T {
  return isOneOf(value, allowed) ? value : fallback;
}

/** Schlüssel eines Auswahl-Verzeichnisses (z. B. LOAN_KINDS) als Liste der erlaubten Werte. */
export function keysOf<K extends string>(record: Record<K, unknown>): K[] {
  return Object.keys(record).filter((k): k is K => k in record);
}

/** Einträge eines Auswahl-Verzeichnisses als Liste [Schlüssel, Wert], z. B. für Auswahlfelder. */
export function entriesOf<K extends string, V>(record: Record<K, V>): [K, V][] {
  return keysOf(record).map((k): [K, V] => [k, record[k]]);
}
