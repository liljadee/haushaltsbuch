import { describe, expect, it } from 'vitest';
import { Account } from '../accounts/account';
import { Booking } from '../bookings/booking';
import { DEFAULT_CATEGORIES as C } from '../categories/categories';
import { nextBankDay, prevBankDay } from '../shared/bank-days';
import { detectRecurring } from '../recurring/recurring';
import { cyclesAround, estimateCategory, forecast } from './forecast';

let n = 0;
const bk = (
  date: string,
  amount: number,
  text: string,
  cat: string | null = null,
  sub: string | null = null,
): Booking => ({
  id: `b${++n}`,
  accountId: 'g',
  kind: amount < 0 ? 'ausgabe' : 'einnahme',
  status: 'gebucht',
  amount,
  date,
  seq: n,
  text,
  splits: cat ? [{ categoryId: cat, subCategory: sub, amount }] : [],
  confidence: 'sicher',
  source: { type: 'email' },
});
const months = (from: string, count: number) =>
  Array.from({ length: count }, (_, i) => {
    const t = Number(from.slice(0, 4)) * 12 + Number(from.slice(5, 7)) - 1 + i;
    return `${Math.floor(t / 12)}-${String((t % 12) + 1).padStart(2, '0')}`;
  });
const TODAY = '2026-11-17';
const giro: Account = {
  id: 'g',
  name: 'Girokonto',
  type: 'giro',
  identifier: '1234',
  purpose: 'allgemein',
  reserve: 0,
  leadDays: 2,
  archived: false,
  order: 0,
  snapshots: [],
};
const data: Booking[] = [];
for (const m of months('2025-11', 13)) {
  data.push(bk(prevBankDay(`${m}-01`), 245000, 'GEHALT SANDRA', 'e-gehalt', 'Gehalt Sandra'));
  data.push(
    bk(nextBankDay(`${m}-13`), -2959, 'AGILA Hau.', 'a-versicherungen', 'Tierversicherung'),
  );
  data.push(bk(nextBankDay(`${m}-01`), -78000, 'SPARKASSE DARLEHEN', 'a-kredite', 'Zinsen'));
  data.push({
    ...bk(nextBankDay(`${m}-01`), -15000, 'Sparrate Tagesgeld'),
    kind: 'umbuchung',
    splits: [],
    transferGroupId: m,
  });
  if (m < '2026-11')
    for (const d of ['04', '11', '18', '25'])
      data.push(bk(`${m}-${d}`, -15000, 'REWE MARKT', 'a-haushalt', 'Lebensmittel'));
  if (m === '2025-12')
    data.push(bk('2025-12-12', -45000, 'MEDIAMARKT GESCHENKE', 'a-haushalt', 'Haushaltswaren'));
}
data.push(bk('2026-11-04', -15000, 'REWE MARKT', 'a-haushalt', 'Lebensmittel'));
data.push(bk('2026-11-11', -15000, 'REWE MARKT', 'a-haushalt', 'Lebensmittel'));
for (const m of ['2025-11', '2026-02', '2026-05', '2026-08'])
  data.push(bk(nextBankDay(`${m}-15`), -16024, 'Markt Alt.', 'a-wasser-abwasser'));
const items = detectRecurring(data, TODAY).map((i) => ({ ...i, id: i.pattern }));
const fc = forecast({
  today: TODAY,
  account: giro,
  balance: 195968,
  items,
  bookings: data,
  cats: C,
  prudence: 'ausgewogen',
});

describe('Prognose', () => {
  it('erkennt auch den Dauerauftrag aufs Tagesgeld als wiederkehrend', () => {
    expect(items.map((i) => i.pattern)).toEqual(
      expect.arrayContaining([
        'GEHALT SANDRA',
        'SPARKASSE DARLEHEN',
        'SPARRATE TAGESGELD',
        'AGILA HAU.',
        'MARKT ALT.',
      ]),
    );
  });
  it('rechnet im Gehaltszyklus von Gehalt zu Gehalt', () => {
    expect(fc.anchor?.pattern).toBe('GEHALT SANDRA');
    expect(fc.cur).toEqual({ start: '2026-10-30', end: '2026-11-30' });
    expect(fc.next).toEqual({ start: '2026-12-01', end: '2026-12-29' });
    expect(cyclesAround(TODAY, null).cur).toEqual({ start: '2026-11-01', end: '2026-11-30' });
  });
  it('plant feste Termine ein und legt Überfälliges auf morgen', () => {
    const ev = fc.events.map((e) => [e.date, e.label, e.amount, e.overdue]);
    expect(ev[0]).toEqual(['2026-11-18', 'Markt Alt.', -16024, true]);
    expect(ev).toContainEqual(['2026-12-01', 'GEHALT SANDRA', 245000, false]);
    expect(ev).toContainEqual(['2026-12-01', 'Sparrate Tagesgeld', -15000, false]);
    expect(ev).toContainEqual(['2026-12-14', 'AGILA Hau.', -2959, false]);
    expect(ev.filter((e) => e[1] === 'AGILA Hau.')).toHaveLength(1);
  });
  it('schätzt variable Ausgaben ohne die wiederkehrenden Zahlungen', () => {
    expect(fc.estimates.map((e) => [e.categoryId, e.monthly])).toEqual([['a-haushalt', 60000]]);
    expect(fc.varMonthly).toBe(60000);
    // zwei von vier Einkäufen im laufenden Zyklus schon gemacht → Rest 300 €
    expect(fc.curVarRest).toBe(30000);
  });
  it('Saisonposten: Dezember wie im Vorjahr teurer', () => {
    expect(fc.seasonal).toEqual([{ categoryId: 'a-haushalt', month: '2026-12', extra: 45000 }]);
  });
  it('Kontoverlauf mit Tiefpunkt', () => {
    expect(fc.series[0].date).toBe('2026-11-18');
    expect(fc.series.at(-1)?.date).toBe('2026-12-29');
    const nov30 = fc.series.find((p) => p.date === '2026-11-30')!.balance;
    expect(nov30).toBe(195968 - 16024 - 30000);
    expect(fc.low.date <= '2026-12-29').toBe(true);
    expect(fc.firstNegative).toBeNull();
  });
  it('vorsichtig schätzt höher als ausgewogen', () => {
    const vals = [10000, 20000, 30000, 40000];
    expect(estimateCategory(vals, 'vorsichtig').est).toBeGreaterThan(
      estimateCategory(vals, 'ausgewogen').est,
    );
    expect(estimateCategory([10000, 10000, 50000], 'ausgewogen')).toMatchObject({
      est: 10000,
      outliers: 1,
    });
  });
});
