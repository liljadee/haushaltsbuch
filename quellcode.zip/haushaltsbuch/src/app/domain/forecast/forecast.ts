import { Account } from '../accounts/account';
import { Booking } from '../bookings/booking';
import { Category } from '../categories/categories';
import { addDays, daysBetween } from '../shared/bank-days';
import { Cents } from '../shared/money';
import { LocalDate } from '../shared/local-date';
import { RecurringItem, occurrences, plannedOccurrences } from '../recurring/recurring';

/**
 * Liquiditätsprognose des Girokontos (Lastenheft 15): im Gehaltszyklus bis zum Ende des nächsten Zyklus.
 * Feste Termine aus bestätigten wiederkehrenden Zahlungen, variable Ausgaben aus der Historie je Kategorie.
 */
export type Prudence = 'ausgewogen' | 'vorsichtig';

export interface Cycle {
  start: LocalDate;
  end: LocalDate;
}
export interface ForecastEvent {
  date: LocalDate;
  amount: Cents;
  label: string;
  overdue: boolean;
  itemId: string;
}
export interface Estimate {
  categoryId: string;
  monthly: Cents;
  values: Cents[];
  outliers: number;
  method: string;
}
export interface ForecastPoint {
  date: LocalDate;
  balance: Cents;
}
export interface Forecast {
  cur: Cycle;
  next: Cycle;
  anchor: RecurringItem | null;
  events: ForecastEvent[];
  estimates: Estimate[];
  varMonthly: Cents;
  curVarRest: Cents;
  seasonal: { categoryId: string; month: string; extra: Cents }[];
  series: ForecastPoint[];
  low: ForecastPoint;
  firstNegative: ForecastPoint | null;
  startBalance: Cents;
}

const median = (a: number[]) => {
  const s = [...a].sort((x, y) => x - y),
    n = s.length;
  return n ? (n % 2 ? s[(n - 1) / 2] : (s[n / 2 - 1] + s[n / 2]) / 2) : 0;
};
function quantile(a: number[], q: number): number {
  const s = [...a].sort((x, y) => x - y);
  if (!s.length) return 0;
  const i = q * (s.length - 1),
    lo = Math.floor(i),
    hi = Math.ceil(i);
  return s[lo] + (s[hi] - s[lo]) * (i - lo);
}

/** Schätzwert je Kategorie: Ausreißer über dem 1,5-fachen Median fallen heraus; ausgewogen Mittelwert, vorsichtig 75-%-Quantil. */
export function estimateCategory(
  values: Cents[],
  prudence: Prudence,
): { est: Cents; outliers: number; method: string } {
  const med = median(values);
  const kept = values.filter((v) => !(med > 0 ? v > med * 1.5 : v > 0));
  const base = kept.length ? kept : values;
  const est =
    prudence === 'vorsichtig'
      ? quantile(base, 0.75)
      : base.reduce((s, v) => s + v, 0) / (base.length || 1);
  return {
    est: Math.round(est),
    outliers: values.length - kept.length,
    method: prudence === 'vorsichtig' ? '75-%-Quantil' : 'Mittelwert',
  };
}

const ym = (d: LocalDate) => d.slice(0, 7);
function shift(month: string, n: number): string {
  const t = Number(month.slice(0, 4)) * 12 + Number(month.slice(5, 7)) - 1 + n;
  return `${Math.floor(t / 12)}-${String((t % 12) + 1).padStart(2, '0')}`;
}

/** Gehaltszyklus: von einem Eingang des Ankergehalts bis zum Tag vor dem nächsten; ohne Anker der Kalendermonat. */
export function cyclesAround(
  today: LocalDate,
  anchor: RecurringItem | null,
): { cur: Cycle; next: Cycle } {
  if (!anchor) {
    const s = `${ym(today)}-01`,
      n = `${shift(ym(today), 1)}-01`,
      nn = `${shift(ym(today), 2)}-01`;
    return { cur: { start: s, end: addDays(n, -1) }, next: { start: n, end: addDays(nn, -1) } };
  }
  const dates = occurrences(anchor, addDays(today, -70), addDays(today, 110)).map((o) => o.date);
  const i = dates.findIndex((d) => d > today);
  const start = dates[i - 1] ?? addDays(dates[i], -30),
    nextStart = dates[i],
    after = dates[i + 1];
  return {
    cur: { start, end: addDays(nextStart, -1) },
    next: { start: nextStart, end: addDays(after, -1) },
  };
}

export interface ForecastInput {
  today: LocalDate;
  account: Account;
  balance: Cents;
  items: RecurringItem[];
  bookings: Booking[];
  cats: Category[];
  prudence: Prudence;
}

export function forecast(inp: ForecastInput): Forecast {
  const { today, account, bookings, cats, prudence } = inp;
  const items = inp.items.filter((i) => i.active && i.accountId === account.id);
  const anchor =
    items
      .filter((i) => i.amount > 0 && i.interval === 'monat' && !i.variable)
      .sort((a, b) => b.amount - a.amount)[0] ?? null;
  const { cur, next } = cyclesAround(today, anchor);
  const own = bookings.filter((b) => b.accountId === account.id && b.status === 'gebucht');
  const savings = new Set(cats.filter((c) => c.savings).map((c) => c.id));

  // Buchungen, die zu wiederkehrenden Zahlungen gehören, zählen nicht in die variablen Ausgaben
  const lastYearFrom = `${shift(ym(today), -12)}-01`;
  const matched = new Set(
    plannedOccurrences(items, own, lastYearFrom, today, today)
      .filter((o) => o.booking)
      .map((o) => o.booking!.id),
  );
  const variable = own.filter((b) => b.kind === 'ausgabe' && !matched.has(b.id));
  const perCatMonth = new Map<string, Map<string, Cents>>();
  for (const b of variable) {
    for (const s of b.splits.length
      ? b.splits
      : [{ categoryId: null, subCategory: null, amount: b.amount }]) {
      if (s.categoryId && savings.has(s.categoryId)) continue;
      const k = s.categoryId ?? 'none';
      const m = perCatMonth.get(k) ?? new Map<string, Cents>();
      m.set(ym(b.date), (m.get(ym(b.date)) ?? 0) - s.amount);
      perCatMonth.set(k, m);
    }
  }
  const histMonths = Array.from({ length: 6 }, (_, i) => shift(ym(today), -6 + i));
  const estimates: Estimate[] = [];
  for (const [categoryId, m] of perCatMonth) {
    const values = histMonths.map((x) => m.get(x) ?? 0);
    if (values.every((v) => v === 0)) continue;
    const e = estimateCategory(values, prudence);
    estimates.push({ categoryId, monthly: e.est, values, outliers: e.outliers, method: e.method });
  }
  estimates.sort((a, b) => b.monthly - a.monthly);
  const varMonthly = estimates.reduce((s, e) => s + e.monthly, 0);

  // Saisonposten: im selben Monat des Vorjahres deutlich mehr als der Schätzwert (≥ 1,5-fach und ≥ 50 €)
  const seasonal: Forecast['seasonal'] = [];
  for (const month of [ym(addDays(today, 1)), ym(next.start), ym(next.end)].filter(
    (v, i, a) => a.indexOf(v) === i,
  )) {
    for (const e of estimates) {
      const ly = perCatMonth.get(e.categoryId)?.get(shift(month, -12)) ?? 0;
      if (ly >= e.monthly * 1.5 && ly - e.monthly >= 5000)
        seasonal.push({ categoryId: e.categoryId, month, extra: ly - e.monthly });
    }
  }
  const extraPerDay = (d: LocalDate) =>
    seasonal.filter((x) => x.month === ym(d)).reduce((s, x) => s + x.extra, 0) /
    Number(new Date(Date.UTC(Number(d.slice(0, 4)), Number(d.slice(5, 7)), 0)).getUTCDate());

  // laufender Zyklus: Rest je Kategorie, mindestens der anteilige Rest der verbleibenden Tage
  const cycleDays = daysBetween(cur.start, cur.end) + 1,
    remDays = Math.max(0, daysBetween(today, cur.end));
  let curVarRest = 0;
  for (const e of estimates) {
    const spent = variable
      .filter((b) => b.date >= cur.start && b.date <= today)
      .flatMap((b) =>
        b.splits.length ? b.splits : [{ categoryId: null, subCategory: null, amount: b.amount }],
      )
      .filter((s) => (s.categoryId ?? 'none') === e.categoryId)
      .reduce((sum, s) => sum - s.amount, 0);
    curVarRest += Math.max(e.monthly - spent, Math.round((e.monthly * remDays) / cycleDays));
  }

  // feste Termine: geplant ab morgen, Überfälliges auf morgen gelegt
  const events: ForecastEvent[] = plannedOccurrences(items, own, cur.start, next.end, today)
    .filter((o) => o.state !== 'gebucht')
    .map((o) => ({
      date: o.date <= today ? addDays(today, 1) : o.date,
      amount: o.amount,
      label: o.item.label,
      overdue: o.state === 'ueberfaellig',
      itemId: o.item.id,
    }))
    .sort((a, b) => (a.date < b.date ? -1 : 1));

  const series: ForecastPoint[] = [];
  let bal = inp.balance,
    acc = 0;
  const nextDays = daysBetween(next.start, next.end) + 1;
  for (let d = addDays(today, 1); d <= next.end; d = addDays(d, 1)) {
    for (const ev of events) if (ev.date === d) bal += ev.amount;
    acc +=
      (d <= cur.end ? (remDays ? curVarRest / remDays : 0) : varMonthly / nextDays) +
      extraPerDay(d);
    const v = Math.round(acc);
    bal -= v;
    acc -= v;
    series.push({ date: d, balance: bal });
  }
  const start = { date: today, balance: inp.balance };
  const low = series.reduce((lo, p) => (p.balance < lo.balance ? p : lo), start);
  return {
    cur,
    next,
    anchor,
    events,
    estimates,
    varMonthly,
    curVarRest,
    seasonal,
    series,
    low,
    firstNegative: series.find((p) => p.balance < 0) ?? null,
    startBalance: inp.balance,
  };
}
