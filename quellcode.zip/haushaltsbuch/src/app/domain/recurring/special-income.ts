import { Booking } from '../bookings/booking';
import { MONTH_NAMES } from '../shared/format';
import { Cents } from '../shared/money';
import { LocalDate } from '../shared/local-date';

/**
 * Sonderzahlungen im Einkommen (Lastenheft 15.3, 15.5): Urlaubs- und Weihnachtsgeld, Prämien. Erkannt an Kategorie
 * und Buchungstext oder als Mehrbetrag in der Gehaltsbuchung (über Median + 50 %), der sich im selben Monat früherer
 * Jahre wiederholt. Unbestätigt zählen sie 0 €; bestätigt plant die App sie im selben Monat in Höhe des letzten Betrags.
 */
export interface SpecialIncome {
  key: string;
  label: string;
  month: number;
  day: number;
  accountId: string;
  years: { year: number; amount: Cents }[];
  lastAmount: Cents;
  /** im Gehalt enthalten (Mehrbetrag) oder eigene Buchung */
  inSalary: boolean;
}
export interface ConfirmedSpecialIncome {
  key: string;
  label: string;
  month: number;
  day: number;
  accountId: string;
  amount: Cents;
}

const WORDS: [RegExp, string][] = [
  [/weihnacht/i, 'Weihnachtsgeld'],
  [/urlaubsgeld|urlaubs-?geld/i, 'Urlaubsgeld'],
  [/13\.?\s*(monats)?gehalt|jahressonderzahlung|sonderzahlung/i, 'Sonderzahlung'],
  [/pr(ä|ae)mie|bonus|tantieme/i, 'Prämie'],
];
const SALARY = 'e-gehalt';
const SPECIAL_CATEGORY = 'e-sonderzahlungen';

function labelOf(b: Booking): string | null {
  const sub = b.splits.find((s) => s.categoryId === SPECIAL_CATEGORY);
  if (sub) return sub.subCategory ?? 'Sonderzahlung';
  return WORDS.find(([re]) => re.test(b.text))?.[1] ?? null;
}
const median = (v: number[]) => {
  const s = [...v].sort((a, b) => a - b);
  return s.length ? s[Math.floor(s.length / 2)] : 0;
};

export function detectSpecialIncome(bookings: Booking[], today: LocalDate): SpecialIncome[] {
  const thisYear = Number(today.slice(0, 4));
  const groups = new Map<string, SpecialIncome>();
  const add = (key: string, label: string, b: Booking, amount: Cents, inSalary: boolean) => {
    const g = groups.get(key) ?? {
      key,
      label,
      month: Number(b.date.slice(5, 7)),
      day: Number(b.date.slice(8, 10)),
      accountId: b.accountId,
      years: [],
      lastAmount: 0,
      inSalary,
    };
    const y = Number(b.date.slice(0, 4));
    const e = g.years.find((x) => x.year === y);
    if (e) e.amount += amount;
    else g.years.push({ year: y, amount });
    g.years.sort((a, c) => a.year - c.year);
    g.lastAmount = g.years.at(-1)!.amount;
    g.day = Number(b.date.slice(8, 10));
    groups.set(key, g);
  };
  const income = bookings.filter(
    (b) =>
      b.kind === 'einnahme' && b.status !== 'geplant' && Number(b.date.slice(0, 4)) <= thisYear,
  );
  // eigene Buchungen: Kategorie „Sonderzahlungen“ oder eindeutiger Buchungstext
  for (const b of income) {
    const label = labelOf(b);
    if (
      label &&
      !b.splits.some((s) => s.categoryId === SALARY && !WORDS.some(([re]) => re.test(b.text)))
    )
      add(`buchung|${b.accountId}|${b.date.slice(5, 7)}|${label}`, label, b, b.amount, false);
  }
  // Mehrbetrag in der Gehaltsbuchung: über Median + 50 % der Gehälter desselben Kontos
  const salaries = income.filter(
    (b) => b.splits.some((s) => s.categoryId === SALARY) && !labelOf(b),
  );
  for (const acc of new Set(salaries.map((b) => b.accountId))) {
    const list = salaries.filter((b) => b.accountId === acc);
    const normal = median(list.map((b) => b.amount));
    for (const b of list)
      if (normal > 0 && b.amount > normal * 1.5) {
        const m = Number(b.date.slice(5, 7));
        const label =
          m === 11 || m === 12
            ? 'Weihnachtsgeld (im Gehalt)'
            : m >= 5 && m <= 7
              ? 'Urlaubsgeld (im Gehalt)'
              : 'Sonderzahlung (im Gehalt)';
        add(`gehalt|${acc}|${b.date.slice(5, 7)}`, label, b, b.amount - normal, true);
      }
  }
  // im Gehalt versteckt: erst bei Wiederholung in mindestens zwei Jahren; als eigene Buchung schon beim ersten Mal
  return [...groups.values()]
    .filter((g) => !g.inSalary || g.years.length >= 2)
    .sort((a, b) => a.month - b.month);
}

export const specialIncomeText = (s: SpecialIncome) => `${s.label} im ${MONTH_NAMES[s.month - 1]}`;

/** Termine bestätigter Sonderzahlungen im Prognosezeitraum (nächstes Vorkommen nach heute) */
export function specialIncomeSchedule(
  confirmed: ConfirmedSpecialIncome[],
  today: LocalDate,
  horizonDays = 400,
): { c: ConfirmedSpecialIncome; date: LocalDate }[] {
  const until = new Date(Date.parse(today) + horizonDays * 86400000).toISOString().slice(0, 10);
  const out: { c: ConfirmedSpecialIncome; date: LocalDate }[] = [];
  for (const c of confirmed)
    for (let y = Number(today.slice(0, 4)); y <= Number(until.slice(0, 4)); y++) {
      const last = new Date(Date.UTC(y, c.month, 0)).getUTCDate();
      const d = `${y}-${String(c.month).padStart(2, '0')}-${String(Math.min(c.day, last)).padStart(2, '0')}`;
      if (d > today && d <= until) out.push({ c, date: d });
    }
  return out.sort((a, b) => a.date.localeCompare(b.date));
}
