import { describe, expect, it } from 'vitest';
import { Booking } from '../bookings/booking';
import {
  easterSunday,
  holidaysBavaria,
  isBankDay,
  nextBankDay,
  prevBankDay,
  subBankDays,
} from '../shared/bank-days';
import { contractState, priceChanges } from './contracts';
import {
  RecurringItem,
  detectRecurring,
  expectedAmount,
  occurrences,
  plannedOccurrences,
} from './recurring';

let n = 0;
const bk = (
  date: string,
  amount: number,
  text: string,
  cat: string | null = null,
  sub: string | null = null,
): Booking => ({
  id: `b${++n}`,
  accountId: 'g',
  kind: amount < 0 ? 'ausgabe' : 'einnahme',
  status: 'gebucht',
  amount,
  date,
  seq: n,
  text,
  splits: cat ? [{ categoryId: cat, subCategory: sub, amount }] : [],
  confidence: 'sicher',
  source: { type: 'email' },
});
const months = (from: string, count: number) =>
  Array.from({ length: count }, (_, i) => {
    const t = Number(from.slice(0, 4)) * 12 + Number(from.slice(5, 7)) - 1 + i;
    return `${Math.floor(t / 12)}-${String((t % 12) + 1).padStart(2, '0')}`;
  });
const TODAY = '2026-11-17';
const data: Booking[] = [];
for (const m of months('2025-11', 13)) {
  data.push(
    bk(nextBankDay(`${m}-13`), -2959, 'AGILA Hau.', 'a-versicherungen', 'Tierversicherung'),
  );
  data.push(
    bk(
      nextBankDay(`${m}-02`),
      m >= '2026-11' ? -9500 : -8900,
      'STADTWERKE STROM ABSCHLAG',
      'a-strom',
    ),
  );
  data.push(
    bk(
      nextBankDay(`${m}-13`),
      m >= '2026-11' ? -1399 : -1299,
      'NETFLIX.COM',
      'a-abos-streaming',
      'Streaming',
    ),
  );
  data.push(bk(prevBankDay(`${m}-01`), 245000, 'GEHALT SANDRA', 'e-gehalt', 'Gehalt Sandra'));
  data.push(
    bk(
      prevBankDay(`${m}-15`),
      190000 + ((Number(m.slice(5)) * 3700) % 50000),
      'GEHALT MARTIN',
      'e-gehalt',
      'Gehalt Martin',
    ),
  );
  for (const d of ['03', '09', '21'])
    data.push(
      bk(`${m}-${d}`, -(2000 + Number(d) * 137), 'REWE MARKT', 'a-haushalt', 'Lebensmittel'),
    );
}
for (const m of ['2025-11', '2026-02', '2026-05', '2026-08'])
  data.push(bk(nextBankDay(`${m}-15`), -16024, 'Markt Alt.', 'a-wasser-abwasser'));
data.push(bk('2024-12-02', -58000, 'KFZ-VERSICHERUNG HUK', 'a-versicherungen', 'Kfz'));
data.push(bk('2025-12-01', -60000, 'KFZ-VERSICHERUNG HUK', 'a-versicherungen', 'Kfz'));
const found = detectRecurring(data, TODAY);
const by = (p: string) => found.find((f) => f.pattern === p)!;

describe('Bankarbeitstage Bayern', () => {
  it('kennt die Feiertage', () => {
    expect(easterSunday(2026)).toBe('2026-04-05');
    expect([...holidaysBavaria(2026)]).toEqual(
      expect.arrayContaining([
        '2026-01-06',
        '2026-04-03',
        '2026-04-06',
        '2026-05-14',
        '2026-05-25',
        '2026-06-04',
        '2026-08-15',
        '2026-11-01',
        '2026-12-24',
        '2026-12-31',
      ]),
    );
    expect(isBankDay('2026-12-24')).toBe(false);
    expect(isBankDay('2026-11-17')).toBe(true);
  });
  it('verschiebt auf den nächsten oder vorigen Bankarbeitstag', () => {
    expect(nextBankDay('2026-11-15')).toBe('2026-11-16');
    expect(prevBankDay('2026-11-01')).toBe('2026-10-30');
    expect(prevBankDay('2027-01-01')).toBe('2026-12-30');
    expect(subBankDays('2026-12-01', 2)).toBe('2026-11-27');
  });
});

describe('Wiederkehrende Zahlungen erkennen', () => {
  it('monatlich mit festem Betrag und üblichem Tag', () => {
    expect(by('AGILA HAU.')).toMatchObject({
      interval: 'monat',
      amount: -2959,
      day: 13,
      categoryId: 'a-versicherungen',
      variable: false,
    });
    expect(by('AGILA HAU.').months).toHaveLength(12);
  });
  it('vierteljährlich und jährlich', () => {
    expect(by('MARKT ALT.')).toMatchObject({
      interval: 'quartal',
      months: [2, 5, 8, 11],
      day: 15,
      amount: -16024,
    });
    expect(by('KFZ-VERSICHERUNG HUK')).toMatchObject({
      interval: 'jahr',
      months: [12],
      amount: -60000,
    });
  });
  it('Gehalt am 1., sonst am Bankarbeitstag davor: fester Betrag, Tag 1', () => {
    expect(by('GEHALT SANDRA')).toMatchObject({
      interval: 'monat',
      day: 1,
      amount: 245000,
      variable: false,
    });
  });
  it('schwankendes Gehalt: vorsichtig der zweitniedrigste der letzten sechs', () => {
    const m = by('GEHALT MARTIN');
    expect(m.variable).toBe(true);
    const last6 = data
      .filter((b) => b.text === 'GEHALT MARTIN')
      .slice(-6)
      .map((b) => b.amount)
      .sort((a, b) => a - b);
    expect(m.amount).toBe(last6[1]);
    expect(expectedAmount([300, 100, 200], true, true)).toBe(100);
  });
  it('mehrere Einkäufe im Monat mit wechselnden Beträgen sind keine Daueraufträge', () => {
    expect(found.find((f) => f.pattern === 'REWE MARKT')).toBeUndefined();
  });
  it('schon bestätigte oder abgelehnte werden nicht erneut vorgeschlagen', () => {
    const again = detectRecurring(data, TODAY, [by('AGILA HAU.')], ['g|NETFLIX.COM']);
    expect(again.some((f) => f.pattern === 'AGILA HAU.' || f.pattern === 'NETFLIX.COM')).toBe(
      false,
    );
  });
});

describe('Termine und Plan-Ist-Abgleich', () => {
  it('Gehaltstermine liegen auf dem Bankarbeitstag davor', () => {
    expect(occurrences(by('GEHALT SANDRA'), '2026-12-01', '2027-02-28').map((o) => o.date)).toEqual(
      ['2026-12-01', '2026-12-30', '2027-02-01'],
    );
  });
  it('erkennt Gebuchtes, Überfälliges und Geplantes', () => {
    const occ = plannedOccurrences(
      [by('MARKT ALT.'), by('AGILA HAU.')],
      data,
      '2026-11-01',
      '2026-12-31',
      TODAY,
    );
    expect(occ.map((o) => [o.item.pattern, o.date, o.state])).toEqual([
      ['AGILA HAU.', '2026-11-13', 'gebucht'],
      ['MARKT ALT.', '2026-11-16', 'ueberfaellig'],
      ['AGILA HAU.', '2026-12-14', 'geplant'],
    ]);
  });
});

describe('Verträge und Preisalarm', () => {
  const item = (p: Partial<RecurringItem>): RecurringItem => ({ ...by('NETFLIX.COM'), ...p });
  it('letzter Kündigungstag und Verlängerung', () => {
    const strom = item({
      contract: {
        provider: 'Stadtwerke',
        monthly: false,
        until: '2026-12-31',
        noticeN: 1,
        noticeUnit: 'Monate',
        renewMonths: 12,
      },
    });
    expect(contractState(strom, TODAY)).toMatchObject({
      deadline: '2026-11-30',
      days: 13,
      renewUntil: '2027-12-31',
    });
    const tsv = item({
      contract: {
        provider: 'TSV',
        monthly: false,
        until: '2026-12-31',
        noticeN: 3,
        noticeUnit: 'Monate',
        renewMonths: 12,
      },
    });
    expect(contractState(tsv, TODAY)).toMatchObject({
      until: '2027-12-31',
      deadline: '2027-09-30',
    });
    expect(
      contractState(
        item({
          contract: {
            provider: 'Netflix',
            monthly: true,
            until: null,
            noticeN: 0,
            noticeUnit: 'Monate',
            renewMonths: 0,
          },
        }),
        TODAY,
      )?.monthly,
    ).toBe(true);
  });
  it('Preiserhöhung bei Netflix, nicht beim verbrauchsabhängigen Strom', () => {
    const pcs = priceChanges([by('NETFLIX.COM'), by('STADTWERKE STROM')], data);
    expect(pcs.map((p) => [p.item.pattern, p.diff, p.percent])).toEqual([
      ['NETFLIX.COM', 100, 7.7],
    ]);
  });
});
