import { Booking } from '../bookings/booking';
import { normalizeText } from '../categories/rules';
import { addDays, daysBetween } from '../shared/bank-days';
import { Cents } from '../shared/money';
import { LocalDate } from '../shared/local-date';
import { RecurringItem } from './recurring';

/** Verträge und Preisalarm (Lastenheft 14a). */
export const USAGE_CATEGORIES = new Set(['a-strom', 'a-wasser-abwasser', 'a-holz']);
export const NOTICE_HINT_DAYS = 45;

function addMonths(d: LocalDate, k: number): LocalDate {
  let y = Number(d.slice(0, 4)),
    m = Number(d.slice(5, 7)) + k;
  while (m > 12) [y, m] = [y + 1, m - 12];
  while (m < 1) [y, m] = [y - 1, m + 12];
  const dim = new Date(Date.UTC(y, m, 0)).getUTCDate();
  return `${y}-${String(m).padStart(2, '0')}-${String(Math.min(Number(d.slice(8, 10)), dim)).padStart(2, '0')}`;
}

export interface ContractState {
  monthly: boolean;
  until: LocalDate | null;
  deadline: LocalDate | null;
  days: number | null;
  renewUntil: LocalDate | null;
}

/** Letzter Kündigungstag = Laufzeitende minus Frist; ist er vorbei, verlängert sich die Laufzeit. */
export function contractState(item: RecurringItem, today: LocalDate): ContractState | null {
  const c = item.contract;
  if (!c) return null;
  if (c.monthly || !c.until)
    return { monthly: c.monthly, until: c.until, deadline: null, days: null, renewUntil: null };
  const back = (d: LocalDate) =>
    c.noticeUnit === 'Wochen' ? addDays(d, -7 * c.noticeN) : addMonths(d, -c.noticeN);
  let until = c.until,
    dl = back(until),
    guard = 0;
  while (dl < today && guard++ < 50) {
    until = addMonths(until, c.renewMonths || 12);
    dl = back(until);
  }
  return {
    monthly: false,
    until,
    deadline: dl,
    days: daysBetween(today, dl),
    renewUntil: addMonths(until, c.renewMonths || 12),
  };
}

export const isUsageBased = (item: RecurringItem) =>
  item.usage ?? USAGE_CATEGORIES.has(item.categoryId ?? '');

export interface PriceChange {
  item: RecurringItem;
  previous: Booking;
  last: Booking;
  diff: Cents;
  percent: number;
  acknowledged: boolean;
}

/** Ist die letzte Zahlung mindestens 0,50 € und 1 % teurer als die vorige? Verbrauchsabhängige sind ausgenommen. */
export function priceChanges(items: RecurringItem[], bookings: Booking[]): PriceChange[] {
  const out: PriceChange[] = [];
  for (const item of items) {
    if (!item.active || item.variable || isUsageBased(item) || item.amount > 0) continue;
    const list = bookings
      .filter(
        (b) =>
          b.status === 'gebucht' &&
          b.kind === 'ausgabe' &&
          b.accountId === item.accountId &&
          normalizeText(b.text).startsWith(item.pattern),
      )
      .sort((a, b) => (a.date < b.date ? -1 : 1));
    if (list.length < 2) continue;
    const last = list[list.length - 1],
      previous = list[list.length - 2],
      diff = Math.abs(last.amount) - Math.abs(previous.amount);
    if (diff >= 50 && diff / Math.abs(previous.amount) >= 0.01)
      out.push({
        item,
        previous,
        last,
        diff,
        percent: Math.round((diff / Math.abs(previous.amount)) * 1000) / 10,
        acknowledged: item.priceAckBookingId === last.id,
      });
  }
  return out;
}
