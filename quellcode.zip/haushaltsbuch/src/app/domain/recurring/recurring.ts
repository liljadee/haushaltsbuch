import { Booking } from '../bookings/booking';
import { textSimilarity } from '../bookings/duplicates';
import { normalizeText } from '../categories/rules';
import { addDays, daysBetween, daysInMonth, nextBankDay, prevBankDay } from '../shared/bank-days';
import { Cents } from '../shared/money';
import { LocalDate } from '../shared/local-date';

/**
 * Wiederkehrende Zahlungen (Lastenheft 14, Bauplan 4 RecurringItem). Die App schlägt sie aus der Historie vor,
 * die Nutzerin bestätigt jede einmal. Danach plant die Prognose sie ein und gleicht sie mit Buchungen ab.
 */
export type Interval = 'monat' | 'quartal' | 'halbjahr' | 'jahr';
export const INTERVALS: Record<Interval, { label: string; months: number }> = {
  monat: { label: 'monatlich', months: 1 },
  quartal: { label: 'vierteljährlich', months: 3 },
  halbjahr: { label: 'halbjährlich', months: 6 },
  jahr: { label: 'jährlich', months: 12 },
};

export interface Contract {
  provider: string;
  monthly: boolean;
  until: LocalDate | null;
  noticeN: number;
  noticeUnit: 'Wochen' | 'Monate';
  renewMonths: number;
}

export interface RecurringItem {
  id: string;
  label: string;
  accountId: string;
  /** erwarteter Betrag (Ausgaben negativ) */
  amount: Cents;
  categoryId: string | null;
  subCategory: string | null;
  /** normalisierter Textanfang zum Wiedererkennen */
  pattern: string;
  interval: Interval;
  /** Kalendermonate (1–12), in denen gezahlt wird */
  months: number[];
  /** üblicher Tag im Monat */
  day: number;
  /** schwankender Betrag (z. B. Gehalt Martin): vorsichtige Schätzung */
  variable: boolean;
  active: boolean;
  /** frühester Monat (JJJJ-MM), ab dem geplant wird */
  startMonth?: string;
  contract?: Contract | null;
  /** verbrauchsabhängig: kein Preisalarm (Strom, Wasser, Holz) */
  usage?: boolean;
  /** quittierte Preisänderung */
  priceAckBookingId?: string | null;
}

export interface Occurrence {
  item: RecurringItem;
  date: LocalDate;
  amount: Cents;
  booking: Booking | null;
  state: 'gebucht' | 'ueberfaellig' | 'geplant';
}

// Ausgaben, Einnahmen und ausgehende Umbuchungen (Daueraufträge aufs Tagesgeld); Korrekturen nie
const regular = (b: Booking) =>
  b.status === 'gebucht' &&
  (b.kind === 'ausgabe' || b.kind === 'einnahme' || (b.kind === 'umbuchung' && b.amount < 0));
const median = (a: number[]) => {
  const s = [...a].sort((x, y) => x - y),
    n = s.length;
  return n ? (n % 2 ? s[(n - 1) / 2] : Math.round((s[n / 2 - 1] + s[n / 2]) / 2)) : 0;
};
export const patternOf = (text: string) => normalizeText(text).split(' ').slice(0, 2).join(' ');

/** Erwarteter Betrag: fester Betrag = letzter; schwankend = zweitniedrigster der letzten 6 (vorsichtig). */
export function expectedAmount(amounts: Cents[], variable: boolean, strict = false): Cents {
  if (!variable) return amounts[amounts.length - 1];
  const last = amounts
    .slice(-6)
    .map(Math.abs)
    .sort((a, b) => a - b);
  const pick = strict ? last[0] : (last[1] ?? last[0]);
  return Math.sign(amounts[0]) * pick;
}

/** Vorschläge aus der Historie: mindestens 3 Zahlungen (jährlich: 2) mit gleichem Text, ähnlichem Betrag, regelmäßigem Abstand. */
export function detectRecurring(
  bookings: Booking[],
  today: LocalDate,
  existing: RecurringItem[] = [],
  rejected: string[] = [],
): RecurringItem[] {
  // 25 Monate Rückblick, damit auch jährliche Zahlungen zweimal vorkommen
  const since = addDays(today, -760);
  const groups = new Map<string, Booking[]>();
  for (const b of bookings) {
    if (!regular(b) || b.date < since || b.date > today) continue;
    const key = `${b.accountId}|${Math.sign(b.amount)}|${patternOf(b.text)}`;
    groups.set(key, [...(groups.get(key) ?? []), b]);
  }
  const out: RecurringItem[] = [];
  for (const [key, list] of groups) {
    const items = list.sort((a, b) => (a.date < b.date ? -1 : 1));
    // eine Zahlung je Monat (Mehrfachkäufe im selben Monat sind kein Dauerauftrag)
    // Einnahmen ab dem 25. gehören zum Folgemonat (Gehalt am 30. für den nächsten Monat)
    const monthKey = (b: Booking) => {
      const [y, m, d] = b.date.split('-').map(Number);
      if (b.amount <= 0 || d < 25) return b.date.slice(0, 7);
      return m === 12 ? `${y + 1}-01` : `${y}-${String(m + 1).padStart(2, '0')}`;
    };
    const perMonth = new Map<string, Booking>();
    for (const b of items) perMonth.set(monthKey(b), b);
    const occ = [...perMonth.values()];
    if (occ.length < 2) continue;
    // häufiger als anderthalbmal im Monat (z. B. Einkäufe) ist kein Dauerauftrag
    if (items.length > occ.length * 1.5) continue;
    const keys = [...perMonth.keys()];
    const monthIndex = (k: string) => Number(k.slice(0, 4)) * 12 + Number(k.slice(5, 7));
    // Abstand in Tagen über die zugeordneten Monate (robust gegen „30. statt 1.“)
    const gaps = keys.slice(1).map((k, i) => (monthIndex(k) - monthIndex(keys[i])) * 30.4);
    const g = median(gaps);
    const interval: Interval | null =
      g >= 25 && g <= 35
        ? 'monat'
        : g >= 80 && g <= 100
          ? 'quartal'
          : g >= 170 && g <= 195
            ? 'halbjahr'
            : g >= 350 && g <= 380
              ? 'jahr'
              : null;
    if (!interval || (interval !== 'jahr' && occ.length < 3)) continue;
    if (gaps.some((x) => Math.abs(x - g) > (interval === 'monat' ? 10 : 20))) continue;
    // Betrag: fest (± 10 %) oder schwankend (Gehalt)
    const amounts = occ.map((b) => b.amount);
    const med = median(amounts.map(Math.abs));
    const fixed = amounts.every((a) => Math.abs(Math.abs(a) - med) <= med * 0.1);
    const income = amounts[0] > 0;
    if (!fixed && !income) continue;
    const last = occ[occ.length - 1];
    // nicht mehr aktiv, wenn die letzte Zahlung deutlich überfällig ist
    if (daysBetween(last.date, today) > g * 1.6 + 10) continue;
    const pattern = key.split('|')[2];
    if (
      rejected.includes(`${last.accountId}|${pattern}`) ||
      existing.some((e) => e.accountId === last.accountId && e.pattern === pattern)
    )
      continue;
    const step = INTERVALS[interval].months;
    const anchor = Number(keys[keys.length - 1].slice(5, 7));
    const months = Array.from(
      { length: 12 / step },
      (_, i) => ((anchor - 1 + i * step) % 12) + 1,
    ).sort((a, b) => a - b);
    const days = occ.map((b) => Number(b.date.slice(8, 10)));
    const split = last.splits[0];
    out.push({
      id: `vorschlag:${key}`,
      label: last.text,
      accountId: last.accountId,
      amount: expectedAmount(amounts, !fixed),
      categoryId: split?.categoryId ?? null,
      subCategory: split?.subCategory ?? null,
      pattern,
      interval,
      months,
      // Bankarbeitstage verschieben Ausgaben nach hinten, Einnahmen nach vorn: der vereinbarte Tag ist bei Ausgaben
      // der früheste, bei Einnahmen der späteste beobachtete (vor dem 25.)
      day: income ? Math.max(...days.filter((d) => d < 25), 1) : Math.min(...days),
      variable: !fixed,
      active: true,
    });
  }
  return out.sort((a, b) => Math.abs(b.amount) - Math.abs(a.amount));
}

/** Termine eines Postens im Zeitraum; Einnahmen am Bankarbeitstag davor, Ausgaben danach. */
export function occurrences(
  item: RecurringItem,
  from: LocalDate,
  to: LocalDate,
): { date: LocalDate; nominal: LocalDate }[] {
  const out: { date: LocalDate; nominal: LocalDate }[] = [];
  let y = Number(from.slice(0, 4)),
    m = Number(from.slice(5, 7)) - 1;
  if (m === 0) [y, m] = [y - 1, 12];
  const endKey = Number(to.slice(0, 4)) * 12 + Number(to.slice(5, 7)) + 1;
  while (y * 12 + m <= endKey) {
    const ym = `${y}-${String(m).padStart(2, '0')}`;
    if (item.months.includes(m) && (!item.startMonth || ym >= item.startMonth)) {
      const nominal = `${ym}-${String(Math.min(item.day, daysInMonth(y, m))).padStart(2, '0')}`;
      const date = item.amount > 0 ? prevBankDay(nominal) : nextBankDay(nominal);
      if (date >= from && date <= to) out.push({ date, nominal });
    }
    m++;
    if (m > 12) [y, m] = [y + 1, 1];
  }
  return out;
}

/** passende Buchung zu einem Termin: gleiches Konto, Text, Betrag ± 10 % (schwankend ± 40 %), Datum ± 5 Tage */
export function findMatch(
  item: RecurringItem,
  date: LocalDate,
  bookings: Booking[],
  used = new Set<string>(),
): Booking | null {
  const tol = item.variable ? 0.4 : 0.1;
  return (
    bookings.find(
      (b) =>
        !used.has(b.id) &&
        regular(b) &&
        b.accountId === item.accountId &&
        Math.sign(b.amount) === Math.sign(item.amount) &&
        Math.abs(Math.abs(b.amount) - Math.abs(item.amount)) <= Math.abs(item.amount) * tol &&
        Math.abs(daysBetween(b.date, date)) <= 5 &&
        (normalizeText(b.text).startsWith(item.pattern) ||
          textSimilarity(b.text, item.label) >= 0.6),
    ) ?? null
  );
}

/** Plan-Ist-Abgleich im Zeitraum (Lastenheft 14). */
export function plannedOccurrences(
  items: RecurringItem[],
  bookings: Booking[],
  from: LocalDate,
  to: LocalDate,
  today: LocalDate,
): Occurrence[] {
  const used = new Set<string>();
  const out: Occurrence[] = [];
  for (const item of items.filter((i) => i.active)) {
    for (const o of occurrences(item, from, to)) {
      const b = findMatch(item, o.date, bookings, used);
      if (b) used.add(b.id);
      out.push({
        item,
        date: o.date,
        amount: b ? b.amount : item.amount,
        booking: b,
        state: b ? 'gebucht' : o.date < today ? 'ueberfaellig' : 'geplant',
      });
    }
  }
  return out.sort((a, b) => (a.date < b.date ? -1 : 1));
}
