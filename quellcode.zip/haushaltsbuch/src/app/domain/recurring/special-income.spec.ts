import { describe, expect, it } from 'vitest';
import { Booking } from '../bookings/booking';
import { DEFAULT_CATEGORIES } from '../categories/categories';
import { expectedAmount } from './recurring';
import { detectSpecialIncome, specialIncomeSchedule } from './special-income';

let n = 0;
const inc = (
  date: string,
  amount: number,
  text: string,
  cat = 'e-gehalt',
  sub: string | null = null,
): Booking => ({
  id: `i${++n}`,
  accountId: 'g',
  kind: 'einnahme',
  status: 'gebucht',
  amount,
  date,
  seq: n,
  text,
  splits: [{ categoryId: cat, subCategory: sub, amount }],
  confidence: 'sicher',
  source: { type: 'email' },
});
const TODAY = '2026-11-19';
const salaries = (extraDec: number) =>
  ['2024', '2025'].flatMap((y) =>
    Array.from({ length: 12 }, (_, i) =>
      inc(
        `${y}-${String(i + 1).padStart(2, '0')}-01`,
        i === 11 ? 245000 + extraDec : 245000,
        'GEHALT SANDRA',
      ),
    ),
  );

describe('Sonderzahlungen im Einkommen (15.3, 15.5)', () => {
  it('Normalwert ohne Ausreißer: Gehalt mit Weihnachtsgeld zählt nicht als regulär', () => {
    expect(expectedAmount([245000, 245000, 245000, 245000, 245000, 455000], false)).toBe(245000);
    expect(expectedAmount([210000, 205000, 380000, 215000, 208000, 212000], true)).toBe(208000);
  });
  it('erhöhtes Gehalt im Dezember zweier Vorjahre: als Sonderzahlung im Dezember vorgeschlagen', () => {
    const s = detectSpecialIncome(salaries(210000), TODAY);
    expect(s).toMatchObject([
      {
        month: 12,
        inSalary: true,
        label: 'Weihnachtsgeld (im Gehalt)',
        years: [
          { year: 2024, amount: 210000 },
          { year: 2025, amount: 210000 },
        ],
        lastAmount: 210000,
      },
    ]);
  });
  it('einmaliger Mehrbetrag im Gehalt wird nicht vorgeschlagen; eigene Buchung mit klarem Text schon beim ersten Mal', () => {
    const once = [...salaries(0), inc('2025-03-01', 400000, 'GEHALT SANDRA')];
    expect(detectSpecialIncome(once, TODAY)).toEqual([]);
    const own = detectSpecialIncome(
      [inc('2025-06-28', 120000, 'Urlaubsgeld 2025', 'e-sonderzahlungen', 'Urlaubsgeld')],
      TODAY,
    );
    expect(own).toMatchObject([
      { month: 6, label: 'Urlaubsgeld', inSalary: false, lastAmount: 120000 },
    ]);
  });
  it('bestätigte Sonderzahlung: im Folgejahr im selben Monat in Höhe des Vorjahres eingeplant', () => {
    const sched = specialIncomeSchedule(
      [{ key: 'k', label: 'Weihnachtsgeld', month: 12, day: 1, accountId: 'g', amount: 210000 }],
      TODAY,
    );
    // Prognosezeitraum gut 13 Monate: beide Dezember
    expect(sched.map((x) => [x.date, x.c.amount])).toEqual([
      ['2026-12-01', 210000],
      ['2027-12-01', 210000],
    ]);
    expect(
      specialIncomeSchedule(
        [{ key: 'k', label: 'U', month: 6, day: 31, accountId: 'g', amount: 1 }],
        TODAY,
      ).map((x) => x.date),
    ).toEqual(['2027-06-30']);
  });
  it('die Kategorie „Sonderzahlungen“ gibt es unter der erwarteten Kennung', () => {
    expect(
      DEFAULT_CATEGORIES.some((c) => c.id === 'e-sonderzahlungen' && c.type === 'einnahme'),
    ).toBe(true);
  });
});
