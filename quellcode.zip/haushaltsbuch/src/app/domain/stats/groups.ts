import { Account } from '../accounts/account';
import { Booking } from '../bookings/booking';
import { normalizeText } from '../categories/rules';
import { Cents } from '../shared/money';
import { inPeriod } from './statistics';

/**
 * Eigene Gruppen für die Statistik (Wunsch 18.11.2026): Kredite und Sparkonten frei zusammenfassen und benennen,
 * z. B. „Hausfinanzierung“ = Rate Hauskredit + Sparrate Bausparvertrag. Eine zusätzliche Sicht; die drei Ebenen
 * (Konsum, Kontobewegungen, Sparbewegungen) bleiben unverändert.
 */
export interface StatGroupMember {
  type: 'kredit' | 'konto';
  /** kredit: Schlüssel aus dem Buchungstext; konto: Konto-ID */
  key: string;
}
export interface StatGroup {
  id: string;
  name: string;
  members: StatGroupMember[];
  /** Säule der Gruppe; frühere Werte „ausgabe“ werden als Finanzierung (mit Kredit) bzw. Konsum gelesen */
  countsAs?: 'fix' | 'konsum' | 'finanzierung' | 'sparen' | 'ausgabe';
}
export interface StatSettings {
  loanLabels: Record<string, string>;
  groups: StatGroup[];
  /** eigene Säulen je Kategorie („a-haushalt“) oder Unterkategorie („a-haushalt|Kleidung“) */
  pillars?: Record<string, 'fix' | 'konsum' | 'finanzierung' | 'sparen'>;
}
export const EMPTY_STAT_SETTINGS: StatSettings = { loanLabels: {}, groups: [] };

const LOAN_RE = /^(kreditrate|sondertilgung)\s+(.+?)\s*(?:\(.*)?$/i;

/** Kredit aus dem Buchungstext: „Kreditrate Hauskredit (…)“ oder „Sondertilgung Hauskredit“. */
export function loanOf(
  text: string,
): { key: string; name: string; kind: 'rate' | 'sondertilgung' } | null {
  const m = LOAN_RE.exec(text.trim());
  if (!m || !m[2].trim()) return null;
  return {
    key: normalizeText(m[2]),
    name: m[2].trim(),
    kind: m[1].toLowerCase() === 'kreditrate' ? 'rate' : 'sondertilgung',
  };
}

export function listLoans(bookings: Booking[]): { key: string; name: string; count: number }[] {
  const m = new Map<string, { key: string; name: string; count: number }>();
  for (const b of bookings) {
    if (b.kind !== 'ausgabe') continue;
    const l = loanOf(b.text);
    if (!l) continue;
    const e = m.get(l.key) ?? { key: l.key, name: l.name, count: 0 };
    e.count++;
    m.set(l.key, e);
  }
  return [...m.values()].sort((a, b) => b.count - a.count);
}

export const loanLabel = (key: string, name: string, s: StatSettings) =>
  s.loanLabels[key]?.trim() || name;

export interface GroupPart {
  member: StatGroupMember;
  label: string;
  amount: Cents;
  items: { booking: Booking; amount: Cents }[];
}
export interface GroupResult {
  group: StatGroup;
  total: Cents;
  parts: GroupPart[];
}

export function computeGroups(
  bookings: Booking[],
  accounts: Account[],
  s: StatSettings,
  months: string[],
  cutoffDay: number | null = null,
): GroupResult[] {
  const set = new Set(months);
  const cutoff = cutoffDay ? { month: months[months.length - 1], day: cutoffDay } : null;
  const live = bookings.filter((b) => b.status === 'gebucht' && inPeriod(b, set, cutoff));
  const names = new Map(listLoans(bookings).map((l) => [l.key, l.name]));
  return s.groups.map((group) => {
    const parts = group.members.map((member) => {
      const items =
        member.type === 'kredit'
          ? live
              .filter((b) => b.kind === 'ausgabe' && loanOf(b.text)?.key === member.key)
              .map((b) => ({ booking: b, amount: -b.amount }))
          : live
              .filter((b) => b.kind === 'umbuchung' && b.accountId === member.key)
              .map((b) => ({ booking: b, amount: b.amount }));
      const label =
        member.type === 'kredit'
          ? loanLabel(member.key, names.get(member.key) ?? member.key, s)
          : (accounts.find((a) => a.id === member.key)?.name ?? 'Konto');
      return { member, label, amount: items.reduce((t, i) => t + i.amount, 0), items };
    });
    return { group, total: parts.reduce((t, p) => t + p.amount, 0), parts };
  });
}
