import { describe, expect, it } from 'vitest';
import { Account } from '../accounts/account';
import { Booking } from '../bookings/booking';
import { DEFAULT_CATEGORIES as C } from '../categories/categories';
import {
  assignMonth,
  changePercent,
  comparisonOf,
  computeStats,
  monthPeriod,
  shiftMonth,
  yearPeriod,
} from './statistics';

const acc = (id: string, type: Account['type']): Account => ({
  id,
  name: id === 'g' ? 'Girokonto' : 'Tagesgeld',
  type,
  identifier: null,
  purpose: 'allgemein',
  reserve: 0,
  leadDays: 2,
  archived: false,
  order: 0,
  snapshots: [],
});
const A = [acc('g', 'giro'), acc('t', 'tagesgeld')];
let n = 0;
const bk = (
  date: string,
  amount: number,
  cat: string | null,
  sub: string | null = null,
  extra: Partial<Booking> = {},
): Booking => ({
  id: `b${++n}`,
  accountId: 'g',
  kind: amount < 0 ? 'ausgabe' : 'einnahme',
  status: 'gebucht',
  amount,
  date,
  seq: n,
  text: extra.text ?? 'Text',
  splits: cat ? [{ categoryId: cat, subCategory: sub, amount }] : [],
  confidence: 'sicher',
  source: { type: 'manuell' },
  ...extra,
});

describe('Zeiträume', () => {
  it('Gehalt ab dem 25. zählt zum Folgemonat', () => {
    expect(assignMonth(bk('2026-10-30', 245000, 'e-gehalt', 'Gehalt Sandra'))).toBe('2026-11');
    expect(assignMonth(bk('2026-10-24', 245000, 'e-gehalt'))).toBe('2026-10');
    expect(assignMonth(bk('2026-12-28', 245000, 'e-gehalt'))).toBe('2027-01');
    expect(assignMonth(bk('2026-10-30', 5000, 'e-sonstige-einnahmen'))).toBe('2026-10');
    expect(shiftMonth('2026-01', -1)).toBe('2025-12');
  });
  it('laufender Monat wird mit demselben Stück des Vormonats verglichen', () => {
    const p = monthPeriod('2026-11', '2026-11-17');
    expect(p).toMatchObject({ running: true, label: 'November 2026' });
    expect(comparisonOf(p, '2026-11-17')).toEqual({
      months: ['2026-10'],
      cutoffDay: 17,
      label: 'Oktober bis zum 17.',
    });
    const y = yearPeriod(2026, '2026-11-17');
    expect([y.months.length, y.label]).toEqual([11, '2026 bis 17.11.']);
    expect(comparisonOf(y, '2026-11-17')).toMatchObject({
      cutoffDay: 17,
      label: '01.01. bis 17.11.2025',
    });
    expect(yearPeriod(2025, '2026-11-17').months).toHaveLength(12);
  });
});

describe('Drei Ebenen', () => {
  const data: Booking[] = [
    bk('2026-10-30', 245000, 'e-gehalt', 'Gehalt Sandra'),
    bk('2026-11-03', -8540, 'a-haushalt', 'Lebensmittel', { text: 'REWE Markt 12' }),
    bk('2026-11-05', -2000, 'a-haushalt', 'Drogerie', { text: 'DM Drogerie' }),
    bk('2026-11-06', -4000, 'a-hunde', 'Futter', { text: 'Fressnapf' }),
    bk('2026-11-07', -10000, 'a-sparen', 'Depot & Sparplan'),
    bk('2026-11-08', -1500, null, null, { text: 'Unbekannt' }),
    { ...bk('2026-11-10', -50000, null), kind: 'umbuchung', transferGroupId: 'x' },
    { ...bk('2026-11-10', 50000, null), accountId: 't', kind: 'umbuchung', transferGroupId: 'x' },
    { ...bk('2026-11-11', -1234, null), kind: 'korrektur' },
    bk('2026-11-12', -999, 'a-haushalt', null, { status: 'geplant' }),
    {
      ...bk('2026-11-13', -9000, 'a-haushalt', 'Lebensmittel'),
      splits: [
        { categoryId: 'a-haushalt', subCategory: 'Lebensmittel', amount: -6000 },
        { categoryId: 'a-versicherungen', subCategory: 'Tierversicherung', amount: -3000 },
      ],
    },
  ];
  const s = computeStats(data, A, C, ['2026-11']);
  it('Ebene 1: Umbuchungen, Korrekturen, geplante Buchungen und Sparen sind kein Konsum', () => {
    expect(s.income).toBe(245000);
    expect(s.consumption).toBe(8540 + 2000 + 4000 + 1500 + 9000);
    expect(s.surplus).toBe(245000 - 25040);
    expect(s.savingsRatePermille).toBe(Math.round((219960 / 245000) * 1000));
  });
  it('Ebene 3: Sparen-Kategorie und Umbuchung aufs Tagesgeld sind Sparbewegungen', () => {
    expect(s.savings).toBe(10000 + 50000);
    expect(s.savingsMoves.map((x) => [x.label, x.amount])).toEqual([
      ['Tagesgeld', 50000],
      ['Depot & Sparplan', 10000],
    ]);
  });
  it('Ebene 2: Kontobewegungen enthalten alles Gebuchte je Konto', () => {
    const g = s.accounts.find((a) => a.accountId === 'g')!;
    expect(g.inflow).toBe(245000);
    expect(g.outflow).toBe(8540 + 2000 + 4000 + 10000 + 1500 + 50000 + 1234 + 9000);
  });
  it('Kategorien, Unterkategorien, Aufteilungen, Bezug und Händler', () => {
    expect(s.byCategory.map((c) => [c.label, c.amount])).toEqual([
      ['Haushalt', 16540],
      ['Hunde', 4000],
      ['Versicherungen', 3000],
      ['Nicht zugeordnet', 1500],
    ]);
    expect(s.bySub['a-haushalt'].map((x) => [x.label, x.amount])).toEqual([
      ['Lebensmittel', 14540],
      ['Drogerie', 2000],
    ]);
    expect(s.byScope.map((x) => [x.key, x.amount])).toEqual([['hunde', 7000]]);
    expect(s.byMerchant.find((m) => m.key === 'REWE MARKT')).toMatchObject({
      label: 'REWE Markt 12',
      amount: 8540,
    });
    expect(s.incomeBySource[0]).toMatchObject({ label: 'Gehalt', amount: 245000 });
  });
  it('Teilvergleich: nur bis zum gleichen Tag, das vorgezogene Gehalt zählt mit', () => {
    const p = computeStats(data, A, C, ['2026-11'], 6);
    expect([p.income, p.consumption]).toEqual([245000, 8540 + 2000 + 4000]);
  });
  it('Veränderungen ab 10 %', () => {
    expect([
      changePercent(110, 100, 10),
      changePercent(105, 100, 10),
      changePercent(50, 100),
      changePercent(5, 0),
    ]).toEqual([10, null, -50, null]);
  });
});
