import { describe, expect, it } from 'vitest';
import { Account } from '../accounts/account';
import { Booking } from '../bookings/booking';
import { DEFAULT_CATEGORIES as C } from '../categories/categories';
import {
  assignMonth,
  changePercent,
  comparisonOf,
  computeStats,
  monthPeriod,
  rangePeriod,
  shiftMonth,
  yearPeriod,
} from './statistics';

const acc = (id: string, type: Account['type']): Account => ({
  id,
  name: id === 'g' ? 'Girokonto' : 'Tagesgeld',
  type,
  identifier: null,
  purpose: 'allgemein',
  reserve: 0,
  leadDays: 2,
  archived: false,
  order: 0,
  snapshots: [],
});
const A = [acc('g', 'giro'), acc('t', 'tagesgeld')];
let n = 0;
const bk = (
  date: string,
  amount: number,
  cat: string | null,
  sub: string | null = null,
  extra: Partial<Booking> = {},
): Booking => ({
  id: `b${++n}`,
  accountId: 'g',
  kind: amount < 0 ? 'ausgabe' : 'einnahme',
  status: 'gebucht',
  amount,
  date,
  seq: n,
  text: extra.text ?? 'Text',
  splits: cat ? [{ categoryId: cat, subCategory: sub, amount }] : [],
  confidence: 'sicher',
  source: { type: 'manuell' },
  ...extra,
});

describe('Zeiträume', () => {
  it('Gehalt ab dem 25. zählt zum Folgemonat', () => {
    expect(assignMonth(bk('2026-10-30', 245000, 'e-gehalt', 'Gehalt Sandra'))).toBe('2026-11');
    expect(assignMonth(bk('2026-10-24', 245000, 'e-gehalt'))).toBe('2026-10');
    expect(assignMonth(bk('2026-12-28', 245000, 'e-gehalt'))).toBe('2027-01');
    expect(assignMonth(bk('2026-10-30', 5000, 'e-sonstige-einnahmen'))).toBe('2026-10');
    expect(shiftMonth('2026-01', -1)).toBe('2025-12');
  });
  it('laufender Monat wird mit demselben Stück des Vormonats verglichen', () => {
    const p = monthPeriod('2026-11', '2026-11-17');
    expect(p).toMatchObject({ running: true, label: 'November 2026' });
    expect(comparisonOf(p, '2026-11-17')).toEqual({
      months: ['2026-10'],
      cutoffDay: 17,
      label: 'Oktober bis zum 17.',
    });
    const y = yearPeriod(2026, '2026-11-17');
    expect([y.months.length, y.label]).toEqual([11, '2026 bis 17.11.']);
    expect(comparisonOf(y, '2026-11-17')).toMatchObject({
      cutoffDay: 17,
      label: '01.01. bis 17.11.2025',
    });
    expect(yearPeriod(2025, '2026-11-17').months).toHaveLength(12);
  });
});

describe('Drei Ebenen', () => {
  const data: Booking[] = [
    bk('2026-10-30', 245000, 'e-gehalt', 'Gehalt Sandra'),
    bk('2026-11-03', -8540, 'a-haushalt', 'Lebensmittel', { text: 'REWE Markt 12' }),
    bk('2026-11-05', -2000, 'a-haushalt', 'Drogerie', { text: 'DM Drogerie' }),
    bk('2026-11-06', -4000, 'a-hunde', 'Futter', { text: 'Fressnapf' }),
    bk('2026-11-07', -10000, 'a-sparen', 'Depot & Sparplan'),
    bk('2026-11-08', -1500, null, null, { text: 'Unbekannt' }),
    { ...bk('2026-11-10', -50000, null), kind: 'umbuchung', transferGroupId: 'x' },
    { ...bk('2026-11-10', 50000, null), accountId: 't', kind: 'umbuchung', transferGroupId: 'x' },
    { ...bk('2026-11-11', -1234, null), kind: 'korrektur' },
    bk('2026-11-12', -999, 'a-haushalt', null, { status: 'geplant' }),
    {
      ...bk('2026-11-13', -9000, 'a-haushalt', 'Lebensmittel'),
      splits: [
        { categoryId: 'a-haushalt', subCategory: 'Lebensmittel', amount: -6000 },
        { categoryId: 'a-versicherungen', subCategory: 'Tierversicherung', amount: -3000 },
      ],
    },
  ];
  const s = computeStats(data, A, C, ['2026-11']);
  it('Säulen: Fixkosten, Konsum, Sparen; Umbuchungen, Korrekturen und Geplantes zählen nicht als Ausgabe', () => {
    expect(s.income).toBe(245000);
    expect([s.fix, s.konsum, s.finanzierung, s.savings]).toEqual([
      8540 + 2000 + 4000 + 6000 + 3000,
      1500,
      0,
      10000 + 50000,
    ]);
    expect(s.consumption).toBe(25040);
    expect(s.free).toBe(245000 - 25040 - 60000);
    expect(s.wealth).toBe(60000);
    expect(s.wealthRatePermille).toBe(Math.round((60000 / 245000) * 1000));
  });
  it('Sparen: Kategorie „Sparen“ und Umbuchung aufs Tagesgeld', () => {
    expect(s.byPillar.sparen.map((x) => [x.label, x.amount])).toEqual([
      ['Tagesgeld', 50000],
      ['Sparen', 10000],
    ]);
  });
  it('Kontobewegungen enthalten alles Gebuchte je Konto', () => {
    const g = s.accounts.find((a) => a.accountId === 'g')!;
    expect(g.inflow).toBe(245000);
    expect(g.outflow).toBe(8540 + 2000 + 4000 + 10000 + 1500 + 50000 + 1234 + 9000);
  });
  it('Kategorien je Säule, Unterkategorien, Aufteilungen, Bezug und Händler', () => {
    expect(s.byPillar.fix.map((c) => [c.label, c.amount])).toEqual([
      ['Haushalt', 16540],
      ['Hunde', 4000],
      ['Versicherungen', 3000],
    ]);
    expect(s.byPillar.konsum.map((c) => [c.label, c.amount])).toEqual([['Nicht zugeordnet', 1500]]);
    expect(s.bySub['fix|a-haushalt'].map((x) => [x.label, x.amount])).toEqual([
      ['Lebensmittel', 14540],
      ['Drogerie', 2000],
    ]);
    expect(s.byScope.map((x) => [x.key, x.amount])).toEqual([['hunde', 7000]]);
    expect(s.byMerchant.find((m) => m.key === 'REWE MARKT')).toMatchObject({
      label: 'REWE Markt 12',
      amount: 8540,
    });
    expect(s.incomeBySource[0]).toMatchObject({ label: 'Gehalt', amount: 245000 });
  });
  it('Teilvergleich: nur bis zum gleichen Tag, das vorgezogene Gehalt zählt mit', () => {
    const p = computeStats(data, A, C, ['2026-11'], 6);
    expect([p.income, p.consumption]).toEqual([245000, 8540 + 2000 + 4000]);
  });
  it('Veränderungen ab 10 %', () => {
    expect([
      changePercent(110, 100, 10),
      changePercent(105, 100, 10),
      changePercent(50, 100),
      changePercent(5, 0),
    ]).toEqual([10, null, -50, null]);
  });
});

describe('Bestätigte Umbuchungen zählen (Rückmeldung 19.11.2026)', () => {
  it('1.250 € auf Sondertilgung, 500 € aufs Sparkonto (bestätigt) und 500 € zurück ergeben 1.250 € Sparen', () => {
    const acc3: Account[] = [
      acc('g', 'giro'),
      { ...acc('s', 'tagesgeld'), name: 'Sondertilgung', purpose: 'sondertilgung' },
      { ...acc('a', 'tagesgeld'), name: 'Sparkonto', purpose: 'allgemein' },
    ];
    const t = (
      id: string,
      from: string,
      to: string,
      amount: number,
      status: Booking['status'],
    ): Booking[] => [
      {
        id: id + 'f',
        accountId: from,
        kind: 'umbuchung',
        status,
        amount: -amount,
        date: '2026-11-10',
        seq: 1,
        text: 'Umbuchung',
        splits: [],
        confidence: 'sicher',
        transferGroupId: id,
        source: { type: 'manuell' },
      },
      {
        id: id + 't',
        accountId: to,
        kind: 'umbuchung',
        status,
        amount,
        date: '2026-11-10',
        seq: 2,
        text: 'Umbuchung',
        splits: [],
        confidence: 'sicher',
        transferGroupId: id,
        source: { type: 'manuell' },
      },
    ];
    const data = [
      ...t('1', 'g', 's', 125000, 'gebucht'),
      ...t('2', 'g', 'a', 50000, 'bestaetigt'),
      ...t('3', 'a', 'g', 50000, 'gebucht'),
    ];
    const s = computeStats(data, acc3, C, ['2026-11']);
    expect(s.savings).toBe(125000);
    expect(s.byPillar.sparen.map((x) => [x.label, x.amount])).toEqual([
      ['Sondertilgung', 125000],
      ['Sparkonto', 0],
    ]);
  });
});

describe('Kreditraten in Zinsen und Tilgung (v0.7)', () => {
  it('teilt eine Rate mit Vertrag in zwei Zeilen; die Summe bleibt die Rate', () => {
    const rate: Booking = {
      id: 'kr',
      accountId: 'g',
      kind: 'ausgabe',
      status: 'gebucht',
      amount: -78000,
      date: '2026-11-30',
      seq: 1,
      text: 'Kreditrate Hauskredit',
      splits: [{ categoryId: 'a-kredite', subCategory: null, amount: -78000 }],
      confidence: 'sicher',
      source: { type: 'xlsx' },
    };
    const s = computeStats(
      [rate],
      A,
      C,
      ['2026-11'],
      null,
      {},
      [],
      {},
      { kr: { interest: 24000, principal: 54000, name: 'Hauskredit' } },
    );
    expect(s.finanzierung).toBe(78000);
    expect(s.bySub['finanzierung|a-kredite'].map((x) => [x.label, x.amount])).toEqual([
      ['Hauskredit: Tilgung', 54000],
      ['Hauskredit: Zinsen', 24000],
    ]);
  });
});

describe('Erstattungen (10.2) und frei gewählter Zeitraum (13.2)', () => {
  it('Erstattung zu einer Ausgabenkategorie mindert die Ausgaben dort und zählt nie als Einkommen', () => {
    const b = [
      bk('2026-10-03', -10000, 'a-haushalt', 'Lebensmittel'),
      bk('2026-10-20', 4000, 'a-haushalt', 'Lebensmittel'),
      bk('2026-10-15', 250000, 'e-gehalt'),
    ];
    const st = computeStats(b, A, C, ['2026-10']);
    const withoutRefund = computeStats(b.slice(0, 1).concat(b.slice(2)), A, C, ['2026-10']);
    expect(st.income).toBe(250000);
    expect(st.free - withoutRefund.free).toBe(4000);
  });
  it('Zeitraum über mehrere Monate, auch „gesamter Zeitraum“; ohne Vergleich mit einem Vorzeitraum', () => {
    const p = rangePeriod('2026-11', '2026-09', '2026-11-19');
    expect([p.kind, p.months, p.running]).toEqual([
      'zeitraum',
      ['2026-09', '2026-10', '2026-11'],
      true,
    ]);
    expect(comparisonOf(p, '2026-11-19').months).toEqual([]);
  });
});
