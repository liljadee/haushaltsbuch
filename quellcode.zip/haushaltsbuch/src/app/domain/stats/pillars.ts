/**
 * Säulen der Statistik (Wunsch 18.11.2026): Fixkosten, Konsum, Finanzierung, Sparen.
 * Fixkosten = laufende, notwendige Kosten, nichts aus der Freizeitgestaltung; Konsum = alles andere,
 * auch Anschaffungen wie ein neues Auto. Voreinstellung je Kategorie und Unterkategorie, in den Einstellungen änderbar.
 */
export type Pillar = 'fix' | 'konsum' | 'finanzierung' | 'sparen';
export const PILLARS: Record<Pillar, string> = {
  fix: 'Fixkosten',
  konsum: 'Konsum',
  finanzierung: 'Finanzierung',
  sparen: 'Sparen',
};
export const PILLAR_ORDER: Pillar[] = ['fix', 'konsum', 'finanzierung', 'sparen'];

export const DEFAULT_PILLARS: Record<string, Pillar> = {
  'a-haushalt': 'fix',
  'a-haushalt|Haushaltswaren': 'konsum',
  'a-haushalt|Kleidung': 'konsum',
  'a-haus-garten': 'konsum',
  'a-haus-garten|Wartung & Schornsteinfeger': 'fix',
  'a-holz': 'fix',
  'a-strom': 'fix',
  'a-wasser-abwasser': 'fix',
  'a-internet-telefon': 'fix',
  'a-abos-streaming': 'konsum',
  'a-versicherungen': 'fix',
  'a-steuern-gebuehren': 'fix',
  'a-kredite': 'finanzierung',
  'a-hunde': 'fix',
  'a-hunde|Zubehör': 'konsum',
  'a-hunde|Betreuung & Hundeschule': 'konsum',
  'a-fahrzeuge': 'konsum',
  'a-fahrzeuge|Tanken': 'fix',
  'a-fahrzeuge|Werkstatt & TÜV': 'fix',
  'a-fahrzeuge|Parken & Maut': 'fix',
  'a-gesundheit': 'fix',
  'a-urlaub': 'konsum',
  'a-freizeit-martin': 'konsum',
  'a-freizeit-sandra': 'konsum',
  'a-vereine-spenden': 'konsum',
  'a-nebenjob': 'fix',
  'a-sparen': 'sparen',
  'a-bargeld': 'konsum',
  'a-andere': 'konsum',
};

/** Eigene Zuordnung vor Voreinstellung; die Kategorie-Wahl gilt für alle Unterkategorien ohne eigene Wahl. */
export function pillarOf(
  categoryId: string | null,
  sub: string | null,
  overrides: Record<string, Pillar> = {},
): Pillar {
  if (!categoryId) return 'konsum';
  const k = `${categoryId}|${sub ?? ''}`;
  return (
    (sub ? overrides[k] : undefined) ??
    overrides[categoryId] ??
    (sub ? DEFAULT_PILLARS[k] : undefined) ??
    DEFAULT_PILLARS[categoryId] ??
    'konsum'
  );
}
