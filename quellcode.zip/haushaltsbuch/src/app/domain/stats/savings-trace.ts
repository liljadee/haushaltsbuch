import { Account } from '../accounts/account';
import { Booking } from '../bookings/booking';
import { Category } from '../categories/categories';
import { Cents } from '../shared/money';
import { StatGroup } from './groups';
import { PILLARS, Pillar, pillarOf } from './pillars';
import { assignMonth, groupPillar, monthName, shiftMonth } from './statistics';

/**
 * Rechenweg „Sparen“ (Rückmeldung 19.11.2026): jede Buchung auf Sparkonten im Zeitraum mit dem Vermerk,
 * ob und wie sie zählt und wenn nicht, warum nicht; dazu Buchungen, die nach einer Umbuchung aussehen,
 * und unvollständige Umbuchungen. Die Summe der gezählten Zeilen ist genau die Kennzahl „Sparen“.
 */
export interface TraceRow {
  booking: Booking;
  account: string;
  /** Beitrag zur Kennzahl Sparen (null = zählt nicht) */
  counted: Cents | null;
  type: 'zaehlt' | 'zaehlt-nicht' | 'verdacht' | 'fehler';
  note: string;
}

const SAVINGS = new Set(['tagesgeld', 'bauspar']);
const HINT = /spar|tagesgeld|rücklage|ruecklage|sondertilg|übertrag|uebertrag|puffer|umbuchung/i;

export function savingsTrace(
  bookings: Booking[],
  accounts: Account[],
  cats: Category[],
  months: string[],
  groups: StatGroup[] = [],
  overrides: Record<string, Pillar> = {},
): TraceRow[] {
  const set = new Set(months);
  const window = new Set([
    shiftMonth(months[0], -1),
    ...months,
    shiftMonth(months[months.length - 1], 1),
  ]);
  const acc = new Map(accounts.map((a) => [a.id, a]));
  const name = (id: string) => acc.get(id)?.name ?? 'unbekanntes Konto';
  const savingsAcc = (id: string) => SAVINGS.has(acc.get(id)?.type ?? '');
  const groupOf = new Map<string, StatGroup>();
  for (const g of groups)
    for (const m of g.members) if (m.type === 'konto' && !groupOf.has(m.key)) groupOf.set(m.key, g);
  const byGroup = new Map<string, Booking[]>();
  for (const b of bookings)
    if (b.transferGroupId)
      byGroup.set(b.transferGroupId, [...(byGroup.get(b.transferGroupId) ?? []), b]);
  const savingsNames = accounts.filter((a) => SAVINGS.has(a.type)).map((a) => a.name.toLowerCase());
  const rows: TraceRow[] = [];

  for (const b of bookings) {
    const month = assignMonth(b);
    if (!window.has(month) || b.kind === 'korrektur') continue;
    const inSet = set.has(month) && b.status !== 'geplant';
    if (b.kind === 'umbuchung') {
      const pair = b.transferGroupId ? (byGroup.get(b.transferGroupId) ?? []) : [b];
      const other = pair.find((x) => x.id !== b.id);
      // Prüfung der Umbuchung: zwei Seiten, entgegengesetzte Vorzeichen, gleicher Betrag, verschiedene Konten
      const issue =
        pair.length !== 2
          ? 'Umbuchung unvollständig: Die Gegenbuchung fehlt.'
          : other && Math.sign(other.amount) === Math.sign(b.amount)
            ? 'Umbuchung fehlerhaft: Beide Seiten haben dasselbe Vorzeichen.'
            : other && Math.abs(other.amount) !== Math.abs(b.amount)
              ? `Umbuchung fehlerhaft: Die Gegenseite hat ${(Math.abs(other.amount) / 100).toFixed(2).replace('.', ',')} €.`
              : other && other.accountId === b.accountId
                ? 'Umbuchung fehlerhaft: Beide Seiten liegen auf demselben Konto.'
                : '';
      if (savingsAcc(b.accountId)) {
        const g = groupOf.get(b.accountId);
        if (!inSet)
          rows.push({
            booking: b,
            account: name(b.accountId),
            counted: null,
            type: issue ? 'fehler' : 'zaehlt-nicht',
            note: issue || `zählt im ${monthName(month)}`,
          });
        else if (g)
          rows.push({
            booking: b,
            account: name(b.accountId),
            counted: groupPillar(g) === 'sparen' ? b.amount : null,
            type: issue ? 'fehler' : groupPillar(g) === 'sparen' ? 'zaehlt' : 'zaehlt-nicht',
            note: issue || `steckt in der Gruppe „${g.name}“ (Säule ${PILLARS[groupPillar(g)]})`,
          });
        else {
          // mögliche Doppelbuchung: gleiche Konten, gleicher Betrag, höchstens 5 Tage Abstand
          const twin = bookings.find(
            (x) =>
              x.id !== b.id &&
              x.kind === 'umbuchung' &&
              x.accountId === b.accountId &&
              x.amount === b.amount &&
              x.transferGroupId !== b.transferGroupId &&
              Math.abs(Date.parse(x.date) - Date.parse(b.date)) <= 5 * 86400000 &&
              (byGroup.get(x.transferGroupId ?? '') ?? []).some(
                (y) => y.id !== x.id && y.accountId === other?.accountId,
              ),
          );
          const base = `${b.amount > 0 ? 'Einzahlung' : 'Entnahme'}${b.status === 'bestaetigt' ? ', bestätigt (Bank meldet noch)' : ''}`;
          rows.push({
            booking: b,
            account: name(b.accountId),
            counted: b.amount,
            type: issue ? 'fehler' : twin ? 'verdacht' : 'zaehlt',
            note:
              issue ||
              (twin
                ? `${base}; möglicherweise doppelt: gleiche Umbuchung „${twin.text}“ vom ${twin.date.slice(8, 10)}.${twin.date.slice(5, 7)}. Falls ja, eine davon löschen.`
                : base),
          });
        }
      } else if (issue && inSet) {
        rows.push({
          booking: b,
          account: name(b.accountId),
          counted: null,
          type: 'fehler',
          note: issue,
        });
      } else if (
        inSet &&
        b.amount < 0 &&
        other &&
        !savingsAcc(other.accountId) &&
        (HINT.test(b.text) || HINT.test(name(other.accountId)))
      ) {
        const t = acc.get(other.accountId)?.type;
        rows.push({
          booking: b,
          account: name(b.accountId),
          counted: null,
          type: 'verdacht',
          note: `Umbuchung auf „${name(other.accountId)}“; dieses Konto ist als ${t === 'giro' ? 'Girokonto' : 'Konto ohne Sparfunktion'} angelegt und zählt daher nicht als Sparen. Falls es ein Sparkonto ist: Kontoart unter Konten auf „Tagesgeld“ ändern.`,
        });
      }
      continue;
    }
    if (!inSet) continue;
    const parts = b.splits.length
      ? b.splits
      : [{ categoryId: null, subCategory: null, amount: b.amount }];
    const sparen = parts.filter(
      (s) => b.kind === 'ausgabe' && pillarOf(s.categoryId, s.subCategory, overrides) === 'sparen',
    );
    if (sparen.length) {
      rows.push({
        booking: b,
        account: name(b.accountId),
        counted: sparen.reduce((s, x) => s - x.amount, 0),
        type: 'zaehlt',
        note: 'Ausgabe in einer Kategorie der Säule Sparen',
      });
      continue;
    }
    const text = b.text.toLowerCase();
    if (HINT.test(b.text) || savingsNames.some((n) => n.length > 3 && text.includes(n)))
      rows.push({
        booking: b,
        account: name(b.accountId),
        counted: null,
        type: 'verdacht',
        note: `Sieht nach Umbuchung aus, ist aber als ${b.kind === 'ausgabe' ? 'Ausgabe' : 'Einnahme'} gebucht${b.kind === 'ausgabe' ? ` (Säule ${PILLARS[pillarOf(parts[0].categoryId, parts[0].subCategory, overrides)]})` : ''}. Ging das Geld auf ein eigenes Konto: öffnen und „In Umbuchung umwandeln“.`,
      });
  }
  return rows.sort((a, b) =>
    a.booking.date < b.booking.date
      ? -1
      : a.booking.date > b.booking.date
        ? 1
        : a.booking.seq - b.booking.seq,
  );
}
