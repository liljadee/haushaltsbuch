import { describe, expect, it } from 'vitest';
import { Account } from '../accounts/account';
import { Booking } from '../bookings/booking';
import { DEFAULT_CATEGORIES as C } from '../categories/categories';
import { StatSettings, computeGroups, listLoans, loanOf } from './groups';
import { pillarOf } from './pillars';
import { computeStats, groupPillar } from './statistics';

const acc = (id: string, name: string, type: Account['type']): Account => ({
  id,
  name,
  type,
  identifier: null,
  purpose: 'allgemein',
  reserve: 0,
  leadDays: 2,
  archived: false,
  order: 0,
  snapshots: [],
});
const A = [acc('g', 'Girokonto', 'giro'), acc('b', 'Bausparvertrag', 'bauspar')];
let n = 0;
const bk = (date: string, amount: number, text: string, extra: Partial<Booking> = {}): Booking => ({
  id: `b${++n}`,
  accountId: 'g',
  kind: amount < 0 ? 'ausgabe' : 'einnahme',
  status: 'gebucht',
  amount,
  date,
  seq: n,
  text,
  splits: [{ categoryId: 'a-kredite', subCategory: null, amount }],
  confidence: 'sicher',
  source: { type: 'xlsx' },
  ...extra,
});
const data: Booking[] = [];
for (const m of ['2026-09', '2026-10']) {
  data.push(bk(`${m}-01`, -78000, 'Kreditrate Hauskredit Sparkasse (Darlehen 4711)'));
  data.push(bk(`${m}-01`, -21000, 'Kreditrate Vorausdarlehen LBS'));
  data.push(bk(`${m}-15`, -24000, 'Kreditrate Autokredit'));
  data.push({
    ...bk(`${m}-02`, -15000, 'Umbuchung nach Bausparvertrag'),
    kind: 'umbuchung',
    splits: [],
    transferGroupId: m,
  });
  data.push({
    ...bk(`${m}-02`, 15000, 'Umbuchung von Girokonto'),
    accountId: 'b',
    kind: 'umbuchung',
    splits: [],
    transferGroupId: m,
  });
}
data.push(bk('2026-10-20', -500000, 'Sondertilgung Hauskredit Sparkasse'));
const settings: StatSettings = {
  loanLabels: {
    'HAUSKREDIT SPARKASSE': 'Hauskredit',
    'VORAUSDARLEHEN LBS': 'Bauspar-Vorausdarlehen',
  },
  groups: [
    {
      id: 'g1',
      name: 'Hausfinanzierung',
      members: [
        { type: 'kredit', key: 'HAUSKREDIT SPARKASSE' },
        { type: 'kredit', key: 'VORAUSDARLEHEN LBS' },
        { type: 'konto', key: 'b' },
      ],
    },
  ],
};

describe('Eigene Gruppen für Kredite und Bausparen', () => {
  it('erkennt Kredite am Buchungstext', () => {
    expect(loanOf('Kreditrate Hauskredit Sparkasse (Darlehen 4711)')).toEqual({
      key: 'HAUSKREDIT SPARKASSE',
      name: 'Hauskredit Sparkasse',
      kind: 'rate',
    });
    expect(loanOf('Sondertilgung Hauskredit Sparkasse')?.kind).toBe('sondertilgung');
    expect(loanOf('REWE Markt')).toBeNull();
    expect(listLoans(data).map((l) => [l.name, l.count])).toEqual([
      ['Hauskredit Sparkasse', 3],
      ['Vorausdarlehen LBS', 2],
      ['Autokredit', 2],
    ]);
  });
  it('fasst Kreditraten und Sparraten zur Gruppe zusammen', () => {
    const [g] = computeGroups(data, A, settings, ['2026-09']);
    expect(g.parts.map((p) => [p.label, p.amount])).toEqual([
      ['Hauskredit', 78000],
      ['Bauspar-Vorausdarlehen', 21000],
      ['Bausparvertrag', 15000],
    ]);
    expect(g.total).toBe(114000);
    const [okt] = computeGroups(data, A, settings, ['2026-10']);
    expect(okt.parts[0].amount).toBe(78000 + 500000);
  });
  it('schlüsselt Kredite in der Säule Finanzierung je Kredit mit Anzeigenamen auf', () => {
    const s = computeStats(data, A, C, ['2026-09'], null, settings.loanLabels);
    expect(s.bySub['finanzierung|a-kredite'].map((x) => [x.label, x.amount])).toEqual([
      ['Hauskredit', 78000],
      ['Autokredit', 24000],
      ['Bauspar-Vorausdarlehen', 21000],
    ]);
    expect([s.consumption, s.finanzierung, s.savings]).toEqual([0, 123000, 15000]);
  });
});

describe('Eigene Gruppen in den Säulen (Wunsch 18.11.2026)', () => {
  const groups = settings.groups;
  it('Gruppe mit Kredit zählt als Finanzierung; Bestandteile nicht doppelt', () => {
    const s = computeStats(data, A, C, ['2026-09'], null, settings.loanLabels, groups);
    expect(s.byPillar.finanzierung.map((c) => [c.label, c.amount])).toEqual([
      ['Hausfinanzierung', 114000],
      ['Kredite', 24000],
    ]);
    expect(s.bySub['finanzierung|grp:g1'].map((x) => [x.label, x.amount])).toEqual([
      ['Hauskredit', 78000],
      ['Bauspar-Vorausdarlehen', 21000],
      ['Bausparvertrag', 15000],
    ]);
    expect(s.bySub['finanzierung|a-kredite'].map((x) => x.label)).toEqual(['Autokredit']);
    expect([s.finanzierung, s.savings, s.byPillar.sparen.length]).toEqual([138000, 0, 0]);
    expect(s.byPillar.finanzierung.reduce((t, c) => t + c.amount, 0)).toBe(s.finanzierung);
  });
  it('Gruppe als Sparen: Zeile unter Sparen', () => {
    const s = computeStats(data, A, C, ['2026-09'], null, settings.loanLabels, [
      { ...groups[0], countsAs: 'sparen' },
    ]);
    expect(s.byPillar.finanzierung.map((c) => c.label)).toEqual(['Kredite']);
    expect(s.byPillar.sparen.map((x) => [x.label, x.amount])).toEqual([
      ['Hausfinanzierung', 114000],
    ]);
    expect([s.finanzierung, s.savings]).toEqual([24000, 114000]);
  });
  it('alte Einstellung „ausgabe“ wird als Finanzierung gelesen, wenn ein Kredit dabei ist', () => {
    expect(groupPillar({ ...groups[0], countsAs: 'ausgabe' })).toBe('finanzierung');
    expect(
      groupPillar({
        id: 'x',
        name: 'Spartopf',
        members: [{ type: 'konto', key: 'b' }],
        countsAs: 'ausgabe',
      }),
    ).toBe('konsum');
  });
});

describe('Säulen-Zuordnung', () => {
  it('Voreinstellung nach der Regel: laufende notwendige Kosten sind Fixkosten, Freizeit und Anschaffungen Konsum', () => {
    expect([
      pillarOf('a-haushalt', 'Lebensmittel'),
      pillarOf('a-haushalt', 'Kleidung'),
      pillarOf('a-abos-streaming', 'Streaming'),
      pillarOf('a-vereine-spenden', 'Mitgliedsbeiträge'),
    ]).toEqual(['fix', 'konsum', 'konsum', 'konsum']);
    expect([
      pillarOf('a-fahrzeuge', 'Tanken'),
      pillarOf('a-fahrzeuge', null),
      pillarOf('a-versicherungen', 'Kfz'),
      pillarOf('a-kredite', null),
      pillarOf('a-sparen', 'Depot & Sparplan'),
      pillarOf(null, null),
    ]).toEqual(['fix', 'konsum', 'fix', 'finanzierung', 'sparen', 'konsum']);
  });
  it('eigene Zuordnung: Kategorie für alle Unterkategorien, Unterkategorie gezielt', () => {
    expect(pillarOf('a-haushalt', 'Lebensmittel', { 'a-haushalt': 'konsum' })).toBe('konsum');
    expect(
      pillarOf('a-haushalt', 'Kleidung', { 'a-haushalt': 'konsum', 'a-haushalt|Kleidung': 'fix' }),
    ).toBe('fix');
  });
});
