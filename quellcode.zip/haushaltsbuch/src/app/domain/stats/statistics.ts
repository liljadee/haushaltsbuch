import { Account } from '../accounts/account';
import { Booking } from '../bookings/booking';
import { Category, Scope, categoryLabel, scopeOf } from '../categories/categories';
import { normalizeText } from '../categories/rules';
import { StatGroup, loanOf } from './groups';
import { Pillar, pillarOf } from './pillars';
import { Cents } from '../shared/money';
import { LocalDate } from '../shared/local-date';

/**
 * Statistik (Lastenheft 13) mit drei getrennten Ebenen (13.4):
 * 1 Haushalt: Einnahmen und Konsumausgaben; Umbuchungen und Korrekturen erscheinen nie.
 * 2 Kontobewegungen: alle Bewegungen je Konto, auch Umbuchungen und Korrekturen.
 * 3 Vermögensaufbau: Kategorie „Sparen“ und Umbuchungen auf Tagesgeld oder Bausparvertrag (Entnahmen negativ).
 * Gehälter ab dem 25. zählen zum Folgemonat (Lastenheft 15.1).
 */
export const SALARY_CUTOFF_DAY = 25;
export const SALARY_CATEGORY = 'e-gehalt';

const ym = (y: number, m: number) => `${y}-${String(m).padStart(2, '0')}`;
export function shiftMonth(month: string, n: number): string {
  const [y, m] = month.split('-').map(Number);
  const t = y * 12 + (m - 1) + n;
  return ym(Math.floor(t / 12), (t % 12) + 1);
}

/** Auswertungsmonat einer Buchung: Gehalt ab dem 25. gehört zum Folgemonat. */
export function assignMonth(b: Booking): string {
  const month = b.date.slice(0, 7);
  const salary = b.kind === 'einnahme' && b.splits.some((s) => s.categoryId === SALARY_CATEGORY);
  return salary && Number(b.date.slice(8, 10)) >= SALARY_CUTOFF_DAY ? shiftMonth(month, 1) : month;
}

export interface Period {
  kind: 'monat' | 'jahr';
  /** Monate, die zum Zeitraum gehören */
  months: string[];
  /** läuft der Zeitraum noch (enthält heute)? */
  running: boolean;
  label: string;
}

const MONTHS = [
  'Januar',
  'Februar',
  'März',
  'April',
  'Mai',
  'Juni',
  'Juli',
  'August',
  'September',
  'Oktober',
  'November',
  'Dezember',
];
export const monthName = (month: string) =>
  `${MONTHS[Number(month.slice(5, 7)) - 1]} ${month.slice(0, 4)}`;

export function monthPeriod(month: string, today: LocalDate): Period {
  return {
    kind: 'monat',
    months: [month],
    running: month === today.slice(0, 7),
    label: monthName(month),
  };
}

export function yearPeriod(year: number, today: LocalDate): Period {
  const running = String(year) === today.slice(0, 4);
  const last = running ? Number(today.slice(5, 7)) : 12;
  return {
    kind: 'jahr',
    months: Array.from({ length: last }, (_, i) => ym(year, i + 1)),
    running,
    label: running ? `${year} bis ${today.slice(8, 10)}.${today.slice(5, 7)}.` : String(year),
  };
}

/** Vergleichszeitraum: Vormonat bzw. Vorjahr; bei laufendem Zeitraum nur dasselbe Stück (bis zum gleichen Tag). */
export function comparisonOf(
  p: Period,
  today: LocalDate,
): { months: string[]; cutoffDay: number | null; label: string } {
  const day = Number(today.slice(8, 10));
  if (p.kind === 'monat') {
    const prev = shiftMonth(p.months[0], -1);
    return {
      months: [prev],
      cutoffDay: p.running ? day : null,
      label: p.running
        ? `${MONTHS[Number(prev.slice(5, 7)) - 1]} bis zum ${day}.`
        : MONTHS[Number(prev.slice(5, 7)) - 1],
    };
  }
  const months = p.months.map((m) => shiftMonth(m, -12));
  const y = Number(months[0].slice(0, 4));
  return {
    months,
    cutoffDay: p.running ? day : null,
    label: p.running ? `01.01. bis ${today.slice(8, 10)}.${today.slice(5, 7)}.${y}` : String(y),
  };
}

export interface Bucket {
  key: string;
  label: string;
  amount: Cents;
  count: number;
  items: { booking: Booking; amount: Cents }[];
}
export interface Stats {
  income: Cents;
  /** Säulen der Ausgaben (positiv) */
  fix: Cents;
  konsum: Cents;
  finanzierung: Cents;
  savings: Cents;
  /** Fixkosten + Konsum */
  consumption: Cents;
  /** Einnahmen − Fixkosten − Konsum − Finanzierung − Sparen */
  free: Cents;
  /** Vermögensaufbau = Sparen + Finanzierung (bis zur Aufteilung in v0.7 einschließlich Zinsen) */
  wealth: Cents;
  wealthRatePermille: number | null;
  /** Kategorien je Säule; Schlüssel „Säule|Kategorie“ */
  byPillar: Record<Pillar, Bucket[]>;
  bySub: Record<string, Bucket[]>;
  incomeBySource: Bucket[];
  byScope: Bucket[];
  byMerchant: Bucket[];
  accounts: { accountId: string; inflow: Cents; outflow: Cents }[];
  count: number;
}

const SAVINGS_TYPES = new Set(['tagesgeld', 'bauspar']);

function add(
  map: Map<string, Bucket>,
  key: string,
  label: string,
  amount: Cents,
  booking: Booking,
) {
  const b = map.get(key) ?? { key, label, amount: 0, count: 0, items: [] };
  b.amount += amount;
  b.count++;
  b.items.push({ booking, amount });
  map.set(key, b);
}
const sorted = (m: Map<string, Bucket>) =>
  [...m.values()].sort((a, b) => Math.abs(b.amount) - Math.abs(a.amount));

export function inPeriod(
  b: Booking,
  months: Set<string>,
  cutoff: { month: string; day: number } | null,
): boolean {
  const month = assignMonth(b);
  if (!months.has(month)) return false;
  // Teilvergleich: im letzten Monat nur bis zum Stichtag (Gehalt vom Vormonatsende zählt mit)
  return (
    !cutoff ||
    month !== cutoff.month ||
    b.date.slice(0, 7) !== month ||
    Number(b.date.slice(8, 10)) <= cutoff.day
  );
}

/** Säule einer eigenen Gruppe; alte Werte: „ausgabe“ = Finanzierung, wenn ein Kredit dabei ist, sonst Konsum. */
export function groupPillar(g: StatGroup): Pillar {
  const v = g.countsAs as string | undefined;
  if (v === 'fix' || v === 'konsum' || v === 'finanzierung' || v === 'sparen') return v;
  return g.members.some((m) => m.type === 'kredit') ? 'finanzierung' : 'konsum';
}

export function computeStats(
  bookings: Booking[],
  accounts: Account[],
  cats: Category[],
  months: string[],
  cutoffDay: number | null = null,
  loanLabels: Record<string, string> = {},
  groups: StatGroup[] = [],
  pillarOverrides: Record<string, Pillar> = {},
): Stats {
  const set = new Set(months);
  const cutoff = cutoffDay ? { month: months[months.length - 1], day: cutoffDay } : null;
  // eigene Gruppen: Bestandteile zählen nur in der Gruppe, nicht mehr in ihrer Kategorie
  const groupOfLoan = new Map<string, StatGroup>(),
    groupOfAccount = new Map<string, StatGroup>();
  for (const g of groups)
    for (const m of g.members) {
      if (m.type === 'kredit' && !groupOfLoan.has(m.key)) groupOfLoan.set(m.key, g);
      if (m.type === 'konto' && !groupOfAccount.has(m.key)) groupOfAccount.set(m.key, g);
    }
  const loanName = (key: string, name: string) => loanLabels[key]?.trim() || name;
  const accName = (id: string) => accounts.find((x) => x.id === id)?.name ?? 'Konto';
  const accType = new Map(accounts.map((a) => [a.id, a.type]));
  const totals: Record<Pillar, Cents> = { fix: 0, konsum: 0, finanzierung: 0, sparen: 0 };
  const pmap: Record<Pillar, Map<string, Bucket>> = {
    fix: new Map(),
    konsum: new Map(),
    finanzierung: new Map(),
    sparen: new Map(),
  };
  const subs = new Map<string, Map<string, Bucket>>();
  const inc = new Map<string, Bucket>(),
    scope = new Map<string, Bucket>(),
    merchant = new Map<string, Bucket>();
  const acc = new Map<string, { accountId: string; inflow: Cents; outflow: Cents }>();
  let income = 0,
    count = 0;
  const put = (
    pillar: Pillar,
    key: string,
    label: string,
    subKey: string,
    subLabel: string,
    amount: Cents,
    b: Booking,
  ) => {
    totals[pillar] += amount;
    const bk = `${pillar}|${key}`;
    add(pmap[pillar], bk, label, amount, b);
    const sm = subs.get(bk) ?? new Map<string, Bucket>();
    add(sm, subKey, subLabel, amount, b);
    subs.set(bk, sm);
  };
  for (const b of bookings) {
    // gebucht und bestätigt (ausgeführt, von der Bank noch nicht gemeldet) zählen; nur Geplantes nicht
    if (b.status === 'geplant' || !inPeriod(b, set, cutoff)) continue;
    count++;
    // Ebene 2: Kontobewegungen
    const a = acc.get(b.accountId) ?? { accountId: b.accountId, inflow: 0, outflow: 0 };
    if (b.amount > 0) a.inflow += b.amount;
    else a.outflow += -b.amount;
    acc.set(b.accountId, a);
    if (b.kind === 'korrektur') continue;
    if (b.kind === 'umbuchung') {
      // Zugang auf ein Spar-Konto (oder ein Konto einer Gruppe) zählt, Entnahmen mindern
      const g = groupOfAccount.get(b.accountId);
      if (g)
        put(
          groupPillar(g),
          `grp:${g.id}`,
          g.name,
          `konto:${b.accountId}`,
          accName(b.accountId),
          b.amount,
          b,
        );
      else if (SAVINGS_TYPES.has(accType.get(b.accountId) ?? ''))
        put(
          'sparen',
          `konto:${b.accountId}`,
          accName(b.accountId),
          'umbuchung',
          'Umbuchungen',
          b.amount,
          b,
        );
      continue;
    }
    const parts = b.splits.length
      ? b.splits
      : [{ categoryId: null, subCategory: null, amount: b.amount }];
    for (const s of parts) {
      if (b.kind === 'einnahme') {
        income += s.amount;
        add(
          inc,
          s.categoryId ?? 'none',
          s.categoryId ? categoryLabel(cats, s.categoryId, null) : 'Nicht zugeordnet',
          s.amount,
          b,
        );
        continue;
      }
      const amt = -s.amount;
      const loan = loanOf(b.text);
      const g = loan ? groupOfLoan.get(loan.key) : undefined;
      if (g && loan) {
        put(
          groupPillar(g),
          `grp:${g.id}`,
          g.name,
          `kredit:${loan.key}`,
          loanName(loan.key, loan.name),
          amt,
          b,
        );
        continue;
      }
      const pillar = pillarOf(s.categoryId, s.subCategory, pillarOverrides);
      const key = s.categoryId ?? 'none';
      const label = s.categoryId ? categoryLabel(cats, s.categoryId, null) : 'Nicht zugeordnet';
      // Kredite je Kredit aufschlüsseln (Buchungstext „Kreditrate …“), mit eigenem Anzeigenamen
      const kred = s.categoryId === 'a-kredite' ? loan : null;
      if (kred)
        put(pillar, key, label, `kredit:${kred.key}`, loanName(kred.key, kred.name), amt, b);
      else
        put(
          pillar,
          key,
          label,
          s.subCategory ?? 'ohne',
          s.subCategory ?? 'ohne Unterkategorie',
          amt,
          b,
        );
      if (pillar === 'fix' || pillar === 'konsum') {
        const sc: Scope | null = scopeOf(cats, s.categoryId, s.subCategory);
        if (sc) add(scope, sc, sc, amt, b);
        add(merchant, normalizeText(b.text).split(' ').slice(0, 2).join(' '), b.text, amt, b);
      }
    }
  }
  const out = totals.fix + totals.konsum + totals.finanzierung + totals.sparen;
  const wealth = totals.sparen + totals.finanzierung;
  return {
    income,
    fix: totals.fix,
    konsum: totals.konsum,
    finanzierung: totals.finanzierung,
    savings: totals.sparen,
    consumption: totals.fix + totals.konsum,
    free: income - out,
    wealth,
    wealthRatePermille: income > 0 ? Math.round((wealth / income) * 1000) : null,
    byPillar: {
      fix: sorted(pmap.fix),
      konsum: sorted(pmap.konsum),
      finanzierung: sorted(pmap.finanzierung),
      sparen: sorted(pmap.sparen),
    },
    bySub: Object.fromEntries([...subs.entries()].map(([k, m]) => [k, sorted(m)])),
    incomeBySource: sorted(inc),
    byScope: sorted(scope),
    byMerchant: sorted(merchant).slice(0, 15),
    accounts: [...acc.values()],
    count,
  };
}

/** Veränderung in Prozent, nur wenn sie mindestens `min` Prozent beträgt (Lastenheft 13.2: ab 10 %). */
export function changePercent(now: Cents, before: Cents, min = 0): number | null {
  if (!before) return null;
  const p = Math.round(((now - before) / Math.abs(before)) * 100);
  return Math.abs(p) >= min ? p : null;
}
