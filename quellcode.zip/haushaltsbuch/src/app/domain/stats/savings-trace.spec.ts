import { describe, expect, it } from 'vitest';
import { Account } from '../accounts/account';
import { Booking } from '../bookings/booking';
import { DEFAULT_CATEGORIES as C } from '../categories/categories';
import { savingsTrace } from './savings-trace';
import { computeStats } from './statistics';

const acc = (id: string, name: string, type: Account['type']): Account => ({
  id,
  name,
  type,
  identifier: null,
  purpose: 'allgemein',
  reserve: 0,
  leadDays: 2,
  archived: false,
  order: 0,
  snapshots: [{ id: 's' + id, date: '2026-10-01', seq: 1, balance: 0, source: 'start' }],
});
const A = [
  acc('g', 'Girokonto', 'giro'),
  acc('s', 'Sondertilgung', 'tagesgeld'),
  acc('a', 'Sparkonto', 'tagesgeld'),
  acc('x', 'Sparbuch Oma', 'giro'),
];
let n = 0;
const side = (
  id: string,
  account: string,
  amount: number,
  date: string,
  group: string,
  text = 'Umbuchung',
  status: Booking['status'] = 'gebucht',
): Booking => ({
  id,
  accountId: account,
  kind: 'umbuchung',
  status,
  amount,
  date,
  seq: ++n,
  text,
  splits: [],
  confidence: 'sicher',
  transferGroupId: group,
  source: { type: 'manuell' },
});
const tr = (
  g: string,
  from: string,
  to: string,
  amount: number,
  date: string,
  text = 'Umbuchung',
) => [side(g + 'f', from, -amount, date, g, text), side(g + 't', to, amount, date, g, text)];
const exp = (id: string, amount: number, text: string, cat = 'a-andere'): Booking => ({
  id,
  accountId: 'g',
  kind: 'ausgabe',
  status: 'gebucht',
  amount,
  date: '2026-11-05',
  seq: ++n,
  text,
  splits: [{ categoryId: cat, subCategory: null, amount }],
  confidence: 'sicher',
  source: { type: 'manuell' },
});
const base = [
  ...tr('st', 'g', 's', 125000, '2026-11-02', 'Sondertilg'),
  ...tr('sp', 'g', 'a', 50000, '2026-11-03', 'Sparen'),
  ...tr('pu', 'a', 'g', 50000, '2026-11-03', 'Puffer'),
];
const sum = (rows: ReturnType<typeof savingsTrace>) =>
  rows.reduce((s, r) => s + (r.counted ?? 0), 0);

describe('Rechenweg Sparen: doppelte Umbuchung', () => {
  it('meldet eine zweite gleiche Entnahme (z. B. „Puffer“ von Hand und „Jetzt umgebucht“); sie zählt, wird aber markiert', () => {
    const data = [...base, ...tr('ju', 'a', 'g', 50000, '2026-11-04', 'Umbuchung von Sparkonto')];
    const rows = savingsTrace(data, A, C, ['2026-11']);
    expect(rows.filter((r) => r.type === 'verdacht').map((r) => r.booking.id)).toEqual([
      'puf',
      'juf',
    ]);
    expect(rows.find((r) => r.booking.id === 'juf')!.note).toContain('möglicherweise doppelt');
    expect(sum(rows)).toBe(computeStats(data, A, C, ['2026-11']).savings);
    expect(sum(rows)).toBe(75000);
  });
});

describe('Rechenweg Sparen', () => {
  it('Beispiel der Nutzerin: 1.250 € + 500 € − 500 € = 1.250 €; Summe = Kennzahl', () => {
    const rows = savingsTrace(base, A, C, ['2026-11']);
    expect(rows.map((r) => [r.account, r.counted, r.type])).toEqual([
      ['Sondertilgung', 125000, 'zaehlt'],
      ['Sparkonto', 50000, 'zaehlt'],
      ['Sparkonto', -50000, 'zaehlt'],
    ]);
    expect(sum(rows)).toBe(computeStats(base, A, C, ['2026-11']).savings);
  });
  it('anderer Monat: „zählt im Oktober“', () => {
    const data = [
      ...base.filter((b) => !b.id.startsWith('sp')),
      ...tr('sp', 'g', 'a', 50000, '2026-10-30', 'Sparen'),
    ];
    const rows = savingsTrace(data, A, C, ['2026-11']);
    expect(rows.find((r) => r.booking.id === 'spt')).toMatchObject({
      counted: null,
      type: 'zaehlt-nicht',
      note: 'zählt im Oktober 2026',
    });
    expect(sum(rows)).toBe(computeStats(data, A, C, ['2026-11']).savings);
  });
  it('fehlerhafte Umbuchungen werden benannt: Gegenbuchung fehlt, gleiches Vorzeichen', () => {
    const orphan = base.filter((b) => b.id !== 'spf');
    const same = base.map((b) => (b.id === 'spf' ? { ...b, amount: 50000 } : b));
    expect(
      savingsTrace(orphan, A, C, ['2026-11']).find((r) => r.booking.id === 'spt'),
    ).toMatchObject({ type: 'fehler', note: 'Umbuchung unvollständig: Die Gegenbuchung fehlt.' });
    expect(
      savingsTrace(same, A, C, ['2026-11']).find((r) => r.booking.id === 'spt')!.note,
    ).toContain('dasselbe Vorzeichen');
    expect(sum(savingsTrace(orphan, A, C, ['2026-11']))).toBe(
      computeStats(orphan, A, C, ['2026-11']).savings,
    );
  });
  it('Konto in einer Gruppe einer anderen Säule zählt nicht als Sparen und wird so benannt', () => {
    const groups = [
      {
        id: 'h',
        name: 'Hausfinanzierung',
        members: [{ type: 'konto' as const, key: 's' }],
        countsAs: 'finanzierung' as const,
      },
    ];
    const rows = savingsTrace(base, A, C, ['2026-11'], groups);
    expect(rows[0]).toMatchObject({
      counted: null,
      note: 'steckt in der Gruppe „Hausfinanzierung“ (Säule Finanzierung)',
    });
    expect(sum(rows)).toBe(computeStats(base, A, C, ['2026-11'], null, {}, groups).savings);
  });
  it('Verdacht: als Ausgabe gebucht oder Umbuchung auf ein Konto, das als Girokonto angelegt ist', () => {
    const data = [
      ...base,
      exp('e', -10000, 'Übertrag Tagesgeld'),
      ...tr('ob', 'g', 'x', 2000, '2026-11-06', 'Sparen Oma'),
      exp('k', -3000, 'Depot Sparplan', 'a-sparen'),
    ];
    const rows = savingsTrace(data, A, C, ['2026-11']);
    expect(rows.find((r) => r.booking.id === 'e')).toMatchObject({ type: 'verdacht' });
    expect(rows.find((r) => r.booking.id === 'obf')!.note).toContain('als Girokonto angelegt');
    expect(rows.find((r) => r.booking.id === 'k')).toMatchObject({ type: 'zaehlt', counted: 3000 });
    expect(sum(rows)).toBe(computeStats(data, A, C, ['2026-11']).savings);
  });
});
