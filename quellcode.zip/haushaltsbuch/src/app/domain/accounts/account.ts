import { Cents } from '../shared/money';
import { LocalDate, isLocalDate } from '../shared/local-date';

/** Konto (Lastenheft 7, Bauplan 4). Kredite folgen mit v0.7 als eigene Verträge. */
export type AccountType = 'giro' | 'tagesgeld' | 'bauspar';
export type AccountPurpose = 'allgemein' | 'sondertilgung' | 'zweckgebunden';

/** Stand laut Bank zu einem Zeitpunkt: Startsaldo, Abgleich von Hand oder „Neuer Saldo“ einer E-Mail. */
export interface BalanceSnapshot {
  id: string;
  date: LocalDate;
  seq: number;
  balance: Cents;
  source: 'start' | 'abgleich' | 'email';
}

export interface Account {
  id: string;
  name: string;
  type: AccountType;
  /** Endziffern der Kontonummer, z. B. "1234" für „*1234“ in der Kontowecker-E-Mail. */
  identifier: string | null;
  purpose: AccountPurpose;
  /** Notreserve, die bei Umbuchungsvorschlägen stehen bleibt. */
  reserve: Cents;
  /** Überweisungsdauer in Bankarbeitstagen. */
  leadDays: number;
  snapshots: BalanceSnapshot[];
  archived: boolean;
  order: number;
}

export const ACCOUNT_TYPES: Record<AccountType, string> = {
  giro: 'Girokonto',
  tagesgeld: 'Tagesgeld',
  bauspar: 'Bausparvertrag',
};
export const PURPOSES: Record<AccountPurpose, string> = {
  allgemein: 'Allgemeine Rücklage',
  sondertilgung: 'Für Sondertilgungen',
  zweckgebunden: 'Zweckgebunden',
};

export interface AccountDraft {
  name: string;
  type: AccountType;
  identifier: string;
  purpose: AccountPurpose;
  reserve: Cents | null;
  leadDays: number | null;
}

/** Prüft die Eingaben eines Kontos; liefert verständliche Fehlertexte, leer = in Ordnung. */
export function validateAccount(d: AccountDraft, others: Account[], selfId?: string): string[] {
  const errors: string[] = [];
  const active = others.filter((a) => a.id !== selfId && !a.archived);
  const name = d.name.trim();
  if (!name) errors.push('Bitte einen Namen eingeben, z. B. „Girokonto“.');
  else if (active.some((a) => a.name.trim().toLowerCase() === name.toLowerCase()))
    errors.push(`Es gibt schon ein Konto „${name}“.`);
  const id = d.identifier.replace(/[\s*]/g, '');
  if (id && !/^\d{2,6}$/.test(id))
    errors.push('Die Kontokennung sind die letzten 2 bis 6 Ziffern der Kontonummer, z. B. 1234.');
  else if (id && active.some((a) => a.identifier === id))
    errors.push(`Die Kennung *${id} gehört schon zu einem anderen Konto.`);
  if (d.reserve === null || d.reserve < 0) errors.push('Die Notreserve ist ein Betrag ab 0,00 €.');
  if (d.leadDays === null || !Number.isInteger(d.leadDays) || d.leadDays < 0 || d.leadDays > 10)
    errors.push('Die Überweisungsdauer ist eine Zahl von 0 bis 10 Bankarbeitstagen.');
  return errors;
}

export function normalizeIdentifier(s: string): string | null {
  const id = s.replace(/[\s*]/g, '');
  return id ? id : null;
}

export function validSnapshotInput(
  date: string,
  balance: Cents | null,
  today: LocalDate,
): string | null {
  if (!isLocalDate(date)) return 'Bitte ein Datum wählen.';
  if (date > today) return 'Der Stand laut Bank kann nicht in der Zukunft liegen.';
  if (balance === null)
    return 'Bitte den Kontostand als Betrag eingeben, z. B. 1.158,12 oder -8,03.';
  return null;
}
