import { Booking } from '../bookings/booking';
import { LocalDate } from '../shared/local-date';
import { Cents } from '../shared/money';
import { Account, BalanceSnapshot } from './account';

/**
 * Kontostände und Saldenabgleich (Lastenheft 7.1 und 8.1, Bauplan 6.1 reconciliation).
 * Ein gemeldeter Stand laut Bank (Snapshot) ist ein Anker: Kontostand = letzter Snapshot plus gebuchte
 * Umsätze danach. Buchungen mit Datum und Erfassung vor einem Snapshot sind darin schon enthalten;
 * nachgetragene ändern den Kontostand deshalb nicht, schließen aber die Lücke.
 */
interface Keyed {
  date: LocalDate;
  seq: number;
}
const cmp = (a: Keyed, b: Keyed) => (a.date < b.date ? -1 : a.date > b.date ? 1 : a.seq - b.seq);
const counts = (b: Booking) => b.status === 'gebucht';

export function sortedSnapshots(acc: Account): BalanceSnapshot[] {
  return [...acc.snapshots].sort(cmp);
}

/** Kontostand am Ende des Tages `date`; null, solange kein Stand bekannt ist. */
export function balanceAt(acc: Account, bookings: Booking[], date: LocalDate): Cents | null {
  const snaps = sortedSnapshots(acc).filter((s) => s.date <= date);
  const anchor = snaps[snaps.length - 1];
  if (!anchor) return null;
  return bookings
    .filter((b) => b.accountId === acc.id && counts(b) && cmp(b, anchor) > 0 && b.date <= date)
    .reduce((s, b) => s + b.amount, anchor.balance);
}

export function currentBalance(acc: Account, bookings: Booking[]): Cents | null {
  return balanceAt(acc, bookings, '9999-12-31');
}

export interface GapInterval {
  /** Snapshot, der die Lücke aufgedeckt hat */
  snapshotId: string;
  from: LocalDate;
  to: LocalDate;
  /** gemeldet − erwartet: negativ = fehlende Ausgaben, positiv = fehlende Einnahmen */
  amount: Cents;
}

export interface GapReport {
  intervals: GapInterval[];
  /** Summe aller noch offenen Differenzen */
  open: Cents;
  /** Datum, ab dem etwas fehlt (erster Abschnitt mit Differenz) */
  since: LocalDate | null;
}

/** Vergleicht jeden Stand laut Bank mit dem vorherigen plus den Buchungen dazwischen. */
export function gapReport(acc: Account, bookings: Booking[]): GapReport {
  const snaps = sortedSnapshots(acc);
  const own = bookings.filter((b) => b.accountId === acc.id && counts(b));
  const intervals: GapInterval[] = [];
  for (let i = 1; i < snaps.length; i++) {
    const prev = snaps[i - 1],
      cur = snaps[i];
    const sum = own
      .filter((b) => cmp(b, prev) > 0 && cmp(b, cur) <= 0)
      .reduce((s, b) => s + b.amount, 0);
    const amount = cur.balance - (prev.balance + sum);
    if (amount !== 0) intervals.push({ snapshotId: cur.id, from: prev.date, to: cur.date, amount });
  }
  const open = intervals.reduce((s, g) => s + g.amount, 0);
  return { intervals, open, since: open !== 0 && intervals.length ? intervals[0].from : null };
}

/** Korrekturbuchung, die die offene Differenz schließt, ohne den Kontostand zu verändern. */
export function correctionFor(
  acc: Account,
  report: GapReport,
): { date: LocalDate; seqBefore: number; amount: Cents } | null {
  if (report.open === 0) return null;
  const last = sortedSnapshots(acc).at(-1);
  if (!last) return null;
  // vor dem letzten Snapshot einsortiert: zählt in die Lücke, nicht in den Kontostand
  return { date: last.date, seqBefore: last.seq - 0.5, amount: report.open };
}
