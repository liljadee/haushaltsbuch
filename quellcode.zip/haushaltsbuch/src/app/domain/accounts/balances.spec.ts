import { describe, expect, it } from 'vitest';
import { Booking } from '../bookings/booking';
import { Account, AccountDraft, validSnapshotInput, validateAccount } from './account';
import { balanceAt, correctionFor, currentBalance, gapReport } from './balances';

let seq = 0;
const acc = (snaps: [string, number][]): Account => ({
  id: 'g',
  name: 'Girokonto',
  type: 'giro',
  identifier: '1234',
  purpose: 'allgemein',
  reserve: 0,
  leadDays: 2,
  archived: false,
  order: 0,
  snapshots: snaps.map(([date, balance], i) => ({
    id: `s${i}`,
    date,
    seq: ++seq,
    balance,
    source: i ? 'email' : 'start',
  })),
});
const bk = (date: string, amount: number, extra: Partial<Booking> = {}): Booking => ({
  id: `b${++seq}`,
  accountId: 'g',
  kind: amount < 0 ? 'ausgabe' : 'einnahme',
  status: 'gebucht',
  amount,
  date,
  seq: ++seq,
  text: 't',
  splits: [],
  confidence: 'sicher',
  source: { type: 'manuell' },
  ...extra,
});

describe('Kontostand', () => {
  it('geht vom Startsaldo aus und zählt nur gebuchte Umsätze danach', () => {
    const a = acc([['2026-11-01', 150000]]);
    const b = [
      bk('2026-11-03', -2959),
      bk('2026-11-04', -16024),
      bk('2026-11-05', -999, { status: 'geplant' }),
    ];
    expect(currentBalance(a, b)).toBe(131017);
    expect(balanceAt(a, b, '2026-11-03')).toBe(147041);
    expect(balanceAt(a, b, '2026-10-31')).toBeNull();
  });

  it('Beispiel der Nutzerin: E-Mail meldet 1.158,12 €, zwei Umsätze bekannt → Lücke −152,05 €', () => {
    const a = acc([['2026-11-10', 150000]]);
    const mail = [bk('2026-11-17', -2959), bk('2026-11-17', -16024)];
    a.snapshots.push({
      id: 'mail',
      date: '2026-11-17',
      seq: ++seq,
      balance: 115812,
      source: 'email',
    });
    expect(currentBalance(a, mail)).toBe(115812);
    const r = gapReport(a, mail);
    expect(r.open).toBe(-15205);
    expect(r.since).toBe('2026-11-10');
  });

  it('nachgetragene Buchungen schließen die Lücke, ohne den Kontostand zu ändern', () => {
    const a = acc([['2026-11-10', 150000]]);
    const b = [bk('2026-11-17', -2959), bk('2026-11-17', -16024)];
    a.snapshots.push({
      id: 'mail',
      date: '2026-11-17',
      seq: ++seq,
      balance: 115812,
      source: 'email',
    });
    b.push(bk('2026-11-14', -10000, { source: { type: 'csv' } }));
    expect(gapReport(a, b).open).toBe(-5205);
    b.push(bk('2026-11-15', -5205, { source: { type: 'csv' } }));
    expect(gapReport(a, b)).toEqual({ intervals: [], open: 0, since: null });
    expect(currentBalance(a, b)).toBe(115812);
  });

  it('eine Korrekturbuchung schließt die Lücke und lässt Kontostand und spätere Umsätze unberührt', () => {
    const a = acc([['2026-11-10', 150000]]);
    a.snapshots.push({
      id: 'mail',
      date: '2026-11-17',
      seq: ++seq,
      balance: 115812,
      source: 'email',
    });
    const b = [bk('2026-11-17', -18983, { seq: a.snapshots[1].seq - 1 })];
    const c = correctionFor(a, gapReport(a, b));
    expect(c).toEqual({ date: '2026-11-17', seqBefore: a.snapshots[1].seq - 0.5, amount: -15205 });
    b.push(bk(c!.date, c!.amount, { kind: 'korrektur', seq: c!.seqBefore }));
    b.push(bk('2026-11-17', -500)); // später am selben Tag erfasst
    expect(gapReport(a, b).open).toBe(0);
    expect(currentBalance(a, b)).toBe(115312);
  });

  it('mehrere E-Mails am selben Tag: die Reihenfolge der Erfassung entscheidet', () => {
    const a = acc([['2026-11-01', 100000]]);
    const b1 = bk('2026-11-17', -1000);
    a.snapshots.push({ id: 'm1', date: '2026-11-17', seq: ++seq, balance: 99000, source: 'email' });
    const b2 = bk('2026-11-17', -2000);
    a.snapshots.push({ id: 'm2', date: '2026-11-17', seq: ++seq, balance: 97000, source: 'email' });
    expect(gapReport(a, [b1, b2]).open).toBe(0);
    expect(currentBalance(a, [b1, b2])).toBe(97000);
  });

  it('Abgleich von Hand mit höherem Stand meldet fehlende Einnahmen', () => {
    const a = acc([['2026-11-01', 485000]]);
    a.snapshots.push({
      id: 'h',
      date: '2026-11-17',
      seq: ++seq,
      balance: 486240,
      source: 'abgleich',
    });
    expect(gapReport(a, []).open).toBe(1240);
  });

  it('Buchungen anderer Konten zählen nicht mit', () => {
    const a = acc([['2026-11-01', 10000]]);
    expect(currentBalance(a, [bk('2026-11-02', -500, { accountId: 'x' })])).toBe(10000);
  });
});

describe('Kontodaten prüfen', () => {
  const draft = (p: Partial<AccountDraft> = {}): AccountDraft => ({
    name: 'Girokonto',
    type: 'giro',
    identifier: '*1234',
    purpose: 'allgemein',
    reserve: 0,
    leadDays: 2,
    ...p,
  });
  it('akzeptiert gültige Angaben', () => expect(validateAccount(draft(), [])).toEqual([]));
  it('verlangt einen eindeutigen Namen und eine eindeutige Kennung', () => {
    const a = acc([['2026-11-01', 0]]);
    expect(validateAccount(draft({ name: ' ' }), [])).toHaveLength(1);
    expect(validateAccount(draft({ name: 'girokonto' }), [a])[0]).toContain('schon ein Konto');
    expect(validateAccount(draft({ name: 'Zweitkonto', identifier: '1234' }), [a])[0]).toContain(
      '*1234',
    );
    expect(validateAccount(draft(), [a], 'g')).toEqual([]);
  });
  it('prüft Kennung, Notreserve und Überweisungsdauer', () => {
    expect(validateAccount(draft({ identifier: 'DE12' }), [])[0]).toContain('2 bis 6 Ziffern');
    expect(validateAccount(draft({ reserve: -1 }), [])[0]).toContain('Notreserve');
    expect(validateAccount(draft({ leadDays: 11 }), [])[0]).toContain('Überweisungsdauer');
  });
  it('prüft den Stand laut Bank', () => {
    expect(validSnapshotInput('2026-11-18', 0, '2026-11-17')).toContain('Zukunft');
    expect(validSnapshotInput('2026-02-30', 0, '2026-11-17')).toContain('Datum');
    expect(validSnapshotInput('2026-11-17', null, '2026-11-17')).toContain('Betrag');
    expect(validSnapshotInput('2026-11-17', -803, '2026-11-17')).toBeNull();
  });
});
