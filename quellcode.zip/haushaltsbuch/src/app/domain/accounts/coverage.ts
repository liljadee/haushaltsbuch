import { Booking } from '../bookings/booking';
import { MONTH_NAMES } from '../shared/format';
import { LocalDate } from '../shared/local-date';
import { Account } from './account';

/**
 * Datenabdeckung (Lastenheft 11.2): Auf einem Girokonto gibt es jeden Monat Umsätze; ein Monat ohne eine einzige
 * Buchung ist deshalb eine Lücke in den Daten, kein Monat ohne Ausgaben. Tages- und Bausparkonten haben oft monatelang
 * keine Umsätze und werden nicht geprüft.
 */
export interface AccountCoverage {
  accountId: string;
  name: string;
  /** erster Monat mit Daten (JJJJ-MM) */
  first: string | null;
  /** Monate ohne Daten zwischen dem ersten und dem Vormonat */
  gaps: string[];
}

const nextMonth = (m: string) => {
  const [y, mo] = m.split('-').map(Number);
  return mo === 12 ? `${y + 1}-01` : `${y}-${String(mo + 1).padStart(2, '0')}`;
};
export const monthLabel = (m: string) =>
  `${MONTH_NAMES[Number(m.slice(5, 7)) - 1]} ${m.slice(0, 4)}`;

export function coverage(
  accounts: Account[],
  bookings: Booking[],
  today: LocalDate,
): AccountCoverage[] {
  const current = today.slice(0, 7);
  return accounts
    .filter((a) => a.type === 'giro' && !a.archived)
    .map((a) => {
      const months = new Set(
        bookings
          .filter((b) => b.accountId === a.id && b.status !== 'geplant')
          .map((b) => b.date.slice(0, 7)),
      );
      const first = [...months].sort()[0] ?? null;
      const gaps: string[] = [];
      if (first)
        for (let m = first; m < current; m = nextMonth(m)) if (!months.has(m)) gaps.push(m);
      return { accountId: a.id, name: a.name, first, gaps };
    });
}

/** Für einen Monat liegen auf allen Girokonten Daten vor (vor dem ersten Monat eines Kontos: keine Daten) */
export function covered(month: string, cov: AccountCoverage[]): boolean {
  return cov.every((c) => c.first !== null && month >= c.first && !c.gaps.includes(month));
}

/** abgeschlossen: vorbei und für alle Girokonten vollständige Daten */
export function completeMonth(month: string, cov: AccountCoverage[], today: LocalDate): boolean {
  return month < today.slice(0, 7) && covered(month, cov);
}

/** Lücken eines Zeitraums als Text, z. B. „Girokonto: März 2025, April 2025“ */
export function gapsIn(months: string[], cov: AccountCoverage[]): string[] {
  return cov
    .map((c) => ({ c, g: c.gaps.filter((m) => months.includes(m)) }))
    .filter((x) => x.g.length)
    .map((x) => `${x.c.name}: ${x.g.map(monthLabel).join(', ')}`);
}
