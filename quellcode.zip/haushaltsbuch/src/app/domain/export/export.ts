import { Account } from '../accounts/account';
import { currentBalance } from '../accounts/balances';
import { Booking } from '../bookings/booking';
import { Category, categoryLabel, isTaxRelevant } from '../categories/categories';
import { Loan, LoanState } from '../loans/loan';
import { MONTH_NAMES } from '../shared/format';
import { LocalDate } from '../shared/local-date';
import { Stats } from '../stats/statistics';

/** Export (Lastenheft 12): Tabellen mit verständlichen Spaltenüberschriften; Format (CSV, XLSX) getrennt davon. */
export type ColType = 'text' | 'date' | 'euro' | 'number' | 'percent';
export interface Column {
  title: string;
  type: ColType;
}
export type Cell = string | number | null;
export interface Table {
  name: string;
  columns: Column[];
  rows: Cell[][];
}
export type ExportKind =
  | 'gesamt'
  | 'konto'
  | 'monat'
  | 'jahr'
  | 'kategorien'
  | 'einnahmen'
  | 'ausgaben'
  | 'sparen'
  | 'kredite'
  | 'steuer'
  | 'zeitraum';
export const EXPORT_KINDS: Record<ExportKind, string> = {
  gesamt: 'Gesamter Finanzbestand (Konten, Kredite, Buchungen)',
  konto: 'Einzelnes Konto',
  monat: 'Monatsübersicht',
  jahr: 'Jahresübersicht',
  kategorien: 'Ausgaben nach Kategorien',
  einnahmen: 'Einnahmen nach Quelle',
  ausgaben: 'Ausgaben nach Händler',
  sparen: 'Sparübersicht (Umbuchungen und Sparbewegungen)',
  kredite: 'Kreditübersicht mit Tilgungsplänen',
  steuer: 'Steuerrelevante Buchungen eines Jahres',
  zeitraum: 'Buchungen eines Zeitraums',
};

export interface ExportData {
  accounts: Account[];
  bookings: Booking[];
  cats: Category[];
  loans: { loan: Loan; state: LoanState }[];
  /** Statistik für eine Liste von Monaten (mit den Einstellungen der Nutzerin) */
  stats: (months: string[]) => Stats;
  today: LocalDate;
}
export interface ExportOptions {
  /** Zeitraum JJJJ-MM bis JJJJ-MM (einschließlich) */
  from: string;
  to: string;
  accountId?: string | null;
  year?: number;
  /** nur diese Kredite (Tilgungsplan eines Kredits) */
  loanIds?: string[];
}

const KIND_LABEL: Record<Booking['kind'], string> = {
  ausgabe: 'Ausgabe',
  einnahme: 'Einnahme',
  umbuchung: 'Umbuchung',
  korrektur: 'Korrektur',
};
const STATUS_LABEL: Record<Booking['status'], string> = {
  gebucht: 'gebucht',
  geplant: 'geplant',
  bestaetigt: 'bestätigt',
};
const LOAN_KIND: Record<string, string> = {
  annuitaet: 'Annuitätendarlehen',
  raten: 'Ratenkredit',
  schlussrate: 'Kredit mit Schlussrate',
  foerder: 'Förderkredit',
  voraus: 'Vorausdarlehen',
};
const nextMonth = (m: string) => {
  const [y, mo] = m.split('-').map(Number);
  return mo === 12 ? `${y + 1}-01` : `${y}-${String(mo + 1).padStart(2, '0')}`;
};
export function monthsBetween(from: string, to: string): string[] {
  const [a, b] = from <= to ? [from, to] : [to, from];
  const out: string[] = [];
  for (let m = a; m <= b; m = nextMonth(m)) out.push(m);
  return out;
}
const monthLabel = (m: string) => `${MONTH_NAMES[Number(m.slice(5, 7)) - 1]} ${m.slice(0, 4)}`;

function bookingsTable(name: string, list: Booking[], d: ExportData): Table {
  const acc = (id: string) => d.accounts.find((a) => a.id === id)?.name ?? '';
  const rows: Cell[][] = [];
  for (const b of [...list].sort((x, y) => x.date.localeCompare(y.date) || x.seq - y.seq)) {
    const parts = b.splits.length
      ? b.splits
      : [{ categoryId: null, subCategory: null, amount: b.amount }];
    for (const s of parts)
      rows.push([
        b.date,
        acc(b.accountId),
        KIND_LABEL[b.kind],
        STATUS_LABEL[b.status],
        b.text,
        s.amount / 100,
        s.categoryId ? categoryLabel(d.cats, s.categoryId, null) : '',
        s.subCategory ?? '',
        parts.length > 1 ? 'ja' : '',
        b.note ?? '',
      ]);
  }
  return {
    name,
    columns: [
      { title: 'Datum', type: 'date' },
      { title: 'Konto', type: 'text' },
      { title: 'Art', type: 'text' },
      { title: 'Status', type: 'text' },
      { title: 'Buchungstext', type: 'text' },
      { title: 'Betrag', type: 'euro' },
      { title: 'Kategorie', type: 'text' },
      { title: 'Unterkategorie', type: 'text' },
      { title: 'Aufgeteilt', type: 'text' },
      { title: 'Notiz', type: 'text' },
    ],
    rows,
  };
}

function accountsTable(d: ExportData): Table {
  return {
    name: 'Konten',
    columns: [
      { title: 'Konto', type: 'text' },
      { title: 'Art', type: 'text' },
      { title: 'Kennung', type: 'text' },
      { title: 'Kontostand heute', type: 'euro' },
      { title: 'archiviert', type: 'text' },
    ],
    rows: d.accounts.map((a) => [
      a.name,
      a.type,
      a.identifier ?? '',
      (currentBalance(a, d.bookings) ?? 0) / 100,
      a.archived ? 'ja' : '',
    ]),
  };
}

function loanTables(d: ExportData, ids?: string[]): Table[] {
  const loans = d.loans.filter((x) => !ids || ids.includes(x.loan.id));
  const overview: Table = {
    name: 'Kredite',
    columns: [
      { title: 'Kredit', type: 'text' },
      { title: 'Art', type: 'text' },
      { title: 'Bank', type: 'text' },
      { title: 'Restschuld heute', type: 'euro' },
      { title: 'Rate', type: 'euro' },
      { title: 'Sollzins %', type: 'percent' },
      { title: 'Zinsbindung bis', type: 'date' },
      { title: 'getilgt voraussichtlich', type: 'date' },
      { title: 'Zinsen bisher', type: 'euro' },
      { title: 'Zinsen künftig', type: 'euro' },
      { title: 'Status', type: 'text' },
    ],
    rows: loans.map(({ loan, state }) => [
      loan.name,
      LOAN_KIND[loan.kind],
      loan.bank,
      state.balance / 100,
      loan.rate / 100,
      loan.rateMilli / 1000,
      loan.fixedUntil,
      state.payoff,
      state.paidInterest / 100,
      state.futureInterest / 100,
      loan.paidOff ? 'abbezahlt' : 'läuft',
    ]),
  };
  const plans: Table = {
    name: 'Tilgungspläne',
    columns: [
      { title: 'Kredit', type: 'text' },
      { title: 'Datum', type: 'date' },
      { title: 'Rate', type: 'euro' },
      { title: 'Zinsen', type: 'euro' },
      { title: 'Tilgung', type: 'euro' },
      { title: 'Sondertilgung', type: 'euro' },
      { title: 'Restschuld', type: 'euro' },
    ],
    rows: loans
      .filter((x) => !x.loan.paidOff)
      .flatMap(({ loan, state }) =>
        state.plan.rows.map((r) => [
          loan.name,
          r.date,
          r.payment / 100,
          r.interest / 100,
          r.principal / 100,
          r.extra / 100,
          r.balance / 100,
        ]),
      ),
  };
  const years: Table = {
    name: 'Restschuld je Jahresende',
    columns: [
      { title: 'Kredit', type: 'text' },
      { title: 'Jahr', type: 'number' },
      { title: 'Zinsen im Jahr', type: 'euro' },
      { title: 'Tilgung im Jahr', type: 'euro' },
      { title: 'Restschuld 31.12.', type: 'euro' },
    ],
    rows: loans
      .filter((x) => !x.loan.paidOff)
      .flatMap(({ loan, state }) => {
        const by = new Map<number, { i: number; t: number; b: number }>();
        for (const r of state.plan.rows) {
          const y = Number(r.date.slice(0, 4)),
            e = by.get(y) ?? { i: 0, t: 0, b: 0 };
          by.set(y, { i: e.i + r.interest, t: e.t + r.principal + r.extra, b: r.balance });
        }
        return [...by].map(([y, e]) => [loan.name, y, e.i / 100, e.t / 100, e.b / 100]);
      }),
  };
  return [overview, plans, years];
}

const SUMMARY_COLUMNS: Column[] = [
  { title: 'Einnahmen', type: 'euro' },
  { title: 'Fixkosten', type: 'euro' },
  { title: 'Konsum', type: 'euro' },
  { title: 'Finanzierung', type: 'euro' },
  { title: 'Sparen', type: 'euro' },
  { title: 'Frei verfügbar', type: 'euro' },
];
const summary = (s: Stats): Cell[] => [
  s.income / 100,
  s.fix / 100,
  s.konsum / 100,
  s.finanzierung / 100,
  s.savings / 100,
  s.free / 100,
];

export function buildExport(kind: ExportKind, d: ExportData, o: ExportOptions): Table[] {
  const months = monthsBetween(o.from, o.to);
  const inRange = (b: Booking) => months.includes(b.date.slice(0, 7));
  switch (kind) {
    case 'gesamt':
      return [accountsTable(d), bookingsTable('Buchungen', d.bookings, d), ...loanTables(d)];
    case 'konto':
      return [
        bookingsTable(
          d.accounts.find((a) => a.id === o.accountId)?.name ?? 'Konto',
          d.bookings.filter((b) => b.accountId === o.accountId && inRange(b)),
          d,
        ),
      ];
    case 'zeitraum':
      return [bookingsTable('Buchungen', d.bookings.filter(inRange), d)];
    case 'monat':
      return [
        {
          name: 'Monatsübersicht',
          columns: [{ title: 'Monat', type: 'text' }, ...SUMMARY_COLUMNS],
          rows: months.map((m) => [monthLabel(m), ...summary(d.stats([m]))]),
        },
      ];
    case 'jahr': {
      const years = [...new Set(months.map((m) => Number(m.slice(0, 4))))];
      const yearMonths = (y: number) =>
        monthsBetween(
          `${y}-01`,
          y === Number(d.today.slice(0, 4)) ? d.today.slice(0, 7) : `${y}-12`,
        );
      return [
        {
          name: 'Jahresübersicht',
          columns: [
            { title: 'Jahr', type: 'number' },
            ...SUMMARY_COLUMNS,
            { title: 'Konsum ggü. Vorjahr %', type: 'percent' },
          ],
          rows: years.map((y) => {
            const s = d.stats(yearMonths(y)),
              prev = d.stats(yearMonths(y - 1));
            return [
              y,
              ...summary(s),
              prev.konsum ? Math.round(((s.konsum - prev.konsum) / prev.konsum) * 1000) / 10 : null,
            ];
          }),
        },
      ];
    }
    case 'kategorien': {
      const s = d.stats(months);
      const rows: Cell[][] = [];
      for (const [pillar, buckets] of Object.entries(s.byPillar))
        for (const c of buckets) {
          const subs = s.bySub[`${pillar}|${c.key}`] ?? [];
          if (subs.length > 1)
            for (const u of subs) rows.push([pillar, c.label, u.label, u.count, u.amount / 100]);
          else rows.push([pillar, c.label, '', c.count, c.amount / 100]);
        }
      return [
        {
          name: 'Kategorien',
          columns: [
            { title: 'Säule', type: 'text' },
            { title: 'Kategorie', type: 'text' },
            { title: 'Unterkategorie', type: 'text' },
            { title: 'Buchungen', type: 'number' },
            { title: 'Summe', type: 'euro' },
          ],
          rows,
        },
      ];
    }
    case 'einnahmen':
      return [
        {
          name: 'Einnahmen',
          columns: [
            { title: 'Quelle', type: 'text' },
            { title: 'Buchungen', type: 'number' },
            { title: 'Summe', type: 'euro' },
          ],
          rows: d.stats(months).incomeBySource.map((b) => [b.label, b.count, b.amount / 100]),
        },
      ];
    case 'ausgaben':
      return [
        {
          name: 'Ausgaben nach Händler',
          columns: [
            { title: 'Händler', type: 'text' },
            { title: 'Buchungen', type: 'number' },
            { title: 'Summe', type: 'euro' },
          ],
          rows: d.stats(months).byMerchant.map((b) => [b.label, b.count, b.amount / 100]),
        },
      ];
    case 'sparen': {
      const savingAcc = new Set(
        d.accounts.filter((a) => a.type === 'tagesgeld' || a.type === 'bauspar').map((a) => a.id),
      );
      const savingCat = new Set(d.cats.filter((c) => c.savings).map((c) => c.id));
      return [
        bookingsTable(
          'Sparbewegungen',
          d.bookings.filter(
            (b) =>
              inRange(b) &&
              (b.kind === 'umbuchung' ||
                savingAcc.has(b.accountId) ||
                b.splits.some((s) => savingCat.has(s.categoryId ?? ''))),
          ),
          d,
        ),
      ];
    }
    case 'kredite':
      return loanTables(d, o.loanIds);
    case 'steuer': {
      const y = String(o.year ?? Number(d.today.slice(0, 4)));
      return [
        bookingsTable(
          `Steuerrelevant ${y}`,
          d.bookings.filter(
            (b) =>
              b.date.startsWith(y) &&
              b.splits.some((s) => isTaxRelevant(d.cats, s.categoryId, s.subCategory)),
          ),
          d,
        ),
      ];
    }
  }
}

// ---------- CSV im deutschen Excel-Format (Lastenheft 12) ----------
const csvCell = (v: Cell, t: ColType): string => {
  if (v === null || v === '') return '';
  if (t === 'date' && typeof v === 'string')
    return `${v.slice(8, 10)}.${v.slice(5, 7)}.${v.slice(0, 4)}`;
  if (typeof v === 'number')
    return t === 'euro' ? v.toFixed(2).replace('.', ',') : String(v).replace('.', ',');
  return /[";\n\r]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v;
};
/** Semikolon als Trenner, Dezimalkomma, UTF-8 mit BOM, Zeilenende CRLF */
export function toCsv(t: Table): string {
  const lines = [
    t.columns.map((c) => csvCell(c.title, 'text')).join(';'),
    ...t.rows.map((r) => r.map((v, i) => csvCell(v, t.columns[i].type)).join(';')),
  ];
  return '\uFEFF' + lines.join('\r\n') + '\r\n';
}
