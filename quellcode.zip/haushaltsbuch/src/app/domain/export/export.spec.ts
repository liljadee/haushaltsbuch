import { describe, expect, it } from 'vitest';
import { Account } from '../accounts/account';
import { AccountCoverage, completeMonth, coverage, covered, gapsIn } from '../accounts/coverage';
import { Booking } from '../bookings/booking';
import { isRefund, refundCandidates, refundedTotal } from '../bookings/refunds';
import { DEFAULT_CATEGORIES as C } from '../categories/categories';
import { Loan, defaultSpecial, loanState } from '../loans/loan';
import { computeStats } from '../stats/statistics';
import { buildExport, monthsBetween, toCsv } from './export';

const TODAY = '2026-11-19';
const acc = (id: string, type: Account['type'], name: string): Account => ({
  id,
  name,
  type,
  identifier: '*1234',
  purpose: 'allgemein',
  reserve: 0,
  leadDays: 2,
  archived: false,
  order: 0,
  snapshots: [],
});
const A = [acc('g', 'giro', 'Girokonto'), acc('t', 'tagesgeld', 'Tagesgeld')];
let n = 0;
const bk = (
  date: string,
  amount: number,
  cat: string | null,
  x: Partial<Booking> = {},
): Booking => ({
  id: `b${++n}`,
  accountId: 'g',
  kind: amount < 0 ? 'ausgabe' : 'einnahme',
  status: 'gebucht',
  amount,
  date,
  seq: n,
  text: x.text ?? 'Text',
  splits: cat ? [{ categoryId: cat, subCategory: null, amount }] : [],
  confidence: 'sicher',
  source: { type: 'manuell' },
  ...x,
});
const loan: Loan = {
  id: 'h',
  name: 'Hauskredit',
  kind: 'annuitaet',
  bank: 'Sparkasse',
  accountId: 'g',
  pattern: 'Kreditrate Hauskredit',
  specialPattern: '',
  rate: 98000,
  day: 30,
  rateMilli: 2850,
  effMilli: null,
  fixedUntil: '2032-06-30',
  endDate: null,
  followMilli: 4000,
  finalPayment: null,
  principal: null,
  special: defaultSpecial('annuitaet'),
  snapshots: [{ date: TODAY, balance: 18240000 }],
  paidOff: null,
  recurringId: null,
  order: 0,
};

describe('Datenabdeckung (11.2)', () => {
  const b = [
    bk('2026-07-03', -1000, 'a-andere'),
    bk('2026-09-03', -1000, 'a-andere'),
    bk('2026-10-03', -1000, 'a-andere'),
    bk('2026-05-01', 100, 'e-gehalt', { accountId: 't' }),
  ];
  const cov = coverage(A, b, TODAY);
  it('nur Girokonten; Monat ohne Buchung ist eine Lücke, kein Monat ohne Ausgaben', () => {
    expect(cov).toEqual([
      { accountId: 'g', name: 'Girokonto', first: '2026-07', gaps: ['2026-08'] },
    ]);
    expect([covered('2026-08', cov), covered('2026-06', cov), covered('2026-09', cov)]).toEqual([
      false,
      false,
      true,
    ]);
  });
  it('abgeschlossen nur, wenn vorbei und vollständig; Lücken eines Zeitraums als Text', () => {
    expect([completeMonth('2026-10', cov, TODAY), completeMonth('2026-11', cov, TODAY)]).toEqual([
      true,
      false,
    ]);
    expect(gapsIn(monthsBetween('2026-07', '2026-10'), cov)).toEqual(['Girokonto: August 2026']);
    const none: AccountCoverage[] = [];
    expect(covered('2026-08', none)).toBe(true);
  });
});

describe('Erstattungen verknüpfen (10.2)', () => {
  it('Kandidaten: Ausgaben derselben Kategorie bis 180 Tage vorher; erstatteter Betrag je Ausgabe', () => {
    const e1 = bk('2026-10-01', -5000, 'a-haushalt'),
      e2 = bk('2026-03-01', -3000, 'a-haushalt'),
      e3 = bk('2026-10-05', -2000, 'a-andere');
    const r = bk('2026-10-20', 1500, 'a-haushalt', { refundOf: e1.id });
    expect(refundCandidates([e1, e2, e3, r], 'a-haushalt', '2026-10-20').map((b) => b.id)).toEqual([
      e1.id,
    ]);
    expect([
      isRefund(r, C),
      isRefund(bk('2026-10-30', 100, 'e-gehalt'), C),
      refundedTotal(e1.id, [e1, r]),
    ]).toEqual([true, false, 1500]);
  });
});

describe('Export (12)', () => {
  const b = [
    bk('2026-10-03', -1250, 'a-haushalt', { text: 'REWE; Markt "Ulm"' }),
    bk('2026-10-15', 245000, 'e-gehalt'),
    bk('2026-11-02', -98000, 'a-kredite', { text: 'Kreditrate Hauskredit' }),
  ];
  const d = {
    accounts: A,
    bookings: b,
    cats: C,
    loans: [{ loan, state: loanState(loan, [], TODAY) }],
    stats: (m: string[]) => computeStats(b, A, C, m),
    today: TODAY,
  };
  it('CSV im deutschen Excel-Format: BOM, Semikolon, Dezimalkomma, TT.MM.JJJJ, Anführungszeichen', () => {
    const csv = toCsv(buildExport('zeitraum', d, { from: '2026-10', to: '2026-10' })[0]);
    expect(csv.startsWith('\uFEFFDatum;Konto;Art;Status;Buchungstext;Betrag;')).toBe(true);
    expect(csv).toContain('03.10.2026;Girokonto;Ausgabe;gebucht;"REWE; Markt ""Ulm""";-12,50;');
    expect(csv.split('\r\n').length).toBe(4);
  });
  it('Monatsübersicht, Kredite mit Tilgungsplan und Restschuld je Jahresende, Gesamtbestand mit allen Blättern', () => {
    const monat = buildExport('monat', d, { from: '2026-10', to: '2026-11' })[0];
    expect(monat.rows.map((r) => [r[0], r[1]])).toEqual([
      ['Oktober 2026', 2450],
      ['November 2026', 0],
    ]);
    const kredite = buildExport('kredite', d, { from: '2026-01', to: '2026-12' });
    expect(kredite.map((t) => t.name)).toEqual([
      'Kredite',
      'Tilgungspläne',
      'Restschuld je Jahresende',
    ]);
    expect(kredite[1].rows[0].slice(0, 3)).toEqual(['Hauskredit', '2026-11-30', 980]);
    expect(buildExport('gesamt', d, { from: '2026-01', to: '2026-12' }).map((t) => t.name)).toEqual(
      ['Konten', 'Buchungen', 'Kredite', 'Tilgungspläne', 'Restschuld je Jahresende'],
    );
  });
});

describe('Export: alle Ansichten', () => {
  const tg: Booking[] = [
    bk('2025-06-10', -2000, 'a-andere', { text: 'REWE' }),
    bk('2025-06-15', 240000, 'e-gehalt'),
    bk('2026-06-10', -3000, 'a-andere', { text: 'REWE' }),
    bk('2026-06-11', -1500, 'a-andere', { text: 'Bäcker' }),
    bk('2026-06-15', 250000, 'e-gehalt'),
    bk('2026-06-20', -10000, null, { kind: 'umbuchung', text: 'Sparen', accountId: 'g' }),
    bk('2026-06-20', 10000, null, { kind: 'umbuchung', text: 'Sparen', accountId: 't' }),
  ];
  const taxCat = C.find((c) => c.taxRelevant)?.id ?? null;
  const all = taxCat ? [...tg, bk('2026-03-01', -5000, taxCat, { text: 'Steuerberater' })] : tg;
  const d = {
    accounts: A,
    bookings: all,
    cats: C,
    loans: [{ loan: { ...loan, paidOff: '2026-01' }, state: loanState(loan, [], TODAY) }],
    stats: (m: string[]) => computeStats(all, A, C, m),
    today: TODAY,
  };
  const o = { from: '2026-06', to: '2026-06' };
  it('einzelnes Konto und Sparübersicht', () => {
    expect(buildExport('konto', d, { ...o, accountId: 't' })[0]).toMatchObject({
      name: 'Tagesgeld',
      rows: [['2026-06-20', 'Tagesgeld', 'Umbuchung', 'gebucht', 'Sparen', 100, '', '', '', '']],
    });
    expect(buildExport('sparen', d, o)[0].rows.length).toBe(2);
    expect(buildExport('konto', d, { ...o, accountId: 'x' })[0].name).toBe('Konto');
  });
  it('Jahresübersicht mit Vergleich zum Vorjahr; Kategorien, Einnahmen, Händler', () => {
    const jahr = buildExport('jahr', d, { from: '2025-01', to: '2026-11' })[0];
    expect(jahr.rows.map((r) => r[0])).toEqual([2025, 2026]);
    expect(jahr.rows[1].at(-1)).toBe(125);
    expect(jahr.rows[0].at(-1)).toBeNull();
    const kat = buildExport('kategorien', d, o)[0];
    expect(kat.rows.some((r) => r[0] === 'konsum' && r[4] === 45)).toBe(true);
    expect(buildExport('einnahmen', d, o)[0].rows[0].slice(1)).toEqual([1, 2500]);
    expect(buildExport('ausgaben', d, o)[0].rows.length).toBeGreaterThanOrEqual(2);
  });
  it('steuerrelevante Buchungen eines Jahres; Kreditübersicht kennzeichnet abbezahlte Kredite', () => {
    const st = buildExport('steuer', d, { ...o, year: 2026 })[0];
    expect(st.name).toBe('Steuerrelevant 2026');
    expect(st.rows.length).toBe(taxCat ? 1 : 0);
    const kr = buildExport('kredite', d, o);
    expect(kr[0].rows[0].at(-1)).toBe('abbezahlt');
    expect(kr[1].rows).toEqual([]);
  });
  it('CSV: leere Zellen, Zahlen und Prozente mit Komma, Text mit Zeilenumbruch in Anführungszeichen', () => {
    const csv = toCsv({
      name: 'x',
      columns: [
        { title: 'Text', type: 'text' },
        { title: 'Jahr', type: 'number' },
        { title: 'Zins %', type: 'percent' },
        { title: 'Datum', type: 'date' },
      ],
      rows: [
        ['a\nb', 2026, 2.85, null],
        [null, null, null, '2026-01-02'],
      ],
    });
    expect(csv.split('\r\n').slice(1, 3)).toEqual(['"a\nb";2026;2,85;', ';;;02.01.2026']);
  });
});
