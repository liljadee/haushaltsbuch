import { Cents } from '../shared/money';
import { LocalDate } from '../shared/local-date';

/** Buchung (Bauplan 4). korrektur = Saldenausgleich, zählt nicht in Statistiken. */
export type BookingKind = 'einnahme' | 'ausgabe' | 'umbuchung' | 'korrektur';
export type BookingStatus = 'gebucht' | 'bestaetigt' | 'geplant';

export interface Split {
  categoryId: string | null;
  subCategory: string | null;
  amount: Cents;
}

export interface Booking {
  id: string;
  accountId: string;
  kind: BookingKind;
  status: BookingStatus;
  amount: Cents;
  date: LocalDate;
  /** Reihenfolge der Erfassung; ordnet Buchungen und Kontostände am selben Tag. */
  seq: number;
  text: string;
  splits: Split[];
  confidence: 'sicher' | 'unsicher' | 'nicht_zugeordnet';
  transferGroupId?: string;
  source: { type: 'email' | 'csv' | 'xlsx' | 'manuell' | 'abgleich'; fingerprint?: string };
  note?: string;
  /** aus diesem Spartopf bezahlt (Lastenheft 16a); bis zur Erstattung per Umbuchung offen */
  potId?: string;
  potSettled?: boolean;
  /** Erstattung zu dieser Ausgabe (optional verknüpft, Lastenheft 10.2) */
  refundOf?: string;
}
