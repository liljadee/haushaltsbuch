import { Category } from '../categories/categories';
import { Cents } from '../shared/money';
import { LocalDate } from '../shared/local-date';
import { Booking } from './booking';

/**
 * Erstattungen (Lastenheft 10.2): eine Einnahme mit Ausgabenkategorie. Optional mit der ursprünglichen Ausgabe
 * verknüpft (refundOf); sie wirkt trotzdem im Zuordnungsmonat der Erstattung.
 */
export function isRefund(b: Booking, cats: Category[]): boolean {
  return (
    b.kind === 'einnahme' &&
    b.splits.some((s) => cats.find((c) => c.id === s.categoryId)?.type === 'ausgabe')
  );
}

/** passende Ausgaben für die Verknüpfung: gleiche Kategorie, bis 180 Tage vor der Erstattung, neueste zuerst */
export function refundCandidates(
  bookings: Booking[],
  categoryId: string,
  date: LocalDate,
  limit = 30,
): Booking[] {
  const from = new Date(Date.parse(date) - 180 * 86400000).toISOString().slice(0, 10);
  return bookings
    .filter(
      (b) =>
        b.kind === 'ausgabe' &&
        b.status !== 'geplant' &&
        b.date <= date &&
        b.date >= from &&
        b.splits.some((s) => s.categoryId === categoryId),
    )
    .sort((a, b) => b.date.localeCompare(a.date) || b.seq - a.seq)
    .slice(0, limit);
}

/** bisher erstattet zu einer Ausgabe */
export function refundedTotal(expenseId: string, bookings: Booking[]): Cents {
  return bookings.filter((b) => b.refundOf === expenseId).reduce((s, b) => s + b.amount, 0);
}
