import { describe, expect, it } from 'vitest';
import { Account } from '../accounts/account';
import { balanceAt } from '../accounts/balances';
import { DEFAULT_CATEGORIES as C, guessCategory } from '../categories/categories';
import { Booking } from './booking';
import { assignCategory, toTransfer } from './batch';

const acc = (id: string, name: string): Account => ({
  id,
  name,
  type: 'giro',
  identifier: null,
  purpose: 'allgemein',
  reserve: 0,
  leadDays: 2,
  archived: false,
  order: 0,
  snapshots: [{ id: 's' + id, date: '2026-11-01', seq: 1, balance: 100000, source: 'start' }],
});
const g = acc('g', 'Girokonto'),
  t = acc('t', 'Tagesgeld');
const b = (
  id: string,
  amount: number,
  kind: Booking['kind'] = amount < 0 ? 'ausgabe' : 'einnahme',
): Booking => ({
  id,
  accountId: 'g',
  kind,
  status: 'gebucht',
  amount,
  date: '2026-11-10',
  seq: 5,
  text: 'Sparen Urlaub',
  splits: [],
  confidence: 'nicht_zugeordnet',
  source: { type: 'xlsx' },
});

describe('Stapelverarbeitung', () => {
  it('ordnet mehreren Buchungen eine Kategorie zu und lässt Umbuchungen aus', () => {
    const out = assignCategory(
      [b('1', -500), b('2', -700), b('3', -100, 'umbuchung')],
      'a-haushalt',
      'Drogerie',
    );
    expect(out.map((x) => [x.id, x.splits[0].amount, x.confidence])).toEqual([
      ['1', -500, 'sicher'],
      ['2', -700, 'sicher'],
    ]);
  });
  it('wandelt eine Ausgabe in eine Umbuchung um; das Zielkonto bekommt die Gegenbuchung', () => {
    const [mine, other] = toTransfer(b('1', -10000), g, t, { group: 'x', counterpart: 'c' }, 6)!;
    expect([mine.kind, mine.amount, other.accountId, other.amount, other.text]).toEqual([
      'umbuchung',
      -10000,
      't',
      10000,
      'Umbuchung von Girokonto',
    ]);
    expect(balanceAt(t, [mine, other], '2026-11-30')).toBe(110000);
    expect(toTransfer(b('1', -1), g, g, { group: 'x', counterpart: 'c' }, 6)).toBeNull();
  });
  it('erkennt unsere Kategorienamen in Altdaten', () => {
    expect(guessCategory('Haushalt › Lebensmittel', 'ausgabe', C)).toEqual({
      categoryId: 'a-haushalt',
      subCategory: 'Lebensmittel',
    });
    expect(guessCategory('haushalt/drogerie', 'ausgabe', C)).toEqual({
      categoryId: 'a-haushalt',
      subCategory: 'Drogerie',
    });
    expect(guessCategory('Sparen', 'ausgabe', C)).toEqual({
      categoryId: 'a-sparen',
      subCategory: null,
    });
    expect(guessCategory('Gehalt: Gehalt Martin', 'einnahme', C)).toEqual({
      categoryId: 'e-gehalt',
      subCategory: 'Gehalt Martin',
    });
    expect(guessCategory('Haushalt › Unsinn', 'ausgabe', C)).toBeNull();
    expect(guessCategory('Nebenkosten', 'ausgabe', C)).toBeNull();
  });
});
