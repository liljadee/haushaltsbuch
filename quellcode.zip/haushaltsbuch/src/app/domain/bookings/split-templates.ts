import { signatureOf } from '../recurring/recurring';
import { Cents } from '../shared/money';
import { LocalDate } from '../shared/local-date';
import { Booking } from './booking';

/**
 * Aufteilungsvorlagen für Sammelabbuchungen (Wunsch 19.11.2026), ohne KI:
 * Aus einer von Hand aufgeteilten Abbuchung lernt die App die Teile je Empfänger. Neue Abbuchungen
 * desselben Empfängers werden in die Kombination der Teile zerlegt, die genau passt; sind Beiträge
 * gestiegen (oder in der Historie niedriger), die Kombination, die bis auf 20 % passt, mit anteilig verteilter Differenz.
 */
export interface TemplatePart {
  categoryId: string;
  subCategory: string | null;
  amount: Cents;
}
export interface SplitTemplate {
  id: string;
  accountId: string;
  signature: string;
  label: string;
  parts: TemplatePart[];
  updated: LocalDate;
}
export interface SplitProposal {
  splits: { categoryId: string | null; subCategory: string | null; amount: Cents }[];
  /** genau passende Kombination der gelernten Beträge */
  exact: boolean;
  /** anteilig verteilte Differenz (Erhöhung positiv) */
  adjustment: Cents;
  /** Rest ohne Kategorie, wenn die bekannten Teile zu wenig ergeben */
  rest: Cents;
}

export const SPLIT_TOLERANCE = 0.2;
const MAX_PARTS = 12;
const key = (p: { categoryId: string | null; subCategory: string | null }) =>
  `${p.categoryId}|${p.subCategory ?? ''}`;

/** Lernt aus einer aufgeteilten Ausgabe; bestehende Teile bekommen den neuen Betrag, fehlende bleiben (Kombinationen wechseln). */
export function learnTemplate(
  existing: SplitTemplate | undefined,
  b: Booking,
  today: LocalDate,
): SplitTemplate | null {
  if (b.amount >= 0 || b.splits.length < 2 || b.splits.some((s) => !s.categoryId || s.amount >= 0))
    return null;
  const parts = new Map((existing?.parts ?? []).map((p) => [key(p), { ...p }]));
  for (const s of b.splits)
    parts.set(key(s), { categoryId: s.categoryId!, subCategory: s.subCategory, amount: -s.amount });
  return {
    id: existing?.id ?? crypto.randomUUID(),
    accountId: b.accountId,
    signature: signatureOf(b.text),
    label: existing?.label ?? b.text,
    parts: [...parts.values()].slice(0, MAX_PARTS),
    updated: today,
  };
}

export function findTemplate(templates: SplitTemplate[], b: Booking): SplitTemplate | null {
  if (b.amount >= 0 || b.kind !== 'ausgabe') return null;
  const sig = signatureOf(b.text);
  return templates.find((t) => t.accountId === b.accountId && t.signature === sig) ?? null;
}

/** Zerlegt einen Betrag (positiv, in Cent) in die passendste Kombination der Vorlagen-Teile. */
export function proposeSplit(t: SplitTemplate, amount: Cents): SplitProposal | null {
  const parts = t.parts;
  const n = parts.length;
  if (!n || amount <= 0) return null;
  let best: { mask: number; sum: number; diff: number } | null = null;
  for (let mask = 1; mask < 1 << n; mask++) {
    let sum = 0;
    for (let i = 0; i < n; i++) if (mask & (1 << i)) sum += parts[i].amount;
    const diff = amount - sum;
    if (Math.abs(diff) > sum * SPLIT_TOLERANCE) continue;
    const bits = popcount(mask);
    // genau vor ungefähr; bei gleicher Abweichung die Kombination mit mehr Teilen
    if (
      !best ||
      Math.abs(diff) < Math.abs(best.diff) ||
      (Math.abs(diff) === Math.abs(best.diff) && bits > popcount(best.mask))
    )
      best = { mask, sum, diff };
  }
  if (best) {
    const chosen = parts.filter((_, i) => best!.mask & (1 << i));
    const scaled = chosen.map((p) => Math.round((p.amount * amount) / best!.sum));
    // Rundungsrest auf den größten Teil, damit die Summe genau stimmt
    const fix = amount - scaled.reduce((s, v) => s + v, 0);
    const big = scaled.indexOf(Math.max(...scaled));
    scaled[big] += fix;
    return {
      splits: chosen.map((p, i) => ({
        categoryId: p.categoryId,
        subCategory: p.subCategory,
        amount: -scaled[i],
      })),
      exact: best.diff === 0,
      adjustment: best.diff,
      rest: 0,
    };
  }
  // alle Teile reichen nicht: bekannte Teile plus Rest zum Zuordnen
  const all = parts.reduce((s, p) => s + p.amount, 0);
  if (all < amount) {
    return {
      splits: [
        ...parts.map((p) => ({
          categoryId: p.categoryId,
          subCategory: p.subCategory,
          amount: -p.amount,
        })),
        { categoryId: null, subCategory: null, amount: -(amount - all) },
      ],
      exact: false,
      adjustment: 0,
      rest: amount - all,
    };
  }
  return null;
}

function popcount(m: number): number {
  let c = 0;
  for (; m; m &= m - 1) c++;
  return c;
}

/** Frühere, noch nicht aufgeteilte Abbuchungen desselben Empfängers, für die die Vorlage passt (rückwirkend übernehmen). */
export function retroCandidates(
  t: SplitTemplate,
  bookings: Booking[],
  excludeId?: string,
): { booking: Booking; proposal: SplitProposal }[] {
  return bookings
    .filter(
      (b) =>
        b.id !== excludeId &&
        b.status === 'gebucht' &&
        b.splits.length <= 1 &&
        findTemplate([t], b),
    )
    .map((b) => ({ booking: b, proposal: proposeSplit(t, -b.amount) }))
    .filter(
      (x): x is { booking: Booking; proposal: SplitProposal } =>
        !!x.proposal && x.proposal.rest === 0,
    );
}
