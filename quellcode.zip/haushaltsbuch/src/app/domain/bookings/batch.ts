import { Account } from '../accounts/account';
import { Booking } from './booking';

/**
 * Stapelverarbeitung (Rückmeldung 17.11.2026): mehreren Buchungen gemeinsam eine Kategorie geben
 * oder sie in Umbuchungen auf ein eigenes Konto umwandeln.
 */
export const isRegular = (b: Booking) => b.kind === 'ausgabe' || b.kind === 'einnahme';

export function assignCategory(
  list: Booking[],
  categoryId: string,
  subCategory: string | null,
): Booking[] {
  return list.filter(isRegular).map((b) => ({
    ...b,
    splits: [{ categoryId, subCategory, amount: b.amount }],
    confidence: 'sicher' as const,
  }));
}

/**
 * Wandelt eine Ausgabe in eine Umbuchung auf das Zielkonto um (eine Einnahme in eine Umbuchung vom Zielkonto).
 * Die eigene Seite behält Betrag, Datum und Text; auf dem Zielkonto entsteht die Gegenbuchung.
 */
export function toTransfer(
  b: Booking,
  own: Account,
  target: Account,
  ids: { group: string; counterpart: string },
  seq: number,
): [Booking, Booking] | null {
  if (!isRegular(b) || own.id === target.id) return null;
  const mine: Booking = {
    ...b,
    kind: 'umbuchung',
    splits: [],
    confidence: 'sicher',
    transferGroupId: ids.group,
  };
  const other: Booking = {
    id: ids.counterpart,
    accountId: target.id,
    kind: 'umbuchung',
    status: b.status,
    amount: -b.amount,
    date: b.date,
    seq,
    text: b.amount < 0 ? `Umbuchung von ${own.name}` : `Umbuchung nach ${own.name}`,
    splits: [],
    confidence: 'sicher',
    transferGroupId: ids.group,
    source: b.source,
  };
  return [mine, other];
}
