import { normalizeText } from '../categories/rules';
import { Cents } from '../shared/money';
import { LocalDate } from '../shared/local-date';
import { Booking } from './booking';

/**
 * Dublettenprüfung (Bauplan 6.1): gleiches Konto und gleicher Betrag, Datum ± 5 Tage,
 * ähnlicher Text. Banken kürzen Namen ab („AGILA Hau.“ ↔ „AGILA HAUSTIERVERSICHERUNG AG“);
 * ein abgekürztes Wort zählt als Treffer, wenn es der Anfang des anderen ist.
 */
export const DUPLICATE_DAYS = 5;
export const SIMILARITY_THRESHOLD = 0.6;

const words = (s: string) =>
  normalizeText(s)
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .split(' ')
    .filter((w) => w.length > 1);

export function textSimilarity(a: string, b: string): number {
  const wa = words(a),
    wb = words(b);
  if (!wa.length || !wb.length) return normalizeText(a) === normalizeText(b) ? 1 : 0;
  const [short, long] = wa.length <= wb.length ? [wa, wb] : [wb, wa];
  const used = new Set<number>();
  let hits = 0;
  for (const w of short) {
    const i = long.findIndex(
      (x, k) =>
        !used.has(k) &&
        (x === w || (w.length >= 3 && x.startsWith(w)) || (x.length >= 3 && w.startsWith(x))),
    );
    if (i >= 0) {
      used.add(i);
      hits++;
    }
  }
  return hits / short.length;
}

const days = (a: LocalDate, b: LocalDate) =>
  Math.abs(Date.parse(a + 'T00:00:00Z') - Date.parse(b + 'T00:00:00Z')) / 86400000;

export function findDuplicate(
  text: string,
  amount: Cents,
  accountId: string,
  date: LocalDate,
  bookings: Booking[],
  ignoreId?: string,
): Booking | null {
  let best: Booking | null = null,
    score = 0;
  for (const b of bookings) {
    if (
      b.id === ignoreId ||
      b.accountId !== accountId ||
      b.amount !== amount ||
      b.status !== 'gebucht' ||
      days(b.date, date) > DUPLICATE_DAYS
    )
      continue;
    const s = textSimilarity(text, b.text);
    if (s >= SIMILARITY_THRESHOLD && s > score) {
      best = b;
      score = s;
    }
  }
  return best;
}
