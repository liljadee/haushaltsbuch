import { describe, expect, it } from 'vitest';
import { Booking } from './booking';
import {
  SplitTemplate,
  findTemplate,
  learnTemplate,
  proposeSplit,
  retroCandidates,
} from './split-templates';

const TODAY = '2026-11-19';
const bk = (
  id: string,
  date: string,
  amount: number,
  splits: [string, string | null, number][] = [],
  text = 'DEBEKA Kranken- und Lebensvers.',
): Booking => ({
  id,
  accountId: 'g',
  kind: 'ausgabe',
  status: 'gebucht',
  amount,
  date,
  seq: 1,
  text,
  splits: splits.map(([c, s, a]) => ({ categoryId: c, subCategory: s, amount: a })),
  confidence: 'sicher',
  source: { type: 'email' },
});
// Debeka: Kfz 45,20, Haftpflicht 8,90, Unfall 12,30
const handSplit = bk('h', '2026-11-02', -6640, [
  ['a-versicherungen', 'Kfz', -4520],
  ['a-versicherungen', 'Haftpflicht', -890],
  ['a-versicherungen', 'Unfall', -1230],
]);
const t = learnTemplate(undefined, handSplit, TODAY)!;

describe('Aufteilungsvorlagen für Sammelabbuchungen', () => {
  it('lernt die Teile aus einer von Hand aufgeteilten Abbuchung', () => {
    expect(t.parts.map((p) => [p.subCategory, p.amount])).toEqual([
      ['Kfz', 4520],
      ['Haftpflicht', 890],
      ['Unfall', 1230],
    ]);
    expect(findTemplate([t], bk('n', '2026-12-01', -6640))).toBe(t);
    expect(findTemplate([t], bk('x', '2026-12-01', -6640, [], 'REWE Markt'))).toBeNull();
    expect(
      learnTemplate(undefined, bk('e', TODAY, -500, [['a-haushalt', null, -500]]), TODAY),
    ).toBeNull();
  });
  it('genau passende Kombination, auch wenn nur ein Teil der Beiträge abgebucht wird', () => {
    const all = proposeSplit(t, 6640)!;
    expect([all.exact, all.splits.map((s) => s.amount)]).toEqual([true, [-4520, -890, -1230]]);
    const two = proposeSplit(t, 5410)!;
    expect([two.exact, two.splits.map((s) => s.subCategory)]).toEqual([
      true,
      ['Kfz', 'Haftpflicht'],
    ]);
  });
  it('gestiegene Beiträge: passende Kombination bis 20 %, Differenz anteilig verteilt, Summe stimmt genau', () => {
    const p = proposeSplit(t, 6973)!; // +5 %
    expect([p.exact, p.adjustment, p.splits.length]).toEqual([false, 333, 3]);
    expect(p.splits.reduce((s, x) => s + x.amount, 0)).toBe(-6973);
    expect(p.splits[0].amount).toBe(-4746);
  });
  it('ältere, niedrigere Beiträge in der Historie werden ebenso erkannt', () => {
    expect(proposeSplit(t, 6200)!.splits.length).toBe(3);
  });
  it('reichen die Teile nicht, bleibt ein Rest zum Zuordnen; viel zu kleine Beträge passen gar nicht', () => {
    const r = proposeSplit(t, 12000)!;
    expect([r.rest, r.splits.at(-1)!.categoryId]).toEqual([5360, null]);
    expect(proposeSplit(t, 300)).toBeNull();
  });
  it('neue Beträge ersetzen die alten, neue Teile kommen dazu', () => {
    const next = learnTemplate(
      t,
      bk('h2', '2027-11-02', -7290, [
        ['a-versicherungen', 'Kfz', -4980],
        ['a-versicherungen', 'Haftpflicht', -980],
        ['a-versicherungen', 'Rechtsschutz', -1330],
      ]),
      '2027-11-02',
    )!;
    expect(next.parts.map((p) => [p.subCategory, p.amount])).toEqual([
      ['Kfz', 4980],
      ['Haftpflicht', 980],
      ['Unfall', 1230],
      ['Rechtsschutz', 1330],
    ]);
    expect(next.id).toBe(t.id);
  });
  it('rückwirkend: frühere, nicht aufgeteilte Abbuchungen desselben Empfängers', () => {
    const data = [
      handSplit,
      bk('a', '2025-11-03', -6100),
      bk('b', '2026-05-02', -6640),
      bk('c', '2026-06-02', -1500, [], 'REWE'),
      bk('d', '2026-07-02', -300),
    ];
    expect(retroCandidates(t, data, 'h').map((x) => x.booking.id)).toEqual(['a', 'b']);
  });
});

export type { SplitTemplate };
