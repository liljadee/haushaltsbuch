import { Account } from '../accounts/account';
import { Cents } from '../shared/money';
import { LocalDate, isLocalDate } from '../shared/local-date';
import { Booking } from './booking';

/**
 * Umbuchungen (Lastenheft 7, Bauplan 4): zwei Buchungen mit derselben transferGroupId,
 * entgegengesetzten Beträgen und demselben Status. Sie zählen nicht als Einnahme oder Ausgabe.
 */
export interface TransferDraft {
  fromId: string | null;
  toId: string | null;
  amount: Cents | null;
  date: string;
  text: string;
}

export function validateTransfer(d: TransferDraft, today: LocalDate): string[] {
  const e: string[] = [];
  if (!d.fromId || !d.toId) e.push('Bitte beide Konten wählen.');
  else if (d.fromId === d.toId) e.push('Von- und Nach-Konto müssen verschieden sein.');
  if (d.amount === null || d.amount <= 0)
    e.push('Bitte einen Betrag größer als 0 eingeben, z. B. 500,00.');
  if (!isLocalDate(d.date)) e.push('Bitte ein Datum wählen.');
  else if (d.date > today) e.push('Das Datum liegt in der Zukunft.');
  return e;
}

export function transferText(from: Account, to: Account, text: string): [string, string] {
  const t = text.trim();
  return [t || `Umbuchung nach ${to.name}`, t || `Umbuchung von ${from.name}`];
}

/** Erzeugt beide Seiten; seq und IDs kommen von außen (Datenschicht). */
export function createTransfer(
  from: Account,
  to: Account,
  amount: Cents,
  date: LocalDate,
  text: string,
  ids: { group: string; a: string; b: string },
  seq: [number, number],
  source: Booking['source'] = { type: 'manuell' },
): [Booking, Booking] {
  const [ta, tb] = transferText(from, to, text);
  const base = {
    kind: 'umbuchung' as const,
    status: 'gebucht' as const,
    date,
    splits: [],
    confidence: 'sicher' as const,
    transferGroupId: ids.group,
    source,
  };
  return [
    { ...base, id: ids.a, accountId: from.id, amount: -Math.abs(amount), seq: seq[0], text: ta },
    { ...base, id: ids.b, accountId: to.id, amount: Math.abs(amount), seq: seq[1], text: tb },
  ];
}

/** Gegenseite einer Umbuchung */
export function counterpart(b: Booking, all: Booking[]): Booking | null {
  if (!b.transferGroupId) return null;
  return all.find((x) => x.transferGroupId === b.transferGroupId && x.id !== b.id) ?? null;
}
