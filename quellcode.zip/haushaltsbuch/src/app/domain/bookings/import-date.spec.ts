import { describe, expect, it } from 'vitest';
import { Account } from '../accounts/account';
import { currentBalance } from '../accounts/balances';
import { Booking, stampImported } from './booking';

const b = (x: Partial<Booking>): Booking => ({
  id: 'b',
  accountId: 'g',
  kind: 'ausgabe',
  status: 'gebucht',
  amount: -1000,
  date: '2026-11-03',
  seq: 1,
  text: 'REWE',
  splits: [],
  confidence: 'sicher',
  source: { type: 'email' },
  ...x,
});

describe('Abnahme: Buchungsdatum und Kontenumbenennung (AK-11, AK-16)', () => {
  it('Importdatum wird beim Erfassen gesetzt und ändert sich nicht, wenn das Buchungsdatum geändert wird', () => {
    const [created] = stampImported([b({})], '2026-11-19');
    expect(created.importedAt).toBe('2026-11-19');
    const edited: Booking = { ...created, date: '2026-11-01' };
    expect(stampImported([edited], '2026-12-05')[0]).toMatchObject({
      date: '2026-11-01',
      importedAt: '2026-11-19',
    });
  });
  it('Konto umbenennen: Buchungen hängen an der Konto-ID, Historie und Kontostand bleiben erhalten', () => {
    const acc: Account = {
      id: 'g',
      name: 'Girokonto',
      type: 'giro',
      identifier: '1234',
      purpose: 'allgemein',
      reserve: 1000,
      leadDays: 2,
      archived: false,
      order: 0,
      snapshots: [{ date: '2026-11-01', balance: 100000 }],
    } as Account;
    const list = [b({}), b({ id: 'c', date: '2026-11-05', amount: -2500 })];
    const renamed = { ...acc, name: 'Gemeinschaftskonto' };
    expect(currentBalance(renamed, list)).toBe(currentBalance(acc, list));
    expect(list.filter((x) => x.accountId === renamed.id).length).toBe(2);
  });
});
