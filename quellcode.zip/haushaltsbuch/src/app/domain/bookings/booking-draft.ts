import { Category } from '../categories/categories';
import { Cents, formatEuro } from '../shared/money';
import { LocalDate, isLocalDate } from '../shared/local-date';
import { Split } from './booking';

/** Eingabe einer Buchung von Hand (Lastenheft 8.4) mit optionaler Aufteilung (Splits). */
export interface BookingDraft {
  accountId: string | null;
  amount: Cents | null;
  date: string;
  text: string;
  splits: Split[];
}

export function remaining(amount: Cents, splits: Split[]): Cents {
  return amount - splits.reduce((s, x) => s + x.amount, 0);
}

/** Pflichtangaben und Aufteilung prüfen; leer = in Ordnung. */
export function validateBooking(d: BookingDraft, cats: Category[], today: LocalDate): string[] {
  const e: string[] = [];
  if (!d.accountId) e.push('Bitte ein Konto wählen.');
  if (d.amount === null || d.amount === 0) e.push('Bitte einen Betrag wie 12,50 eingeben.');
  if (!d.text.trim()) e.push('Bitte einen kurzen Buchungstext eingeben, z. B. „Bäckerei“.');
  if (!isLocalDate(d.date)) e.push('Bitte ein Datum wählen.');
  else if (d.date > today)
    e.push('Das Datum liegt in der Zukunft. Geplante Buchungen kommen mit der Prognose (v0.5).');
  if (!d.splits.length || d.splits.some((s) => !s.categoryId))
    e.push('Bitte eine Kategorie wählen.');
  if (d.amount) {
    const type = d.amount < 0 ? 'ausgabe' : 'einnahme';
    if (
      d.splits.length &&
      d.splits.every((s) => s.categoryId) &&
      // Einnahmen dürfen auch eine Ausgabenkategorie haben: Erstattung, mindert dort die Ausgaben (Lastenheft 10.2)
      d.splits.some((s) => {
        const t = cats.find((c) => c.id === s.categoryId)?.type;
        return type === 'ausgabe' ? t !== 'ausgabe' : t !== 'einnahme' && t !== 'ausgabe';
      })
    )
      e.push(
        type === 'ausgabe'
          ? 'Für eine Ausgabe bitte eine Ausgaben-Kategorie wählen.'
          : 'Für eine Einnahme bitte eine Einnahmen-Kategorie oder als Erstattung eine Ausgaben-Kategorie wählen.',
      );
    if (d.splits.length > 1) {
      if (d.splits.some((s) => s.amount === 0 || Math.sign(s.amount) !== Math.sign(d.amount!)))
        e.push('Jeder Teilbetrag braucht einen Betrag mit demselben Vorzeichen wie die Buchung.');
      const r = remaining(d.amount, d.splits);
      if (r !== 0)
        e.push(`Die Teilbeträge ergeben nicht den Gesamtbetrag; es fehlen noch ${formatEuro(r)}.`);
    }
  }
  return e;
}

/** Bei einer einzigen Kategorie trägt der Split immer den ganzen Betrag. */
export function normalizeSplits(amount: Cents, splits: Split[]): Split[] {
  return splits.length === 1 ? [{ ...splits[0], amount }] : splits;
}
