import { describe, expect, it } from 'vitest';
import { Account } from '../accounts/account';
import { balanceAt, gapReport } from '../accounts/balances';
import { Booking } from './booking';
import { findDuplicate, textSimilarity } from './duplicates';
import { counterpart, createTransfer, validateTransfer } from './transfer';

const acc = (id: string, name: string, balance: number): Account => ({
  id,
  name,
  type: id === 'g' ? 'giro' : 'tagesgeld',
  identifier: null,
  purpose: 'allgemein',
  reserve: 0,
  leadDays: 2,
  archived: false,
  order: 0,
  snapshots: [{ id: 's' + id, date: '2026-11-01', seq: 1, balance, source: 'start' }],
});
const giro = acc('g', 'Girokonto', 150000),
  tg = acc('t', 'Tagesgeld', 485000);

describe('Umbuchung', () => {
  it('erzeugt zwei verbundene Buchungen mit entgegengesetzten Beträgen', () => {
    const [a, b] = createTransfer(
      giro,
      tg,
      50000,
      '2026-11-17',
      '',
      { group: 'x', a: 'a', b: 'b' },
      [10, 11],
    );
    expect([a.amount, b.amount, a.kind, b.transferGroupId]).toEqual([
      -50000,
      50000,
      'umbuchung',
      'x',
    ]);
    expect([a.text, b.text]).toEqual(['Umbuchung nach Tagesgeld', 'Umbuchung von Girokonto']);
    expect(counterpart(a, [a, b])?.id).toBe('b');
    expect(balanceAt(giro, [a, b], '2026-11-30')).toBe(100000);
    expect(balanceAt(tg, [a, b], '2026-11-30')).toBe(535000);
    expect(gapReport(giro, [a, b]).open).toBe(0);
  });
  it('prüft Konten, Betrag und Datum', () => {
    const ok = { fromId: 'g', toId: 't', amount: 50000, date: '2026-11-17', text: '' };
    expect(validateTransfer(ok, '2026-11-17')).toEqual([]);
    expect(validateTransfer({ ...ok, toId: 'g' }, '2026-11-17')[0]).toContain('verschieden');
    expect(validateTransfer({ ...ok, amount: 0 }, '2026-11-17')[0]).toContain('größer als 0');
    expect(validateTransfer({ ...ok, date: '2026-11-18' }, '2026-11-17')[0]).toContain('Zukunft');
  });
});

describe('Dublettenprüfung', () => {
  const b = (text: string, amount: number, date: string, accountId = 'g'): Booking => ({
    id: text + date,
    accountId,
    kind: 'ausgabe',
    status: 'gebucht',
    amount,
    date,
    seq: 1,
    text,
    splits: [],
    confidence: 'sicher',
    source: { type: 'manuell' },
  });
  it('erkennt abgekürzte Bankentexte als ähnlich', () => {
    expect(textSimilarity('AGILA Hau.', 'AGILA HAUSTIERVERSICHERUNG AG')).toBe(1);
    expect(textSimilarity('Markt Alt.', 'MARKT ALTUSRIED WASSER ABWASSER')).toBe(1);
    expect(textSimilarity('REWE Markt', 'EDEKA Markt')).toBe(0.5);
    expect(textSimilarity('Tankstelle', 'Bäckerei')).toBe(0);
  });
  it('findet Dubletten nur bei gleichem Konto, Betrag und Zeitraum ± 5 Tage', () => {
    const existing = [b('AGILA HAUSTIERVERSICHERUNG AG', -2959, '2026-11-13')];
    expect(findDuplicate('AGILA Hau.', -2959, 'g', '2026-11-17', existing)?.text).toBe(
      'AGILA HAUSTIERVERSICHERUNG AG',
    );
    expect(findDuplicate('AGILA Hau.', -2959, 'g', '2026-11-19', existing)).toBeNull();
    expect(findDuplicate('AGILA Hau.', -2960, 'g', '2026-11-17', existing)).toBeNull();
    expect(findDuplicate('AGILA Hau.', -2959, 't', '2026-11-17', existing)).toBeNull();
    expect(findDuplicate('Tierarzt', -2959, 'g', '2026-11-17', existing)).toBeNull();
    expect(
      findDuplicate('AGILA Hau.', -2959, 'g', '2026-11-17', existing, existing[0].id),
    ).toBeNull();
  });
});
