import { describe, expect, it } from 'vitest';
import {
  DEFAULT_CATEGORIES as C,
  categoryLabel,
  forType,
  isTaxRelevant,
  scopeOf,
} from '../categories/categories';
import { BookingDraft, normalizeSplits, remaining, validateBooking } from './booking-draft';

const d = (p: Partial<BookingDraft> = {}): BookingDraft => ({
  accountId: 'g',
  amount: -1250,
  date: '2026-11-17',
  text: 'Bäckerei',
  splits: [{ categoryId: 'a-haushalt', subCategory: 'Lebensmittel', amount: -1250 }],
  ...p,
});

describe('Kategorien', () => {
  it('enthalten den abgestimmten Startbestand mit eindeutigen IDs', () => {
    expect(new Set(C.map((c) => c.id)).size).toBe(C.length);
    expect(forType(C, 'ausgabe').map((c) => c.name)).toContain('Holz');
    expect(forType(C, 'einnahme')[0].name).toBe('Gehalt');
    expect(C.find((c) => c.id === 'a-versicherungen')?.priority).toBe('vorrang');
  });
  it('leiten den Bezug aus der Unterkategorie ab', () => {
    expect(scopeOf(C, 'a-versicherungen', 'Tierversicherung')).toBe('hunde');
    expect(scopeOf(C, 'a-versicherungen', 'Haftpflicht')).toBeNull();
    expect(scopeOf(C, 'a-hunde', 'Futter')).toBe('hunde');
    expect(scopeOf(C, 'e-gehalt', 'Gehalt Martin')).toBe('martin');
  });
  it('kennen steuerrelevante Unterkategorien und Beschriftungen', () => {
    expect(isTaxRelevant(C, 'a-haus-garten', 'Handwerker & Reparaturen')).toBe(true);
    expect(isTaxRelevant(C, 'a-haus-garten', 'Baumarkt')).toBe(false);
    expect(isTaxRelevant(C, 'a-nebenjob', 'Fahrtkosten')).toBe(true);
    expect(categoryLabel(C, 'a-haushalt', 'Lebensmittel')).toBe('Haushalt › Lebensmittel');
    expect(categoryLabel(C, null, null)).toBe('Nicht zugeordnet');
  });
});

describe('Buchung erfassen', () => {
  const today = '2026-11-17';
  it('akzeptiert eine vollständige Ausgabe', () =>
    expect(validateBooking(d(), C, today)).toEqual([]));
  it('verlangt Konto, Betrag, Text, Datum und Kategorie', () => {
    const e = validateBooking(
      d({ accountId: null, amount: null, text: ' ', date: '2026-13-01', splits: [] }),
      C,
      today,
    );
    expect(e).toHaveLength(5);
    expect(
      validateBooking(
        d({ splits: [{ categoryId: null, subCategory: null, amount: -1250 }] }),
        C,
        today,
      ),
    ).toEqual(['Bitte eine Kategorie wählen.']);
  });
  it('lehnt Zukunftsdaten und unpassende Kategorien ab', () => {
    expect(validateBooking(d({ date: '2026-11-18' }), C, today)[0]).toContain('Zukunft');
    expect(
      validateBooking(
        d({
          amount: 245000,
          splits: [{ categoryId: 'a-haushalt', subCategory: null, amount: 245000 }],
        }),
        C,
        today,
      )[0],
    ).toContain('Einnahmen-Kategorie');
  });
  it('prüft die Aufteilung auf mehrere Kategorien', () => {
    const splits = [
      { categoryId: 'a-haushalt', subCategory: 'Lebensmittel', amount: -4000 },
      { categoryId: 'a-haushalt', subCategory: 'Drogerie', amount: -1000 },
    ];
    expect(validateBooking(d({ amount: -5000, splits }), C, today)).toEqual([]);
    expect(remaining(-5500, splits)).toBe(-500);
    expect(
      validateBooking(d({ amount: -5500, splits }), C, today)[0].replace(/\u00a0/g, ' '),
    ).toContain('es fehlen noch -5,00 €');
    expect(
      validateBooking(
        d({ amount: -5000, splits: [splits[0], { ...splits[1], amount: 1000 }] }),
        C,
        today,
      )[0],
    ).toContain('Vorzeichen');
  });
  it('setzt bei einer einzigen Kategorie den ganzen Betrag', () => {
    expect(
      normalizeSplits(-999, [{ categoryId: 'a-andere', subCategory: null, amount: 0 }]),
    ).toEqual([{ categoryId: 'a-andere', subCategory: null, amount: -999 }]);
  });
});
