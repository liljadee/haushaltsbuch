import { describe, expect, it } from 'vitest';
import { Account } from '../accounts/account';
import { Booking } from '../bookings/booking';
import { DEFAULT_CATEGORIES as C } from '../categories/categories';
import { Rule } from '../categories/rules';
import { buildPreview } from './import-preview';
import { parseKontowecker } from './kontowecker-parser';

const giro: Account = {
  id: 'g',
  name: 'Girokonto',
  type: 'giro',
  identifier: '1234',
  purpose: 'allgemein',
  reserve: 0,
  leadDays: 2,
  archived: false,
  order: 0,
  snapshots: [{ id: 's', date: '2026-11-10', seq: 1, balance: 150000, source: 'start' }],
};
const mail =
  'auf dem Konto *1234 wurden folgende Umsätze verbucht:\nAGILA Hau.: -29,59 EUR\nMarkt Alt.: -160,24 EUR\n\nneuer Saldo: 1.158,12 EUR';
const rules: Rule[] = [
  {
    id: 'r1',
    pattern: 'AGILA HAU.',
    matchType: 'beginnt_mit',
    accountId: null,
    amount: -2959,
    useAmount: false,
    categoryId: 'a-versicherungen',
    subCategory: 'Tierversicherung',
    hits: 3,
  },
];

describe('Importvorschau', () => {
  it('Beispiel der Nutzerin: Konto über *1234, Vorschläge, Lücke −152,05 €', () => {
    const p = buildPreview(parseKontowecker(mail), [giro], [], rules, C, '2026-11-17', 'fp1');
    expect(p.account?.id).toBe('g');
    expect(p.rows.map((r) => [r.text, r.suggestion.confidence])).toEqual([
      ['AGILA Hau.', 'sicher'],
      ['Markt Alt.', 'nicht_zugeordnet'],
    ]);
    expect(p.previousBalance).toBe(150000);
    expect(p.reconciliation).toEqual({ expected: 131017, reported: 115812, gap: -15205 });
    expect(p.alreadyImported).toBe(false);
  });

  it('erkennt eine schon eingefügte E-Mail und schon vorhandene Buchungen', () => {
    const existing: Booking = {
      id: 'b1',
      accountId: 'g',
      kind: 'ausgabe',
      status: 'gebucht',
      amount: -2959,
      date: '2026-11-15',
      seq: 2,
      text: 'AGILA Hau.',
      splits: [],
      confidence: 'sicher',
      source: { type: 'email', fingerprint: 'fp1' },
    };
    const p = buildPreview(
      parseKontowecker(mail),
      [giro],
      [existing],
      rules,
      C,
      '2026-11-17',
      'fp1',
    );
    expect(p.alreadyImported).toBe(true);
    expect(p.rows[0]).toMatchObject({ duplicateOf: 'b1', include: false });
    expect(p.rows[1].include).toBe(true);
    // die vorhandene Buchung ist schon im Saldo; ohne die Dublette geht nur Markt Alt. in den Abgleich
    expect(p.reconciliation?.expected).toBe(150000 - 2959 - 16024);
  });

  it('ohne passende Kennung wird kein Konto geraten', () => {
    const p = buildPreview(
      parseKontowecker(mail.replace('*1234', '*9999')),
      [giro],
      [],
      rules,
      C,
      '2026-11-17',
      'fp2',
    );
    expect(p.account).toBeNull();
    expect(p.reconciliation).toBeNull();
    expect(
      buildPreview(
        parseKontowecker(mail.replace('*1234', '*9999')),
        [giro],
        [],
        rules,
        C,
        '2026-11-17',
        'fp2',
        'g',
      ).account?.id,
    ).toBe('g');
  });
});
