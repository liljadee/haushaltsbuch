import { Account } from '../accounts/account';
import { currentBalance } from '../accounts/balances';
import { Booking } from '../bookings/booking';
import { Category } from '../categories/categories';
import { findDuplicate } from '../bookings/duplicates';
import { daysBetween } from '../shared/bank-days';
import { Rule, Suggestion, suggest } from '../categories/rules';
import { Cents } from '../shared/money';
import { LocalDate } from '../shared/local-date';
import { KontoweckerResult, Reconciliation, reconcile } from './kontowecker-parser';

/** Importvorschau (Lastenheft 8.2): alles sichtbar, korrigierbar, gespeichert wird erst nach Bestätigung. */
export interface PreviewRow {
  text: string;
  amount: Cents;
  suggestion: Suggestion;
  /** mögliche Dublette: gleiche Buchung schon vorhanden (Konto, Betrag, ähnlicher Text, ± 5 Tage) */
  duplicateOf: string | null;
  /** passende bestätigte Umbuchung (Lastenheft 16.7): wird auf „gebucht“ gesetzt statt neu angelegt */
  confirmedOf: string | null;
  include: boolean;
}

export interface ImportPreview {
  account: Account | null;
  rows: PreviewRow[];
  previousBalance: Cents | null;
  reconciliation: Reconciliation | null;
  alreadyImported: boolean;
  unknown: string[];
}

export function buildPreview(
  parsed: KontoweckerResult,
  accounts: Account[],
  bookings: Booking[],
  rules: Rule[],
  cats: Category[],
  date: LocalDate,
  fingerprint: string,
  chosenAccountId?: string | null,
): ImportPreview {
  const account =
    (chosenAccountId
      ? accounts.find((a) => a.id === chosenAccountId)
      : accounts.find((a) => !a.archived && a.identifier && a.identifier === parsed.account)) ??
    null;
  const used = new Set<string>();
  const rows = parsed.bookings.map((b) => {
    const conf = account
      ? bookings.find(
          (x) =>
            x.status === 'bestaetigt' &&
            x.accountId === account.id &&
            x.amount === b.amount &&
            !used.has(x.id) &&
            Math.abs(daysBetween(x.date, date)) <= 5,
        )
      : undefined;
    if (conf) used.add(conf.id);
    const dup =
      account && !conf ? findDuplicate(b.text, b.amount, account.id, date, bookings) : null;
    return {
      text: b.text,
      amount: b.amount,
      suggestion: suggest(b.text, b.amount, account?.id ?? null, rules, cats),
      duplicateOf: dup?.id ?? null,
      confirmedOf: conf?.id ?? null,
      include: !dup,
    };
  });
  const previousBalance = account ? currentBalance(account, bookings) : null;
  return {
    account,
    rows,
    previousBalance,
    reconciliation:
      previousBalance === null
        ? null
        : reconcile(
            previousBalance,
            // bestätigte Umbuchungen stecken schon im Kontostand
            rows.filter((r) => r.include && !r.confirmedOf).map((r) => r.amount),
            parsed.newBalance,
          ),
    alreadyImported: bookings.some((b) => b.source.fingerprint === fingerprint),
    unknown: parsed.unknown,
  };
}
