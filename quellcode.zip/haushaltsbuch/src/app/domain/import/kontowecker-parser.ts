import { Cents, formatEuro, parseEuro } from '../shared/money';

/**
 * Liest den Text einer Kontowecker-E-Mail (Lastenheft 8.1, Bauplan 6.1).
 *   auf dem Konto *1234 wurden folgende Umsätze verbucht:
 *   AGILA Hau.: -29,59 EUR
 *   Markt Alt.: -160,24 EUR
 *
 *   neuer Saldo: 1.158,12 EUR
 * Die Zeile „Neuer Saldo“ ist optional und wird nie als Buchung erfasst.
 */
export interface KontoweckerLine {
  text: string;
  amount: Cents;
  line: number;
}

export interface KontoweckerResult {
  /** Endziffern der Kontokennung, z. B. "1234"; null, wenn die E-Mail keine nennt. */
  account: string | null;
  bookings: KontoweckerLine[];
  /** „Neuer Saldo“ in Cent; null, wenn die E-Mail keinen nennt. */
  newBalance: Cents | null;
  /** Zeilen, die weder Kopf, Umsatz noch Saldo sind; sie werden angezeigt, nie gebucht. */
  unknown: string[];
}

const AMOUNT = String.raw`([+\-]?\s?(?:\d{1,3}(?:\.\d{3})+|\d+)(?:,\d{1,2})?)\s*(?:EUR|€)?`;
const ACCOUNT_RE = /konto\s*\*\s*(\d{2,})/i;
const HEADER_RE = /umsätze\s+verbucht/i;
const BALANCE_RE = new RegExp(String.raw`^neuer\s+saldo\s*:\s*${AMOUNT}$`, 'i');
const BOOKING_RE = new RegExp(String.raw`^(.+):\s*${AMOUNT}$`, 'i');

export function parseKontowecker(mail: string): KontoweckerResult {
  const result: KontoweckerResult = { account: null, bookings: [], newBalance: null, unknown: [] };
  const lines = mail
    .replace(/\r\n?/g, '\n')
    .replace(/\u2212/g, '-')
    .replace(/\u00a0/g, ' ')
    .split('\n');
  lines.forEach((raw, i) => {
    const line = raw
      .trim()
      .replace(/^["„“]|["“”]$/g, '')
      .trim();
    if (!line) return;
    const acc = ACCOUNT_RE.exec(line);
    if (acc) {
      result.account ??= acc[1];
      return;
    }
    if (HEADER_RE.test(line)) return;
    const bal = BALANCE_RE.exec(line);
    if (bal) {
      result.newBalance = parseEuro(bal[1].replace(/\s/g, ''));
      return;
    }
    const bk = BOOKING_RE.exec(line);
    const amount = bk ? parseEuro(bk[2].replace(/\s/g, '')) : null;
    if (bk && amount !== null && bk[1].trim()) {
      result.bookings.push({ text: bk[1].trim(), amount, line: i + 1 });
      return;
    }
    result.unknown.push(line);
  });
  return result;
}

/** Saldenabgleich (Lastenheft 8.1): letzter bekannter Stand plus neue Umsätze gegen „Neuer Saldo“. */
export interface Reconciliation {
  expected: Cents;
  reported: Cents;
  /** reported − expected: negativ = vermutlich fehlende Ausgaben, positiv = fehlende Einnahmen. */
  gap: Cents;
}

export function reconcile(
  previousBalance: Cents,
  newAmounts: Cents[],
  reported: Cents | null,
): Reconciliation | null {
  if (reported === null) return null;
  const expected = newAmounts.reduce((s, a) => s + a, previousBalance);
  return { expected, reported, gap: reported - expected };
}

/** Text für den Hinweis; leer, wenn alles aufgeht. */
export function gapMessage(r: Reconciliation | null): string {
  if (!r || r.gap === 0) return '';
  const what = r.gap < 0 ? 'Ausgaben' : 'Einnahmen';
  return `Vermutlich fehlen Buchungen über ${formatEuro(r.gap)} (${what}). Erwartet waren ${formatEuro(r.expected)}, die Bank meldet ${formatEuro(r.reported)}.`;
}
