import { describe, expect, it } from 'vitest';
import { gapMessage, parseKontowecker, reconcile } from './kontowecker-parser';

const nbsp = (s: string) => s.replace(/\u00a0/g, ' ');

describe('Kontowecker-E-Mail', () => {
  it('Beispiel der Nutzerin vom 17.11.2026: zwei Umsätze, neuer Saldo, eine Lücke von −152,05 €', () => {
    const mail = `auf dem Konto *1234 wurden folgende Umsätze verbucht:
AGILA Hau.: -29,59 EUR
Markt Alt.: -160,24 EUR

neuer Saldo: 1.158,12 EUR`;
    const r = parseKontowecker(mail);
    expect(r.account).toBe('1234');
    expect(r.bookings.map((b) => [b.text, b.amount])).toEqual([
      ['AGILA Hau.', -2959],
      ['Markt Alt.', -16024],
    ]);
    expect(r.newBalance).toBe(115812);
    expect(r.unknown).toEqual([]);
    const rec = reconcile(
      150000,
      r.bookings.map((b) => b.amount),
      r.newBalance,
    );
    expect(rec).toEqual({ expected: 131017, reported: 115812, gap: -15205 });
    expect(nbsp(gapMessage(rec))).toBe(
      'Vermutlich fehlen Buchungen über -152,05 € (Ausgaben). Erwartet waren 1.310,17 €, die Bank meldet 1.158,12 €.',
    );
  });

  it('Beispiel aus dem Lastenheft 8.1: negativer Saldo, Großschreibung', () => {
    const r = parseKontowecker(
      'auf dem Konto *3478 wurden folgende Umsätze verbucht:\nTankstelle: -10,00 EUR\nSGAT-VR P.: -9,00 EUR\nNeuer Saldo: -8,03 EUR',
    );
    expect(r.account).toBe('3478');
    expect(r.bookings.map((b) => b.amount)).toEqual([-1000, -900]);
    expect(r.newBalance).toBe(-803);
  });

  it('ohne „Neuer Saldo“ gibt es keinen Abgleich (erste Beispiel-E-Mail der Nutzerin)', () => {
    const r = parseKontowecker(
      'auf dem Konto *1234 wurden folgende Umsätze verbucht:\nAGILA Hau.: -29,59 EUR\nMarkt Alt.: -160,24 EUR',
    );
    expect(r.newBalance).toBeNull();
    expect(
      reconcile(
        150000,
        r.bookings.map((b) => b.amount),
        r.newBalance,
      ),
    ).toBeNull();
    expect(gapMessage(null)).toBe('');
  });

  it('geht der Saldo auf, gibt es keinen Hinweis', () => {
    expect(gapMessage(reconcile(150000, [-2959, -16024], 131017))).toBe('');
  });

  it('meldet fehlende Einnahmen mit positivem Betrag', () => {
    expect(nbsp(gapMessage(reconcile(10000, [-500], 254500)))).toContain(
      'über 2.450,00 € (Einnahmen)',
    );
  });

  it('liest Einnahmen, Pluszeichen, Tausenderpunkt, Euro-Zeichen und typografisches Minus', () => {
    const r = parseKontowecker(
      'Konto *1234\nGEHALT SANDRA: 2.450,00 EUR\nErstattung: +12,50 EUR\nREWE: \u221231,07 €\nBargeld: -50 EUR',
    );
    expect(r.bookings.map((b) => b.amount)).toEqual([245000, 1250, -3107, -5000]);
  });

  it('behält Doppelpunkte im Buchungstext und verträgt Windows-Zeilenenden und Leerzeilen', () => {
    const r = parseKontowecker(
      'auf dem Konto *1234 wurden folgende Umsätze verbucht:\r\n\r\nAmazon: Bestellung 4711: -5,99 EUR\r\n\r\nneuer Saldo: 100,00 EUR\r\n',
    );
    expect(r.bookings).toEqual([{ text: 'Amazon: Bestellung 4711', amount: -599, line: 3 }]);
    expect(r.newBalance).toBe(10000);
  });

  it('markiert unbekannte Zeilen, statt sie zu buchen', () => {
    const r = parseKontowecker(
      'Hallo Sandra,\nauf dem Konto *1234 wurden folgende Umsätze verbucht:\nREWE: -12,00 EUR\nViele Grüße, Ihr Kontowecker',
    );
    expect(r.bookings).toHaveLength(1);
    expect(r.unknown).toEqual(['Hallo Sandra,', 'Viele Grüße, Ihr Kontowecker']);
  });

  it('nimmt eine eingefügte E-Mail mit Anführungszeichen', () => {
    const r = parseKontowecker(
      '"auf dem Konto *1234 wurden folgende Umsätze verbucht:\nAGILA Hau.: -29,59 EUR\n\nneuer Saldo: 1.158,12 EUR"',
    );
    expect(r.bookings).toHaveLength(1);
    expect(r.newBalance).toBe(115812);
    expect(r.unknown).toEqual([]);
  });
});
