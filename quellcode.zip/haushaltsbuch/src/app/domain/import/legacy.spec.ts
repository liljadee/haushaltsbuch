import { describe, expect, it } from 'vitest';
import { Account } from '../accounts/account';
import { DEFAULT_CATEGORIES as C } from '../categories/categories';
import { Rule } from '../categories/rules';
import {
  LegacyMapping,
  catKey,
  commentKey,
  excelSerialToDate,
  guessAccount,
  parseDotAmount,
  parseLegacyDate,
  parseLegacyWorkbook,
  planLegacyImport,
  sheetKind,
} from './legacy';

const acc = (id: string, name: string, identifier: string | null, start: string): Account => ({
  id,
  name,
  type: id === 'g' ? 'giro' : 'tagesgeld',
  identifier,
  purpose: 'allgemein',
  reserve: 0,
  leadDays: 2,
  archived: false,
  order: 0,
  snapshots: [{ id: 's' + id, date: start, seq: 1, balance: 0, source: 'start' }],
});
const giro = acc('g', 'Girokonto', '1234', '2026-11-10'),
  st = acc('t', 'Tagesgeld Sondertilgung', '1250', '2026-11-10');
const head = [
  ['Ausgaben'],
  ['Datum', 'Kategorie', 'Konto', 'Betrag', 'Währung', 'x', 'y', 'z', 'Kommentar'],
];

describe('Altdaten: Einzelwerte', () => {
  it('erkennt die Blätter', () => {
    expect([
      sheetKind('Ausgaben'),
      sheetKind('Einnahmen'),
      sheetKind('Überweisungen'),
      sheetKind('Expenses'),
      sheetKind('Notizen'),
    ]).toEqual(['ausgabe', 'einnahme', 'umbuchung', 'ausgabe', null]);
  });
  it('liest Datum als MM/DD/JJJJ und als Excel-Zahl', () => {
    expect(parseLegacyDate('11/03/2026')).toBe('2026-11-03');
    expect(parseLegacyDate('2/9/2026')).toBe('2026-02-09');
    expect(parseLegacyDate('13/03/2026')).toBeNull();
    expect(parseLegacyDate(46340)).toBe('2026-11-14');
    expect(excelSerialToDate(46023)).toBe('2026-01-01');
    expect(parseLegacyDate('Datum')).toBeNull();
  });
  it('liest Beträge mit Punkt, als Text und als Zahl', () => {
    expect([
      parseDotAmount('160.24'),
      parseDotAmount(29.59),
      parseDotAmount(380),
      parseDotAmount('1,234.50'),
      parseDotAmount('-12.5'),
      parseDotAmount('12,50'),
    ]).toEqual([16024, 2959, 38000, 123450, 1250, null]);
    expect(parseDotAmount(0.1 + 0.2)).toBe(30);
  });
});

describe('Altdaten: Arbeitsmappe', () => {
  const sheets = [
    {
      name: 'Ausgaben',
      rows: [
        ...head,
        [
          '09/13/2026',
          'Versicherung',
          'Girokonto',
          29.59,
          'EUR',
          0,
          0,
          0,
          'AGILA Hundeversicherung',
        ],
        ['10/02/2026', 'Lebensmittel', 'Girokonto', 85.4, 'EUR', 0, 0, 0, 'REWE'],
        ['10/21/2026', 'Lebensmittel', 'Girokonto', null, 'EUR', 0, 0, 0, 'x'],
        ['11/16/2026', 'Lebensmittel', 'Girokonto', 33.1, 'EUR'],
        ['10/22/2026', 'Urlaub', 'Girokonto', 50, 'USD'],
      ],
    },
    {
      name: 'Einnahmen',
      rows: [...head, ['09/30/2026', 'Gehalt', 'Girokonto', 2450, 'EUR', 0, 0, 0, 'Gehalt Sandra']],
    },
    {
      name: 'Überweisungen',
      rows: [
        ...head,
        ['10/01/2026', 'Girokonto', 'Sondertilg 1250', 150, 'EUR', 0, 0, 0, 'Sparrate'],
      ],
    },
    { name: 'Diagramme', rows: [['egal']] },
  ];
  const parsed = parseLegacyWorkbook(sheets);

  it('liest Zeilen ab der ersten Datumszeile und meldet Probleme verständlich', () => {
    expect(parsed.sheets.map((s) => [s.name, s.kind, s.count])).toEqual([
      ['Ausgaben', 'ausgabe', 3],
      ['Einnahmen', 'einnahme', 1],
      ['Überweisungen', 'umbuchung', 1],
      ['Diagramme', null, 0],
    ]);
    expect(parsed.problems).toEqual([
      { sheet: 'Ausgaben', row: 5, reason: 'Betrag fehlt oder ist unlesbar' },
      { sheet: 'Ausgaben', row: 7, reason: 'Währung USD wird nicht übernommen' },
    ]);
    expect(parsed.rows[0]).toMatchObject({
      kind: 'ausgabe',
      date: '2026-09-13',
      category: 'Versicherung',
      account: 'Girokonto',
      amount: 2959,
      comment: 'AGILA Hundeversicherung',
      row: 3,
    });
  });

  it('Blätter lassen sich von Hand zuordnen oder ignorieren', () => {
    const p = parseLegacyWorkbook([{ name: 'Tabelle1', rows: sheets[0].rows }, sheets[1]], {
      Tabelle1: 'ausgabe',
      Einnahmen: null,
    });
    expect(p.sheets.map((x) => [x.name, x.kind, x.count])).toEqual([
      ['Tabelle1', 'ausgabe', 3],
      ['Einnahmen', null, 0],
    ]);
  });

  it('schlägt Konten nach Name und Ziffern vor', () => {
    expect(guessAccount('Girokonto', [giro, st])).toBe('g');
    expect(guessAccount('Sondertilg 1250', [giro, st])).toBe('t');
    expect(guessAccount('Bargeld', [giro, st])).toBeNull();
  });

  it('ordnet zu: Kommentar-Ausnahme vor Regel vor alter Kategorie; nur vor dem Startsaldo', () => {
    const mapping: LegacyMapping = {
      categories: {
        [catKey('ausgabe', 'Lebensmittel')]: {
          categoryId: 'a-haushalt',
          subCategory: 'Lebensmittel',
        },
        [catKey('ausgabe', 'Versicherung')]: { categoryId: 'a-versicherungen', subCategory: null },
        [catKey('einnahme', 'Gehalt')]: { categoryId: 'e-gehalt', subCategory: null },
      },
      comments: {
        [commentKey('einnahme', 'Gehalt', 'Gehalt Sandra')]: {
          categoryId: 'e-gehalt',
          subCategory: 'Gehalt Sandra',
        },
      },
      accounts: { Girokonto: 'g', 'Sondertilg 1250': 't' },
    };
    const rules: Rule[] = [
      {
        id: 'r',
        pattern: 'AGILA',
        matchType: 'beginnt_mit',
        accountId: null,
        amount: -2959,
        useAmount: false,
        categoryId: 'a-versicherungen',
        subCategory: 'Tierversicherung',
        hits: 1,
      },
    ];
    const plan = planLegacyImport(parsed, mapping, [giro, st], [], rules, C);
    const by = (c: string) => plan.rows.find((r) => r.src.comment === c || r.src.category === c)!;
    expect(by('AGILA Hundeversicherung')).toMatchObject({
      categoryId: 'a-versicherungen',
      subCategory: 'Tierversicherung',
      via: 'regel',
      include: true,
    });
    expect(by('REWE')).toMatchObject({ categoryId: 'a-haushalt', via: 'kategorie' });
    expect(by('Gehalt Sandra')).toMatchObject({ subCategory: 'Gehalt Sandra', via: 'kommentar' });
    expect(by('Sparrate')).toMatchObject({ accountId: 't', fromAccountId: 'g', include: true });
    expect(plan.rows.find((r) => r.src.date === '2026-11-16')).toMatchObject({
      afterStart: true,
      include: false,
    });
    expect([plan.importable, plan.skippedAfterStart, plan.uncategorized]).toEqual([4, 1, 0]);
    expect(planLegacyImport(parsed, mapping, [giro, st], [], rules, C, false).importable).toBe(5);
  });

  it('ohne Kontozuordnung wird nichts übernommen; Doppelte werden erkannt', () => {
    const plan = planLegacyImport(
      parsed,
      { categories: {}, comments: {}, accounts: {} },
      [giro, st],
      [],
      [],
      C,
    );
    expect([plan.importable, plan.unmappedAccounts]).toEqual([0, 5]);
    const existing = [
      {
        id: 'b',
        accountId: 'g',
        kind: 'ausgabe' as const,
        status: 'gebucht' as const,
        amount: -8540,
        date: '2026-10-02',
        seq: 1,
        text: 'REWE',
        splits: [],
        confidence: 'sicher' as const,
        source: { type: 'manuell' as const },
      },
    ];
    const p2 = planLegacyImport(
      parsed,
      { categories: {}, comments: {}, accounts: { Girokonto: 'g' } },
      [giro],
      existing,
      [],
      C,
    );
    expect(p2.rows.find((r) => r.src.comment === 'REWE')).toMatchObject({
      duplicateOf: 'b',
      include: false,
    });
  });
});

describe('Altdaten: Sparen als Umbuchung, Ersetzen, Kategorienamen', () => {
  const sheets = [
    {
      name: 'Ausgaben',
      rows: [
        ...head,
        ['10/25/2026', 'Sparen', 'Girokonto', 100, 'EUR', 0, 0, 0, 'Urlaub'],
        ['10/26/2026', 'Haushalt › Drogerie', 'Girokonto', 5, 'EUR', 0, 0, 0, 'dm'],
      ],
    },
  ];
  const parsed = parseLegacyWorkbook(sheets);
  it('eine alte Kategorie kann zur Umbuchung auf ein eigenes Konto werden', () => {
    const plan = planLegacyImport(
      parsed,
      {
        categories: {
          [catKey('ausgabe', 'Sparen')]: { categoryId: null, subCategory: null, transferTo: 't' },
        },
        comments: {},
        accounts: { Girokonto: 'g' },
      },
      [giro, st],
      [],
      [],
      C,
    );
    expect(plan.rows[0]).toMatchObject({ transferTo: 't', categoryId: null, include: true });
    expect(plan.uncategorized).toBe(1);
    const self = planLegacyImport(
      parsed,
      {
        categories: {
          [catKey('ausgabe', 'Sparen')]: { categoryId: null, subCategory: null, transferTo: 'g' },
        },
        comments: {},
        accounts: { Girokonto: 'g' },
      },
      [giro, st],
      [],
      [],
      C,
    );
    expect(self.rows[0].include).toBe(false);
  });
  it('„Vorherigen Import ersetzen“ ignoriert frühere Altdaten bei der Doppelprüfung', () => {
    const old = {
      id: 'x',
      accountId: 'g',
      kind: 'ausgabe' as const,
      status: 'gebucht' as const,
      amount: -500,
      date: '2026-10-26',
      seq: 1,
      text: 'dm',
      splits: [],
      confidence: 'sicher' as const,
      source: { type: 'xlsx' as const },
    };
    const m = { categories: {}, comments: {}, accounts: { Girokonto: 'g' } };
    expect(planLegacyImport(parsed, m, [giro], [old], [], C).rows[1].duplicateOf).toBe('x');
    const p = planLegacyImport(parsed, m, [giro], [old], [], C, true, true);
    expect([p.rows[1].duplicateOf, p.replaced]).toEqual([null, 1]);
  });
});
