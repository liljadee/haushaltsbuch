import { Account } from '../accounts/account';
import { Booking } from '../bookings/booking';
import { findDuplicate } from '../bookings/duplicates';
import { Category } from '../categories/categories';
import { Rule, normalizeText, suggest } from '../categories/rules';
import { Cents } from '../shared/money';
import { LocalDate, isLocalDate } from '../shared/local-date';

/**
 * Altdaten aus der bisherigen App (Lastenheft 11): XLSX mit je einem Blatt für Ausgaben, Einnahmen
 * und Überweisungen, Daten ab der ersten Zeile mit Datum.
 * A Datum (MM/DD/JJJJ), B Kategorie bzw. Von-Konto, C Konto bzw. Nach-Konto, D Betrag mit Punkt,
 * E Währung, I Kommentar.
 */
export type LegacyKind = 'ausgabe' | 'einnahme' | 'umbuchung';
type Cell = string | number | boolean | null;

export interface LegacyRow {
  kind: LegacyKind;
  date: LocalDate;
  /** Kategorie der alten App; bei Überweisungen das Von-Konto */
  category: string;
  /** Konto; bei Überweisungen das Nach-Konto */
  account: string;
  /** positiv */
  amount: Cents;
  comment: string;
  sheet: string;
  row: number;
}

export interface LegacyProblem {
  sheet: string;
  row: number;
  reason: string;
}
export interface LegacyParse {
  rows: LegacyRow[];
  problems: LegacyProblem[];
  sheets: { name: string; kind: LegacyKind | null; count: number }[];
}

export function sheetKind(name: string): LegacyKind | null {
  const n = name.toLowerCase();
  if (/ausgab|expens/.test(n)) return 'ausgabe';
  if (/einnahm|income/.test(n)) return 'einnahme';
  if (/überweis|uberweis|ueberweis|transfer|umbuch/.test(n)) return 'umbuchung';
  return null;
}

/** Excel-Seriennummer (Tage seit 30.12.1899) → Datum */
export function excelSerialToDate(n: number): LocalDate {
  const d = new Date(Date.UTC(1899, 11, 30) + Math.round(n) * 86400000);
  return d.toISOString().slice(0, 10);
}

export function parseLegacyDate(v: Cell): LocalDate | null {
  if (typeof v === 'number' && v > 20000 && v < 80000) return excelSerialToDate(v);
  if (typeof v !== 'string') return null;
  const s = v.trim();
  let m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(s);
  if (m) {
    const d = `${m[3]}-${m[1].padStart(2, '0')}-${m[2].padStart(2, '0')}`;
    return isLocalDate(d) ? d : null;
  }
  m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s);
  return m && isLocalDate(m[0]) ? m[0] : null;
}

/** Betrag mit Punkt als Dezimaltrennzeichen („160.24“), auch als Zahl; Ergebnis positiv in Cent. */
export function parseDotAmount(v: Cell): Cents | null {
  if (typeof v === 'number') return Number.isFinite(v) ? Math.abs(Math.round(v * 100)) : null;
  if (typeof v !== 'string') return null;
  const s = v
    .trim()
    .replace(/\s|€|EUR/gi, '')
    .replace(/,(?=\d{3}(\D|$))/g, '');
  if (!/^[-+]?\d+(\.\d{1,2})?$/.test(s)) return null;
  return Math.abs(Math.round(Number(s) * 100));
}

const text = (v: Cell) => (v === null || v === undefined ? '' : String(v).trim());

/** kinds: Art je Blatt von Hand festlegen (null = Blatt ignorieren); sonst nach dem Blattnamen. */
export function parseLegacyWorkbook(
  sheets: { name: string; rows: Cell[][] }[],
  kinds: Record<string, LegacyKind | null> = {},
): LegacyParse {
  const out: LegacyParse = { rows: [], problems: [], sheets: [] };
  for (const sh of sheets) {
    const kind = sh.name in kinds ? kinds[sh.name] : sheetKind(sh.name);
    let count = 0,
      started = false;
    if (kind)
      sh.rows.forEach((r, i) => {
        const date = parseLegacyDate(r[0] ?? null);
        if (!date) {
          if (started && r.some((c) => text(c)))
            out.problems.push({
              sheet: sh.name,
              row: i + 1,
              reason: 'Datum fehlt oder ist unlesbar',
            });
          return;
        }
        started = true;
        const amount = parseDotAmount(r[3] ?? null);
        const currency = text(r[4] ?? null).toUpperCase();
        if (amount === null || amount === 0)
          return void out.problems.push({
            sheet: sh.name,
            row: i + 1,
            reason: 'Betrag fehlt oder ist unlesbar',
          });
        if (currency && currency !== 'EUR')
          return void out.problems.push({
            sheet: sh.name,
            row: i + 1,
            reason: `Währung ${currency} wird nicht übernommen`,
          });
        const category = text(r[1] ?? null),
          account = text(r[2] ?? null);
        if (!account || (kind === 'umbuchung' && !category))
          return void out.problems.push({ sheet: sh.name, row: i + 1, reason: 'Konto fehlt' });
        out.rows.push({
          kind,
          date,
          category,
          account,
          amount,
          comment: text(r[8] ?? null),
          sheet: sh.name,
          row: i + 1,
        });
        count++;
      });
    out.sheets.push({ name: sh.name, kind, count });
  }
  return out;
}

// ---------- Zuordnung und Plan ----------

/** Ziel einer Zuordnung: Kategorie oder Umbuchung auf ein eigenes Konto (transferTo). */
export interface Target {
  categoryId: string | null;
  subCategory: string | null;
  transferTo?: string | null;
}
export interface LegacyMapping {
  /** alte Kategorie (je Art) → neue Kategorie */
  categories: Record<string, Target | null>;
  /** alte Kategorie + Kommentar → neue Kategorie (Ausnahmen nach Kommentar) */
  comments: Record<string, Target | null>;
  /** Kontoname der alten App → Konto-ID */
  accounts: Record<string, string | null>;
}

export const catKey = (kind: LegacyKind, category: string) => `${kind}|${category}`;
export const commentKey = (kind: LegacyKind, category: string, comment: string) =>
  `${kind}|${category}|${normalizeText(comment)}`;

export interface PlanRow {
  src: LegacyRow;
  accountId: string | null;
  /** Gegenkonto bei Umbuchungen (Von-Konto) */
  fromAccountId: string | null;
  categoryId: string | null;
  subCategory: string | null;
  /** Ausgabe oder Einnahme wird zur Umbuchung auf dieses eigene Konto (z. B. „Sparen“ aufs Tagesgeld) */
  transferTo: string | null;
  via: 'kommentar' | 'regel' | 'kategorie' | null;
  duplicateOf: string | null;
  afterStart: boolean;
  include: boolean;
}

export interface LegacyPlan {
  rows: PlanRow[];
  importable: number;
  skippedAfterStart: number;
  duplicates: number;
  unmappedAccounts: number;
  uncategorized: number;
  /** Anzahl früher importierter Buchungen, die ersetzt werden */
  replaced: number;
}

/** Vorschlag: Konto gleichen Namens oder mit den Ziffern im Namen als Kennung („Sondertilg 1250“ → *1250). */
export function guessAccount(name: string, accounts: Account[]): string | null {
  const n = normalizeText(name);
  const byName = accounts.find((a) => normalizeText(a.name) === n);
  if (byName) return byName.id;
  const digits = /\d{3,6}/.exec(name)?.[0];
  return (
    (digits && accounts.find((a) => a.identifier === digits)?.id) ||
    accounts.find((a) => n.includes(normalizeText(a.name)) || normalizeText(a.name).includes(n))
      ?.id ||
    null
  );
}

/** Startsaldo eines Kontos = frühester Stand laut Bank */
const startDate = (a: Account | undefined) =>
  a ? ([...a.snapshots].sort((x, y) => (x.date < y.date ? -1 : 1))[0]?.date ?? null) : null;

export function planLegacyImport(
  parse: LegacyParse,
  mapping: LegacyMapping,
  accounts: Account[],
  bookings: Booking[],
  rules: Rule[],
  cats: Category[],
  onlyBeforeStart = true,
  /** frühere Importe aus der alten App ersetzen statt als Doppelte zu überspringen */
  replaceLegacy = false,
): LegacyPlan {
  const index = new Map<string, Booking[]>();
  for (const b of bookings) {
    if (replaceLegacy && b.source.type === 'xlsx') continue;
    const k = `${b.accountId}|${b.amount}`;
    index.set(k, [...(index.get(k) ?? []), b]);
  }
  const rows: PlanRow[] = parse.rows.map((src) => {
    const accountId = mapping.accounts[src.account] ?? null;
    const fromAccountId =
      src.kind === 'umbuchung' ? (mapping.accounts[src.category] ?? null) : null;
    const signed = src.kind === 'ausgabe' ? -src.amount : src.amount;
    let target: Target | null = null,
      via: PlanRow['via'] = null;
    if (src.kind !== 'umbuchung') {
      const byComment = src.comment
        ? mapping.comments[commentKey(src.kind, src.category, src.comment)]
        : null;
      const rule = src.comment ? suggest(src.comment, signed, accountId, rules, cats) : null;
      const byCat = mapping.categories[catKey(src.kind, src.category)];
      if (byComment) [target, via] = [byComment, 'kommentar'];
      else if (rule?.confidence === 'sicher' && rule.categoryId)
        [target, via] = [{ categoryId: rule.categoryId, subCategory: rule.subCategory }, 'regel'];
      else if (byCat) [target, via] = [byCat, 'kategorie'];
    }
    const acc = accounts.find((a) => a.id === accountId);
    const start = startDate(acc);
    const afterStart = !!start && src.date >= start;
    const text = src.comment || (src.kind === 'umbuchung' ? 'Umbuchung' : src.category);
    const dup = accountId
      ? findDuplicate(
          text,
          src.kind === 'umbuchung' ? src.amount : signed,
          accountId,
          src.date,
          index.get(`${accountId}|${src.kind === 'umbuchung' ? src.amount : signed}`) ?? [],
        )
      : null;
    const transferTo = src.kind !== 'umbuchung' ? (target?.transferTo ?? null) : null;
    const missingAcc =
      !accountId ||
      (src.kind === 'umbuchung' && (!fromAccountId || fromAccountId === accountId)) ||
      (transferTo !== null &&
        (transferTo === accountId || !accounts.some((a) => a.id === transferTo)));
    return {
      src,
      accountId,
      fromAccountId,
      categoryId: transferTo ? null : (target?.categoryId ?? null),
      subCategory: transferTo ? null : (target?.subCategory ?? null),
      transferTo,
      via,
      duplicateOf: dup?.id ?? null,
      afterStart,
      include: !missingAcc && !dup && !(onlyBeforeStart && afterStart),
    };
  });
  return {
    rows,
    importable: rows.filter((r) => r.include).length,
    skippedAfterStart: rows.filter((r) => onlyBeforeStart && r.afterStart).length,
    duplicates: rows.filter((r) => r.duplicateOf).length,
    unmappedAccounts: rows.filter(
      (r) => !r.accountId || (r.src.kind === 'umbuchung' && !r.fromAccountId),
    ).length,
    uncategorized: rows.filter(
      (r) => r.include && r.src.kind !== 'umbuchung' && !r.transferTo && !r.categoryId,
    ).length,
    replaced: replaceLegacy ? bookings.filter((b) => b.source.type === 'xlsx').length : 0,
  };
}
