#!/usr/bin/env python3
"""
Haushaltsbuch: Backup (.hhb) ohne App entschlüsseln (Bauplan 5.4).

Aufruf:
    pip install cryptography
    python3 restore.py haushaltsbuch-backup-2026-11-16.hhb
    -> fragt nach dem Wiederherstellungsschlüssel und schreibt die Daten
       als lesbares JSON nach haushaltsbuch-backup-2026-11-16.json

Alternativ mit App-Passwort:  python3 restore.py DATEI.hhb --passwort
"""
import base64, getpass, gzip, json, sys
from pathlib import Path

try:
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives.keywrap import aes_key_unwrap
except ImportError:
    sys.exit("Bitte zuerst installieren:  pip install cryptography")

ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"   # Crockford Base32, wie in der App


def normalize_key(text: str) -> str:
    s = text.upper().replace(" ", "").replace("-", "").replace("O", "0").replace("I", "1").replace("L", "1")
    if len(s) != 30 or any(c not in ALPHABET for c in s):
        sys.exit("Der Wiederherstellungsschlüssel hat 30 Zeichen in sechs Gruppen (z. B. 7K2QX-...).")
    return s


def b64(s: str) -> bytes:
    return base64.b64decode(s)


def main() -> None:
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    path = Path(sys.argv[1])
    use_password = "--passwort" in sys.argv[2:]
    backup = json.loads(path.read_text(encoding="utf-8"))
    if backup.get("format") != "haushaltsbuch-backup":
        sys.exit("Das ist kein Haushaltsbuch-Backup.")
    if backup.get("formatVersion", 0) > 1:
        sys.exit("Das Backup ist neuer als dieses Skript (formatVersion > 1).")

    if use_password:
        p = backup["keys"].get("password")
        if not p:
            sys.exit("Dieses Backup enthält keinen Passwort-Zugang.")
        secret = getpass.getpass("App-Passwort: ")
        import unicodedata
        kek = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=b64(p["salt"]), iterations=p["iterations"]).derive(
            unicodedata.normalize("NFC", secret).encode("utf-8"))
        wrapped = b64(p["wrappedKey"])
    else:
        r = backup["keys"]["recovery"]
        key = normalize_key(getpass.getpass("Wiederherstellungsschlüssel: "))
        kek = HKDF(algorithm=hashes.SHA256(), length=32, salt=b64(r["salt"]), info=r["info"].encode("utf-8")).derive(key.encode("ascii"))
        wrapped = b64(r["wrappedKey"])

    try:
        data_key = aes_key_unwrap(kek, wrapped)
    except Exception:
        sys.exit("Schlüssel oder Passwort passt nicht zu diesem Backup.")

    pl = backup["payload"]
    try:
        packed = AESGCM(data_key).decrypt(b64(pl["iv"]), b64(pl["data"]), pl["aad"].encode("utf-8"))
    except Exception:
        sys.exit("Das Backup ist beschädigt oder wurde verändert.")
    content = json.loads(gzip.decompress(packed).decode("utf-8"))
    out = path.with_suffix(".json")
    out.write_text(json.dumps(content, ensure_ascii=False, indent=2), encoding="utf-8")
    n = sum(len(v) for v in content.get("stores", {}).values())
    print(f"Entschlüsselt: {n} Datensätze -> {out}")
    print("Achtung: Diese Datei ist NICHT verschlüsselt. Nach dem Ansehen sicher löschen.")


if __name__ == "__main__":
    main()
