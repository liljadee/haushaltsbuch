# ADR 0009: Schichten, Signals und Qualitätsregeln

- Datum: 16.11.2026
- Status: akzeptiert

## Kontext

Niemand liest den Code gegen; jede Regel muss automatisch prüfbar sein.

## Entscheidung

Vier Schichten (domain, data, features, shared) mit Lint-Regel für die Abhängigkeitsrichtung; Fachlogik ohne Angular und Browser. Standalone-Komponenten mit OnPush, Zustand über Angular Signals. TypeScript strict und strictTemplates, kein any. ESLint und Prettier. Abdeckung der Fachlogik mindestens 90 % in jedem Teilbereich. Ende-zu-Ende-Tests mit Playwright. Exakte Versionen (save-exact), Lockfile, Sicherheitsprüfung vor jeder Lieferung. Keine schweren Fremdbibliotheken (z. B. kein Moment.js, kein Lodash); stattdessen Browser-Bordmittel (Intl, Web Crypto, DecompressionStream).

## Folgen

Größe: Angular-Budget roh (Warnung 1,2 MB, Abbruch 1,5 MB) und übertragene Größe im Prüfbericht (Warnung 250 kB, Abbruch 350 kB); strengere Budgets setzen Lazy Loading voraus (ADR 0007).
