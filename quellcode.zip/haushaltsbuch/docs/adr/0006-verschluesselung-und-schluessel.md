# ADR 0006: Verschlüsselung und Schlüssel

- Datum: 16.11.2026
- Status: akzeptiert

## Kontext

Finanzdaten liegen lokal im Browser; Verlust des Geräts oder Zugriff Dritter darf nichts preisgeben.

## Entscheidung

AES-256-GCM über Web Crypto; ein Datenschlüssel, dreifach verpackt: Passkey mit PRF (HKDF-SHA-256), Wiederherstellungsschlüssel (30 Zeichen Crockford-Base32), optional App-Passwort (PBKDF2-HMAC-SHA-256, 600.000 Durchläufe). Sperre nach 1 Minute im Hintergrund.

## Folgen

Keine Fremdbibliothek für Kryptografie; Backup (.hhb) lässt sich auch ohne App mit docs/restore.py entschlüsseln.
