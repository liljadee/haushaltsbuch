# ADR 0010: Ablösung durch den Bausparvertrag als Korrekturbuchung

- Datum: 19.11.2026
- Status: akzeptiert

## Kontext

Lastenheft 18.10: Ein Assistent erfasst die Ablösung in einem Schritt; Guthaben und neu angelegtes Bauspardarlehen werden auf das Darlehen umgebucht. Kredite sind in der App keine Konten, sondern Verträge mit Ständen laut Bank; eine Umbuchung im Sinne zweier verknüpfter Kontobuchungen ist deshalb nicht möglich.

## Entscheidung

Der Assistent schreibt in einer Transaktion: eine Korrekturbuchung auf dem Bausparkonto über das ausgezahlte Guthaben (Konto danach 0 €, auf Wunsch archiviert), einen neuen Kredit „Bauspardarlehen …“ mit Stand zum Ablösetag und Rate als wiederkehrende Zahlung, den neuen Stand des Darlehens (0 € → abbezahlt; sonst Anschlussfinanzierung mit neuer Rate und neuem Zins) und den Vermerk „abgelöst“ am Bausparvertrag.

## Folgen

Die Korrekturbuchung zählt nicht in der Statistik: Erspartes zur Tilgung umzuschichten ist weder Ausgabe noch Einnahme; das Sparen wurde bereits mit den Sparraten gezählt. Ein abgelöster Bausparvertrag geht nicht mehr in Prognose und Sondertilgungsplan ein.
