# ADR 0001: PWA statt nativer Android-App

- Datum: 16.11.2026
- Status: akzeptiert

## Kontext

Die Nutzerin bekommt fertige Dateien und lädt sie selbst hoch; es gibt keine Programmierwerkzeuge auf ihrer Seite und kein App-Store-Konto.

## Entscheidung

Reine Progressive Web App mit Angular und TypeScript, bereitgestellt über GitHub Pages (öffentliches Repository), installiert über Chrome auf Android. Kein APK, kein Capacitor.

## Folgen

Kein natives Widget (Ersatz: Schnellzugriff „Neue Buchung“), Entsperren per Passkey statt BiometricPrompt, keine Push-Benachrichtigungen. Daten liegen in IndexedDB (Browserdaten); Schutz durch Backup und Sicherungsdatei (ADR 0008).
