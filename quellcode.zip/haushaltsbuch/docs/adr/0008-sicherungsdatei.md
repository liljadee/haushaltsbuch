# ADR 0008: Sicherungsdatei im Handyspeicher

- Datum: 19.11.2026
- Status: akzeptiert

## Kontext

Browserdaten können gelöscht werden; die App kann das weder verhindern noch eine Rückfrage einbauen.

## Entscheidung

Zusätzlich zum Backup schreibt die App auf Wunsch nach jeder Änderung eine verschlüsselte Kopie (Backup-Format) in eine Datei im normalen Handyspeicher (File System Access API). Erinnerung zum Verbinden nur bei offenen Änderungen und Datei älter als einen Tag, weil Android die Schreiberlaubnis nicht über Neustarts behält.

## Folgen

Wiederherstellung über „Backup einspielen“; schützt vor gelöschten Browserdaten, nicht vor Geräteverlust (dafür das Backup außerhalb des Handys).
