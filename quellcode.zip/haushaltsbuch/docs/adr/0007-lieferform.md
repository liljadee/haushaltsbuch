# ADR 0007: Lieferform: eine ZIP mit einem Ordner ohne Unterordner

- Datum: 17.11.2026
- Status: akzeptiert; Lazy Loading geprüft und am 19.11.2026 zurückgestellt

## Kontext

Die Nutzerin lädt die Dateien über die GitHub-Weboberfläche hoch; Unterordner und wechselnde Dateinamen machen das fehleranfällig.

## Entscheidung

Eine ZIP mit einem Ordner: index.html, app.js, sw.js, manifest.webmanifest, icon.png, neu.png, quellcode.zip (mit Änderungsprotokoll und Prüfbericht). Vor jeder Lieferung laufen Formatierung, Lint, alle Tests, Sicherheitsprüfung und Build; ausgeliefert wird nur bei „bestanden“ und passender Versionsnummer.

## Folgen

Route-Level Lazy Loading und @defer erzeugen zusätzliche Dateien mit wechselnden Namen. Messung mit v0.8.1: Startteil 606 statt 914 kB roh (152 statt 204 kB übertragen), dafür 23 statt 6 Programmdateien; weil der Service Worker für den Offlinebetrieb ohnehin alles vorab lädt, wäre nur der Start etwas schneller. Entscheidung der Nutzerin vom 19.11.2026: Lieferform bleibt. Neu entschieden wird, sobald die übertragene Größe der app.js die Warnschwelle von 250 kB erreicht; der Prüfbericht weist dann darauf hin.
