# ADR 0007: Lieferform: eine ZIP mit einem Ordner ohne Unterordner

- Datum: 17.11.2026
- Status: akzeptiert; Erweiterung um Lazy Loading in Prüfung

## Kontext

Die Nutzerin lädt die Dateien über die GitHub-Weboberfläche hoch; Unterordner und wechselnde Dateinamen machen das fehleranfällig.

## Entscheidung

Eine ZIP mit einem Ordner: index.html, app.js, sw.js, manifest.webmanifest, icon.png, neu.png, quellcode.zip (mit Änderungsprotokoll und Prüfbericht). Vor jeder Lieferung laufen Formatierung, Lint, alle Tests, Sicherheitsprüfung und Build; ausgeliefert wird nur bei „bestanden“ und passender Versionsnummer.

## Folgen

Route-Level Lazy Loading und @defer erzeugen zusätzliche Dateien mit wechselnden Namen; sie sind deshalb nur nach Anpassung dieser Lieferform möglich (Entscheidung der Nutzerin ausstehend).
