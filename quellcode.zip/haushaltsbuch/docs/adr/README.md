# Entscheidungsnotizen (ADR)

Kurze Notizen zu wichtigen Architekturentscheidungen: Kontext, Entscheidung, Folgen.

- [ADR 0001: PWA statt nativer Android-App](0001-pwa-statt-nativer-app.md) – akzeptiert
- [ADR 0002: Eigener Service Worker statt Angular Service Worker](0002-eigener-service-worker.md) – akzeptiert (Abweichung vom Lastenheft V2.1, Abschnitt 2)
- [ADR 0003: Eigener Excel-Leser statt SheetJS](0003-eigener-excel-leser.md) – akzeptiert (Abweichung vom Lastenheft V2.1, Abschnitt 24.1)
- [ADR 0004: Angular Material als Komponentenbibliothek](0004-angular-material.md) – akzeptiert (bestätigt nach Versuch ohne Material in v0.8.0)
- [ADR 0005: Geld in Cent, Datum ohne Uhrzeit](0005-geld-und-datum.md) – akzeptiert
- [ADR 0006: Verschlüsselung und Schlüssel](0006-verschluesselung-und-schluessel.md) – akzeptiert
- [ADR 0007: Lieferform: eine ZIP mit einem Ordner ohne Unterordner](0007-lieferform.md) – akzeptiert; Lazy Loading geprüft und am 19.11.2026 zurückgestellt
- [ADR 0008: Sicherungsdatei im Handyspeicher](0008-sicherungsdatei.md) – akzeptiert
- [ADR 0009: Schichten, Signals und Qualitätsregeln](0009-schichten-und-qualitaet.md) – akzeptiert
- [ADR 0010: Ablösung durch den Bausparvertrag als Korrekturbuchung](0010-abloesung-durch-bausparvertrag.md) – akzeptiert
