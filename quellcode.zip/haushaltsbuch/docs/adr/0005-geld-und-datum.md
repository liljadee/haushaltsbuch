# ADR 0005: Geld in Cent, Datum ohne Uhrzeit

- Datum: 16.11.2026
- Status: akzeptiert

## Kontext

Rundungsfehler bei Kommazahlen und Zeitzonenfehler an Monatsgrenzen müssen ausgeschlossen sein.

## Entscheidung

Geld als ganze Cent (Typ Cents) mit getesteten Funktionen (formatEuro, parseEuro); Zinssätze in Tausendstel-Prozent; Datum als Text JJJJ-MM-TT (Typ LocalDate) mit getesteten Funktionen; Bankarbeitstage Bayern inklusive 24.12. und 31.12.

## Folgen

Statt eigener Klassen werden Typen mit reinen Funktionen verwendet: gleichwertig, einfacher zu speichern und zu testen.
