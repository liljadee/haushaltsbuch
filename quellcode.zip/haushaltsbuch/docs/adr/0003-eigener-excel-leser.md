# ADR 0003: Eigener Excel-Leser statt SheetJS

- Datum: 17.11.2026
- Status: akzeptiert (Abweichung vom Lastenheft V2.1, Abschnitt 24.1)

## Kontext

Das npm-Paket von SheetJS ist veraltet und hat bekannte Sicherheitslücken; ExcelJS wird nicht mehr gepflegt. Für den Import der alten App reicht das Lesen einfacher XLSX-Tabellen.

## Entscheidung

Eigener, schlanker XLSX-Leser (ZIP und XML mit Browser-Bordmitteln, DecompressionStream), mit Tests.

## Folgen

Keine Fremdbibliothek für Excel; der spätere Export wird ebenso ohne schwere Bibliothek gebaut.
