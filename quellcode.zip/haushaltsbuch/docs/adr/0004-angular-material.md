# ADR 0004: Angular Material als Komponentenbibliothek

- Datum: 19.11.2026
- Status: akzeptiert (bestätigt nach Versuch ohne Material in v0.8.0)

## Kontext

In v0.8.0 wurde Material probeweise durch eigene Bausteine ersetzt (−27 % Dateigröße). Abgewogen gegen Lastenheft-Vorgabe, geprüfte Barrierefreiheit, bekannte Standards für andere Entwickler und spätere Erweiterungen (Dialoge, Menüs, Datumsauswahl) ist der Größenvorteil in der Praxis unerheblich (übertragen rund 204 kB, einmal je Update, danach offline).

## Entscheidung

Angular Material bleibt (Material 3, grünes Thema). Eingebunden werden nur einzelne Standalone-Bausteine je Komponente (MatButton, MatFormField, MatInput, MatCheckbox, MatButtonToggle …), keine ganzen NgModules, damit das Tree-Shaking greift.

## Folgen

Material und CDK werden mit jeder Angular-Hauptversion mit aktualisiert; Version exakt gleich der Angular-Version.
