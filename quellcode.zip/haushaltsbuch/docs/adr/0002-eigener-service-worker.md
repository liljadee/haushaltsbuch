# ADR 0002: Eigener Service Worker statt Angular Service Worker

- Datum: 17.11.2026
- Status: akzeptiert (Abweichung vom Lastenheft V2.1, Abschnitt 2)

## Kontext

Die Lieferung soll aus wenigen Dateien in einem Ordner ohne Unterordner bestehen; Updates sollen erst nach Bestätigung aktiv werden.

## Entscheidung

Eigener, kleiner Service Worker (sw.js): legt alle Programmdateien beim Installieren in den Zwischenspeicher (entspricht „prefetch“), bedient die App offline und aktiviert eine neue Version erst nach „Jetzt aktualisieren“.

## Folgen

Alle Bereiche sind sofort offline verfügbar; ein „lazy“ Nachladen einzelner Bereiche (installMode lazy) ist bewusst nicht vorgesehen, weil die App vollständig offline funktionieren muss. Offlinebetrieb und Update sind per Ende-zu-Ende-Test geprüft.
