# Testkatalog nach Lastenheft 22

Wird bei jeder Prüfung neu erzeugt (scripts/testkatalog.py). Status: auto = automatisch geprüft; angepasst = Kriterium an eine Entscheidung angepasst, automatisch geprüft; manuell = im Praxistest auf dem Handy; teilweise; offen.

Zusammenfassung: 3 angepasst, 34 auto, 1 manuell, 2 teilweise

| Kennung | Bereich | Test | Sollwert | Status | Nachweis | Hinweis |
| --- | --- | --- | --- | --- | --- | --- |
| AK-01 | Entsperrung | Fingerabdruck | Daten nach erfolgreicher Prüfung lesbar | auto | E2E „Gelernte Regeln gelten auch nach Sperren und Entsperren“<br>E2E „Offline: entsperren, Daten vollständig“ |  |
| AK-02 | Entsperrung | Geräte-PIN als Rückfall | funktioniert | manuell | – | Am Handy: Passkey mit Geräte-PIN statt Finger bestätigen. |
| AK-03 | Wiederherstellung | Passkey gelöscht, Wiederherstellungsschlüssel eingegeben | Daten vollständig lesbar | auto | E2E „Neuer Wiederherstellungsschlüssel: alter passt nicht mehr, neuer öffnet die App“<br>Unit „crypto.spec.ts: lässt sich mit dem Wiederherstellungsschlüssel und dem Passwort öffnen“ |  |
| AK-04 | Sperre | 1 Minute im Hintergrund | erneute Authentifizierung nötig | auto | E2E „Sperre: nach 1 Minute im Hintergrund“ |  |
| AK-05 | Verschlüsselung | Rohdaten im Browserspeicher prüfen | keine lesbaren Beträge oder Texte | auto | E2E „Verschlüsselung: Rohdaten im Browserspeicher“<br>E2E „Backup verschlüsselt; restore.py öffnet Konten und Buchungen“ |  |
| AK-06 | Vorschau | Wechsel in den Hintergrund | Finanzdaten ausgeblendet | auto | E2E „Vorschau: beim Wechsel in den Hintergrund“ |  |
| AK-07 | Offline | Flugmodus nach Installation | alle Funktionen außer Updates verfügbar | auto | E2E „Offline: entsperren, Daten vollständig“ | Zusätzlich im Praxistest einmal im Flugmodus öffnen. |
| AK-08 | E-Mail-Import | Beispiel-E-Mail mit 2 Umsätzen | 2 Buchungen; Saldo nicht als Buchung | auto | Unit „kontowecker-parser.spec.ts: Beispiel der Nutzerin vom 17.11.2026: zwei Umsätze“ |  |
| AK-09 | Saldenabgleich | E-Mail-Saldo weicht ab | Hinweis mit Differenzbetrag | auto | E2E „Import: Kontostand 1.158,12 € laut Bank, Hinweis auf der Übersicht“ |  |
| AK-10 | Doppelte E-Mail | gleiche E-Mail zweimal eingefügt | Warnung, keine doppelten Buchungen | auto | E2E „Gleiche E-Mail nochmal: erkannt, Buchungen abgewählt“ |  |
| AK-11 | Buchungsdatum | vor und nach dem Speichern ändern | korrekt gespeichert; Importdatum unverändert | auto | Unit „import-date.spec.ts: Importdatum wird beim Erfassen gesetzt“ | Importdatum seit v0.8.8. |
| AK-12 | Zuordnungsmonat | Gehalt am 29. | zählt zum Folgemonat | auto | Unit „statistics.spec.ts: Gehalt ab dem 25. zählt zum Folgemonat“ |  |
| AK-13 | Import | Testdateien (Altdaten-XLSX) | alle Zeilen korrekt; Saldo stimmt | angepasst | E2E „Altdaten: Datei gelesen, Konten und Kategorien zugeordnet“<br>E2E „Altdaten: Kontostände bleiben unverändert“ | Bank-CSV-Import entfällt (Entscheidung vom 19.11.2026). |
| AK-14 | Dubletten | gleicher Umsatz mit anderem Datum und gekürztem Text | als Dublette erkannt | angepasst | E2E „Doppelte Buchung von Hand wird erkannt (abgekürzter Bankentext)“<br>E2E „Altdaten: zweiter Import bringt nichts doppelt“ | Ohne CSV-Import: E-Mail, Altdaten und Eingabe von Hand. |
| AK-15 | Umbuchung | 500 € Giro → Tagesgeld | beide Konten korrekt; nichts auf Ebene 1 | auto | E2E „Umbuchung Girokonto → Tagesgeld: beide Kontostände“<br>Unit „statistics.spec.ts: Säulen: Fixkosten, Konsum, Sparen; Umbuchungen“ |  |
| AK-16 | Kontenumbenennung | Konto umbenennen | Historie erhalten | auto | Unit „import-date.spec.ts: Konto umbenennen“ |  |
| AK-17 | Regeln | bestätigte Zuordnung | beim nächsten Import vorgeschlagen | auto | E2E „Regel aus dem Import schlägt die Kategorie beim Tippen vor“<br>Unit „rules.spec.ts: lernt aus einer Zuordnung und schlägt sie beim nächsten Mal sicher vor“ |  |
| AK-18 | Jahresausgabe | Kfz-Versicherung 600 € | voll im Fälligkeitsmonat, nicht zusätzlich im Durchschnitt | auto | E2E „Rücklagen: Jahreszahlungs-Topf mit Rate 50 €“<br>Unit „forecast.spec.ts: schätzt variable Ausgaben ohne die wiederkehrenden Zahlungen“<br>Unit „forecast.spec.ts: plant feste Termine ein“ |  |
| AK-19 | Variables Einkommen | 6 Testmonate | Ansatz = zweitniedrigster Wert | auto | E2E „Auch ein schwankendes Gehalt taktet die Prognose“<br>Unit „recurring.spec.ts: schwankendes Gehalt: vorsichtig der zweitniedrigste“ |  |
| AK-20 | Sonderzahlung | vermutetes Weihnachtsgeld | nicht in der Prognose bis zur Bestätigung | auto | E2E „Sonderzahlungen: erkannt, erst nach Bestätigung eingeplant“<br>Unit „special-income.spec.ts: einmaliger Mehrbetrag im Gehalt wird nicht vorgeschlagen“ | Unbestätigt 0 € (Lastenheft 15.3). |
| AK-21 | Liquiditätsprognose | Testzyklus | Kontostand, Tiefpunkt und Datum wie Sollwert | auto | E2E „Prognose: Leitaussage bis zum nächsten Gehalt“<br>Unit „forecast.spec.ts: Kontoverlauf mit Tiefpunkt“ |  |
| AK-22 | Sicherheitspuffer | Testzyklus | an keinem Tag unter 200 € | auto | E2E „Puffer in den Einstellungen wirkt auf die Empfehlung“<br>Unit „advice.spec.ts: Fehlbetrag zum Puffer“ |  |
| AK-23 | Umbuchungsempfehlung | Fehlbetrag 600 € | Empfehlung mit Datum „umbuchen spätestens am“ | auto | E2E „Abgleich: Umbuchung vom Tagesgeld empfohlen, mit Betrag und Termin“ |  |
| AK-24 | Ein-Klick-Umbuchung | „Jetzt umgebucht“ | verknüpfte Buchungen, Status „bestätigt“, Neuberechnung | auto | E2E „„Jetzt umgebucht“: bestätigte Umbuchung“ |  |
| AK-25 | Doppelbuchungsschutz | bestätigte Umbuchung später importiert | zugeordnet; keine zweite Umbuchung | auto | E2E „Kontowecker: Bankbuchung wird der bestätigten Umbuchung zugeordnet“<br>Unit „import-preview.spec.ts: ordnet den Umsatz der bestätigten Umbuchung zu“ |  |
| AK-26 | Kreditrate | Rate per Import | korrekt in Zins und Tilgung aufgeteilt | auto | E2E „Kredit angelegt: Vorschau, Restschuld, Rate erkannt und rückwirkend in Zinsen und Tilgung aufgeteilt“<br>Unit „loan.spec.ts: teilt frühere Raten rückwärts vom Stand laut Bank auf“ |  |
| AK-27 | Tilgungsplan | Vergleich mit dem Plan der Bank | Abweichung höchstens 1 € pro Jahr | auto | Unit „loan.spec.ts: Tilgungsplan wie bei der Bank“ | Vergleich mit der Annuitätenformel, wie Banken rechnen. |
| AK-28 | Kreditalarm | Zinsbindungsende in 12 Monaten | Alarm mit Restschuld nach Szenario A und B | auto | Unit „alarms.spec.ts: Zinsbindungsende ab 12 Monate vorher mit Restschuld“<br>Unit „alarms.spec.ts: nennt die Restschuld nach Szenario A und nach Szenario B“ |  |
| AK-29 | Ratenkredit | vertraglicher Plan endet nicht bei 0 € | Eingabe wird beanstandet | auto | Unit „loan.spec.ts: Ratenkredit, dessen Plan zum Laufzeitende nicht bei 0 € endet“ |  |
| AK-30 | Sondertilgung | zwei Kredite mit 4 % und 2 % | Empfehlung zuerst für 4 %, Grenzen eingehalten | auto | E2E „Sondertilgungsplan: Budget ohne Notreserve“<br>Unit „special-plan.spec.ts: höchster Zins zuerst“<br>Unit „special-plan.spec.ts: Höchstbetrag je Jahr“ |  |
| AK-31 | Rentabilität | Kreditzins unter Tagesgeldzins nach Steuern | Hinweis „lohnt sich rechnerisch nicht“ | auto | E2E „Rentabilität: Hinweis „lohnt sich rechnerisch nicht““<br>Unit „special-plan.spec.ts: Kreditzins unter Tagesgeldzins nach Steuern“ | Tagesgeldzins und Steuersatz unter Einstellungen → Kredite. |
| AK-32 | Excel-Export | Monats- und Jahresübersicht | Summen stimmen mit der App überein | auto | E2E „Export Gesamter Finanzbestand als Excel“<br>Unit „export.spec.ts: Monatsübersicht, Kredite mit Tilgungsplan“<br>Unit „export.spec.ts: Jahresübersicht mit Vergleich zum Vorjahr“ |  |
| AK-33 | Backup | Wiederherstellung auf zweitem Gerät | alle Daten und Einstellungen vollständig | auto | E2E „Vollständiges Backup:“<br>E2E „Backup in der laufenden App einspielen“ |  |
| AK-34 | Backup-Erinnerung | Zeitraum ohne Backup | Hinweis erscheint | angepasst | E2E „Nach dem Backup verschwindet die Backup-Erinnerung“<br>E2E „Backup-Erinnerung nach dem Import“ | Zeitraum wählbar (wöchentlich, 2 Wochen, monatlich) statt fest 30 Tage. |
| AK-35 | Schnellzugriff | Shortcut antippen | Buchungserfassung direkt geöffnet | auto | E2E „Schnellzugriff „Neue Buchung“ nach dem Entsperren“ | Zusätzlich im Praxistest am echten Startbildschirm. |
| AK-36 | Schnellzugriff gesperrt | Shortcut bei gesperrter App | erst Authentifizierung, dann Erfassung | auto | E2E „Schnellzugriff „Neue Buchung“ nach dem Entsperren“ |  |
| AK-37 | Update | neue Version einspielen | Daten erhalten; Backup vorher erstellt | teilweise | E2E „Update v0.1 → v0.2: Fingerabdruck gilt weiter“ | Daten erhalten; Backup vor dem Update seit v0.8.8 (Sicherungsdatei automatisch, sonst Nachfrage); automatischer Test des Update-Ablaufs folgt. |
| AK-38 | Leistung | 10 Jahre Testdaten, ca. 30.000 Buchungen | Entsperren und Dashboard unter 3 Sekunden | teilweise | E2E „Leistung: zehn Jahre Daten“ | Test mit über 10.000 Buchungen; Erhöhung auf 30.000 folgt. |
| AK-39 | Ausreißer | erhöhtes Gehalt im Dezember zweier Vorjahre | nicht im Normalwert; als Sonderzahlung vorgeschlagen | auto | Unit „special-income.spec.ts: erhöhtes Gehalt im Dezember zweier Vorjahre“<br>Unit „special-income.spec.ts: Normalwert ohne Ausreißer“ |  |
| AK-40 | Bestätigte Sonderzahlung | Folgejahr | im selben Monat in Höhe des Vorjahres eingeplant | auto | Unit „special-income.spec.ts: bestätigte Sonderzahlung“ |  |
