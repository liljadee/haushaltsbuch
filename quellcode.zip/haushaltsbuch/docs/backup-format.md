# Backup-Format `.hhb` (Version 1)

Eine `.hhb`-Datei ist eine JSON-Datei mit unverschlüsseltem Kopf und verschlüsseltem Inhalt. Sie lässt sich mit `docs/restore.py` auch ohne die App öffnen.

```json
{
  "format": "haushaltsbuch-backup",
  "formatVersion": 1,
  "appVersion": "0.1.0",
  "createdAt": "2026-11-16T12:00:00.000Z",
  "keys": {
    "recovery": { "kdf": "HKDF-SHA-256", "info": "haushaltsbuch/v1/recovery-kek", "salt": "<Base64, 16 Byte>", "wrap": "AES-KW", "wrappedKey": "<Base64, 40 Byte>" },
    "password": { "kdf": "PBKDF2-HMAC-SHA-256", "iterations": 600000, "salt": "<Base64, 16 Byte>", "wrap": "AES-KW", "wrappedKey": "<Base64, 40 Byte>" }
  },
  "payload": { "cipher": "AES-256-GCM", "compression": "gzip", "encoding": "base64", "aad": "haushaltsbuch-backup|1", "iv": "<Base64, 12 Byte>", "data": "<Base64>" }
}
```

## Schlüssel

- **Datenschlüssel:** 256 Bit AES, zufällig bei der Einrichtung erzeugt. Er verschlüsselt alle Datensätze in der App und den Inhalt des Backups.
- **Wiederherstellungsschlüssel:** 30 Zeichen Crockford-Base32 (`0123456789ABCDEFGHJKMNPQRSTVWXYZ`), angezeigt in sechs Gruppen zu fünf Zeichen. Eingaben werden normalisiert: Großbuchstaben, ohne Leerzeichen und Bindestriche, `O` → `0`, `I`/`L` → `1`.
- **Verpackungsschlüssel aus dem Wiederherstellungsschlüssel:** HKDF-SHA-256, Eingabe = die 30 normalisierten Zeichen als ASCII, Salz = `keys.recovery.salt`, Info = `haushaltsbuch/v1/recovery-kek`, 32 Byte.
- **Verpackungsschlüssel aus dem App-Passwort (optional):** PBKDF2-HMAC-SHA-256, Passwort in Unicode-NFC als UTF-8, Salz und Durchläufe aus `keys.password`, 32 Byte.
- **Verpackt** ist der Datenschlüssel nach RFC 3394 (AES-KW); `wrappedKey` ist 40 Byte lang.

## Inhalt

1. `payload.data` Base64-dekodieren.
2. Mit AES-256-GCM entschlüsseln: Schlüssel = Datenschlüssel, IV = `payload.iv`, zusätzliche Daten = `payload.aad` als UTF-8. Der 16-Byte-Authentifizierungstag hängt am Ende.
3. Ergebnis mit gzip entpacken.
4. Ergebnis ist JSON: `{ "stores": { "<Speicher>": [ { "key": "...", "value": ... } ] } }`.

In Version 0.1 gibt es nur den Speicher `testdata` mit dem Schlüssel `eintraege`: eine Liste von `{ id, date (JJJJ-MM-TT), amount (Cent, Ausgaben negativ), text }`.

## In der App gespeicherte Datensätze

In IndexedDB (`haushaltsbuch`, Version 1) liegt im Speicher `meta` unter `vault` der unverschlüsselte Kopf: Formatversion, die verpackten Datenschlüssel (Passkey, Wiederherstellung, optional Passwort), Passkey-ID und Salze. Alle anderen Speicher enthalten nur `{ key, v, iv, ct }`: AES-256-GCM über das JSON des Inhalts, zusätzliche Daten `"<Speichername>|<key>"`, damit ein Datensatz nicht unbemerkt an eine andere Stelle kopiert werden kann.

Der Passkey-Weg: Das PRF-Ergebnis des Passkeys (32 Byte, Salz `prfSalt`) → HKDF-SHA-256 mit Salz `hkdfSalt` und Info `haushaltsbuch/v1/passkey-kek` → AES-KW.
