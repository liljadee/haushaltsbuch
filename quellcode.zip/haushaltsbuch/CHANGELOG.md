# Änderungen

## v0.1.0 – Machbarkeit (17.11.2026)

Erste installierbare Version. Sie prüft, ob alles Wichtige auf deinem Handy funktioniert; echte Buchungen kommen mit v0.2.

- Installierbare App (PWA) mit Symbol, läuft offline nach dem ersten Öffnen.
- Einrichtung in vier Schritten: Fingerabdruck (Passkey mit PRF), Wiederherstellungsschlüssel (30 Zeichen) anzeigen und Abschreiben kontrollieren, freiwilliges App-Passwort.
- Verschlüsselung nach Bauplan 5: AES-256-GCM für alle Daten, Datenschlüssel dreifach verpackt (Passkey, Wiederherstellungsschlüssel, App-Passwort mit PBKDF2 und 600.000 Durchläufen).
- Entsperren per Fingerabdruck, App-Passwort oder Wiederherstellungsschlüssel; danach Fingerabdruck neu einrichten.
- Sperre: Inhalt wird beim Verlassen sofort verdeckt, nach über einer Minute gesperrt; Sperren-Knopf oben rechts.
- Schnellzugriff „Neue Buchung“ (App-Symbol lange drücken), führt nach dem Entsperren direkt zur Erfassung.
- Verschlüsselte Testbuchungen erfassen und löschen.
- Backup als verschlüsselte .hhb-Datei herunterladen oder teilen; auf einem anderen Handy einspielen. docs/restore.py öffnet ein Backup auch ohne App.
- Machbarkeitsprüfung mit Selbsttest und Checkliste; das Ergebnis lässt sich kopieren und weitergeben.
- Update-Hinweis „Neue Version verfügbar“; eine neue Version wird erst nach Bestätigung aktiv.
- Auslieferung als sieben Dateien: `index.html` und `app.js`, dazu `sw.js`, Manifest, zwei Symbole und `quellcode.zip`. Der Quellcode ist in Klassen und Komponenten getrennt; CHANGELOG, Prüfbericht und Backup-Werkzeug stecken in `quellcode.zip`.
