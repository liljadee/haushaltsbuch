# Änderungen

## v0.7.4 – Sondertilgungsplan (19.11.2026)

- Kredite → „Sondertilgungsplan“: Budget aus der Sondertilgungsrücklage (Tagesgeld mit Zweck „Sondertilgungsrücklage“, ohne Notreserve) plus monatlichem Zufluss (Dauerauftrag bzw. Durchschnitt der Eingänge der letzten 12 Monate; änderbar).
- Sondertilgungsrecht je Kredit: Rhythmus, Höchstbetrag als Betrag oder Prozent des Darlehensbetrags, Mindestbetrag, Gebühr. Zahlungen zum Ende des erlaubten Zeitraums (jährlich: Dezember; halbjährlich, jederzeit, monatlich: Juni und Dezember; vierteljährlich: Quartalsende).
- Drei Reihenfolgen (Zinsbindungsende zuerst, höchster Zins zuerst, kleinste Restschuld zuerst); empfohlen wird die mit der frühesten Schuldenfreiheit, wählbar. Das Budget wartet beim vordersten Kredit, bis dort eine Sondertilgung erlaubt ist.
- Ergebnis: schuldenfrei mit und ohne Sondertilgungen, Zinsersparnis, nächster Schritt, Sondertilgungen je Jahr und Kredit, Restschuld zum Zinsbindungsende mit und ohne; Tipp zu frei werdenden Raten.

## v0.7.3 – Bausparvertrag, Schutz vor doppelten Umbuchungen (19.11.2026)

- Kredite → „Bausparvertrag verknüpfen“: Konto des Bausparvertrags, abgelöstes Darlehen, Bauart über die Frage „Was zahlt ihr jeden Monat auf das Darlehen?“ (Nur Zinsen / Zinsen und Tilgung / weiß ich nicht, mit Vorschlag aus der Rate), Bausparsumme, Sparrate (erkannter Dauerauftrag als Vorschlag), Guthabenzins, Mindestsparguthaben, voraussichtliche Zuteilung, Zins und Rate des Bauspardarlehens.
- Prognose: Ansparphase mit jährlicher Zinsgutschrift, Ablösung (Nur Zinsen: zur Zuteilung; Zinsen und Tilgung: zum Zinsbindungsende, frühestens zur Zuteilung), Bauspardarlehen bis zur Tilgung, Lücke für eine Anschlussfinanzierung.
- Erklärung in Klartext aus festen Textbausteinen; Abgleich „Passt das zusammen?“ mit Ampeln für Zeitpunkt, Betrag und Zuteilungsreife; Jahresübersicht mit Guthaben, Restschuld und Nettoschuld.
- „Schuldenfrei“ rechnet bei verknüpften Darlehen mit dem Bauspardarlehen; Hinweis auf der Übersicht bis 12 Monate vor der Ablösung, wenn die Bauart offen ist, eine Lücke bleibt oder ein Punkt nicht passt.
- Umbuchungsformular warnt vor doppelter Erfassung (gleiche Konten, gleicher Betrag, höchstens 5 Tage Abstand).
- Rechenweg Sparen markiert mögliche doppelte Umbuchungen.
- Datenbank Version 6 (Speicher für Bausparverträge); Teil von Backup und Sicherungsdatei.

## v0.7.2 – Rechenweg für Sparen (19.11.2026)

- Statistik: neue Karte „Sparen: Rechenweg“. Sie zeigt jede Buchung auf Sparkonten im Zeitraum mit dem Vermerk, ob und mit welchem Betrag sie zählt, und wenn nicht, warum nicht (z. B. „zählt im Oktober“, „steckt in der Gruppe …“). Die Summe der gezählten Zeilen ist immer die Kennzahl „Sparen“.
- Prüfung der Umbuchungen: fehlende Gegenbuchung, gleiches Vorzeichen auf beiden Seiten, abweichende Beträge oder dasselbe Konto werden benannt.
- Verdachtsfälle: Ausgaben oder Einnahmen, die nach einer Umbuchung aussehen („Spar“, „Tagesgeld“, „Übertrag“, Name eines Sparkontos), und Umbuchungen auf Konten, die als Girokonto angelegt sind; mit Link zur Buchung.

## v0.7.1 – Sammelabbuchungen, ruhigere Sicherungsdatei (19.11.2026)

- Sammelabbuchungen (z. B. Debeka, Gemeinde): Eine von Hand aufgeteilte Abbuchung wird zur Aufteilungsvorlage des Empfängers. Neue Abbuchungen werden in die Kombination der gelernten Teile zerlegt, die genau passt – auch wenn nur ein Teil der Beiträge abgebucht wird. Sind Beiträge gestiegen (bis 20 %), wird die Differenz anteilig verteilt und die Buchung unter „Zu prüfen“ vorgelegt; reichen die Teile nicht, bleibt ein Rest zum Zuordnen. Korrigierte Beträge lernt die App.
- Nach dem Lernen bietet die App an, frühere, nicht aufgeteilte Abbuchungen desselben Empfängers rückwirkend aufzuteilen (auch mit damals niedrigeren Beiträgen).
- Buchungsformular: „Wie gelernt aufteilen“, sobald Empfänger und Betrag zu einer Vorlage passen.
- Kontowecker-Import teilt passende Abbuchungen automatisch auf.
- Einstellungen: Liste der Aufteilungsvorlagen mit Löschen.
- Sicherungsdatei: Der Hinweis „verbinden“ erscheint nur noch, wenn seit dem letzten Schreiben Änderungen offen sind und die Datei älter als einen Tag ist (Android merkt sich die Schreiberlaubnis nicht über einen Neustart).

## v0.7.0 – Kredite (19.11.2026)

- Neuer Reiter „Kredite“: Kredite anlegen und bearbeiten (Grunddaten; Stand und Konditionen; Laufzeit; Sondertilgung), Kreditarten Annuitätendarlehen, Ratenkredit, Förderkredit, 0-%-Finanzierung, Kredit mit Schlussrate, Vorausdarlehen. Übliche Sondertilgungsregeln je Art werden vorgeschlagen.
- Prüfung beim Speichern: Deckt die Rate die Zinsen nicht (außer beim Vorausdarlehen), speichert die App nicht und erklärt warum; Vorschau „abbezahlt voraussichtlich im …“ mit Anschlusszins nach der Zinsbindung (Standard 4 %).
- Tilgungsplan je Jahr; Restschuld heute und zum Zinsbindungsende; „schuldenfrei am“; bisher gezahlte und künftige Zinsen; Diagramm der Gesamtschuld.
- Raten werden am Buchungstext erkannt (Vorschläge aus den „Kreditrate …“-Buchungen) und in Zinsen und Tilgung aufgeteilt, auch rückwirkend vom Stand laut Bank aus. Sondertilgungen („Sondertilgung …“) senken die Restschuld.
- „Stand laut Bank“: Restschuld zu einem Stichtag eintragen; die App zeigt die Abweichung und rechnet mit dem Bankwert weiter.
- Die Rate wird beim Speichern als wiederkehrende Zahlung eingeplant (eine schon eingeplante Rate wird übernommen, nicht verdoppelt).
- Statistik: Kreditraten mit Vertrag erscheinen als „Name: Zinsen“ und „Name: Tilgung“, auch in eigenen Gruppen.
- Übersicht: Restschulden der Kredite und Vermögen netto unter den Konten.
- Abbezahlt markieren (mit Monat der letzten Rate), wieder aktivieren; löschen nur ohne zugeordnete Buchungen.
- Datenbank Version 5 (Speicher für Kredite); Kredite sind Teil von Backup und Sicherungsdatei.

## v0.6.8 – Dauerauftrag als regelmäßige Umbuchung (19.11.2026)

- Rücklagen: Ist kein Dauerauftrag aufs Topfkonto bekannt, lässt er sich direkt eintragen (Betrag, vorgeschlagen die Summe der Monatsraten, und Tag). Anzeige „(eingetragen)“ bzw. „(erkannt)“.
- Buchungen → Wiederkehrend → „Regelmäßige Zahlung anlegen“: neue Art „Umbuchung“ mit „Von Konto“ und „Auf Konto“.
- Regelmäßige Umbuchungen erkennt die App an Konto, Zielkonto und Betrag, unabhängig vom Text der Bank; die automatische Verteilung auf die Töpfe greift ab dem ersten Eingang.

## v0.6.7 – Statistik: bestätigte Umbuchungen, Speicheranzeige (19.11.2026)

- Behoben: Die Statistik zählte nur gebuchte Umsätze. Per „Jetzt umgebucht“ bestätigte Umbuchungen (ausgeführt, von der Bank noch nicht gemeldet) fehlten; eine danach gebuchte Rückbuchung minderte das Sparen trotzdem. Jetzt zählen bestätigte Umbuchungen mit und sind in den Listen als „(bestätigt)“ gekennzeichnet; wird die Bankbuchung zugeordnet, bleibt es dieselbe Buchung.
- Statistik: Kennzahl „Vermögensaufbau“ vorerst ausgeblendet (kommt mit dem Thema Investitionen).
- Einstellungen → Gerät: belegter Speicher mit Aufteilung in App-Dateien und verschlüsselte Daten.

## v0.6.6 – Wiederkehrende Zahlungen zentral anlegen, Backup-Inhalt (19.11.2026)

- Buchungen → Wiederkehrend: „Regelmäßige Zahlung anlegen“ für Gehälter, Abbuchungen und Daueraufträge (Bezeichnung, Einnahme/Ausgabe, Konto, Betrag, Rhythmus, Tag, Kategorie, „Betrag schwankt“, Buchungstext zum Wiedererkennen). Der Editor bietet diese Felder auch für bestehende Posten.
- Behoben: Zwei Gehälter unter derselben Kategorie ohne Unterkategorie galten als dieselbe Zahlung; das zweite ließ sich nicht einplanen. Über die Kategorie erkennt die App jetzt nur bei gleicher Unterkategorie.
- Buchungsformular: „Trotzdem als eigene Zahlung einplanen“, falls die App eine Buchung für schon eingeplant hält.
- Backup-Karte: Liste, was im Backup steckt (alles außer dem gerätebezogenen Fingerabdruck); per Test geprüft für Gruppen, Kredit-Namen, wiederkehrende Zahlungen, Spartöpfe, Regeln, Puffer und Vorsichtsstufe.

## v0.6.5 – Sicherungsdatei im Handyspeicher (19.11.2026)

- Einstellungen → „Sicherungsdatei“ (oder Tipp auf der Übersicht): einmal einen Speicherort wählen, z. B. „Dokumente“. Die App schreibt danach nach jeder Änderung (gebündelt nach 2 Sekunden) und beim Verlassen eine verschlüsselte Kopie aller Daten in diese Datei. Sie liegt außerhalb der Browserdaten und bleibt erhalten, wenn diese gelöscht werden.
- Wiederherstellen: bei der Einrichtung „Backup einspielen“ und die Sicherungsdatei wählen; Stand bis zur letzten Änderung.
- Fragt Android nach einem Neustart erneut nach der Erlaubnis, zeigt die Übersicht „Sicherungsdatei verbinden“ (ein Tipp).
- Machbarkeitsprüfung: drei neue Punkte (Dateizugriff möglich, Sicherungsdatei eingerichtet, Schreiberlaubnis bleibt nach Neustart).

## v0.6.4 – Rücklagen: Dauerauftrag erkennen und automatisch verteilen (19.11.2026)

- Rücklagen erkennen den Dauerauftrag vom Girokonto aufs Topfkonto aus der Historie und vergleichen ihn mit den Monatsraten der Töpfe („es fehlen …“ bzw. „… bleiben frei“).
- Startverteilung (einmalig): Der freie Teil kommt in die Töpfe, bis jeder seinen Soll-Stand hat (Jahreszahlungen: Raten seit der letzten Zahlung); Beträge vorher änderbar.
- Danach verteilt die App jeden Eingang des Dauerauftrags automatisch nach den Monatsraten, genau einmal: Töpfe mit Vorrang zuerst, dann der früheste Termin; der Rest bleibt frei. Jede Verteilung ist sichtbar und lässt sich ändern. Der Knopf „Monatsraten verteilen“ entfällt.
- Neu am Topf: „Vorrang“. Neu: „Umschichten“ zwischen Töpfen und dem freien Teil.
- Umbuchungsempfehlung: Auf dem Topfkonto gilt für einen Fehlbetrag nur der freie Teil als verfügbar; Topfgeld fließt nur über die Topf-Anteile.

## v0.6.3 – Gehalt als Taktgeber der Prognose (18.11.2026)

- Den Gehaltszyklus taktet jetzt auch ein schwankendes Gehalt; Kategorie „Gehalt“ hat Vorrang, dann fester vor schwankendem Betrag, dann der größte Betrag.
- Ist kein Gehalt eingeplant, meldet die Prognosekarte das und bietet erkannte Gehälter mit „Einplanen“ an; sonst führt „Gehaltsbuchungen zeigen“ direkt zu den Buchungen, um „Regelmäßig einplanen“ anzuhaken.
- Wiederkehrend: neues Häkchen „Betrag schwankt“ im Editor.
- Links in die Buchungsliste können einen Suchbegriff mitgeben.

## v0.6.2 – Backups öfter und mit einem Tipp (18.11.2026)

- Backup-Erinnerung auf der Übersicht standardmäßig wöchentlich; in den Einstellungen wählbar: wöchentlich, alle zwei Wochen oder monatlich.
- Nach größeren Änderungen erinnert die App sofort: nach einem Import aus der alten App, nach einem Kontowecker-Import mit mindestens 10 Buchungen und nach Stapeländerungen an mindestens 10 Buchungen.
- Der Hinweis hat einen eigenen Knopf „Backup teilen“ (z. B. auf Google Drive); der Umweg über die Einstellungen entfällt.
- Ein abgebrochenes Teilen zählt nicht mehr als Backup.

## v0.6.1 – Updates zuverlässiger erkennen (18.11.2026)

- Die App sucht auch nach einer neuen Version, wenn sie aus dem Hintergrund zurückkommt (höchstens alle 10 Minuten), nicht nur beim Neustart und alle 6 Stunden. Der Service Worker wird dabei ohne Zwischenspeicher geladen.
- Einstellungen → Gerät: „Nach Updates suchen“ meldet sofort, ob es eine neue Version gibt.
- Enthält alles aus v0.6.0.

## v0.6.0 – Liquiditätsabgleich und Spartöpfe (18.11.2026)

- Übersicht → „Liquiditätsabgleich“: tiefster Stand ohne Umbuchung, Puffer, Fehlbetrag und Topf-Anteile; empfohlene Umbuchung vom Tagesgeld „Allgemeine Rücklage“ mit „spätestens am“ (Überweisungsdauer vor dem ersten Engpass). Ab 500 € über dem Puffer: Vorschlag, den Überschuss aufs Tagesgeld zu bringen.
- Quellkonto wählbar; die Notreserve wird nie angetastet, reicht das Guthaben nicht, warnt die App.
- „Jetzt umgebucht“: legt zwei verknüpfte Buchungen mit Status „bestätigt“ an; beide Kontostände und die Prognose rechnen sofort damit. Kommt die Bankbuchung per Kontowecker-E-Mail, ordnet die App sie zu und setzt sie auf „gebucht“ – eine zweite Umbuchung entsteht nie.
- Neuer Reiter „Rücklagen“: Topfkonto mit Aufteilung in Töpfe, Notreserve und freien Teil; Summe der Monatsraten für den Dauerauftrag; „Monatsraten verteilen“.
- Spartöpfe: Jahreszahlungs-Topf (zu einer eingeplanten Zahlung, Rate = Jahresbetrag ÷ 12) und Sparziel-Topf (Zielbetrag, Termin, optional Kategorie); Budgetwarnung, wenn ein Topf bis zum Termin nicht reicht. Fällige Jahreszahlungen und aus einem Topf bezahlte Ausgaben holt die Empfehlung aus dem Topf zurück; erst „Jetzt umgebucht“ macht die Töpfe kleiner.
- Buchungsformular: „Aus Spartopf bezahlt?“ mit Vorschlag nach Kategorie.
- Einstellungen → „Liquidität“: Puffer (Standard 200 €) und Überschuss-Schwelle (Standard 500 €).
- Neue Konten bekommen eine Notreserve von 10 € voreingestellt.
- Datenbank Version 4 (Speicher für Spartöpfe); deine Daten bleiben beim Update erhalten.

## v0.5.4 – Statistik in vier Säulen (18.11.2026)

- Statistik und Monatskarte: Einnahmen − Fixkosten − Konsum − Finanzierung − Sparen = Frei verfügbar; dazu Vermögensaufbau (Sparen + Finanzierung, bis v0.7 einschließlich Zinsen) mit Quote.
- Fixkosten sind laufende, notwendige Kosten ohne Freizeit (Energie, Internet & Telefon, Versicherungen, Steuern & Gebühren, Lebensmittel & Drogerie, Gesundheit, Hundefutter & Tierarzt, Tanken, Werkstatt & TÜV, Wartung & Schornsteinfeger). Konsum ist alles andere, auch Abos, Vereine, Freizeit, Urlaub und Anschaffungen. Kredite gehören zur Finanzierung, die Kategorie „Sparen“ und Umbuchungen auf Tagesgeld oder Bausparvertrag zum Sparen.
- Einstellungen → „Statistik: Säulen“: jede Ausgabenkategorie und auf Wunsch jede Unterkategorie einer Säule zuordnen; „Voreinstellung wiederherstellen“.
- Eigene Gruppen wählen ihre Säule (Fixkosten, Konsum, Finanzierung, Sparen); Gruppen mit Kredit stehen voreingestellt unter Finanzierung.
- Je Säule eine aufklappbare Liste bis zur Buchung, mit Durchschnitt je Monat und Veränderung; die Summe der Liste entspricht der Kennzahl.

## v0.5.3 – Eigene Gruppen wie Kategorien (18.11.2026)

- Eigene Gruppen (z. B. „Hausfinanzierung“) erscheinen in der Statistik wie eine Kategorie unter „Ausgaben nach Kategorie“, aufklappbar bis zu den Bestandteilen und Buchungen. Ihre Bestandteile zählen nur noch in der Gruppe, nicht mehr zusätzlich in „Kredite“ oder unter den Sparbewegungen.
- Je Gruppe wählbar: zählt als Ausgabe (Standard) oder als Sparen (dann als Zeile unter den Sparbewegungen). Die Summe der Kategorien entspricht immer den Konsumausgaben; die Monatskarte auf der Übersicht rechnet genauso.
- Die getrennte Karte „Eigene Gruppen“ entfällt.

## v0.5.2 – Regelmäßig einplanen und mitlernen (18.11.2026)

- Buchungsformular: „Regelmäßig einplanen (für die Prognose)“ mit Rhythmus, Tag und „Betrag schwankt“. Ein Gehalt ab dem 25. wird mit Termin am 1. vorgeschlagen. Ist eine Buchung schon eingeplant, zeigt das Formular das an.
- Die App lernt aus den tatsächlichen Zahlungen: Ab drei Zahlungen gilt der beobachtete Tag, bei schwankendem Betrag der vorsichtige Wert (zweitniedrigster der letzten sechs).
- Robustere Erkennung: Zahlen und Daten im Buchungstext stören nicht mehr („LOHN/GEHALT 10/2026 …“); Einnahmen mit Kategorie werden über die Kategorie erkannt; zwei Gehälter unter demselben Text werden nach Zahlungstag und Betrag getrennt.
- Links in die Buchungen (z. B. auf „Wiederkehrend“ oder „Zu prüfen“) wechseln den Reiter auch, wenn die Buchungen schon offen sind.

## v0.5.1 – Statistik: Kredite und Bausparen (18.11.2026)

- Einstellungen → „Statistik: Kredite und Bausparen“: Die App erkennt Kredite an Buchungstexten wie „Kreditrate Hauskredit“ oder „Sondertilgung Hauskredit“; für jeden Kredit lässt sich ein Anzeigename festlegen.
- Eigene Gruppen: Kredite und Sparkonten (Bausparvertrag, Tagesgeld) frei zusammenfassen und benennen, z. B. „Hausfinanzierung“ = Rate Hauskredit + Sparrate Bausparvertrag. Ein Kredit kann auch allein unter eigenem Namen stehen.
- Statistik: neue Karte „Eigene Gruppen“ mit Summe, Bestandteilen, Durchschnitt je Monat und Veränderung; „Ausgaben nach Kategorie → Kredite“ ist je Kredit aufgeschlüsselt. Konsum und Sparbewegungen bleiben getrennt gezählt.
- Import: Unterkategorien mit Schrägstrich (z. B. „Versicherungen › Leben/BU“) werden jetzt erkannt.

## v0.5.0 – Prognose (18.11.2026)

- Wiederkehrende Zahlungen: Die App erkennt sie aus deinen Buchungen (monatlich, vierteljährlich, halbjährlich, jährlich; auch Daueraufträge aufs Tagesgeld und schwankende Gehälter), du übernimmst oder lehnst sie ab. Unter Buchungen → „Wiederkehrend“ lassen sie sich bearbeiten oder pausieren.
- Prognose auf der Übersicht: Leitaussage, Kontoverlauf des Girokontos bis zum Ende des nächsten Gehaltszyklus mit Tiefpunkt, überfällige Zahlungen und der Rechenweg zum Aufklappen.
- Rechnung: feste Termine aus den wiederkehrenden Zahlungen (Einnahmen am Bankarbeitstag davor, Ausgaben danach; Feiertage in Bayern), variable Ausgaben je Kategorie aus den letzten 6 Monaten ohne Ausreißer, Saisonposten wie im Vorjahr, im laufenden Zyklus nur noch der Rest.
- Vorsichtsstufe in den Einstellungen: ausgewogen (Mittelwert) oder vorsichtig (75-%-Quantil).
- Verträge: Laufzeit, Kündigungsfrist und Verlängerung am Posten; Hinweis 45 Tage vor dem letzten Kündigungstag.
- Preisalarm ab 0,50 € und 1 % gegenüber der vorigen Zahlung, bis „Zur Kenntnis genommen“; verbrauchsabhängige Zahlungen (Strom, Wasser, Holz oder per Schalter) sind ausgenommen.
- Kalender unter Buchungen: gebuchte und geplante Zahlungen des Girokontos je Tag.
- Datenbank Version 3 (Speicher für wiederkehrende Zahlungen); deine Daten bleiben beim Update erhalten.

## v0.4.0 – Übersicht und Statistik (17.11.2026)

- Neuer Reiter „Statistik“: Monat oder Jahr, mit Pfeilen blättern; ein laufender Zeitraum wird mit demselben Stück des Vorzeitraums verglichen.
- Kennzahlen: Haushaltseinnahmen, Konsumausgaben, Sparbewegungen, Sparquote und Überschuss; im Jahr der Durchschnitt je Monat (nur Monate mit Daten).
- Drei getrennte Ebenen (Lastenheft 13.4): Umbuchungen und Korrekturen sind nie Konsum; die Kategorie „Sparen“ und Umbuchungen auf Tagesgeld oder Bausparvertrag sind Sparbewegungen; Kontobewegungen zeigen alles je Konto.
- Ausgaben nach Kategorie, antippbar bis zu Unterkategorie und Buchung, mit Veränderungen ab 10 %; Einnahmen nach Quelle, Sparbewegungen, Querschnitt nach Bezug, größte Ausgaben je Händler.
- Jahresansicht mit Monatsbalken für Einnahmen und Konsumausgaben; antippen öffnet den Monat.
- Gehälter ab dem 25. zählen zum Folgemonat.
- Übersicht: Karte „Dieser Monat“ mit Einnahmen, Ausgaben, Sparbewegungen und Überschuss; Erinnerung, wenn das letzte Backup älter als 30 Tage ist.
- Leistung geprüft mit zehn Jahren Daten (über 11.000 Buchungen).

## v0.3.1 – Sparen und Stapelverarbeitung (17.11.2026)

- Neue Kategorie „Sparen“ (Sparkonto andere Bank, Depot & Sparplan, Für andere, z. B. Kinder) für Geld auf Konten außerhalb der App; bestehende Installationen bekommen sie beim Update dazu.
- Altdaten-Import: Eine alte Kategorie oder ein einzelner Kommentar lässt sich als „Umbuchung auf eigenes Konto“ zuordnen. Stehen in Spalte B schon unsere Kategorienamen (auch „Haushalt › Lebensmittel“), ordnet die App sie selbst zu. Neu: „Vorherigen Import ersetzen“.
- Buchungsliste: „Auswählen“ und „Alle auswählen“ (passend zu Suche und Filter), dann gemeinsam eine Kategorie zuordnen, in Umbuchungen umwandeln oder löschen. Zugeordnete Texte lernt die App als Regeln.
- Einzelne Buchung: „In Umbuchung umwandeln“ direkt im Buchungsformular.

## v0.3.0 – Daten aus der alten App (17.11.2026)

- Einstellungen → „Daten importieren“: Excel-Datei (.xlsx) der alten App mit den Blättern Ausgaben, Einnahmen und Überweisungen übernehmen. Gelesen wird mit eigenem Code, ohne fremde Bibliothek.
- Datum als MM/DD/JJJJ oder Excel-Datum, Beträge mit Punkt, Ausgaben werden negativ; Überweisungen werden zu Umbuchungspaaren.
- Konten zuordnen (Vorschlag nach Name oder Ziffern wie „Sondertilg 1250“ → *1250), alte Kategorien einmal zuordnen, bei Bedarf mit Ausnahmen nach dem Kommentar; passende gelernte Regeln greifen von selbst.
- Standardmäßig nur Buchungen vor dem Startsaldo des Kontos: Kontostände bleiben unverändert, nichts zählt doppelt. Schon vorhandene Buchungen werden erkannt.
- Vorschau mit Zahlen (übernommen, übersprungen, schon vorhanden, ohne Kategorie) und Liste unlesbarer Zeilen; die Zuordnungen merkt sich die App für den nächsten Import.

## v0.2.0 – Konten und Buchungen (17.11.2026)

Ab dieser Version erfasst du echte Daten; sie bleiben bei jedem weiteren Update erhalten. Fingerabdruck und Wiederherstellungsschlüssel aus v0.1 gelten weiter, die Testbuchungen entfallen.

- Konten anlegen und bearbeiten (Girokonto, Tagesgeld, Bausparvertrag) mit Kennung „*1234“ und Startsaldo; archivieren bei 0,00 €.
- Kontostand abgleichen: Stand laut Bank eintragen; eine Differenz bleibt als Hinweis, bis fehlende Buchungen nachgetragen sind oder eine Korrekturbuchung sie schließt.
- Buchungen von Hand: Ausgabe oder Einnahme, Kategorie und Unterkategorie, Aufteilen auf mehrere Kategorien, Notiz; Warnung bei möglichen Doppelten.
- Kategorien: der abgestimmte Startbestand; der Bezug ergibt sich aus der Unterkategorie.
- Kontowecker-Import: E-Mail einfügen, Vorschau mit Konto über die Kennung, Kategorie-Vorschlägen und Saldenabgleich („Vermutlich fehlen Buchungen über X €“); dieselbe E-Mail wird beim zweiten Mal erkannt.
- Regeln lernen aus jeder Zuordnung; gleicher Text mit verschiedenen Kategorien wird nach dem Betrag (± 10 %) unterschieden; Regeln in den Einstellungen einsehen und löschen.
- Umbuchungen zwischen eigenen Konten, von Hand oder aus der E-Mail; Bearbeiten und Löschen wirken auf beide Seiten.
- Buchungsliste mit Suche, Kontofilter und Filter „Zu prüfen“; Bearbeiten direkt an der Buchung.
- Untere Navigation (Übersicht, Buchungen) und Plus-Knopf für eine neue Buchung.

## v0.1.0 – Machbarkeit (17.11.2026)

Erste installierbare Version. Sie prüft, ob alles Wichtige auf deinem Handy funktioniert; echte Buchungen kommen mit v0.2.

- Installierbare App (PWA) mit Symbol, läuft offline nach dem ersten Öffnen.
- Einrichtung in vier Schritten: Fingerabdruck (Passkey mit PRF), Wiederherstellungsschlüssel (30 Zeichen) anzeigen und Abschreiben kontrollieren, freiwilliges App-Passwort.
- Verschlüsselung nach Bauplan 5: AES-256-GCM für alle Daten, Datenschlüssel dreifach verpackt (Passkey, Wiederherstellungsschlüssel, App-Passwort mit PBKDF2 und 600.000 Durchläufen).
- Entsperren per Fingerabdruck, App-Passwort oder Wiederherstellungsschlüssel; danach Fingerabdruck neu einrichten.
- Sperre: Inhalt wird beim Verlassen sofort verdeckt, nach über einer Minute gesperrt; Sperren-Knopf oben rechts.
- Schnellzugriff „Neue Buchung“ (App-Symbol lange drücken), führt nach dem Entsperren direkt zur Erfassung.
- Verschlüsselte Testbuchungen erfassen und löschen.
- Backup als verschlüsselte .hhb-Datei herunterladen oder teilen; auf einem anderen Handy einspielen. docs/restore.py öffnet ein Backup auch ohne App.
- Machbarkeitsprüfung mit Selbsttest und Checkliste; das Ergebnis lässt sich kopieren und weitergeben.
- Update-Hinweis „Neue Version verfügbar“; eine neue Version wird erst nach Bestätigung aktiv.
- Auslieferung als sieben Dateien: `index.html` und `app.js`, dazu `sw.js`, Manifest, zwei Symbole und `quellcode.zip`. Der Quellcode ist in Klassen und Komponenten getrennt; CHANGELOG, Prüfbericht und Backup-Werkzeug stecken in `quellcode.zip`.
