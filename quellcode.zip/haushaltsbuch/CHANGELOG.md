# Änderungen

## v0.3.1 – Sparen und Stapelverarbeitung (17.11.2026)

- Neue Kategorie „Sparen“ (Sparkonto andere Bank, Depot & Sparplan, Für andere, z. B. Kinder) für Geld auf Konten außerhalb der App; bestehende Installationen bekommen sie beim Update dazu.
- Altdaten-Import: Eine alte Kategorie oder ein einzelner Kommentar lässt sich als „Umbuchung auf eigenes Konto“ zuordnen. Stehen in Spalte B schon unsere Kategorienamen (auch „Haushalt › Lebensmittel“), ordnet die App sie selbst zu. Neu: „Vorherigen Import ersetzen“.
- Buchungsliste: „Auswählen“ und „Alle auswählen“ (passend zu Suche und Filter), dann gemeinsam eine Kategorie zuordnen, in Umbuchungen umwandeln oder löschen. Zugeordnete Texte lernt die App als Regeln.
- Einzelne Buchung: „In Umbuchung umwandeln“ direkt im Buchungsformular.

## v0.3.0 – Daten aus der alten App (17.11.2026)

- Einstellungen → „Daten importieren“: Excel-Datei (.xlsx) der alten App mit den Blättern Ausgaben, Einnahmen und Überweisungen übernehmen. Gelesen wird mit eigenem Code, ohne fremde Bibliothek.
- Datum als MM/DD/JJJJ oder Excel-Datum, Beträge mit Punkt, Ausgaben werden negativ; Überweisungen werden zu Umbuchungspaaren.
- Konten zuordnen (Vorschlag nach Name oder Ziffern wie „Sondertilg 1250“ → *1250), alte Kategorien einmal zuordnen, bei Bedarf mit Ausnahmen nach dem Kommentar; passende gelernte Regeln greifen von selbst.
- Standardmäßig nur Buchungen vor dem Startsaldo des Kontos: Kontostände bleiben unverändert, nichts zählt doppelt. Schon vorhandene Buchungen werden erkannt.
- Vorschau mit Zahlen (übernommen, übersprungen, schon vorhanden, ohne Kategorie) und Liste unlesbarer Zeilen; die Zuordnungen merkt sich die App für den nächsten Import.

## v0.2.0 – Konten und Buchungen (17.11.2026)

Ab dieser Version erfasst du echte Daten; sie bleiben bei jedem weiteren Update erhalten. Fingerabdruck und Wiederherstellungsschlüssel aus v0.1 gelten weiter, die Testbuchungen entfallen.

- Konten anlegen und bearbeiten (Girokonto, Tagesgeld, Bausparvertrag) mit Kennung „*1234“ und Startsaldo; archivieren bei 0,00 €.
- Kontostand abgleichen: Stand laut Bank eintragen; eine Differenz bleibt als Hinweis, bis fehlende Buchungen nachgetragen sind oder eine Korrekturbuchung sie schließt.
- Buchungen von Hand: Ausgabe oder Einnahme, Kategorie und Unterkategorie, Aufteilen auf mehrere Kategorien, Notiz; Warnung bei möglichen Doppelten.
- Kategorien: der abgestimmte Startbestand; der Bezug ergibt sich aus der Unterkategorie.
- Kontowecker-Import: E-Mail einfügen, Vorschau mit Konto über die Kennung, Kategorie-Vorschlägen und Saldenabgleich („Vermutlich fehlen Buchungen über X €“); dieselbe E-Mail wird beim zweiten Mal erkannt.
- Regeln lernen aus jeder Zuordnung; gleicher Text mit verschiedenen Kategorien wird nach dem Betrag (± 10 %) unterschieden; Regeln in den Einstellungen einsehen und löschen.
- Umbuchungen zwischen eigenen Konten, von Hand oder aus der E-Mail; Bearbeiten und Löschen wirken auf beide Seiten.
- Buchungsliste mit Suche, Kontofilter und Filter „Zu prüfen“; Bearbeiten direkt an der Buchung.
- Untere Navigation (Übersicht, Buchungen) und Plus-Knopf für eine neue Buchung.

## v0.1.0 – Machbarkeit (17.11.2026)

Erste installierbare Version. Sie prüft, ob alles Wichtige auf deinem Handy funktioniert; echte Buchungen kommen mit v0.2.

- Installierbare App (PWA) mit Symbol, läuft offline nach dem ersten Öffnen.
- Einrichtung in vier Schritten: Fingerabdruck (Passkey mit PRF), Wiederherstellungsschlüssel (30 Zeichen) anzeigen und Abschreiben kontrollieren, freiwilliges App-Passwort.
- Verschlüsselung nach Bauplan 5: AES-256-GCM für alle Daten, Datenschlüssel dreifach verpackt (Passkey, Wiederherstellungsschlüssel, App-Passwort mit PBKDF2 und 600.000 Durchläufen).
- Entsperren per Fingerabdruck, App-Passwort oder Wiederherstellungsschlüssel; danach Fingerabdruck neu einrichten.
- Sperre: Inhalt wird beim Verlassen sofort verdeckt, nach über einer Minute gesperrt; Sperren-Knopf oben rechts.
- Schnellzugriff „Neue Buchung“ (App-Symbol lange drücken), führt nach dem Entsperren direkt zur Erfassung.
- Verschlüsselte Testbuchungen erfassen und löschen.
- Backup als verschlüsselte .hhb-Datei herunterladen oder teilen; auf einem anderen Handy einspielen. docs/restore.py öffnet ein Backup auch ohne App.
- Machbarkeitsprüfung mit Selbsttest und Checkliste; das Ergebnis lässt sich kopieren und weitergeben.
- Update-Hinweis „Neue Version verfügbar“; eine neue Version wird erst nach Bestätigung aktiv.
- Auslieferung als sieben Dateien: `index.html` und `app.js`, dazu `sw.js`, Manifest, zwei Symbole und `quellcode.zip`. Der Quellcode ist in Klassen und Komponenten getrennt; CHANGELOG, Prüfbericht und Backup-Werkzeug stecken in `quellcode.zip`.
