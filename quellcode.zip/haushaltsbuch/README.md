# Mein Haushaltsbuch

Privates Haushaltsbuch als installierbare Web-App: ohne Server, ohne Bankanbindung, ohne Werbung. Alle Daten liegen verschlüsselt im Browser des Handys.

Eine Lieferung besteht aus sieben Dateien, die alle direkt ins Repository kommen:

| Datei | Zweck |
| --- | --- |
| `index.html` | Einstieg der App, mit eingebettetem Stylesheet |
| `app.js` | die gesamte App in einer Datei, am Ende die Lizenzhinweise der Bibliotheken |
| `sw.js` | Service Worker: Offlinebetrieb und Updates erst nach Bestätigung |
| `manifest.webmanifest` | macht die App installierbar, mit Schnellzugriff „Neue Buchung“ |
| `icon.png` | App-Symbol |
| `neu.png` | Symbol des Schnellzugriffs |
| `quellcode.zip` | dieser Quellcode mit CHANGELOG.md, pruefbericht.md und docs/restore.py |

## Quellcode

`quellcode.zip` enthält den vollständigen Quellcode (Angular, Angular Material, TypeScript), getrennt in Klassen und Komponenten:

- `src/app/domain`: Fachlogik als reine Klassen und Funktionen, ohne Angular, mit Tests daneben
- `src/app/data`: Verschlüsselung, Speicher, Sitzung und Dienste
- `src/app/features`: eine Komponente je Bildschirm
- `src/app/shared`: wiederverwendbare Bausteine

Bauen: `npm ci`, dann `npm run build:prod`. Das ergibt genau die sechs App-Dateien oben in `dist/haushaltsbuch/browser`. Alle Prüfungen: `python3 scripts/pruefbericht.py`.
