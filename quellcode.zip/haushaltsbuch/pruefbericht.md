# Prüfbericht Haushaltsbuch v0.6.0

Erstellt am 18.11.2026 automatisch mit `scripts/pruefbericht.py`. Geliefert wird nur, was alle Prüfungen besteht (Bauplan 9).

**Gesamtergebnis: bestanden**

| Prüfung | Ergebnis |
| --- | --- |
| Formatierung (Prettier) | bestanden |
| Lint (ESLint, Angular-Regeln, Barrierefreiheit, Schichtenregel) | bestanden, keine Befunde |
| TypeScript im strengen Modus, Produktions-Build | bestanden |
| Auslieferung | index.html, app.js, manifest.webmanifest, icon.png, neu.png, sw.js (Version 0.6.0-e785e0db2f17) |
| Unit-Tests (Vitest) | 140 von 140 bestanden |
| Abdeckung gesamt (Zeilen) | 98.87 % |
| Abdeckung Fachlogik domain (Zeilen, Ziel ≥ 90 %) | 100 % |
| Ende-zu-Ende-Tests (Chromium, virtueller Passkey mit PRF, Update von v0.1, Altdaten-Import, Statistik, Prognose, Liquidität, Leistungstest) | 68 von 68 bestanden |
| Sicherheitsprüfung der App-Abhängigkeiten | info 0, low 0, moderate 0, high 0, critical 0 (gesamt 0) |
| Sicherheitsprüfung inkl. Entwicklungswerkzeuge | info 0, low 0, moderate 6, high 17, critical 0 (gesamt 23) |
| app.js (Grenze: Warnung 600 kB, Abbruch 1 MB) | 763.23 kB roh, 170.50 kB übertragen |

## Ende-zu-Ende-Tests im Einzelnen

| Test | Ergebnis |
| --- | --- |
| v0.1 eingerichtet (Ausgangslage wie auf dem Handy) | bestanden |
| Update v0.1 → v0.2: Fingerabdruck gilt weiter, Testdaten entfernt | bestanden – accounts, bookings, categories, meta, pots, recurring, rules, settings |
| Kopfzeile zeigt v0.6 | bestanden |
| Konto: doppelter Name und doppelte Kennung abgelehnt | bestanden – Es gibt schon ein Konto „girokonto“.; Die Kennung *1234 gehört schon zu einem anderen Konto. |
| Konten angelegt mit Startsaldo | bestanden – {'Girokonto': '1.500,00 €', 'Tagesgeld': '4.850,00 €'} |
| Import: Konto *1234 erkannt, zwei Umsätze | bestanden – ['AGILA Hau.erkannt -29,59 €', 'Markt Alt.erkannt -160,24 €'] |
| Import: Lücke −152,05 € erkannt (Beispiel der Nutzerin) | bestanden – ['Vermutlich fehlen Buchungen über -152,05 € (Ausgaben). Erwartet waren 1.310,17 €, die Bank meldet 1.158,12 €. Der Kontostand wird auf 1.158,12 € gesetzt; die Differenz bleibt als Hinweis, bis sie geklärt ist.'] |
| Import: Kontostand 1.158,12 € laut Bank, Hinweis auf der Übersicht | bestanden – ['Noch kein Backup. Jetzt sichern: Zahnrad, „Backup teilen“.', 'Girokonto: Vermutlich fehlen Buchungen über -152,05 € seit 10.11.2026. Antippen zum Klären.'] |
| Gleiche E-Mail nochmal: erkannt, Buchungen abgewählt | bestanden – Nur Saldo übernehmen |
| Korrekturbuchung schließt die Lücke, Kontostand bleibt 1.158,12 € | bestanden |
| Aufteilung: Fehlbetrag gemeldet, dann gespeichert | bestanden – 1.073,12 € |
| Regel aus dem Import schlägt die Kategorie beim Tippen vor | bestanden – a-versicherungen |
| Doppelte Buchung von Hand wird erkannt (abgekürzter Bankentext) | bestanden |
| Umbuchung Girokonto → Tagesgeld: beide Kontostände | bestanden – {'Girokonto': '573,12 €', 'Tagesgeld': '5.350,00 €'} |
| Umbuchung bearbeiten ändert beide Seiten | bestanden – {'Girokonto': '673,12 €', 'Tagesgeld': '5.250,00 €'} |
| Umbuchung löschen entfernt beide Seiten | bestanden – {'Girokonto': '1.073,12 €', 'Tagesgeld': '4.850,00 €'} |
| Import: Zeile als Umbuchung markierbar, Saldo geht auf | bestanden – ['Übertrag TagesgeldUmbuchung -200,00 €', 'Markt Alt.erkannt -120,00 €', 'Unbekannt GmbHbitte zuordnen -9,99 €'] |
| Umbuchung aus E-Mail bucht die Gegenseite aufs Tagesgeld | bestanden – {'Girokonto': '743,13 €', 'Tagesgeld': '5.050,00 €'} |
| Nicht zugeordnete Buchung erscheint als Hinweis „Zu prüfen“ | bestanden |
| Filter „Zu prüfen“ zeigt genau diese Buchung | bestanden |
| Gemeinde-Regel: 158,00 € → Wasser & Abwasser (120,00 € war Grundsteuer) | bestanden – a-wasser-abwasser |
| Altdaten: unsere Kategorienamen in Spalte B werden von selbst zugeordnet | bestanden – Drogerie |
| Altdaten: Datei gelesen, Konten und Kategorien zugeordnet | bestanden – {'sum-import': '12', 'sum-after': '1', 'sum-dup': '0', 'sum-uncat': '0'} |
| Altdaten: Kontostände bleiben unverändert (Buchungen vor dem Startsaldo) | bestanden – {'Girokonto': '743,13 €', 'Tagesgeld': '5.050,00 €'} |
| Altdaten: Buchungen mit Kategorie und Ausnahme nach Kommentar in der Liste | bestanden – Grundsteuer Girokonto, Steuern & Gebühren › Grundsteuer -120,00 € |
| Altdaten: zweiter Import bringt nichts doppelt, Zuordnungen sind gemerkt | bestanden – ({'sum-import': '0', 'sum-dup': '12'}, 'a-holz') |
| Altdaten: „Vorherigen Import ersetzen“ spielt die Datei sauber neu ein | bestanden – {'sum-import': '12', 'sum-dup': '0'} |
| Altdaten: nach dem Ersetzen nichts doppelt | bestanden |
| Stapel: alle „Zu prüfen“ auf einmal zugeordnet | bestanden |
| Stapel: Ausgabe in Umbuchung aufs Tagesgeld umgewandelt, Kontostände unverändert (vor Startsaldo) | bestanden – ['Umbuchung von Girokonto Tagesgeld: Umbuchung von Girokonto 200,00 €', 'Umbuchung von Girokonto Tagesgeld: Umbuchung von Girokonto 5,00 €'] |
| Übersicht: Karte „Dieser Monat“ in Säulen und Backup-Erinnerung | bestanden – ['0,00 €', '394,83 €', '9,99 €', '0,00 €', '200,00 €', '-604,82 €'] |
| Statistik: Monat stimmt in allen Säulen mit der Übersicht überein | bestanden – ['0,00 €', '394,83 €', '9,99 €', '0,00 €', '200,00 €', '-604,82 €'] |
| Statistik: Jahresbalken öffnen den Monat, Kategorie bis zur Buchung aufklappbar | bestanden – ('Oktober 2026', ['20.10.2026 Lebensmittel 12,50 €', '02.10.2026 REWE 85,40 €']) |
| Statistik: Blättern zum Vormonat | bestanden |
| Statistik: Umbuchungen aufs Tagesgeld zählen als Sparbewegung (Oktober) | bestanden – ('0,00 €', '-745,00 €') |
| Schnellzugriff „Neue Buchung“ nach dem Entsperren | bestanden |
| Gelernte Regeln gelten auch nach Sperren und Entsperren | bestanden |
| Offline: entsperren, Daten vollständig | bestanden – {'Girokonto': '743,13 €', 'Tagesgeld': '5.050,00 €'} |
| Nach dem Backup verschwindet die Backup-Erinnerung | bestanden |
| Backup verschlüsselt; restore.py öffnet Konten und Buchungen | bestanden |
| Zweites Gerät: Backup eingespielt, gleiche Kontostände | bestanden – {'Girokonto': '743,13 €', 'Tagesgeld': '5.050,00 €'} |
| Zweites Gerät: gelernte Regeln sind mitgekommen | bestanden – 5 |
| Statistik: Gruppe „Hausfinanzierung“ in der Säule Finanzierung, Bestandteile nicht doppelt | bestanden – (['Hausfinanzierung 980,00 € +215 %'], ['Hauskredit 780,00 €', 'Tagesgeld 200,00 €'], 980.0) |
| Statistik: Gruppe auf „Sparen“ gestellt steht unter Sparen | bestanden – ('Sparen 980,00 €  Sparen und Umbuchungen auf Tagesgeld oder Bausparvertrag; Entna', '') |
| Einstellungen: Säule einer Kategorie umstellbar und zurücksetzbar (Haushalt Fixkosten ↔ Konsum) | bestanden – (True, True) |
| Statistik-Gruppen bleiben nach Sperren und Entsperren erhalten | bestanden |
| Buchung als wiederkehrend eingeplant: Gehalt am 30. → Termin am 1., Prognose rechnet danach | bestanden – ('1', ['Gehalt Sandra Oktober monatlich am 1., nächste 01.12.2026 2.450,00 €'], 'So rechnet die Prognose Kontostand Girokonto heute: -36,87 € Gehaltszyklus: 30.10.2026 bis 30.11.2026, danach 01.12.2026 bis 29.12.2026 (nach „Gehalt Sandra Oktober“) Feste Termine: 2 Zahlungen aus „W') |
| Die Buchung zeigt, dass sie eingeplant ist (kein zweiter Posten) | bestanden |
| Prognose: regelmäßige Zahlungen erkannt, Einkäufe nicht | bestanden – ['GEHALT SANDRA', 'Markt Alt.', 'STADTWERKE STROM', 'AGILA Hau.', 'NETFLIX.COM'] |
| Prognose: Leitaussage bis zum nächsten Gehalt | bestanden – Das Geld reicht bis zum Gehalt am 01.12.2026. |
| Prognose: nur die fehlende Quartalsabbuchung ist überfällig | bestanden – Überfällig: Markt Alt. -160,24 €, eingeplant für morgen |
| Preisalarm: Netflix teurer, Strom (verbrauchsabhängig) nicht | bestanden – ['Preiserhöhung: NETFLIX.COM kostet seit 13.11.2026 13,99 € statt 12,99 € (+7,7 %).'] |
| Vertrag: Kündigungsfrist erscheint als Hinweis, quittierter Preisalarm verschwindet | bestanden – ['STADTWERKE STROM: Kündigung bis 28.11.2026 möglich (in 10 Tagen), sonst Verlängerung bis 28.12.2027.'] |
| Kalender: nächstes Gehalt ist eingeplant | bestanden – ('2026-12-01', '1 +2.450') |
| Vorsichtsstufe umstellbar (Rechenweg zeigt sie) | bestanden |
| Abgleich: Umbuchung vom Tagesgeld empfohlen, mit Betrag und Termin | bestanden – Umbuchung empfohlen: 170,00 € bis spätestens 19.11.2026 |
| Rücklagen: Jahreszahlungs-Topf mit Rate 50 €, Aufteilung des Tagesgelds | bestanden – ('500,00 €', '4.340,00 €', '50,00 €') |
| Rücklagen: mehr als der freie Teil lässt sich nicht zuteilen | bestanden |
| Abgleich: Kfz-Versicherung wird aus dem Topf geholt (Topf-Anteil in der Empfehlung) | bestanden – Umbuchung empfohlen: 670,00 € bis spätestens 19.11.2026 Tiefster Stand ohne Umbuchung 31,00 € am 30.11.2026 Sicherheitspuffer 200,00 € Fehlbetrag 170,00 € Kfz-Versicherung: für HUK KFZ VERSICHERUNG am |
| „Jetzt umgebucht“: bestätigte Umbuchung, beide Kontostände sofort angepasst, wartet auf die Bank | bestanden – ('670,00', {'Girokonto': '300,00 €', 'Rücklagen': '4.850,00 €'}, {'Girokonto': '970,00 €', 'Rücklagen': '4.180,00 €'}) |
| Spartopf schmilzt erst mit der bestätigten Umbuchung | bestanden – 0,00 € |
| Kontowecker: Bankbuchung wird der bestätigten Umbuchung zugeordnet | bestanden – ['Übertrag Tagesgeldbestätigte Umbuchung 670,00 €'] |
| Keine doppelte Umbuchung: Kontostände unverändert, nicht mehr „wartet auf die Bank“ | bestanden – ({'Girokonto': '970,00 €', 'Rücklagen': '4.180,00 €'}, 'line-Banking; die App bewegt kein Geld. Danach hier bestätigen.  Jetzt umgebucht') |
| Puffer in den Einstellungen wirkt auf die Empfehlung | bestanden – ('Umbuchung empfohlen: 170,00 € bis spätestens 19.11.2026', 'Jetzt umbuchen: 4.300,00 €') |
| Leistung: zehn Jahre Daten (über 10.000 Buchungen) bleiben flüssig | bestanden – 11070 Zeilen: Datei lesen 1.4 s, übernehmen 0.5 s, entsperren 0.3 s, Jahresstatistik 0.1 s |
| Auslieferung: genau index.html, app.js, sw.js, Manifest und zwei Symbole | bestanden – app.js, icon.png, index.html, manifest.webmanifest, neu.png, sw.js |
| Keine Verstöße gegen die Content Security Policy | bestanden |
| Keine JavaScript-Fehler | bestanden |

## Bekannte Einschränkungen

- Getestet ist mit einem virtuellen Passkey in Chromium. Ob dein Handy den Fingerabdruck als Schlüssel liefert (PRF), zeigt erst der Test auf dem Gerät; dafür gibt es die Machbarkeitsprüfung in der App.
- „Dauerhafter Speicher“ vergibt Chrome selbst, meist erst für installierte Apps. Die Machbarkeitsprüfung zeigt den Stand.
- Der Service Worker sw.js ist eigener Code statt des Angular-Service-Workers, damit die App nur aus index.html und app.js plus sw.js, Manifest und zwei Symbolen besteht; Offlinebetrieb und Update nach Bestätigung sind per Ende-zu-Ende-Test geprüft.
- Ob der Schnellzugriff „Neue Buchung“ auf den Startbildschirm gezogen werden kann, hängt vom Launcher ab.
- Die app.js liegt über der Warngrenze von 600 kB (Abbruch erst bei 1 MB); übertragen werden rund 140 kB, danach lädt die App aus dem Zwischenspeicher.
- Der Altdaten-Import ist mit einer nachgebauten Datei im beschriebenen Format geprüft; die echte Datei der alten App zeigt erst dein Test.
- Allgemeiner CSV-Import von Bankumsätzen und Excel-Export folgen; Prognose, Statistik, Rücklagen und Kredite mit v0.4 bis v0.7.
- Die mittleren Befunde der Sicherheitsprüfung betreffen nur das Entwicklungswerkzeug ESLint (minimatch) und sind nicht Teil der App.
- Ausnahme GHSA-fc5q-39xc-vjpf (picomatch bis 4.0.7): ReDoS in der Mustersuche der Bauwerkzeuge (Angular CLI, Vitest); nicht in der App enthalten, keine korrigierte Version verfügbar. Die Ausnahme endet automatisch, sobald eine korrigierte Version erscheint.
