# Prüfbericht Haushaltsbuch v0.8.1

Erstellt am 19.11.2026 automatisch mit `scripts/pruefbericht.py`. Geliefert wird nur, was alle Prüfungen besteht (Bauplan 9).

**Gesamtergebnis: bestanden**

| Prüfung | Ergebnis |
| --- | --- |
| Formatierung (Prettier) | bestanden |
| Lint (ESLint, Angular-Regeln, Barrierefreiheit, Schichtenregel) | bestanden, keine Befunde |
| TypeScript im strengen Modus, Produktions-Build | bestanden |
| Auslieferung | index.html, app.js, manifest.webmanifest, icon.png, neu.png, sw.js (Version 0.8.1-b9d725d17400) |
| Unit-Tests (Vitest) | 216 von 216 bestanden |
| Abdeckung gesamt (Zeilen) | 97.05 % |
| Abdeckung Fachlogik domain (Zeilen, Ziel ≥ 90 % in jedem Teilbereich) | niedrigster Teilbereich domain/loans: 92.64 % (10 Teilbereiche geprüft) |
| Ende-zu-Ende-Tests (Chromium, virtueller Passkey mit PRF, Update von v0.1, Altdaten-Import, Statistik, Prognose, Liquidität, Kredite und Bausparen, Leistungstest) | 112 von 112 bestanden |
| Sicherheitsprüfung der App-Abhängigkeiten | info 0, low 0, moderate 0, high 0, critical 0 (gesamt 0) |
| Sicherheitsprüfung inkl. Entwicklungswerkzeuge | info 0, low 0, moderate 7, high 0, critical 0 (gesamt 7) |
| app.js übertragen (Grenze: Warnung 250 kB, Abbruch 350 kB; roh höchstens 1,5 MB) | 204.16 kB übertragen, 914.54 kB roh |

## Ende-zu-Ende-Tests im Einzelnen

| Test | Ergebnis |
| --- | --- |
| v0.1 eingerichtet (Ausgangslage wie auf dem Handy) | bestanden |
| Update v0.1 → v0.2: Fingerabdruck gilt weiter, Testdaten entfernt | bestanden – accounts, bauspar, bookings, categories, loans, meta, pots, recurring, rules, settings |
| Kopfzeile zeigt v0.8.1 | bestanden |
| Konto: doppelter Name und doppelte Kennung abgelehnt | bestanden – Es gibt schon ein Konto „girokonto“.; Die Kennung *1234 gehört schon zu einem anderen Konto. |
| Konten angelegt mit Startsaldo | bestanden – {'Girokonto': '1.500,00 €', 'Tagesgeld': '4.850,00 €'} |
| Import: Konto *1234 erkannt, zwei Umsätze | bestanden – ['AGILA Hau.erkannt -29,59 €', 'Markt Alt.erkannt -160,24 €'] |
| Import: Lücke −152,05 € erkannt (Beispiel der Nutzerin) | bestanden – ['Vermutlich fehlen Buchungen über -152,05 € (Ausgaben). Erwartet waren 1.310,17 €, die Bank meldet 1.158,12 €. Der Kontostand wird auf 1.158,12 € gesetzt; die Differenz bleibt als Hinweis, bis sie geklärt ist.'] |
| Import: Kontostand 1.158,12 € laut Bank, Hinweis auf der Übersicht | bestanden – ['Tipp: Lege eine Sicherungsdatei im Handyspeicher an. Die App hält sie automatisch aktuell; sie bleibt erhalten, auch wenn Browserdaten gelöscht werden. Einrichten Nicht jetzt', 'Noch kein Backup. Jetzt sichern, am besten auf Google Drive. Backup herunterladen', 'Girokonto: Vermutlich fehlen Buchungen über -152,05 € seit 10.11.2026. Antippen zum Klären.'] |
| Gleiche E-Mail nochmal: erkannt, Buchungen abgewählt | bestanden – Nur Saldo übernehmen |
| Korrekturbuchung schließt die Lücke, Kontostand bleibt 1.158,12 € | bestanden |
| Aufteilung: Fehlbetrag gemeldet, dann gespeichert | bestanden – 1.073,12 € |
| Regel aus dem Import schlägt die Kategorie beim Tippen vor | bestanden – a-versicherungen |
| Doppelte Buchung von Hand wird erkannt (abgekürzter Bankentext) | bestanden |
| Umbuchung Girokonto → Tagesgeld: beide Kontostände | bestanden – {'Girokonto': '573,12 €', 'Tagesgeld': '5.350,00 €'} |
| Umbuchung bearbeiten ändert beide Seiten | bestanden – {'Girokonto': '673,12 €', 'Tagesgeld': '5.250,00 €'} |
| Umbuchung löschen entfernt beide Seiten | bestanden – {'Girokonto': '1.073,12 €', 'Tagesgeld': '4.850,00 €'} |
| Import: Zeile als Umbuchung markierbar, Saldo geht auf | bestanden – ['Übertrag TagesgeldUmbuchung -200,00 €', 'Markt Alt.erkannt -120,00 €', 'Unbekannt GmbHbitte zuordnen -9,99 €'] |
| Umbuchung aus E-Mail bucht die Gegenseite aufs Tagesgeld | bestanden – {'Girokonto': '743,13 €', 'Tagesgeld': '5.050,00 €'} |
| Nicht zugeordnete Buchung erscheint als Hinweis „Zu prüfen“ | bestanden |
| Filter „Zu prüfen“ zeigt genau diese Buchung | bestanden |
| Gemeinde-Regel: 158,00 € → Wasser & Abwasser (120,00 € war Grundsteuer) | bestanden – a-wasser-abwasser |
| Altdaten: unsere Kategorienamen in Spalte B werden von selbst zugeordnet | bestanden – Drogerie |
| Altdaten: Datei gelesen, Konten und Kategorien zugeordnet | bestanden – {'sum-import': '12', 'sum-after': '1', 'sum-dup': '0', 'sum-uncat': '0'} |
| Altdaten: Kontostände bleiben unverändert (Buchungen vor dem Startsaldo) | bestanden – {'Girokonto': '743,13 €', 'Tagesgeld': '5.050,00 €'} |
| Altdaten: Buchungen mit Kategorie und Ausnahme nach Kommentar in der Liste | bestanden – Grundsteuer Girokonto, Steuern & Gebühren › Grundsteuer -120,00 € |
| Altdaten: zweiter Import bringt nichts doppelt, Zuordnungen sind gemerkt | bestanden – ({'sum-import': '0', 'sum-dup': '12'}, 'a-holz') |
| Altdaten: „Vorherigen Import ersetzen“ spielt die Datei sauber neu ein | bestanden – {'sum-import': '12', 'sum-dup': '0'} |
| Altdaten: nach dem Ersetzen nichts doppelt | bestanden |
| Stapel: alle „Zu prüfen“ auf einmal zugeordnet | bestanden |
| Stapel: Ausgabe in Umbuchung aufs Tagesgeld umgewandelt, Kontostände unverändert (vor Startsaldo) | bestanden – ['Umbuchung von Girokonto Tagesgeld: Umbuchung von Girokonto 200,00 €', 'Umbuchung von Girokonto Tagesgeld: Umbuchung von Girokonto 5,00 €'] |
| Übersicht: Karte „Dieser Monat“ in Säulen und Backup-Erinnerung | bestanden – ['0,00 €', '394,83 €', '9,99 €', '0,00 €', '200,00 €', '-604,82 €'] |
| Statistik: Monat stimmt in allen Säulen mit der Übersicht überein | bestanden – ['0,00 €', '394,83 €', '9,99 €', '0,00 €', '200,00 €', '-604,82 €'] |
| Statistik: Jahresbalken öffnen den Monat, Kategorie bis zur Buchung aufklappbar | bestanden – ('Oktober 2026', ['20.10.2026 Lebensmittel 12,50 €', '02.10.2026 REWE 85,40 €']) |
| Statistik: Blättern zum Vormonat | bestanden |
| Statistik: Umbuchungen aufs Tagesgeld zählen als Sparbewegung (Oktober) | bestanden – ('0,00 €', '-745,00 €') |
| Schnellzugriff „Neue Buchung“ nach dem Entsperren | bestanden |
| Gelernte Regeln gelten auch nach Sperren und Entsperren | bestanden |
| Offline: entsperren, Daten vollständig | bestanden – {'Girokonto': '743,13 €', 'Tagesgeld': '5.050,00 €'} |
| Nach dem Backup verschwindet die Backup-Erinnerung | bestanden |
| Backup verschlüsselt; restore.py öffnet Konten und Buchungen | bestanden |
| Zweites Gerät: Backup eingespielt, gleiche Kontostände | bestanden – {'Girokonto': '743,13 €', 'Tagesgeld': '5.050,00 €'} |
| Zweites Gerät: gelernte Regeln sind mitgekommen | bestanden – 5 |
| Statistik: Gruppe „Hausfinanzierung“ in der Säule Finanzierung, Bestandteile nicht doppelt | bestanden – (['Hausfinanzierung 980,00 € +215 %'], ['Hauskredit 780,00 €', 'Tagesgeld 200,00 €'], 980.0) |
| Statistik: Gruppe auf „Sparen“ gestellt steht unter Sparen | bestanden – ('Sparen 980,00 €  Sparen und Umbuchungen auf Tagesgeld oder Bausparvertrag; Entna', '') |
| Einstellungen: Säule einer Kategorie umstellbar und zurücksetzbar (Haushalt Fixkosten ↔ Konsum) | bestanden – (True, True) |
| Statistik-Gruppen bleiben nach Sperren und Entsperren erhalten | bestanden |
| Buchung als wiederkehrend eingeplant: Gehalt am 30. → Termin am 1., Prognose rechnet danach | bestanden – ('1', ['Gehalt Sandra Oktober monatlich am 1., nächste 01.12.2026 2.450,00 €'], 'So rechnet die Prognose Kontostand Girokonto heute: -36,87 € Gehaltszyklus: 30.10.2026 bis 30.11.2026, danach 01.12.2026 bis 29.12.2026 (nach „Gehalt Sandra Oktober“) Feste Termine: 2 Zahlungen aus „W') |
| Die Buchung zeigt, dass sie eingeplant ist (kein zweiter Posten) | bestanden |
| Prognose: regelmäßige Zahlungen erkannt, Einkäufe nicht | bestanden – ['GEHALT SANDRA', 'Markt Alt.', 'STADTWERKE STROM', 'AGILA Hau.', 'NETFLIX.COM'] |
| Prognose: Leitaussage bis zum nächsten Gehalt | bestanden – Das Geld reicht bis zum Gehalt am 01.12.2026. |
| Prognose: nur die fehlende Quartalsabbuchung ist überfällig | bestanden – Überfällig: Markt Alt. -160,24 €, eingeplant für morgen |
| Preisalarm: Netflix teurer, Strom (verbrauchsabhängig) nicht | bestanden – ['Preiserhöhung: NETFLIX.COM kostet seit 13.11.2026 13,99 € statt 12,99 € (+7,7 %).'] |
| Vertrag: Kündigungsfrist erscheint als Hinweis, quittierter Preisalarm verschwindet | bestanden – ['STADTWERKE STROM: Kündigung bis 29.11.2026 möglich (in 10 Tagen), sonst Verlängerung bis 29.12.2027.'] |
| Kalender: nächstes Gehalt ist eingeplant | bestanden – ('2026-12-01', '1 +2.450') |
| Vorsichtsstufe umstellbar (Rechenweg zeigt sie) | bestanden |
| Backup-Erinnerung nach dem Import, ein Tipp sichert, danach ist sie weg | bestanden – Seit dem letzten Backup gab es größere Änderungen, zum Beispiel einen Import. Jetzt sicher |
| Abgleich: Umbuchung vom Tagesgeld empfohlen, mit Betrag und Termin | bestanden – Umbuchung empfohlen: 90,00 € bis spätestens 24.11.2026 |
| Rücklagen: Jahreszahlungs-Topf mit Rate 50 €, Aufteilung des Tagesgelds | bestanden – ('500,00 €', '4.340,00 €', '50,00 €') |
| Rücklagen: mehr als der freie Teil lässt sich nicht zuteilen | bestanden |
| Abgleich: Kfz-Versicherung wird aus dem Topf geholt (Topf-Anteil in der Empfehlung) | bestanden – Umbuchung empfohlen: 590,00 € bis spätestens 24.11.2026 Tiefster Stand ohne Umbuchung 119,87 € am 30.11.2026 Sicherheitspuffer 200,00 € Fehlbetrag 90,00 € Kfz-Versicherung: für HUK KFZ VERSICHERUNG am |
| „Jetzt umgebucht“: bestätigte Umbuchung, beide Kontostände sofort angepasst, wartet auf die Bank | bestanden – ('590,00', {'Girokonto': '300,00 €', 'Rücklagen': '4.850,00 €'}, {'Girokonto': '890,00 €', 'Rücklagen': '4.260,00 €'}) |
| Spartopf schmilzt erst mit der bestätigten Umbuchung | bestanden – 0,00 € |
| Kontowecker: Bankbuchung wird der bestätigten Umbuchung zugeordnet | bestanden – ['Übertrag Tagesgeldbestätigte Umbuchung 590,00 €'] |
| Keine doppelte Umbuchung: Kontostände unverändert, nicht mehr „wartet auf die Bank“ | bestanden – ({'Girokonto': '890,00 €', 'Rücklagen': '4.260,00 €'}, 'line-Banking; die App bewegt kein Geld. Danach hier bestätigen.  Jetzt umgebucht') |
| Puffer in den Einstellungen wirkt auf die Empfehlung | bestanden – ('Umbuchung empfohlen: 90,00 € bis spätestens 24.11.2026', 'Jetzt umbuchen: 4.300,00 €') |
| Rücklagen: Dauerauftrag aus der Historie erkannt und mit dem Bedarf verglichen | bestanden – Dauerauftrag  Dein Dauerauftrag: 150,00 € monatlich am 2. vom Girokonto (erkannt).  Monatsraten deiner Töpfe: 50,00 €  Die übrigen 100,00 € bleiben frei auf dem |
| Startverteilung füllt den Kfz-Topf auf seinen Soll-Stand (Raten seit der letzten Zahlung) | bestanden – ('550,00', '550,00 €') |
| Neuer Eingang des Dauerauftrags wird automatisch verteilt: Kfz bekommt seine Rate, der Rest bleibt frei | bestanden – ('heste Termin. Was übrig bleibt, ist frei. Läuft seit 19.11.2026.  19.11.2026: 150,00 € → Kfz-Versicherung 50,00 € ändern', '600,00 €') |
| Jeder Eingang wird nur einmal verteilt | bestanden |
| Umschichten in den freien Teil | bestanden |
| Auch ein schwankendes Gehalt taktet die Prognose | bestanden – So rechnet die Prognose Kontostand Girokonto heute: 740,00 € Gehaltszyklus: 30.10.2026 bis 30.11.2026, danach 01.12.2026 bis 29.12.2026 (nach „GEHALT SANDRA“) F |
| Ohne Gehalt: Prognose meldet es und bietet das erkannte Gehalt an; ein Tipp plant es ein | bestanden – ('Kein Gehalt eingeplant. Ohne Gehalt rechnet die Prognose nur mit Ausgaben. Erkannt: GEHALT SANDRA, 2.450,00 € am 1. Einp', 'So rechnet die Prognose Kontostand Girokonto heute: 740,00 € Gehaltszyklus: 30.10.2026 bis 30.11.2026, danach 01.12.2026') |
| Wiederkehrend: zweites Gehalt zentral angelegt, das erste bleibt eingeplant | bestanden – ['GEHALT SANDRA monatlich am 1., nächste 01.12.2026 2.450,00 €', 'Dauerauftrag Rücklagen monatlich am 2., nächste 02.12.2026 -150,00 €', 'HUK KFZ VERSICHERUNG jährlich (Dez) am 5., nächste 07.12.2026 -600,00 €', 'AGILA Hau. monatlich am 13., nächste 14.12.2026 -29,59 €'] |
| Sicherungsdatei: eingerichtet, nach jeder Änderung aktualisiert, verschlüsselt und mit dem Schlüssel lesbar | bestanden |
| Nach Neustart weiter aktiv; Machbarkeitsprüfung meldet „Schreiberlaubnis bleibt“ | bestanden – ('Aktiv: haushaltsbuch-sicherung.hhb, zuletzt aktualisiert 19.',) |
| Rücklagen: Dauerauftrag als regelmäßige Umbuchung eingetragen (Vorschlag = Monatsraten), sichtbar unter Wiederkehrend | bestanden – ('100,00', 'Dauerauftrag  Dein Dauerauftrag: 100,00 € monatlich am 1. vom Girokonto (eingetragen).  Monatsraten deiner Töpfe: 100,00', ['Dauerauftrag Rücklagen Umbuchung auf Rücklagen, monatlich am 1., nächste 01.12.2026 -100,00 €']) |
| Eingang wird an Konto und Betrag erkannt (anderer Banktext) und auf die Töpfe verteilt | bestanden – n. Was übrig bleibt, ist frei. Läuft seit 19.11.2026.  19.11.2026: 100,00 € → Urlaub 100,00 € ändern |
| Statistik: Rechenweg Sparen zeigt jede Buchung mit Grund, meldet Verdachtsfälle, Summe = Kennzahl | bestanden – ('100,00 €', 'Sparen: Rechenweg · 2 Buchungen zeigen  1 Buchung braucht einen Blick: Sie sehen nach Umbuchung aus oder die Umbuchung ist nicht vollständig.  19.11.2026 · Rücklagen · Übertrag Spar 100,00 € zählt 100') |
| Nach gelöschten Browserdaten: Wiederherstellung aus der Sicherungsdatei bis zur letzten Änderung | bestanden – {'Girokonto': '987,66 €'} |
| Bausparvertrag zugeklappt mit Zusammenfassung: Ablösung, Bauspardarlehen, Stand des Abgleichs | bestanden – Ablösung September 2027 · Bauspardarlehen 26.890,75 € bis Mai 2038 · 2 Punkte prüfen |
| Bausparvertrag verknüpft: Erkennungshilfe, Klartext zu Zuteilung und Bauspardarlehen, Abgleich mit drei Ampeln | bestanden – ('Die Rate entspricht genau den Zinsen; das spricht für „Nur Zinsen“.', 'Bis voraussichtlich September 2027 zahlst du monatlich 116,70 € Zinsen für das Darlehen, die Restschuld bleibt bei 38.900,00 €. Dazu gehen 200,00 € in den Bausparvertrag. Dann wird der Bausparvertrag zugeteilt: Dein Guth', 3) |
| „Schuldenfrei“ wird mit dem Bausparvertrag absehbar | bestanden – ('nicht absehbar', 'Mai 2038') |
| Vergleich mit dem Vertrag: passende Werte bestätigt, abweichende markiert | bestanden – ('von Rundungen und der genauen Zinsgutschrift; nach der Zuteilung rechnet die App mit den echten Werten.  Jahresübersicht', ' Abweichung: Prüfe Guthaben heute, Sparrate, Zuteilungstermin sowie Zins und Rate des Bauspardarlehens.  Jahresübersicht') |
| Umbuchung: Warnung vor doppelter Erfassung; nochmal Tippen speichert trotzdem | bestanden – Es gibt schon eine Umbuchung über 200,00 € von Girokonto nach LBS Bausparen am 19.11.2026  |
| Sondertilgungsplan: Budget ohne Notreserve, früher schuldenfrei, Zinsersparnis und nächster Schritt | bestanden – ('19.990,00 €', 'August 2048', 'August 2052', 'Nächster Schritt: im Dezember 2026 9.750,00 € Sondertilgung auf „Autokredit“.', '14.804,94 €') |
| Fahrplan: zum Zinsbindungsende Restschuld, Anteil aus der Rücklage und nachzufinanzierender Betrag | bestanden – Dezember 2030 Hauskredit: Zinsbindung endet Restschuld 70.771,76 €, davon 5.040,00 € aus der Sondertilgungsrücklage. nachzufinanzieren: 65.731,76 € |
| Reihenfolge (Details) und monatlicher Betrag (Einstellungen → Kredite) bleiben erhalten | bestanden – ('zinsbindung', '200,00') |
| Vorausdarlehen: „Mit Bausparvertrag verknüpfen“ öffnet das Formular vorbelegt; Details zeigen die Eckdaten | bestanden – ('37896cc5-f3d6-496a-84b0-08c63ae209ce', 'Löst ab Vorfinanzierung Bausparsumme 30.000,00 € Guthaben heute 10.000,00 € Sparrate 200,00 € im Monat Guthabenzins 0,1 % Mindestsparguthaben 40 % = 12.000,00 € Zuteilung laut Bausparkasse September 2') |
| Diagramme zum Wischen: alle Kredite und jeder Kredit einzeln | bestanden – 3 |
| Sondertilgungsplan rechnet die Bauspar-Ablösung mit: Bauspardarlehen und Anschlussfinanzierung für die Lücke | bestanden – ('Vorfinanzierung: Ablösung durch den Bausparvertrag im September 2027; danach Bauspardarlehen über 17.990,75 € und eine Anschlussfinanzierung über 8.900,00 € (An', 'April 2055') |
| Rate des Autokredits nach der Tilgung weiterleiten (im Kredit eingestellt) | bestanden – Budget: 19.990,00 € in der Rücklage, dazu 200,00 € im Monat und weitergeleitete Raten getilgter Kredite. Annahmen ändern |
| KfW mit tilgungsfreier Zeit gespeichert; Fristen: Ende der tilgungsfreien Zeit und Zinsbindungsende | bestanden – Fristen KfW: tilgungsfreie Zeit endet am 18.01.2027  Danach zahlst du 600,00 € statt 60,42 € im Monat (539,58 € mehr). Die Prognose rechnet schon damit.  KfW: Zinsbindung endet am 15.09.2027  Restschu |
| Termine als Kalenderdatei (.ics) ohne Beträge | bestanden – BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Haushaltsbuch//Kredite//DE
CALSCALE:GREGOR |
| Übersicht zeigt die Fristen als Hinweise | bestanden – 2 |
| Was wäre wenn: Zinsersparnis durch Sondertilgung; Anschlusszins 3/4/5 % mit Rate fürs Wunschende | bestanden – ('1.651,65 €', ['3 %\t271,04 €\tSeptember 2034', '4 %\t294,14 €\tDezember 2034', '5 %\t318,33 €\tApril 2035']) |
| Leistung: zehn Jahre Daten (über 10.000 Buchungen) bleiben flüssig | bestanden – 11070 Zeilen: Datei lesen 1.0 s, übernehmen 0.5 s, entsperren 0.2 s, Jahresstatistik 1.0 s |
| Kredit angelegt: Vorschau, Restschuld, Rate erkannt und rückwirkend in Zinsen und Tilgung aufgeteilt | bestanden – ('Ohne Sondertilgungen abbezahlt voraussichtlich im Oktober 2050 (nach der Zinsbin', '150.000,00 €', '1 Buchungen zugeordnet (Buchungstext beg', '388,51 €') |
| Tilgungsplan je Jahr bis zur Tilgung | bestanden – 25 |
| Statistik: Kreditrate in der Gruppe als Zinsen und Tilgung | bestanden – ['Hauskredit: Tilgung 391,49 €', 'Hauskredit: Zinsen 388,51 €', 'Tagesgeld 200,00 €'] |
| Rate einmal für die Prognose eingeplant; Übersicht zeigt Restschuld und Vermögen netto | bestanden – 1 |
| Plausibilität: Rate unter den Zinsen wird nicht gespeichert | bestanden |
| Sammelabbuchung: von Hand aufgeteilt, frühere (niedrigere) Abbuchung wird rückwirkend angeboten und aufgeteilt | bestanden – Aufteilung für „DEBEKA Beiträge“ gelernt: 1 frühere Abbuchung passt ebenso, auch wenn die Beiträge d |
| Neue Buchung: „Wie gelernt aufteilen“ findet die passende Kombination (2 von 3 Teilen) | bestanden – Wie gelernt aufteilen (2 Teile) |
| Kontowecker: gestiegener Beitrag (+5 %) wird automatisch aufgeteilt und unter „Zu prüfen“ vorgelegt | bestanden – (0, 'Aufteilung nach Vorlage; Beiträge um 3,33\xa0€ angepasst, bitte prüfen.') |
| Vollständiges Backup: Gruppen, Kredit-Namen, wiederkehrende Zahlungen, Spartöpfe, Regeln, Puffer und Vorsichtsstufe kommen mit | bestanden – ('Finanzierung 980,00 €  Kreditraten und Sondertilgungen; ab v', ['Hauskredit: Tilgung 391,49 €', 'Hauskredit: Zinsen 388,51 €'], ['Kreditrate Hauskredit monatlich am 30., nächste 30.11.2026 -780,00 €', 'Gehalt Sandra Oktober monatlich am 1., nächste 01.12.2026 2.450,00 €'], '300,00', 'vorsichtig', 8) |
| Kredite kommen mit dem Backup mit | bestanden |
| Einstellungen: belegter Speicher mit Aufteilung in App-Dateien und Daten | bestanden – Belegter Speicher: 3,3 MB, davon App-Dateien 3,1 MB (damit die App ohne Internet läuft) und deine verschlüsselten Daten 0,2 MB. Zum Vergleich: Ein Handyfoto hat etwa 3 bis 5 MB. |
| „Nach Updates suchen“: meldet aktuell bzw. neue Version, Hinweis erscheint | bestanden – ('Du hast die neueste Version (0.8.1).', 1) |
| Update über die Einstellungen eingespielt, Daten unverändert | bestanden – {'Girokonto': '-106,60 €', 'Tagesgeld': '5.050,00 €'} |
| Auslieferung: genau index.html, app.js, sw.js, Manifest und zwei Symbole | bestanden – app.js, icon.png, index.html, manifest.webmanifest, neu.png, sw.js |
| Keine Verstöße gegen die Content Security Policy | bestanden |
| Keine JavaScript-Fehler | bestanden |

## Bekannte Einschränkungen

- Getestet ist mit einem virtuellen Passkey in Chromium. Ob dein Handy den Fingerabdruck als Schlüssel liefert (PRF), zeigt erst der Test auf dem Gerät; dafür gibt es die Machbarkeitsprüfung in der App.
- „Dauerhafter Speicher“ vergibt Chrome selbst, meist erst für installierte Apps. Die Machbarkeitsprüfung zeigt den Stand.
- Der Service Worker sw.js ist eigener Code statt des Angular-Service-Workers, damit die App nur aus index.html und app.js plus sw.js, Manifest und zwei Symbolen besteht; Offlinebetrieb und Update nach Bestätigung sind per Ende-zu-Ende-Test geprüft.
- Ob der Schnellzugriff „Neue Buchung“ auf den Startbildschirm gezogen werden kann, hängt vom Launcher ab.
- Gemessen wird die übertragene Größe der app.js; danach lädt die App aus dem Zwischenspeicher. Nachladen in Teilen ist wegen der festen Lieferform (sieben Dateien ohne Unterordner) nicht vorgesehen.
- Der Altdaten-Import ist mit einer nachgebauten Datei im beschriebenen Format geprüft; die echte Datei der alten App zeigt erst dein Test.
- Allgemeiner CSV-Import von Bankumsätzen und Excel-Export folgen.
- Die mittleren Befunde der Sicherheitsprüfung betreffen nur das Entwicklungswerkzeug ESLint (minimatch) und sind nicht Teil der App.
