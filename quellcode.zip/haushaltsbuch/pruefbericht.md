# Prüfbericht Haushaltsbuch v0.1.0

Erstellt am 17.11.2026 automatisch mit `scripts/pruefbericht.py`. Geliefert wird nur, was alle Prüfungen besteht (Bauplan 9).

**Gesamtergebnis: bestanden**

| Prüfung | Ergebnis |
| --- | --- |
| Formatierung (Prettier) | bestanden |
| Lint (ESLint, Angular-Regeln, Barrierefreiheit, Schichtenregel) | bestanden, keine Befunde |
| TypeScript im strengen Modus, Produktions-Build | bestanden |
| Auslieferung | index.html, app.js, manifest.webmanifest, icon.png, neu.png, sw.js (Version 0.1.0-2866bb27db8a) |
| Unit-Tests (Vitest) | 30 von 30 bestanden |
| Abdeckung gesamt (Zeilen) | 98.95 % |
| Abdeckung Fachlogik domain (Zeilen, Ziel ≥ 90 %) | 100 % |
| Ende-zu-Ende-Tests (Chromium, virtueller Passkey mit PRF) | 30 von 30 bestanden |
| Sicherheitsprüfung der App-Abhängigkeiten | info 0, low 0, moderate 0, high 0, critical 0 (gesamt 0) |
| Sicherheitsprüfung inkl. Entwicklungswerkzeuge | info 0, low 0, moderate 7, high 0, critical 0 (gesamt 7) |
| app.js (Grenze: Warnung 600 kB, Abbruch 1 MB) | 545.15 kB roh, 119.94 kB übertragen |

## Ende-zu-Ende-Tests im Einzelnen

| Test | Ergebnis |
| --- | --- |
| Erster Start führt zur Einrichtung | bestanden |
| Passkey mit PRF angelegt, Wiederherstellungsschlüssel angezeigt | bestanden – MCG3Z-… |
| Falsch abgeschriebene Gruppe wird erkannt | bestanden |
| Zu kurzes App-Passwort wird abgelehnt | bestanden |
| Einrichtung abgeschlossen (inkl. PBKDF2 600.000) | bestanden – 0.2 s |
| Testbuchungen erfasst und angezeigt | bestanden |
| Auf dem Gerät nur Verschlüsseltes (kein Klartext in IndexedDB) | bestanden |
| Datenschlüssel dreifach verpackt (Passkey, Wiederherstellung, Passwort) | bestanden |
| Sperren verwirft die Daten aus der Ansicht | bestanden |
| Entsperren per Passkey (Fingerabdruck) | bestanden |
| Falsches App-Passwort wird abgelehnt | bestanden |
| Entsperren per App-Passwort | bestanden |
| Beim Verlassen sofort verdeckt, nach über 1 Minute gesperrt | bestanden |
| Kurz weg (unter 1 Minute): App bleibt offen und sichtbar | bestanden |
| Schnellzugriff „Neue Buchung“: erst entsperren, dann direkt Erfassung | bestanden – /neu |
| Offline: App startet, entsperrt, erfasst und lädt alle Seiten | bestanden – ✓ Offline bereit (Service Worker aktiv) ja |
| Backup .hhb heruntergeladen, Inhalt verschlüsselt | bestanden – haushaltsbuch-backup-2026-11-17.hhb |
| docs/restore.py entschlüsselt das Backup ohne App | bestanden – Entschlüsselt: 1 Datensätze -> /tmp/tmp9t1sw3_o/haushaltsbuch-backup-2026-11-17.json |
| Falscher Wiederherstellungsschlüssel wird abgelehnt | bestanden |
| Backup auf zweitem Gerät eingespielt, alle Testbuchungen da | bestanden |
| Auf Gerät B gilt auch das App-Passwort aus dem Backup | bestanden |
| Wiederherstellungsschlüssel entsperrt, neuer Passkey funktioniert | bestanden |
| Update: Hinweis erscheint, alte Version läuft bis zur Bestätigung | bestanden |
| Update: nach Bestätigung neue Version aktiv, alte gelöscht | bestanden – haushaltsbuch-neu-0.1.0-2866bb27db8a |
| Update: Daten nach dem Update unverändert | bestanden |
| Manifest: installierbar, Schnellzugriff „Neue Buchung“ | bestanden |
| Auslieferung: genau index.html, app.js, sw.js, Manifest und zwei Symbole | bestanden – app.js, icon.png, index.html, manifest.webmanifest, neu.png, sw.js |
| Lizenzhinweise der Bibliotheken sind in app.js enthalten | bestanden |
| Keine Verstöße gegen die Content Security Policy | bestanden |
| Keine JavaScript-Fehler | bestanden |

## Bekannte Einschränkungen

- Getestet ist mit einem virtuellen Passkey in Chromium. Ob dein Handy den Fingerabdruck als Schlüssel liefert (PRF), zeigt erst der Test auf dem Gerät; dafür gibt es die Machbarkeitsprüfung in der App.
- „Dauerhafter Speicher“ vergibt Chrome selbst, meist erst für installierte Apps. Die Machbarkeitsprüfung zeigt den Stand.
- Der Service Worker sw.js ist eigener Code statt des Angular-Service-Workers, damit die App nur aus index.html und app.js plus sw.js, Manifest und zwei Symbolen besteht; Offlinebetrieb und Update nach Bestätigung sind per Ende-zu-Ende-Test geprüft.
- Ob der Schnellzugriff „Neue Buchung“ auf den Startbildschirm gezogen werden kann, hängt vom Launcher ab.
- Version 0.1 enthält nur Testbuchungen. Echte Daten gehören erst in Version 0.2; das Datenformat kann sich bis dahin noch ändern.
- Die mittleren Befunde der Sicherheitsprüfung betreffen nur das Entwicklungswerkzeug ESLint (minimatch) und sind nicht Teil der App.
