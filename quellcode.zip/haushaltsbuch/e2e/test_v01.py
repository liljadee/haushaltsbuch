#!/usr/bin/env python3
"""
Ende-zu-Ende-Tests v0.1 (Bauplan 9): Chromium mit Smartphone-Profil, virtueller Passkey mit PRF.
Die App läuft unter /haushaltsbuch/ wie auf GitHub Pages. Ergebnis: e2e/ergebnis.json

Aufruf: python3 e2e/test_v01.py <Ordner mit der gebauten App>
"""
import asyncio, json, os, re, shutil, subprocess, sys, tempfile, time
from pathlib import Path
from playwright.async_api import async_playwright

DIST = Path(sys.argv[1] if len(sys.argv) > 1 else "dist/haushaltsbuch/browser").resolve()
PORT = 8765
BASE = f"http://localhost:{PORT}/haushaltsbuch/"
results = []

def ok(name, cond, detail=""):
    results.append({"test": name, "ok": bool(cond), "detail": detail})
    print(("OK   " if cond else "FAIL ") + name + (f" ({detail})" if detail else ""))

async def authenticator(context, page):
    cdp = await context.new_cdp_session(page)
    await cdp.send("WebAuthn.enable", {"enableUI": False})
    await cdp.send("WebAuthn.addVirtualAuthenticator", {"options": {
        "protocol": "ctap2", "ctap2Version": "ctap2_1", "transport": "internal", "hasResidentKey": True,
        "hasUserVerification": True, "isUserVerified": True, "hasPrf": True, "automaticPresenceSimulation": True}})
    return cdp

async def setup_device(p, name):
    ctx = await p.chromium.launch_persistent_context(tempfile.mkdtemp(prefix=name), headless=True, viewport={"width": 390, "height": 844},
        device_scale_factor=2, is_mobile=True, has_touch=True, locale="de-DE", accept_downloads=True,
        user_agent="Mozilla/5.0 (Linux; Android 15; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Mobile Safari/537.36")
    page = ctx.pages[0] if ctx.pages else await ctx.new_page()
    errors = []
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    page.on("pageerror", lambda e: errors.append(str(e)))
    await authenticator(ctx, page)
    return ctx, page, errors

async def has(page, text, timeout=10000):
    """Wartet, bis der Text im Hauptbereich erscheint (Seitenwechsel sind asynchron)."""
    try:
        await page.locator("main").get_by_text(text, exact=False).first.wait_for(timeout=timeout)
        return True
    except Exception:
        return False

async def unlock_passkey(page):
    await page.get_by_test_id("unlock-passkey").click()
    await page.wait_for_url(re.compile(r"#/(start|neu|einstellungen)"), timeout=15000)

async def main():
    site = Path(tempfile.mkdtemp(prefix="site")); shutil.copytree(DIST, site / "haushaltsbuch")
    server = subprocess.Popen([sys.executable, "-m", "http.server", str(PORT), "--bind", "127.0.0.1"], cwd=site, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(0.8)
    try:
        async with async_playwright() as p:
            # ---------- Gerät A: Einrichtung ----------
            a, page, errs_a = await setup_device(p, "geraetA")
            await page.goto(BASE)
            await page.wait_for_url(re.compile("#/einrichtung"))
            ok("Erster Start führt zur Einrichtung", True)
            await page.get_by_test_id("neu").click()
            await page.get_by_test_id("passkey").click()
            key = re.sub(r"\s+", "", await page.get_by_test_id("recovery-key").inner_text(timeout=15000))
            ok("Passkey mit PRF angelegt, Wiederherstellungsschlüssel angezeigt", re.fullmatch(r"([0-9A-Z]{5}-){5}[0-9A-Z]{5}", key) is not None, key[:5] + "-…")
            groups = key.split("-")
            await page.get_by_test_id("key-written").click()
            ga = int(await page.get_by_test_id("group-a").get_attribute("data-group")); gb = int(await page.get_by_test_id("group-b").get_attribute("data-group"))
            await page.get_by_test_id("group-a").fill("falsch"); await page.get_by_test_id("group-b").fill(groups[gb].lower())
            await page.get_by_test_id("check-key").click()
            ok("Falsch abgeschriebene Gruppe wird erkannt", "stimmt noch nicht" in await page.get_by_role("alert").inner_text(timeout=5000))
            await page.get_by_test_id("group-a").fill(groups[ga].lower().replace("0", "o"))
            await page.get_by_test_id("check-key").click()
            await page.get_by_test_id("pw1").fill("zu kurz")
            await page.get_by_test_id("pw2").fill("zu kurz")
            await page.get_by_test_id("finish-pw").click()
            ok("Zu kurzes App-Passwort wird abgelehnt", "mindestens 12" in (await page.get_by_role("alert").inner_text()))
            pw = "Hunde lieben Brennholz im Winter"
            await page.get_by_test_id("pw1").fill(pw); await page.get_by_test_id("pw2").fill(pw)
            t0 = time.time(); await page.get_by_test_id("finish-pw").click()
            await page.get_by_test_id("to-app").wait_for(timeout=20000)
            dt = time.time() - t0
            await page.get_by_test_id("to-app").click()
            ok("Einrichtung abgeschlossen (inkl. PBKDF2 600.000)", True, f"{dt:.1f} s")
            await page.wait_for_url(re.compile("#/start"))

            # ---------- Testbuchungen ----------
            for amount, text in (("12,50", "Bäckerei Testmann"), ("1.234,56", "Brennholz Probe")):
                await page.get_by_test_id("new-entry").click()
                await page.get_by_test_id("amount").fill(amount); await page.get_by_test_id("text").fill(text)
                await page.get_by_test_id("save").click(); await page.wait_for_url(re.compile("#/start"))
            ok("Testbuchungen erfasst und angezeigt", await has(page, "Bäckerei Testmann") and await has(page, "1.234,56"))
            raw = await page.evaluate("""() => new Promise((res) => { const r = indexedDB.open('haushaltsbuch'); r.onsuccess = () => {
                const tx = r.result.transaction(['testdata','meta']); const out = {};
                tx.objectStore('testdata').getAll().onsuccess = (e) => { out.t = JSON.stringify(e.target.result);
                  tx.objectStore('meta').get('vault').onsuccess = (e2) => { out.m = JSON.stringify(e2.target.result); res(out); }; }; }; })""")
            ok("Auf dem Gerät nur Verschlüsseltes (kein Klartext in IndexedDB)", "Bäckerei" not in raw["t"] and "Brennholz" not in raw["t"] and "Bäckerei" not in raw["m"] and '"ct"' in raw["t"])
            meta = json.loads(raw["m"])
            ok("Datenschlüssel dreifach verpackt (Passkey, Wiederherstellung, Passwort)", all(k in meta for k in ("passkey", "recovery", "password")) and meta["password"]["iterations"] >= 600000)

            # ---------- Sperren und Entsperren ----------
            await page.get_by_role("button", name="Jetzt sperren").click()
            await page.wait_for_url(re.compile("#/entsperren"))
            ok("Sperren verwirft die Daten aus der Ansicht", await has(page, "ist gesperrt") and "Bäckerei" not in await page.inner_text("main"))
            await unlock_passkey(page)
            ok("Entsperren per Passkey (Fingerabdruck)", await has(page, "Bäckerei Testmann"))
            await page.get_by_role("button", name="Jetzt sperren").click()
            await page.get_by_test_id("show-pw").click(); await page.get_by_test_id("unlock-pw").fill("falsches Passwort!!")
            await page.get_by_test_id("unlock-pw-go").click()
            ok("Falsches App-Passwort wird abgelehnt", "stimmt nicht" in await page.get_by_role("alert").inner_text(timeout=15000))
            await page.get_by_test_id("unlock-pw").fill(pw); await page.get_by_test_id("unlock-pw-go").click()
            await page.wait_for_url(re.compile("#/start"), timeout=15000)
            ok("Entsperren per App-Passwort", await has(page, "Bäckerei Testmann"))

            # ---------- Automatische Sperre nach 1 Minute ----------
            await page.evaluate("""() => { Object.defineProperty(document, 'hidden', { configurable: true, get: () => true });
                document.dispatchEvent(new Event('visibilitychange')); }""")
            covered = await page.evaluate("document.body.classList.contains('hb-covered')")
            await page.evaluate("""() => { const real = Date.now; Date.now = () => real() + 61000;
                Object.defineProperty(document, 'hidden', { configurable: true, get: () => false }); document.dispatchEvent(new Event('visibilitychange')); }""")
            await page.wait_for_url(re.compile("#/entsperren"), timeout=5000)
            ok("Beim Verlassen sofort verdeckt, nach über 1 Minute gesperrt", covered)
            await unlock_passkey(page)
            await page.evaluate("""() => { Object.defineProperty(document, 'hidden', { configurable: true, get: () => true }); document.dispatchEvent(new Event('visibilitychange'));
                Object.defineProperty(document, 'hidden', { configurable: true, get: () => false }); document.dispatchEvent(new Event('visibilitychange')); }""")
            await page.wait_for_timeout(300)
            ok("Kurz weg (unter 1 Minute): App bleibt offen und sichtbar", "#/start" in page.url and not await page.evaluate("document.body.classList.contains('hb-covered')"))

            # ---------- Schnellzugriff ----------
            await page.goto(BASE + "?start=neue-buchung")
            await page.wait_for_url(re.compile(r"#/entsperren\?ziel=%2Fneu"))
            await unlock_passkey(page)
            ok("Schnellzugriff „Neue Buchung“: erst entsperren, dann direkt Erfassung", page.url.endswith("#/neu"), page.url.split("#")[1])

            # ---------- Offline ----------
            await page.goto(BASE); await page.wait_for_load_state()
            await page.wait_for_function("navigator.serviceWorker && navigator.serviceWorker.controller !== null", timeout=20000)
            await a.set_offline(True)
            await page.reload(); await page.wait_for_url(re.compile("#/entsperren"))
            await unlock_passkey(page)
            await page.get_by_test_id("new-entry").click()
            await page.get_by_test_id("amount").fill("3,20"); await page.get_by_test_id("text").fill("Offline-Kaffee")
            await page.get_by_test_id("save").click(); await page.wait_for_url(re.compile("#/start"))
            for route in ("einstellungen", "pruefung"):
                await page.goto(BASE + "#/" + route); await page.wait_for_load_state()
            row = page.locator(".row", has_text="Offline bereit")
            await row.wait_for(timeout=10000)
            ok("Offline: App startet, entsperrt, erfasst und lädt alle Seiten", "✓" in await row.inner_text() and "Offline-Kaffee" not in "", (await row.inner_text()).replace("\n", " "))
            await a.set_offline(False)
            await page.goto(BASE + "#/start"); await page.wait_for_load_state()
            if "#/entsperren" in page.url: await unlock_passkey(page)

            # ---------- Backup ----------
            await page.goto(BASE + "#/einstellungen"); await page.wait_for_load_state()
            async with page.expect_download() as dl:
                await page.get_by_test_id("backup-download").click()
            d = await dl.value
            bpath = Path(tempfile.mkdtemp()) / d.suggested_filename
            await d.save_as(bpath)
            btext = bpath.read_text(encoding="utf-8")
            ok("Backup .hhb heruntergeladen, Inhalt verschlüsselt", d.suggested_filename.endswith(".hhb") and "Offline-Kaffee" not in btext and '"haushaltsbuch-backup"' in btext, d.suggested_filename)
            r = subprocess.run([sys.executable, str(Path(__file__).resolve().parent.parent / "docs" / "restore.py"), str(bpath)], input=key + "\n", capture_output=True, text=True,
                               env={**os.environ, "PYTHONIOENCODING": "utf-8"})
            plain = bpath.with_suffix(".json")
            ok("docs/restore.py entschlüsselt das Backup ohne App", r.returncode == 0 and plain.exists() and "Offline-Kaffee" in plain.read_text(encoding="utf-8"), (r.stdout or r.stderr).strip().splitlines()[0] if (r.stdout or r.stderr) else "")

            # ---------- Gerät B: Wiederherstellung ----------
            b, pb, errs_b = await setup_device(p, "geraetB")
            await pb.goto(BASE); await pb.wait_for_url(re.compile("#/einrichtung"))
            await pb.get_by_test_id("restore").click()
            await pb.set_input_files("#backupFile", str(bpath))
            await pb.get_by_test_id("restore-key").fill("ZZZZZ-ZZZZZ-ZZZZZ-ZZZZZ-ZZZZZ-ZZZZZ"); await pb.get_by_test_id("open-backup").click()
            ok("Falscher Wiederherstellungsschlüssel wird abgelehnt", "passt nicht" in await pb.get_by_role("alert").inner_text(timeout=10000))
            await pb.get_by_test_id("restore-key").fill(key.lower().replace("-", " ")); await pb.get_by_test_id("open-backup").click()
            await pb.get_by_test_id("passkey").click()
            await pb.get_by_test_id("finish-nopw").click(timeout=15000)
            await pb.get_by_test_id("to-app").click(timeout=20000); await pb.wait_for_url(re.compile("#/start"))
            ok("Backup auf zweitem Gerät eingespielt, alle Testbuchungen da", all([await has(pb, x) for x in ("Bäckerei Testmann", "Brennholz Probe", "Offline-Kaffee")]))
            await pb.get_by_role("button", name="Jetzt sperren").click()
            await pb.get_by_test_id("show-pw").click(); await pb.get_by_test_id("unlock-pw").fill(pw); await pb.get_by_test_id("unlock-pw-go").click()
            await pb.wait_for_url(re.compile("#/start"), timeout=15000)
            ok("Auf Gerät B gilt auch das App-Passwort aus dem Backup", True)
            await b.close()

            # ---------- Wiederherstellungsschlüssel auf Gerät A, neuer Passkey ----------
            await page.goto(BASE + "#/start"); await page.wait_for_load_state()
            if "#/start" in page.url: await page.get_by_role("button", name="Jetzt sperren").click()
            await page.get_by_test_id("show-recovery").click(); await page.get_by_test_id("unlock-recovery").fill(key)
            await page.get_by_test_id("unlock-recovery-go").click()
            await page.get_by_test_id("new-passkey").click(); await page.wait_for_url(re.compile("#/start"), timeout=15000)
            await page.get_by_role("button", name="Jetzt sperren").click(); await unlock_passkey(page)
            ok("Wiederherstellungsschlüssel entsperrt, neuer Passkey funktioniert", await has(page, "Bäckerei Testmann"))

            # ---------- Update nach Bestätigung ----------
            old = await page.evaluate("caches.keys()")
            swfile = site / "haushaltsbuch" / "sw.js"
            swfile.write_text(swfile.read_text(encoding="utf-8").replace("const VERSION = '", "const VERSION = 'neu-", 1), encoding="utf-8")
            await page.evaluate("navigator.serviceWorker.getRegistration().then((r) => r.update())")
            banner = page.get_by_text("Neue Version verfügbar")
            await banner.wait_for(timeout=15000)
            still_old = await page.evaluate("caches.keys()") 
            ok("Update: Hinweis erscheint, alte Version läuft bis zur Bestätigung", any(k in still_old for k in old))
            async with page.expect_navigation(timeout=15000):
                await page.get_by_role("button", name="Jetzt aktualisieren").click()
            await page.wait_for_load_state()
            keys = await page.evaluate("caches.keys()")
            ok("Update: nach Bestätigung neue Version aktiv, alte gelöscht", len(keys) == 1 and keys[0].startswith("haushaltsbuch-neu-") and await page.get_by_text("Neue Version verfügbar").count() == 0, keys[0] if keys else "")
            if "#/entsperren" in page.url: await unlock_passkey(page)
            ok("Update: Daten nach dem Update unverändert", await has(page, "Bäckerei Testmann"))

            # ---------- Manifest und Sicherheit ----------
            man = await page.evaluate("fetch('manifest.webmanifest').then(r => r.json())")
            ok("Manifest: installierbar, Schnellzugriff „Neue Buchung“", man["display"] == "standalone" and man["shortcuts"][0]["url"] == "./?start=neue-buchung" and any(i.get("purpose") == "maskable" for i in man["icons"]))
            files = sorted(str(x.relative_to(DIST)) for x in DIST.rglob("*") if x.is_file())
            ok("Auslieferung: genau index.html, app.js, sw.js, Manifest und zwei Symbole", files == ["app.js", "icon.png", "index.html", "manifest.webmanifest", "neu.png", "sw.js"], ", ".join(files))
            lic = await page.evaluate("fetch('app.js').then(r => r.text()).then(t => t.includes('Lizenzhinweise') && t.includes('@angular/core'))")
            ok("Lizenzhinweise der Bibliotheken sind in app.js enthalten", lic)
            csp = [e for e in errs_a if "Content Security Policy" in e or "Refused" in e]
            ok("Keine Verstöße gegen die Content Security Policy", not csp, "; ".join(csp)[:200])
            other = [e for e in errs_a if e not in csp and "Failed to load resource" not in e and "net::ERR_INTERNET_DISCONNECTED" not in e]
            ok("Keine JavaScript-Fehler", not other, "; ".join(other)[:300])
            await a.close()
    finally:
        server.terminate()
    out = Path(__file__).resolve().parent / "ergebnis.json"
    out.write_text(json.dumps(results, ensure_ascii=False, indent=1), encoding="utf-8")
    failed = [r for r in results if not r["ok"]]
    print(f"\n{len(results) - len(failed)} von {len(results)} Ende-zu-Ende-Tests bestanden")
    sys.exit(1 if failed else 0)

asyncio.run(main())
