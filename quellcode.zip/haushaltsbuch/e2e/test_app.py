#!/usr/bin/env python3
"""
Ende-zu-Ende-Tests v0.2 (Bauplan 9): Chromium mit Smartphone-Profil, virtueller Passkey mit PRF,
App unter /haushaltsbuch/ wie auf GitHub Pages. Ausgangslage ist die gelieferte v0.1 (e2e/v01),
darauf wird v0.2 als Update eingespielt. Ergebnis: e2e/ergebnis.json

Aufruf: python3 e2e/test_app.py <Ordner mit der gebauten App>
"""
import asyncio, json, os, re, shutil, socket, subprocess, sys, tempfile, time
from pathlib import Path
from playwright.async_api import async_playwright

HERE = Path(__file__).resolve().parent
DIST = Path(sys.argv[1] if len(sys.argv) > 1 else "dist/haushaltsbuch/browser").resolve()
V01 = HERE / "v01"
APP_FILES = ["index.html", "app.js", "sw.js", "manifest.webmanifest", "icon.png", "neu.png"]
MAIL = "auf dem Konto *1234 wurden folgende Umsätze verbucht:\nAGILA Hau.: -29,59 EUR\nMarkt Alt.: -160,24 EUR\n\nneuer Saldo: 1.158,12 EUR"
results = []

def freeport():
    with socket.socket() as so:
        so.bind(("127.0.0.1", 0))
        return so.getsockname()[1]

PORT = freeport()
BASE = f"http://localhost:{PORT}/haushaltsbuch/"

def ok(name, cond, detail=""):
    results.append({"test": name, "ok": bool(cond), "detail": str(detail)})
    print(("OK   " if cond else "FAIL ") + name + (f" ({detail})" if detail else ""))

def plain(s):
    return s.replace("\u00a0", " ").replace("\n", " ")

async def device(p, name):
    ctx = await p.chromium.launch_persistent_context(tempfile.mkdtemp(prefix=name), headless=True, viewport={"width": 390, "height": 844},
        device_scale_factor=2, is_mobile=True, has_touch=True, locale="de-DE", accept_downloads=True,
        user_agent="Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Mobile Safari/537.36")
    page = ctx.pages[0] if ctx.pages else await ctx.new_page()
    errors = []
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    page.on("pageerror", lambda e: errors.append(str(e)))
    cdp = await ctx.new_cdp_session(page)
    await cdp.send("WebAuthn.enable", {"enableUI": False})
    await cdp.send("WebAuthn.addVirtualAuthenticator", {"options": {"protocol": "ctap2", "ctap2Version": "ctap2_1", "transport": "internal",
        "hasResidentKey": True, "hasUserVerification": True, "isUserVerified": True, "hasPrf": True, "automaticPresenceSimulation": True}})
    return ctx, page, errors

async def has(page, text, timeout=10000):
    try:
        await page.locator("main").get_by_text(text, exact=False).first.wait_for(timeout=timeout)
        return True
    except Exception:
        return False

async def unlock(page):
    await page.get_by_test_id("unlock-passkey").click()
    await page.wait_for_url(re.compile(r"#/(start|neu|buchungen|einstellungen)"), timeout=15000)

async def balances(page):
    await page.goto(BASE + "#/start"); await page.wait_for_load_state()
    if "#/entsperren" in page.url: await unlock(page)
    await page.locator(".acc .row").first.wait_for()
    out = {}
    for t in await page.locator(".acc .row").all_inner_texts():
        parts = plain(t).split(" ")
        out[parts[0]] = " ".join(parts[-2:])
    return out

async def setup(page, password=None):
    await page.get_by_test_id("neu").click()
    await page.get_by_test_id("passkey").click()
    key = re.sub(r"\s+", "", await page.get_by_test_id("recovery-key").inner_text(timeout=15000))
    groups = key.split("-")
    await page.get_by_test_id("key-written").click()
    a = int(await page.get_by_test_id("group-a").get_attribute("data-group")); b = int(await page.get_by_test_id("group-b").get_attribute("data-group"))
    await page.get_by_test_id("group-a").fill(groups[a]); await page.get_by_test_id("group-b").fill(groups[b]); await page.get_by_test_id("check-key").click()
    if password:
        await page.get_by_test_id("pw1").fill(password); await page.get_by_test_id("pw2").fill(password); await page.get_by_test_id("finish-pw").click()
    else:
        await page.get_by_test_id("finish-nopw").click()
    await page.get_by_test_id("to-app").click(timeout=20000)
    return key

async def import_mail(page, text, choose=None):
    await page.goto(BASE + "#/neu"); await page.wait_for_load_state()
    await page.get_by_test_id("tab-email").click()
    await page.get_by_test_id("mail").fill(text)
    rows = page.locator(".import .row")
    await rows.first.wait_for()
    for i, (kind, a, b) in (choose or {}).items():
        if kind == "cat":
            await rows.nth(i).locator("[data-testid=cat]").select_option(a)
            if b: await rows.nth(i).locator("[data-testid=sub]").select_option(b)
        elif kind == "transfer":
            await page.get_by_test_id(f"transfer-{i}").select_option(a)
    await page.wait_for_timeout(150)
    return {
        "rows": [plain(await rows.nth(i).locator(".head").inner_text()) for i in range(await rows.count())],
        "gap": [plain(t) for t in await page.get_by_test_id("gap").all_inner_texts()],
        "warn": [plain(t) for t in await page.locator(".import p.warn").all_inner_texts()],
        "button": await page.get_by_test_id("import-commit").inner_text(),
    }

async def main():
    site = Path(tempfile.mkdtemp(prefix="site")) / "haushaltsbuch"
    site.mkdir(parents=True)
    for f in APP_FILES: shutil.copy(V01 / f, site / f)
    server = subprocess.Popen([sys.executable, "-m", "http.server", str(PORT), "--bind", "127.0.0.1"], cwd=site.parent, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(0.8)
    try:
        async with async_playwright() as p:
            a, page, errs = await device(p, "A")
            # ---------- Ausgangslage: installierte v0.1 ----------
            await page.goto(BASE); await page.wait_for_url(re.compile("#/einrichtung"))
            pw = "Hunde lieben Brennholz im Winter"
            key = await setup(page, pw)
            await page.wait_for_function("navigator.serviceWorker && navigator.serviceWorker.controller !== null", timeout=20000)
            ok("v0.1 eingerichtet (Ausgangslage wie auf dem Handy)", await has(page, "Version 0.1"))

            # ---------- Update auf v0.2 ----------
            for f in APP_FILES: shutil.copy(DIST / f, site / f)
            await page.evaluate("navigator.serviceWorker.getRegistration().then((r) => r.update())")
            await page.get_by_text("Neue Version verfügbar").wait_for(timeout=20000)
            async with page.expect_navigation(timeout=20000):
                await page.get_by_role("button", name="Jetzt aktualisieren").click()
            await page.wait_for_url(re.compile("#/entsperren"), timeout=15000)
            await unlock(page)
            stores = await page.evaluate("new Promise((r) => { const q = indexedDB.open('haushaltsbuch'); q.onsuccess = () => r([...q.result.objectStoreNames]); })")
            ok("Update v0.1 → v0.2: Fingerabdruck gilt weiter, Testdaten entfernt", await has(page, "Noch keine Konten") and "testdata" not in stores and "accounts" in stores, ", ".join(stores))
            ver = "v" + json.loads((HERE.parent / "package.json").read_text())["version"].removesuffix(".0")
            ok(f"Kopfzeile zeigt {ver}", ver in await page.locator("header").inner_text())

            # ---------- Konten ----------
            for name, typ, ident, start, date in (("Girokonto", "giro", "1234", "1.500,00", "2026-11-10"), ("Tagesgeld", "tagesgeld", "5678", "4.850,00", "2026-11-10")):
                await page.get_by_test_id("acc-new").click()
                await page.get_by_test_id("acc-name").fill(name); await page.get_by_test_id("acc-type").select_option(typ)
                await page.get_by_test_id("acc-id").fill(ident); await page.get_by_test_id("acc-start").fill(start)
                await page.locator(".newbox input[type=date]").fill(date)
                await page.get_by_test_id("acc-save").click(); await page.wait_for_timeout(200)
            await page.get_by_test_id("acc-new").click(); await page.get_by_test_id("acc-name").fill("girokonto"); await page.get_by_test_id("acc-id").fill("1234")
            await page.get_by_test_id("acc-start").fill("1"); await page.get_by_test_id("acc-save").click()
            await page.get_by_role("alert").first.wait_for(timeout=5000)
            dupe = [plain(t) for t in await page.get_by_role("alert").all_inner_texts()]
            ok("Konto: doppelter Name und doppelte Kennung abgelehnt", len(dupe) == 2, "; ".join(dupe))
            await page.get_by_role("button", name="Abbrechen").click()
            bal = await balances(page)
            ok("Konten angelegt mit Startsaldo", bal == {"Girokonto": "1.500,00 €", "Tagesgeld": "4.850,00 €"}, bal)

            # ---------- Kontowecker-Import mit dem Beispiel der Nutzerin ----------
            r = await import_mail(page, MAIL, {0: ("cat", "a-versicherungen", "Tierversicherung"), 1: ("cat", "a-wasser-abwasser", None)})
            ok("Import: Konto *1234 erkannt, zwei Umsätze", len(r["rows"]) == 2 and await has(page, "Konto: Girokonto"), r["rows"])
            ok("Import: Lücke −152,05 € erkannt (Beispiel der Nutzerin)", r["gap"] and "-152,05 €" in r["gap"][0] and "1.310,17 €" in r["gap"][0], r["gap"])
            await page.get_by_test_id("import-commit").click(); await page.wait_for_url(re.compile("#/start"))
            bal = await balances(page)
            hint = [plain(t) for t in await page.locator(".hint-row").all_inner_texts()]
            ok("Import: Kontostand 1.158,12 € laut Bank, Hinweis auf der Übersicht", bal["Girokonto"] == "1.158,12 €" and any("-152,05 €" in h for h in hint), hint)
            r = await import_mail(page, MAIL)
            ok("Gleiche E-Mail nochmal: erkannt, Buchungen abgewählt", any("schon einmal übernommen" in w for w in r["warn"]) and all("schon vorhanden" in x for x in r["rows"]), r["button"])

            # ---------- Lücke per Korrekturbuchung schließen ----------
            await page.goto(BASE + "#/start"); await page.locator(".hint-row", has_text="Girokonto").click()
            await page.get_by_test_id("acc-correction").click(); await page.wait_for_timeout(300)
            bal = await balances(page)
            ok("Korrekturbuchung schließt die Lücke, Kontostand bleibt 1.158,12 €", await page.locator(".hint-row", has_text="Girokonto").count() == 0 and bal["Girokonto"] == "1.158,12 €")

            # ---------- Buchung von Hand mit Aufteilung ----------
            await page.goto(BASE + "#/neu"); await page.get_by_test_id("amount").fill("85,00"); await page.get_by_test_id("text").fill("REWE Einkauf")
            await page.locator("[data-testid=cat]").first.select_option("a-haushalt"); await page.locator("[data-testid=sub]").first.select_option("Lebensmittel")
            await page.get_by_test_id("split-toggle").click(); await page.get_by_test_id("split-0").fill("70,00")
            await page.locator("[data-testid=cat]").nth(1).select_option("a-haushalt"); await page.locator("[data-testid=sub]").nth(1).select_option("Drogerie")
            await page.get_by_test_id("split-1").fill("10,00"); await page.get_by_test_id("save").click()
            await page.get_by_role("alert").first.wait_for(timeout=5000)
            err = [plain(t) for t in await page.get_by_role("alert").all_inner_texts()]
            await page.get_by_test_id("split-1").fill("15,00"); await page.get_by_test_id("save").click(); await page.wait_for_url(re.compile("#/start"))
            bal = await balances(page)
            ok("Aufteilung: Fehlbetrag gemeldet, dann gespeichert", any("-5,00 €" in e for e in err) and bal["Girokonto"] == "1.073,12 €", bal["Girokonto"])

            # ---------- Doppelte Buchung von Hand ----------
            await page.goto(BASE + "#/neu"); await page.get_by_test_id("amount").fill("29,59"); await page.get_by_test_id("text").fill("AGILA Hau.")
            await page.get_by_test_id("text").blur(); await page.wait_for_timeout(200)
            suggested = await page.locator("[data-testid=cat]").input_value()
            ok("Regel aus dem Import schlägt die Kategorie beim Tippen vor", suggested == "a-versicherungen", suggested)
            await page.get_by_test_id("text").fill("AGILA HAUSTIERVERSICHERUNG AG")
            await page.get_by_test_id("save").click()
            try:
                await page.get_by_test_id("dup-warning").wait_for(timeout=5000); warned = True
            except Exception:
                warned = False
            ok("Doppelte Buchung von Hand wird erkannt (abgekürzter Bankentext)", warned)
            await page.get_by_role("button", name="Abbrechen").click()

            # ---------- Umbuchung ----------
            await page.goto(BASE + "#/neu"); await page.get_by_test_id("tab-umbuchung").click()
            await page.get_by_test_id("tr-amount").fill("500,00"); await page.get_by_test_id("tr-save").click(); await page.wait_for_url(re.compile("#/start"))
            bal = await balances(page)
            ok("Umbuchung Girokonto → Tagesgeld: beide Kontostände", bal == {"Girokonto": "573,12 €", "Tagesgeld": "5.350,00 €"}, bal)
            await page.goto(BASE + "#/buchungen"); await page.locator(".bk .row", has_text="Umbuchung nach Tagesgeld").click()
            await page.locator(".bk.open [data-testid=amount]").fill("400,00"); await page.locator(".bk.open [data-testid=save]").click(); await page.wait_for_timeout(300)
            bal = await balances(page)
            ok("Umbuchung bearbeiten ändert beide Seiten", bal == {"Girokonto": "673,12 €", "Tagesgeld": "5.250,00 €"}, bal)
            await page.goto(BASE + "#/buchungen"); await page.locator(".bk .row", has_text="Umbuchung von Girokonto").click()
            try:
                await page.get_by_role("button", name=re.compile("Umbuchung löschen")).click(timeout=5000)
            except Exception:
                await page.screenshot(path="/tmp/fail_transfer.png", full_page=True)
                raise
            await page.get_by_test_id("delete").click(); await page.wait_for_timeout(300)
            bal = await balances(page)
            ok("Umbuchung löschen entfernt beide Seiten", bal == {"Girokonto": "1.073,12 €", "Tagesgeld": "4.850,00 €"}, bal)

            # ---------- Umbuchung aus der E-Mail, Gemeinde-Regel nach Betrag, Zu prüfen ----------
            r = await import_mail(page, "auf dem Konto *1234 wurden folgende Umsätze verbucht:\nÜbertrag Tagesgeld: -200,00 EUR\nMarkt Alt.: -120,00 EUR\nUnbekannt GmbH: -9,99 EUR\n\nneuer Saldo: 743,13 EUR",
                                  {0: ("transfer", None, None), 1: ("cat", "a-steuern-gebuehren", "Grundsteuer")})
            tg = await page.locator("[data-testid=transfer-0] option").all_inner_texts()
            await page.get_by_test_id("transfer-0").select_option(label=[t for t in tg if "Tagesgeld" in t][0]); await page.wait_for_timeout(150)
            r2 = [plain(await page.locator(".import .row").nth(i).locator(".head").inner_text()) for i in range(3)]
            ok("Import: Zeile als Umbuchung markierbar, Saldo geht auf", "Umbuchung" in r2[0] and await page.get_by_test_id("gap").count() == 0, r2)
            await page.get_by_test_id("import-commit").click(); await page.wait_for_url(re.compile("#/start"))
            bal = await balances(page)
            ok("Umbuchung aus E-Mail bucht die Gegenseite aufs Tagesgeld", bal == {"Girokonto": "743,13 €", "Tagesgeld": "5.050,00 €"}, bal)
            ok("Nicht zugeordnete Buchung erscheint als Hinweis „Zu prüfen“", await page.get_by_test_id("hint-unclear").count() == 1)
            await page.get_by_test_id("hint-unclear").click(); await page.wait_for_url(re.compile("#/buchungen"))
            await page.locator(".bk .t").first.wait_for(timeout=10000)
            ok("Filter „Zu prüfen“ zeigt genau diese Buchung", [t for t in await page.locator(".bk .t").all_inner_texts()] == ["Unbekannt GmbH"])
            await page.goto(BASE + "#/neu"); await page.get_by_test_id("amount").fill("158,00"); await page.get_by_test_id("text").fill("Markt Alt."); await page.get_by_test_id("text").blur(); await page.wait_for_timeout(150)
            wasser = await page.locator("[data-testid=cat]").input_value()
            await page.get_by_test_id("amount").fill("121,50"); await page.locator("[data-testid=cat]").select_option("a-andere")
            ok("Gemeinde-Regel: 158,00 € → Wasser & Abwasser (120,00 € war Grundsteuer)", wasser == "a-wasser-abwasser", wasser)

            # ---------- Altdaten aus der alten App (XLSX) ----------
            before = await balances(page)
            await page.goto(BASE + "#/einstellungen"); await page.get_by_test_id("to-import").click(); await page.wait_for_url(re.compile("#/import"))
            await page.get_by_test_id("xlsx-file").set_input_files(str(HERE.parent / "test-data" / "altdaten-beispiel.xlsx"))
            await page.get_by_test_id("legacy-summary").wait_for(timeout=10000)
            await page.get_by_test_id("acc-map-Sondertilg 1250").select_option(label="Tagesgeld (*5678)")
            cards = page.locator(".grp")
            async def map_group(title, cat, sub=None):
                g = cards.filter(has_text=title).first
                await g.locator("[data-testid=cat]").first.select_option(cat)
                if sub: await g.locator("[data-testid=sub]").first.select_option(sub)
            await map_group("Ausgaben: Versicherung", "a-versicherungen")
            await map_group("Ausgaben: Nebenkosten", "a-wasser-abwasser")
            await map_group("Ausgaben: Lebensmittel", "a-haushalt", "Lebensmittel")
            await map_group("Ausgaben: Haus", "a-holz")
            await map_group("Einnahmen: Gehalt", "e-gehalt")
            await page.get_by_test_id("tr-ausgabe|Sparen").select_option(label="nach Tagesgeld")
            auto = await cards.filter(has_text="Ausgaben: Haushalt › Drogerie").first.locator("[data-testid=sub]").first.input_value()
            ok("Altdaten: unsere Kategorienamen in Spalte B werden von selbst zugeordnet", auto == "Drogerie", auto)
            g = cards.filter(has_text="Ausgaben: Nebenkosten").first
            await g.get_by_role("button", name=re.compile("Nach Kommentar unterscheiden")).click()
            await g.locator(".cm-row", has_text="Grundsteuer").wait_for(timeout=5000)
            texts = await g.locator(".cm-row").all_inner_texts()
            row = g.locator(".cm app-category-picker").nth(next(i for i, t in enumerate(texts) if "Grundsteuer" in t))
            await row.locator("[data-testid=cat]").select_option("a-steuern-gebuehren"); await row.locator("[data-testid=sub]").select_option("Grundsteuer")
            await page.wait_for_timeout(200)
            summary = {k: await page.get_by_test_id(k).inner_text() for k in ("sum-import", "sum-after", "sum-dup", "sum-uncat")}
            ok("Altdaten: Datei gelesen, Konten und Kategorien zugeordnet", summary == {"sum-import": "12", "sum-after": "1", "sum-dup": "0", "sum-uncat": "0"}, summary)
            await page.get_by_test_id("legacy-commit").click(); await page.wait_for_url(re.compile("#/start"))
            after = await balances(page)
            ok("Altdaten: Kontostände bleiben unverändert (Buchungen vor dem Startsaldo)", after == before, after)
            await page.goto(BASE + "#/buchungen"); await page.get_by_role("button", name=re.compile("Ältere Buchungen")).click(); await page.wait_for_timeout(200)
            older = [plain(t) for t in await page.locator(".bk .row").all_inner_texts()]
            gs = next((t for t in older if t.startswith("Grundsteuer ")), "")
            ok("Altdaten: Buchungen mit Kategorie und Ausnahme nach Kommentar in der Liste", any("Brennholz Maier" in t and "Holz" in t for t in older) and "Steuern & Gebühren › Grundsteuer" in gs and any("Sparrate" in t and "Umbuchung" in t for t in older) and any(t.startswith("Tagesgeld Urlaub") and "Umbuchung nach Tagesgeld" in t for t in older), gs)
            await page.goto(BASE + "#/import"); await page.get_by_test_id("xlsx-file").set_input_files(str(HERE.parent / "test-data" / "altdaten-beispiel.xlsx"))
            await page.get_by_test_id("legacy-summary").wait_for(timeout=10000)
            again = {k: await page.get_by_test_id(k).inner_text() for k in ("sum-import", "sum-dup")}
            remembered = await cards.filter(has_text="Ausgaben: Haus").first.locator("[data-testid=cat]").first.input_value()
            ok("Altdaten: zweiter Import bringt nichts doppelt, Zuordnungen sind gemerkt", again == {"sum-import": "0", "sum-dup": "12"} and remembered == "a-holz", (again, remembered))

            # ---------- Vorherigen Import ersetzen ----------
            await page.get_by_test_id("replace-legacy").click(); await page.wait_for_timeout(200)
            repl = {k: await page.get_by_test_id(k).inner_text() for k in ("sum-import", "sum-dup")}
            await page.get_by_test_id("legacy-commit").click(); await page.wait_for_url(re.compile("#/start"))
            ok("Altdaten: „Vorherigen Import ersetzen“ spielt die Datei sauber neu ein", repl == {"sum-import": "12", "sum-dup": "0"} and await balances(page) == before, repl)
            await page.goto(BASE + "#/buchungen"); await page.get_by_role("button", name=re.compile("Ältere Buchungen")).click(); await page.wait_for_timeout(200)
            ok("Altdaten: nach dem Ersetzen nichts doppelt", sum(1 for t in [plain(x) for x in await page.locator(".bk .t").all_inner_texts()] if t == "Brennholz Maier") == 1)

            # ---------- Stapelverarbeitung ----------
            await page.goto(BASE + "#/buchungen"); await page.get_by_test_id("filter-check").click()
            await page.get_by_test_id("select-mode").click(); await page.get_by_test_id("select-all").click()
            await page.get_by_test_id("batch-panel").locator("[data-testid=cat]").select_option("a-andere")
            await page.get_by_test_id("batch-assign").click(); await page.wait_for_timeout(300)
            await page.goto(BASE + "#/start"); await page.wait_for_timeout(200)
            ok("Stapel: alle „Zu prüfen“ auf einmal zugeordnet", await page.get_by_test_id("hint-unclear").count() == 0)
            await page.goto(BASE + "#/buchungen"); await page.get_by_test_id("search").fill("dm"); await page.wait_for_timeout(200)
            await page.get_by_test_id("select-mode").click(); await page.get_by_test_id("select-all").click()
            await page.get_by_test_id("batch-target").select_option(label="Tagesgeld"); await page.get_by_test_id("batch-transfer").click(); await page.wait_for_timeout(300)
            await page.get_by_test_id("search").fill("Umbuchung von Girokonto"); await page.wait_for_timeout(200)
            conv = [plain(t) for t in await page.locator(".bk .row").all_inner_texts()]
            ok("Stapel: Ausgabe in Umbuchung aufs Tagesgeld umgewandelt, Kontostände unverändert (vor Startsaldo)", any("5,00 €" in t for t in conv) and await balances(page) == before, conv[:2])

            # ---------- Übersicht und Statistik (v0.4) ----------
            await page.goto(BASE + "#/start"); await page.get_by_test_id("month-card").wait_for(timeout=10000)
            m_cons = plain(await page.get_by_test_id("m-consumption").inner_text())
            ok("Übersicht: Karte „Dieser Monat“ und Backup-Erinnerung", await page.get_by_test_id("hint-backup").count() == 1, m_cons)
            await page.get_by_test_id("nav-statistik").click(); await page.wait_for_url(re.compile("#/statistik"))
            await page.get_by_test_id("kpi-consumption").wait_for()
            k_cons = plain(await page.get_by_test_id("kpi-consumption").inner_text())
            ok("Statistik: Monat stimmt mit der Übersicht überein", k_cons == m_cons, k_cons)
            await page.get_by_test_id("stat-year").click(); await page.locator(".mb").first.wait_for()
            await page.locator("button.mb").filter(has_text="Okt").click(); await page.wait_for_timeout(200)
            label = await page.get_by_test_id("stat-label").inner_text()
            await page.get_by_test_id("cat-a-haushalt").click(); await page.locator(".sub .bar").first.click(); await page.wait_for_timeout(200)
            items = [plain(t) for t in await page.locator(".items li").all_inner_texts()]
            ok("Statistik: Jahresbalken öffnen den Monat, Kategorie bis zur Buchung aufklappbar", label == "Oktober 2026" and len(items) > 0, (label, items[:2]))
            await page.get_by_test_id("stat-prev").click(); await page.wait_for_timeout(200)
            ok("Statistik: Blättern zum Vormonat", await page.get_by_test_id("stat-label").inner_text() == "September 2026")
            sav = plain(await page.get_by_test_id("kpi-savings").inner_text())
            await page.get_by_test_id("stat-next").click(); await page.wait_for_timeout(200)
            sav_okt = plain(await page.get_by_test_id("kpi-savings").inner_text())
            ok("Statistik: Umbuchungen aufs Tagesgeld zählen als Sparbewegung (Oktober)", sav_okt not in ("0,00 €",), (sav, sav_okt))

            # ---------- Sperren, Schnellzugriff, Offline ----------
            await page.goto(BASE + "#/start"); await page.get_by_role("button", name="Jetzt sperren").click()
            await page.goto(BASE + "?start=neue-buchung"); await page.wait_for_url(re.compile(r"ziel=%2Fneu")); await unlock(page)
            ok("Schnellzugriff „Neue Buchung“ nach dem Entsperren", page.url.endswith("#/neu"))
            await page.get_by_test_id("amount").fill("29,59"); await page.get_by_test_id("text").fill("AGILA Hau."); await page.get_by_test_id("text").blur(); await page.wait_for_timeout(200)
            ok("Gelernte Regeln gelten auch nach Sperren und Entsperren", await page.locator("[data-testid=cat]").input_value() == "a-versicherungen")
            await page.wait_for_function("navigator.serviceWorker.controller !== null", timeout=20000)
            await a.set_offline(True)
            await page.goto(BASE + "#/start"); await page.reload(); await page.wait_for_url(re.compile("#/entsperren")); await unlock(page)
            bal = await balances(page)
            ok("Offline: entsperren, Daten vollständig", bal == {"Girokonto": "743,13 €", "Tagesgeld": "5.050,00 €"}, bal)
            await a.set_offline(False)

            # ---------- Backup und Wiederherstellung ----------
            await page.goto(BASE + "#/einstellungen"); await page.wait_for_load_state()
            if "#/entsperren" in page.url: await unlock(page); await page.goto(BASE + "#/einstellungen")
            async with page.expect_download() as dl:
                await page.get_by_test_id("backup-download").click()
            d = await dl.value
            bpath = Path(tempfile.mkdtemp()) / d.suggested_filename
            await d.save_as(bpath)
            raw = bpath.read_text(encoding="utf-8")
            res = subprocess.run([sys.executable, str(HERE.parent / "docs" / "restore.py"), str(bpath)], input=key + "\n", capture_output=True, text=True, env={**os.environ, "PYTHONIOENCODING": "utf-8"})
            plainjson = bpath.with_suffix(".json").read_text(encoding="utf-8") if bpath.with_suffix(".json").exists() else ""
            await page.goto(BASE + "#/start"); await page.wait_for_timeout(500)
            await page.get_by_test_id("month-card").wait_for(timeout=10000)
            ok("Nach dem Backup verschwindet die Backup-Erinnerung", await page.get_by_test_id("hint-backup").count() == 0)
            ok("Backup verschlüsselt; restore.py öffnet Konten und Buchungen", "AGILA" not in raw and res.returncode == 0 and "Girokonto" in plainjson and "AGILA Hau." in plainjson and "MARKT ALT." in plainjson)
            b, pb, errs_b = await device(p, "B")
            await pb.goto(BASE); await pb.wait_for_url(re.compile("#/einrichtung"))
            await pb.get_by_test_id("restore").click(); await pb.set_input_files("#backupFile", str(bpath))
            await pb.get_by_test_id("restore-key").fill(key); await pb.get_by_test_id("open-backup").click()
            await pb.get_by_test_id("passkey").click(); await pb.get_by_test_id("finish-nopw").click(timeout=15000)
            await pb.get_by_test_id("to-app").click(timeout=20000); await pb.wait_for_url(re.compile("#/start"))
            bal_b = await balances(pb)
            ok("Zweites Gerät: Backup eingespielt, gleiche Kontostände", bal_b == {"Girokonto": "743,13 €", "Tagesgeld": "5.050,00 €"}, bal_b)
            await pb.goto(BASE + "#/einstellungen"); await pb.locator(".rule").first.wait_for(timeout=10000)
            ok("Zweites Gerät: gelernte Regeln sind mitgekommen", await pb.locator(".rule").count() >= 3, await pb.locator(".rule").count())
            await b.close()

            # ---------- Eigene Gruppen für Kredite und Bausparen (v0.5.1) ----------
            await page.goto(BASE + "#/neu"); await page.get_by_test_id("amount").fill("780,00"); await page.get_by_test_id("text").fill("Kreditrate Hauskredit Sparkasse")
            await page.locator("[data-testid=cat]").select_option("a-kredite"); await page.get_by_test_id("save").click(); await page.wait_for_url(re.compile("#/start"))
            await page.goto(BASE + "#/einstellungen"); await page.get_by_test_id("stat-groups").wait_for()
            await page.get_by_test_id("loan-label-HAUSKREDIT SPARKASSE").fill("Hauskredit")
            await page.get_by_test_id("group-add").click(); await page.get_by_test_id("group-name-0").fill("Hausfinanzierung")
            await page.get_by_test_id("member-0-Hauskredit").click(); await page.get_by_test_id("member-0-Tagesgeld").click()
            await page.get_by_test_id("groups-save").click(); await page.wait_for_timeout(300)
            await page.goto(BASE + "#/statistik"); await page.get_by_test_id("own-groups").wait_for(timeout=10000)
            grp = plain(await page.get_by_test_id("own-groups").inner_text())
            await page.get_by_test_id("cat-a-kredite").click(); await page.wait_for_timeout(200)
            subs = [plain(t) for t in await page.locator(".sub .bar").all_inner_texts()]
            ok("Statistik: eigene Gruppe „Hausfinanzierung“ aus Kreditrate und Sparkonto, Kredit mit Anzeigenamen", "Hausfinanzierung" in grp and "Hauskredit 780,00 €" in grp and "Tagesgeld" in grp and any(t.startswith("Hauskredit") for t in subs), (grp[:160], subs))
            await page.get_by_role("button", name="Jetzt sperren").click(); await unlock(page)
            await page.goto(BASE + "#/statistik"); await page.wait_for_timeout(300)
            ok("Statistik-Gruppen bleiben nach Sperren und Entsperren erhalten", await page.get_by_test_id("own-groups").count() == 1)

            # ---------- Prognose, Wiederkehrend, Verträge, Kalender (v0.5) ----------
            import openpyxl, datetime
            today = datetime.date.today()
            def prev_bank(d):
                while d.weekday() >= 5: d -= datetime.timedelta(days=1)
                return d
            def next_bank(d):
                while d.weekday() >= 5: d += datetime.timedelta(days=1)
                return d
            def month_add(y, m, k):
                t = y * 12 + m - 1 + k
                return t // 12, t % 12 + 1
            wb = openpyxl.Workbook(); wa = wb.active; wa.title = "Ausgaben"; wa.append(["Ausgaben"]); wa.append(["Datum"])
            we = wb.create_sheet("Einnahmen"); we.append(["Einnahmen"]); we.append(["Datum"])
            dt = lambda d: datetime.datetime.combine(d, datetime.time())
            def put(sheet, d, row):
                if d < today: sheet.append([dt(d)] + row)
            for k in range(-14, 2):
                y, m = month_add(today.year, today.month, k)
                put(we, prev_bank(datetime.date(y, m, 1)), ["Gehalt", "Girokonto", 2450, "EUR", "", "", "", "GEHALT SANDRA"])
                put(wa, next_bank(datetime.date(y, m, 13)), ["Versicherung", "Girokonto", 29.59, "EUR", "", "", "", "AGILA Hau."])
                put(wa, next_bank(datetime.date(y, m, 13)), ["Abos", "Girokonto", 13.99 if k == 0 else 12.99, "EUR", "", "", "", "NETFLIX.COM"])
                put(wa, next_bank(datetime.date(y, m, 2)), ["Strom", "Girokonto", 89, "EUR", "", "", "", "STADTWERKE STROM"])
                for wd, amt in ((4, 61.2), (11, 48.9), (18, 72.35), (25, 55.1)):
                    put(wa, datetime.date(y, m, wd), ["Lebensmittel", "Girokonto", amt + k, "EUR", "", "", "", "REWE MARKT"])
                if m in (2, 5, 8, 11) and k < 0:
                    put(wa, next_bank(datetime.date(y, m, 15)), ["Nebenkosten", "Girokonto", 160.24, "EUR", "", "", "", "Markt Alt."])
            hist = Path(tempfile.mkdtemp()) / "prognose.xlsx"; wb.save(hist)
            dd, pd_, errs_d = await device(p, "D")
            await pd_.goto(BASE); await pd_.wait_for_url(re.compile("#/einrichtung")); await setup(pd_)
            await pd_.get_by_test_id("acc-new").click(); await pd_.get_by_test_id("acc-name").fill("Girokonto"); await pd_.get_by_test_id("acc-start").fill("1.500,00"); await pd_.get_by_test_id("acc-save").click(); await pd_.wait_for_timeout(300)
            await pd_.goto(BASE + "#/import"); await pd_.get_by_test_id("xlsx-file").set_input_files(str(hist)); await pd_.get_by_test_id("legacy-summary").wait_for(timeout=20000)
            for title, cat in (("Ausgaben: Versicherung", "a-versicherungen"), ("Ausgaben: Abos", "a-abos-streaming"), ("Ausgaben: Strom", "a-strom"), ("Ausgaben: Lebensmittel", "a-haushalt"), ("Ausgaben: Nebenkosten", "a-wasser-abwasser"), ("Einnahmen: Gehalt", "e-gehalt")):
                await pd_.locator(".grp").filter(has_text=title).first.locator("[data-testid=cat]").first.select_option(cat)
            await pd_.wait_for_timeout(200)
            await pd_.get_by_test_id("legacy-commit").click(); await pd_.wait_for_url(re.compile("#/start"))
            await pd_.get_by_test_id("hint-recurring").click(); await pd_.wait_for_url(re.compile("ansicht=wiederkehrend"))
            sug = [plain(t) for t in await pd_.locator(".sug strong").all_inner_texts()]
            ok("Prognose: regelmäßige Zahlungen erkannt, Einkäufe nicht", {"GEHALT SANDRA", "AGILA Hau.", "NETFLIX.COM", "STADTWERKE STROM", "Markt Alt."} <= set(sug) and "REWE MARKT" not in sug, sug)
            await pd_.get_by_test_id("rec-confirm-all").click(); await pd_.wait_for_timeout(300)
            await pd_.goto(BASE + "#/start"); await pd_.get_by_test_id("verdict").wait_for()
            verdict = plain(await pd_.get_by_test_id("verdict").inner_text())
            overdue = plain(await pd_.get_by_test_id("overdue").inner_text()) if await pd_.get_by_test_id("overdue").count() else ""
            ok("Prognose: Leitaussage bis zum nächsten Gehalt", "Gehalt am" in verdict or "ins Minus" in verdict, verdict)
            quarter_due = today.month in (2, 5, 8, 11) and next_bank(datetime.date(today.year, today.month, 15)) < today
            ok("Prognose: nur die fehlende Quartalsabbuchung ist überfällig", ("Markt Alt." in overdue) == quarter_due and "GEHALT" not in overdue and "AGILA" not in overdue, overdue)
            notices = [plain(t) for t in await pd_.get_by_test_id("hint-notice").all_inner_texts()]
            ok("Preisalarm: Netflix teurer, Strom (verbrauchsabhängig) nicht", any("NETFLIX" in t and "Preiserhöhung" in t for t in notices) and not any("STROM" in t for t in notices), notices)
            await pd_.goto(BASE + "#/buchungen?ansicht=wiederkehrend"); await pd_.get_by_test_id("rec-STADTWERKE STROM").click()
            await pd_.get_by_test_id("rec-contract").click()
            until = (today + datetime.timedelta(days=40)).isoformat()
            await pd_.get_by_test_id("rec-until").fill(until); await pd_.get_by_test_id("rec-save").click(); await pd_.wait_for_timeout(300)
            await pd_.get_by_test_id("rec-NETFLIX.COM").click(); await pd_.get_by_test_id("price-ack").click(); await pd_.wait_for_timeout(300)
            await pd_.goto(BASE + "#/start"); await pd_.get_by_test_id("verdict").wait_for()
            notices = [plain(t) for t in await pd_.get_by_test_id("hint-notice").all_inner_texts()]
            ok("Vertrag: Kündigungsfrist erscheint als Hinweis, quittierter Preisalarm verschwindet", any("Kündigung bis" in t for t in notices) and not any("NETFLIX" in t for t in notices), notices)
            await pd_.goto(BASE + "#/buchungen?ansicht=kalender"); await pd_.get_by_test_id("cal-label").wait_for()
            ny, nm = month_add(today.year, today.month, 1)
            sal = prev_bank(datetime.date(ny, nm, 1)).isoformat()
            if sal[:7] != today.isoformat()[:7]:
                await pd_.locator(".nav button").nth(1).click(); await pd_.wait_for_timeout(200)
            cell = plain(await pd_.get_by_test_id(f"cal-{sal}").inner_text()) if await pd_.get_by_test_id(f"cal-{sal}").count() else ""
            ok("Kalender: nächstes Gehalt ist eingeplant", "+2.450" in cell, (sal, cell))
            await pd_.goto(BASE + "#/einstellungen"); await pd_.get_by_test_id("prudence").select_option("vorsichtig"); await pd_.wait_for_timeout(200)
            await pd_.goto(BASE + "#/start"); await pd_.get_by_test_id("verdict").wait_for()
            await pd_.locator(".calc summary").click(); await pd_.wait_for_timeout(150)
            ok("Vorsichtsstufe umstellbar (Rechenweg zeigt sie)", "vorsichtig" in (await pd_.locator(".calc").inner_text()))
            await pd_.screenshot(path="/tmp/fc_0.png", full_page=True)
            await dd.close()

            # ---------- Leistungstest: zehn Jahre Daten (Bauplan 11) ----------
            import openpyxl, datetime, random
            random.seed(7)
            wb = openpyxl.Workbook(); ws = wb.active; ws.title = "Ausgaben"; ws.append(["Ausgaben"]); ws.append(["Datum", "Kategorie", "Konto", "Betrag", "Währung", "", "", "", "Kommentar"])
            day0 = datetime.date(2016, 1, 1)
            shops = ["REWE", "EDEKA", "ALDI", "LIDL", "DM", "Tankstelle", "Bäckerei", "Fressnapf", "Bauhaus", "Apotheke"]
            n_rows = 0
            for d in range(0, 3650):
                for _ in range(3):
                    ws.append([datetime.datetime.combine(day0 + datetime.timedelta(days=d), datetime.time()), "Lebensmittel", "Girokonto", round(random.uniform(2, 120), 2), "EUR", "", "", "", random.choice(shops)]); n_rows += 1
            wi = wb.create_sheet("Einnahmen"); wi.append(["Einnahmen"]); wi.append(["Datum"])
            for mth in range(120):
                y, mm = 2016 + mth // 12, mth % 12 + 1
                wi.append([datetime.datetime(y, mm, 28), "Gehalt", "Girokonto", 2450, "EUR", "", "", "", "Gehalt"]); n_rows += 1
            big = Path(tempfile.mkdtemp()) / "viele-jahre.xlsx"; wb.save(big)
            c, pc, errs_c = await device(p, "C")
            await pc.goto(BASE); await pc.wait_for_url(re.compile("#/einrichtung")); await setup(pc)
            await pc.get_by_test_id("acc-new").click(); await pc.get_by_test_id("acc-name").fill("Girokonto"); await pc.get_by_test_id("acc-start").fill("1.000,00"); await pc.get_by_test_id("acc-save").click(); await pc.wait_for_timeout(300)
            await pc.goto(BASE + "#/import"); t0 = time.time()
            await pc.get_by_test_id("xlsx-file").set_input_files(str(big)); await pc.get_by_test_id("legacy-summary").wait_for(timeout=120000)
            t_read = time.time() - t0
            g = pc.locator(".grp").filter(has_text="Ausgaben: Lebensmittel").first
            await g.locator("[data-testid=cat]").first.select_option("a-haushalt")
            await pc.locator(".grp").filter(has_text="Einnahmen: Gehalt").first.locator("[data-testid=cat]").first.select_option("e-gehalt")
            await pc.wait_for_timeout(300)
            t0 = time.time(); await pc.get_by_test_id("legacy-commit").click(); await pc.wait_for_url(re.compile("#/start"), timeout=180000); t_commit = time.time() - t0
            await pc.get_by_role("button", name="Jetzt sperren").click()
            t0 = time.time(); await unlock(pc); await pc.get_by_test_id("month-card").wait_for(timeout=60000); t_unlock = time.time() - t0
            await pc.goto(BASE + "#/statistik"); await pc.get_by_test_id("kpi-consumption").wait_for()
            t0 = time.time(); await pc.get_by_test_id("stat-year").click(); await pc.locator("button.mb").first.wait_for(timeout=60000); t_year = time.time() - t0
            await pc.get_by_test_id("stat-prev").click(); await pc.locator("button.mb").nth(11).wait_for(timeout=60000)
            perf = f"{n_rows} Zeilen: Datei lesen {t_read:.1f} s, übernehmen {t_commit:.1f} s, entsperren {t_unlock:.1f} s, Jahresstatistik {t_year:.1f} s"
            ok("Leistung: zehn Jahre Daten (über 10.000 Buchungen) bleiben flüssig", t_unlock < 4 and t_year < 4, perf)
            await c.close()

            # ---------- Dateien, Sicherheit ----------
            files = sorted(str(x.relative_to(DIST)) for x in DIST.rglob("*") if x.is_file())
            ok("Auslieferung: genau index.html, app.js, sw.js, Manifest und zwei Symbole", files == sorted(APP_FILES), ", ".join(files))
            csp = [e for e in errs + errs_b + errs_c + errs_d if "Content Security Policy" in e or "Refused" in e]
            ok("Keine Verstöße gegen die Content Security Policy", not csp, "; ".join(csp)[:200])
            other = [e for e in errs + errs_b + errs_c + errs_d if e not in csp and "Failed to load resource" not in e and "ERR_INTERNET_DISCONNECTED" not in e]
            ok("Keine JavaScript-Fehler", not other, "; ".join(other)[:300])
            await a.close()
    finally:
        server.terminate()
    (HERE / "ergebnis.json").write_text(json.dumps(results, ensure_ascii=False, indent=1), encoding="utf-8")
    failed = [r for r in results if not r["ok"]]
    print(f"\n{len(results) - len(failed)} von {len(results)} Ende-zu-Ende-Tests bestanden")
    sys.exit(1 if failed else 0)

asyncio.run(main())
