#!/usr/bin/env python3
"""
Ende-zu-Ende-Tests v0.2 (Bauplan 9): Chromium mit Smartphone-Profil, virtueller Passkey mit PRF,
App unter /haushaltsbuch/ wie auf GitHub Pages. Ausgangslage ist die gelieferte v0.1 (e2e/v01),
darauf wird v0.2 als Update eingespielt. Ergebnis: e2e/ergebnis.json

Aufruf: python3 e2e/test_app.py <Ordner mit der gebauten App>
"""
import asyncio, datetime, json, os, re, shutil, socket, subprocess, sys, tempfile, time
from pathlib import Path
from playwright.async_api import async_playwright

HERE = Path(__file__).resolve().parent
DIST = Path(sys.argv[1] if len(sys.argv) > 1 else "dist/haushaltsbuch/browser").resolve()
V01 = HERE / "v01"
APP_FILES = ["index.html", "app.js", "sw.js", "manifest.webmanifest", "icon.png", "neu.png"]
MAIL = "auf dem Konto *1234 wurden folgende Umsätze verbucht:\nAGILA Hau.: -29,59 EUR\nMarkt Alt.: -160,24 EUR\n\nneuer Saldo: 1.158,12 EUR"
results = []

def freeport():
    with socket.socket() as so:
        so.bind(("127.0.0.1", 0))
        return so.getsockname()[1]

PORT = freeport()
BASE = f"http://localhost:{PORT}/haushaltsbuch/"

def ok(name, cond, detail=""):
    results.append({"test": name, "ok": bool(cond), "detail": str(detail)})
    print(("OK   " if cond else "FAIL ") + name + (f" ({detail})" if detail else ""))

def plain(s):
    return s.replace("\u00a0", " ").replace("\n", " ")

def euro_cents(t):
    return int(round(float(t.replace("€", "").replace("\u00a0", "").replace(".", "").replace(",", ".").strip()) * 100))

async def device(p, name):
    ctx = await p.chromium.launch_persistent_context(tempfile.mkdtemp(prefix=name), headless=True, viewport={"width": 390, "height": 844},
        device_scale_factor=2, is_mobile=True, has_touch=True, locale="de-DE", accept_downloads=True,
        user_agent="Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Mobile Safari/537.36")
    page = ctx.pages[0] if ctx.pages else await ctx.new_page()
    errors = []
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    page.on("pageerror", lambda e: errors.append(str(e)))
    cdp = await ctx.new_cdp_session(page)
    await cdp.send("WebAuthn.enable", {"enableUI": False})
    await cdp.send("WebAuthn.addVirtualAuthenticator", {"options": {"protocol": "ctap2", "ctap2Version": "ctap2_1", "transport": "internal",
        "hasResidentKey": True, "hasUserVerification": True, "isUserVerified": True, "hasPrf": True, "automaticPresenceSimulation": True}})
    return ctx, page, errors

async def has(page, text, timeout=10000):
    try:
        await page.locator("main").get_by_text(text, exact=False).first.wait_for(timeout=timeout)
        return True
    except Exception:
        return False

async def unlock(page):
    await page.get_by_test_id("unlock-passkey").click()
    # nach dem Entsperren geht es zur gewünschten Seite zurück (Übersicht, Rücklagen, Statistik …)
    await page.wait_for_url(lambda u: "#/" in u and "#/entsperren" not in u and "#/einrichtung" not in u, timeout=15000)

async def balances(page):
    await page.goto(BASE + "#/start"); await page.wait_for_load_state()
    if "#/entsperren" in page.url: await unlock(page)
    await page.locator(".acc .row").first.wait_for()
    out = {}
    for t in await page.locator(".acc .row").all_inner_texts():
        parts = plain(t).split(" ")
        out[parts[0]] = " ".join(parts[-2:])
    return out

async def dismiss_welcome(page):
    """Nach einer Einrichtung von Hand: Willkommensauswahl schließen, falls sie erscheint."""
    try:
        await page.get_by_test_id("welcome").wait_for(timeout=2500)
        await page.get_by_test_id("welcome-self").click()
    except Exception:
        pass

async def setup(page, password=None, welcome="self"):
    await page.get_by_test_id("neu").click()
    await page.get_by_test_id("passkey").click()
    key = re.sub(r"\s+", "", await page.get_by_test_id("recovery-key").inner_text(timeout=15000))
    groups = key.split("-")
    await page.get_by_test_id("key-written").click()
    a = int(await page.get_by_test_id("group-a").get_attribute("data-group")); b = int(await page.get_by_test_id("group-b").get_attribute("data-group"))
    await page.get_by_test_id("group-a").fill(groups[a]); await page.get_by_test_id("group-b").fill(groups[b]); await page.get_by_test_id("check-key").click()
    if password:
        await page.get_by_test_id("pw1").fill(password); await page.get_by_test_id("pw2").fill(password); await page.get_by_test_id("finish-pw").click()
    else:
        await page.get_by_test_id("finish-nopw").click()
    await page.get_by_test_id("to-app").click(timeout=20000)
    # Erster Start: Willkommensauswahl; die bestehenden Tests schauen sich „selbst um“
    if welcome:
        await page.get_by_test_id("welcome").wait_for(timeout=10000)
        await page.get_by_test_id(f"welcome-{welcome}").click()
        await page.get_by_test_id("welcome").wait_for(state="detached", timeout=5000)
    return key

async def import_mail(page, text, choose=None):
    await page.goto(BASE + "#/neu"); await page.wait_for_load_state()
    await page.get_by_test_id("tab-email").click()
    await page.get_by_test_id("mail").fill(text)
    rows = page.locator(".import .row")
    await rows.first.wait_for()
    for i, (kind, a, b) in (choose or {}).items():
        if kind == "cat":
            await rows.nth(i).locator("[data-testid=cat]").select_option(a)
            if b: await rows.nth(i).locator("[data-testid=sub]").select_option(b)
        elif kind == "transfer":
            await page.get_by_test_id(f"transfer-{i}").select_option(a)
    await page.wait_for_timeout(150)
    return {
        "rows": [plain(await rows.nth(i).locator(".head").inner_text()) for i in range(await rows.count())],
        "gap": [plain(t) for t in await page.get_by_test_id("gap").all_inner_texts()],
        "warn": [plain(t) for t in await page.locator(".import p.warn").all_inner_texts()],
        "button": await page.get_by_test_id("import-commit").inner_text(),
    }

async def main():
    site = Path(tempfile.mkdtemp(prefix="site")) / "haushaltsbuch"
    site.mkdir(parents=True)
    for f in APP_FILES: shutil.copy(V01 / f, site / f)
    server = subprocess.Popen([sys.executable, "-m", "http.server", str(PORT), "--bind", "127.0.0.1"], cwd=site.parent, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(0.8)
    try:
        async with async_playwright() as p:
            a, page, errs = await device(p, "A")
            # ---------- Ausgangslage: installierte v0.1 ----------
            await page.goto(BASE); await page.wait_for_url(re.compile("#/einrichtung"))
            pw = "Hunde lieben Brennholz im Winter"
            key = await setup(page, pw, welcome=None)  # v0.1 kennt noch keine Willkommensauswahl
            await page.wait_for_function("navigator.serviceWorker && navigator.serviceWorker.controller !== null", timeout=20000)
            ok("v0.1 eingerichtet (Ausgangslage wie auf dem Handy)", await has(page, "Version 0.1"))

            # ---------- Update auf v0.2 ----------
            for f in APP_FILES: shutil.copy(DIST / f, site / f)
            await page.evaluate("navigator.serviceWorker.getRegistration().then((r) => r.update())")
            await page.get_by_text("Neue Version verfügbar").wait_for(timeout=20000)
            async with page.expect_navigation(timeout=20000):
                await page.get_by_role("button", name="Jetzt aktualisieren").click()
            await page.wait_for_url(re.compile("#/entsperren"), timeout=15000)
            await unlock(page)
            stores = await page.evaluate("new Promise((r) => { const q = indexedDB.open('haushaltsbuch'); q.onsuccess = () => r([...q.result.objectStoreNames]); })")
            ok("Update v0.1 → v0.2: Fingerabdruck gilt weiter, Testdaten entfernt", await has(page, "Noch keine Konten") and "testdata" not in stores and "accounts" in stores, ", ".join(stores))
            ver = "v" + json.loads((HERE.parent / "package.json").read_text())["version"].removesuffix(".0")
            ok(f"Kopfzeile zeigt {ver}", ver in await page.locator("header").inner_text())

            # ---------- Konten ----------
            for name, typ, ident, start, date in (("Girokonto", "giro", "1234", "1.500,00", "2026-11-10"), ("Tagesgeld", "tagesgeld", "5678", "4.850,00", "2026-11-10")):
                await page.get_by_test_id("acc-new").click()
                await page.get_by_test_id("acc-name").fill(name); await page.get_by_test_id("acc-type").select_option(typ)
                await page.get_by_test_id("acc-id").fill(ident); await page.get_by_test_id("acc-start").fill(start)
                await page.locator(".newbox input[type=date]").fill(date)
                await page.get_by_test_id("acc-save").click(); await page.wait_for_timeout(200)
            await page.get_by_test_id("acc-new").click(); await page.get_by_test_id("acc-name").fill("girokonto"); await page.get_by_test_id("acc-id").fill("1234")
            await page.get_by_test_id("acc-start").fill("1"); await page.get_by_test_id("acc-save").click()
            await page.get_by_role("alert").first.wait_for(timeout=5000)
            dupe = [plain(t) for t in await page.get_by_role("alert").all_inner_texts()]
            ok("Konto: doppelter Name und doppelte Kennung abgelehnt", len(dupe) == 2, "; ".join(dupe))
            await page.get_by_role("button", name="Abbrechen").click()
            bal = await balances(page)
            ok("Konten angelegt mit Startsaldo", bal == {"Girokonto": "1.500,00 €", "Tagesgeld": "4.850,00 €"}, bal)

            # ---------- Kontowecker-Import mit dem Beispiel der Nutzerin ----------
            r = await import_mail(page, MAIL, {0: ("cat", "a-versicherungen", "Tierversicherung"), 1: ("cat", "a-wasser-abwasser", None)})
            ok("Import: Konto *1234 erkannt, zwei Umsätze", len(r["rows"]) == 2 and await has(page, "Konto: Girokonto"), r["rows"])
            ok("Import: Lücke −152,05 € erkannt (Beispiel der Nutzerin)", r["gap"] and "-152,05 €" in r["gap"][0] and "1.310,17 €" in r["gap"][0], r["gap"])
            await page.get_by_test_id("import-commit").click(); await page.wait_for_url(re.compile("#/start"))
            bal = await balances(page)
            hint = [plain(t) for t in await page.locator(".hint-row").all_inner_texts()]
            ok("Import: Kontostand 1.158,12 € laut Bank, Hinweis auf der Übersicht", bal["Girokonto"] == "1.158,12 €" and any("-152,05 €" in h for h in hint), hint)
            r = await import_mail(page, MAIL)
            ok("Gleiche E-Mail nochmal: erkannt, Buchungen abgewählt", any("schon einmal übernommen" in w for w in r["warn"]) and all("schon vorhanden" in x for x in r["rows"]), r["button"])

            # ---------- Lücke per Korrekturbuchung schließen ----------
            await page.goto(BASE + "#/start"); await page.locator(".hint-row", has_text="Girokonto").click()
            await page.get_by_test_id("acc-correction").click(); await page.wait_for_timeout(300)
            bal = await balances(page)
            ok("Korrekturbuchung schließt die Lücke, Kontostand bleibt 1.158,12 €", await page.locator(".hint-row", has_text="Girokonto").count() == 0 and bal["Girokonto"] == "1.158,12 €")

            # ---------- Buchung von Hand mit Aufteilung ----------
            await page.goto(BASE + "#/neu"); await page.get_by_test_id("amount").fill("85,00"); await page.get_by_test_id("text").fill("REWE Einkauf")
            await page.locator("[data-testid=cat]").first.select_option("a-haushalt"); await page.locator("[data-testid=sub]").first.select_option("Lebensmittel")
            await page.get_by_test_id("split-toggle").click(); await page.get_by_test_id("split-0").fill("70,00")
            await page.locator("[data-testid=cat]").nth(1).select_option("a-haushalt"); await page.locator("[data-testid=sub]").nth(1).select_option("Drogerie")
            await page.get_by_test_id("split-1").fill("10,00"); await page.get_by_test_id("save").click()
            await page.get_by_role("alert").first.wait_for(timeout=5000)
            err = [plain(t) for t in await page.get_by_role("alert").all_inner_texts()]
            await page.get_by_test_id("split-1").fill("15,00"); await page.get_by_test_id("save").click(); await page.wait_for_url(re.compile("#/start"))
            bal = await balances(page)
            ok("Aufteilung: Fehlbetrag gemeldet, dann gespeichert", any("-5,00 €" in e for e in err) and bal["Girokonto"] == "1.073,12 €", bal["Girokonto"])

            # ---------- Doppelte Buchung von Hand ----------
            await page.goto(BASE + "#/neu"); await page.get_by_test_id("amount").fill("29,59"); await page.get_by_test_id("text").fill("AGILA Hau.")
            await page.get_by_test_id("text").blur(); await page.wait_for_timeout(200)
            suggested = await page.locator("[data-testid=cat]").input_value()
            ok("Regel aus dem Import schlägt die Kategorie beim Tippen vor", suggested == "a-versicherungen", suggested)
            await page.get_by_test_id("text").fill("AGILA HAUSTIERVERSICHERUNG AG")
            await page.get_by_test_id("save").click()
            try:
                await page.get_by_test_id("dup-warning").wait_for(timeout=5000); warned = True
            except Exception:
                warned = False
            ok("Doppelte Buchung von Hand wird erkannt (abgekürzter Bankentext)", warned)
            await page.get_by_role("button", name="Abbrechen").click()

            # ---------- Umbuchung ----------
            await page.goto(BASE + "#/neu"); await page.get_by_test_id("tab-umbuchung").click()
            await page.get_by_test_id("tr-amount").fill("500,00"); await page.get_by_test_id("tr-save").click(); await page.wait_for_url(re.compile("#/start"))
            bal = await balances(page)
            ok("Umbuchung Girokonto → Tagesgeld: beide Kontostände", bal == {"Girokonto": "573,12 €", "Tagesgeld": "5.350,00 €"}, bal)
            await page.goto(BASE + "#/buchungen"); await page.locator(".bk .row", has_text="Umbuchung nach Tagesgeld").click()
            await page.locator(".bk.open [data-testid=amount]").fill("400,00"); await page.locator(".bk.open [data-testid=save]").click(); await page.wait_for_timeout(300)
            bal = await balances(page)
            ok("Umbuchung bearbeiten ändert beide Seiten", bal == {"Girokonto": "673,12 €", "Tagesgeld": "5.250,00 €"}, bal)
            await page.goto(BASE + "#/buchungen"); await page.locator(".bk .row", has_text="Umbuchung von Girokonto").click()
            try:
                await page.get_by_role("button", name=re.compile("Umbuchung löschen")).click(timeout=5000)
            except Exception:
                await page.screenshot(path="/tmp/fail_transfer.png", full_page=True)
                raise
            await page.get_by_test_id("delete").click(); await page.wait_for_timeout(300)
            bal = await balances(page)
            ok("Umbuchung löschen entfernt beide Seiten", bal == {"Girokonto": "1.073,12 €", "Tagesgeld": "4.850,00 €"}, bal)

            # ---------- Umbuchung aus der E-Mail, Gemeinde-Regel nach Betrag, Zu prüfen ----------
            r = await import_mail(page, "auf dem Konto *1234 wurden folgende Umsätze verbucht:\nÜbertrag Tagesgeld: -200,00 EUR\nMarkt Alt.: -120,00 EUR\nUnbekannt GmbH: -9,99 EUR\n\nneuer Saldo: 743,13 EUR",
                                  {0: ("transfer", None, None), 1: ("cat", "a-steuern-gebuehren", "Grundsteuer")})
            tg = await page.locator("[data-testid=transfer-0] option").all_inner_texts()
            await page.get_by_test_id("transfer-0").select_option(label=[t for t in tg if "Tagesgeld" in t][0]); await page.wait_for_timeout(150)
            r2 = [plain(await page.locator(".import .row").nth(i).locator(".head").inner_text()) for i in range(3)]
            ok("Import: Zeile als Umbuchung markierbar, Saldo geht auf", "Umbuchung" in r2[0] and await page.get_by_test_id("gap").count() == 0, r2)
            await page.get_by_test_id("import-commit").click(); await page.wait_for_url(re.compile("#/start"))
            bal = await balances(page)
            ok("Umbuchung aus E-Mail bucht die Gegenseite aufs Tagesgeld", bal == {"Girokonto": "743,13 €", "Tagesgeld": "5.050,00 €"}, bal)
            ok("Nicht zugeordnete Buchung erscheint als Hinweis „Zu prüfen“", await page.get_by_test_id("hint-unclear").count() == 1)
            await page.get_by_test_id("hint-unclear").click(); await page.wait_for_url(re.compile("#/buchungen"))
            await page.locator(".bk .t").first.wait_for(timeout=10000)
            ok("Filter „Zu prüfen“ zeigt genau diese Buchung", [t for t in await page.locator(".bk .t").all_inner_texts()] == ["Unbekannt GmbH"])
            await page.goto(BASE + "#/neu"); await page.get_by_test_id("amount").fill("158,00"); await page.get_by_test_id("text").fill("Markt Alt."); await page.get_by_test_id("text").blur(); await page.wait_for_timeout(150)
            wasser = await page.locator("[data-testid=cat]").input_value()
            await page.get_by_test_id("amount").fill("121,50"); await page.locator("[data-testid=cat]").select_option("a-andere")
            ok("Gemeinde-Regel: 158,00 € → Wasser & Abwasser (120,00 € war Grundsteuer)", wasser == "a-wasser-abwasser", wasser)

            # ---------- Altdaten aus der alten App (XLSX) ----------
            before = await balances(page)
            await page.goto(BASE + "#/einstellungen"); await page.get_by_test_id("to-import").click(); await page.wait_for_url(re.compile("#/import"))
            await page.get_by_test_id("xlsx-file").set_input_files(str(HERE.parent / "test-data" / "altdaten-beispiel.xlsx"))
            await page.get_by_test_id("legacy-summary").wait_for(timeout=10000)
            await page.get_by_test_id("acc-map-Sondertilg 1250").select_option(label="Tagesgeld (*5678)")
            cards = page.locator(".grp")
            async def map_group(title, cat, sub=None):
                g = cards.filter(has_text=title).first
                await g.locator("[data-testid=cat]").first.select_option(cat)
                if sub: await g.locator("[data-testid=sub]").first.select_option(sub)
            await map_group("Ausgaben: Versicherung", "a-versicherungen")
            await map_group("Ausgaben: Nebenkosten", "a-wasser-abwasser")
            await map_group("Ausgaben: Lebensmittel", "a-haushalt", "Lebensmittel")
            await map_group("Ausgaben: Haus", "a-holz")
            await map_group("Einnahmen: Gehalt", "e-gehalt")
            await page.get_by_test_id("tr-ausgabe|Sparen").select_option(label="nach Tagesgeld")
            auto = await cards.filter(has_text="Ausgaben: Haushalt › Drogerie").first.locator("[data-testid=sub]").first.input_value()
            ok("Altdaten: unsere Kategorienamen in Spalte B werden von selbst zugeordnet", auto == "Drogerie", auto)
            g = cards.filter(has_text="Ausgaben: Nebenkosten").first
            await g.get_by_role("button", name=re.compile("Nach Kommentar unterscheiden")).click()
            await g.locator(".cm-row", has_text="Grundsteuer").wait_for(timeout=5000)
            texts = await g.locator(".cm-row").all_inner_texts()
            row = g.locator(".cm app-category-picker").nth(next(i for i, t in enumerate(texts) if "Grundsteuer" in t))
            await row.locator("[data-testid=cat]").select_option("a-steuern-gebuehren"); await row.locator("[data-testid=sub]").select_option("Grundsteuer")
            await page.wait_for_timeout(200)
            summary = {k: await page.get_by_test_id(k).inner_text() for k in ("sum-import", "sum-after", "sum-dup", "sum-uncat")}
            ok("Altdaten: Datei gelesen, Konten und Kategorien zugeordnet", summary == {"sum-import": "12", "sum-after": "1", "sum-dup": "0", "sum-uncat": "0"}, summary)
            await page.get_by_test_id("legacy-commit").click(); await page.wait_for_url(re.compile("#/start"))
            after = await balances(page)
            ok("Altdaten: Kontostände bleiben unverändert (Buchungen vor dem Startsaldo)", after == before, after)
            await page.goto(BASE + "#/buchungen"); await page.get_by_role("button", name=re.compile("Ältere Buchungen")).click(); await page.wait_for_timeout(200)
            older = [plain(t) for t in await page.locator(".bk .row").all_inner_texts()]
            gs = next((t for t in older if t.startswith("Grundsteuer ")), "")
            ok("Altdaten: Buchungen mit Kategorie und Ausnahme nach Kommentar in der Liste", any("Brennholz Maier" in t and "Holz" in t for t in older) and "Steuern & Gebühren › Grundsteuer" in gs and any("Sparrate" in t and "Umbuchung" in t for t in older) and any(t.startswith("Tagesgeld Urlaub") and "Umbuchung nach Tagesgeld" in t for t in older), gs)
            await page.goto(BASE + "#/import"); await page.get_by_test_id("xlsx-file").set_input_files(str(HERE.parent / "test-data" / "altdaten-beispiel.xlsx"))
            await page.get_by_test_id("legacy-summary").wait_for(timeout=10000)
            again = {k: await page.get_by_test_id(k).inner_text() for k in ("sum-import", "sum-dup")}
            remembered = await cards.filter(has_text="Ausgaben: Haus").first.locator("[data-testid=cat]").first.input_value()
            ok("Altdaten: zweiter Import bringt nichts doppelt, Zuordnungen sind gemerkt", again == {"sum-import": "0", "sum-dup": "12"} and remembered == "a-holz", (again, remembered))

            # ---------- Vorherigen Import ersetzen ----------
            await page.get_by_test_id("replace-legacy").click(); await page.wait_for_timeout(200)
            repl = {k: await page.get_by_test_id(k).inner_text() for k in ("sum-import", "sum-dup")}
            await page.get_by_test_id("legacy-commit").click(); await page.wait_for_url(re.compile("#/start"))
            ok("Altdaten: „Vorherigen Import ersetzen“ spielt die Datei sauber neu ein", repl == {"sum-import": "12", "sum-dup": "0"} and await balances(page) == before, repl)
            await page.goto(BASE + "#/buchungen"); await page.get_by_role("button", name=re.compile("Ältere Buchungen")).click(); await page.wait_for_timeout(200)
            ok("Altdaten: nach dem Ersetzen nichts doppelt", sum(1 for t in [plain(x) for x in await page.locator(".bk .t").all_inner_texts()] if t == "Brennholz Maier") == 1)

            # ---------- Stapelverarbeitung ----------
            await page.goto(BASE + "#/buchungen"); await page.get_by_test_id("filter-check").click()
            await page.get_by_test_id("select-mode").click(); await page.get_by_test_id("select-all").click()
            await page.get_by_test_id("batch-panel").locator("[data-testid=cat]").select_option("a-andere")
            await page.get_by_test_id("batch-assign").click(); await page.wait_for_timeout(300)
            await page.goto(BASE + "#/start"); await page.wait_for_timeout(200)
            ok("Stapel: alle „Zu prüfen“ auf einmal zugeordnet", await page.get_by_test_id("hint-unclear").count() == 0)
            await page.goto(BASE + "#/buchungen"); await page.get_by_test_id("search").fill("dm"); await page.wait_for_timeout(200)
            await page.get_by_test_id("select-mode").click(); await page.get_by_test_id("select-all").click()
            await page.get_by_test_id("batch-target").select_option(label="Tagesgeld"); await page.get_by_test_id("batch-transfer").click(); await page.wait_for_timeout(300)
            await page.get_by_test_id("search").fill("Umbuchung von Girokonto"); await page.wait_for_timeout(200)
            conv = [plain(t) for t in await page.locator(".bk .row").all_inner_texts()]
            ok("Stapel: Ausgabe in Umbuchung aufs Tagesgeld umgewandelt, Kontostände unverändert (vor Startsaldo)", any("5,00 €" in t for t in conv) and await balances(page) == before, conv[:2])

            # ---------- Übersicht und Statistik (v0.4) ----------
            await page.goto(BASE + "#/start"); await page.get_by_test_id("month-card").wait_for(timeout=10000)
            m_vals = [plain(await page.get_by_test_id(f"m-{k}").inner_text()) for k in ("income", "fix", "konsum", "finanzierung", "sparen", "free")]
            ok("Übersicht: Karte „Dieser Monat“ in Säulen und Backup-Erinnerung", await page.get_by_test_id("hint-backup").count() == 1, m_vals)
            await page.get_by_test_id("nav-statistik").click(); await page.wait_for_url(re.compile("#/statistik"))
            await page.get_by_test_id("kpi-fix").wait_for()
            k_vals = [plain(await page.get_by_test_id(f"kpi-{k}").inner_text()) for k in ("income", "fix", "konsum", "finanzierung", "sparen", "free")]
            ok("Statistik: Monat stimmt in allen Säulen mit der Übersicht überein", k_vals == m_vals, k_vals)
            await page.get_by_test_id("stat-year").click(); await page.locator(".mb").first.wait_for()
            await page.locator("button.mb").filter(has_text="Okt").click(); await page.wait_for_timeout(200)
            label = await page.get_by_test_id("stat-label").inner_text()
            await page.get_by_test_id("cat-fix|a-haushalt").click(); await page.locator(".sub .bar").first.click(); await page.wait_for_timeout(200)
            items = [plain(t) for t in await page.locator(".items li").all_inner_texts()]
            ok("Statistik: Jahresbalken öffnen den Monat, Kategorie bis zur Buchung aufklappbar", label == "Oktober 2026" and len(items) > 0, (label, items[:2]))
            await page.get_by_test_id("stat-prev").click(); await page.wait_for_timeout(200)
            ok("Statistik: Blättern zum Vormonat", await page.get_by_test_id("stat-label").inner_text() == "September 2026")
            sav = plain(await page.get_by_test_id("kpi-sparen").inner_text())
            await page.get_by_test_id("stat-next").click(); await page.wait_for_timeout(200)
            sav_okt = plain(await page.get_by_test_id("kpi-sparen").inner_text())
            ok("Statistik: Umbuchungen aufs Tagesgeld zählen als Sparbewegung (Oktober)", sav_okt not in ("0,00 €",), (sav, sav_okt))

            # ---------- Sperren, Schnellzugriff, Offline ----------
            await page.goto(BASE + "#/start"); await page.get_by_role("button", name="Jetzt sperren").click()
            await page.goto(BASE + "?start=neue-buchung"); await page.wait_for_url(re.compile(r"ziel=%2Fneu")); await unlock(page)
            ok("Schnellzugriff „Neue Buchung“ nach dem Entsperren", page.url.endswith("#/neu"))
            await page.get_by_test_id("amount").fill("29,59"); await page.get_by_test_id("text").fill("AGILA Hau."); await page.get_by_test_id("text").blur(); await page.wait_for_timeout(200)
            ok("Gelernte Regeln gelten auch nach Sperren und Entsperren", await page.locator("[data-testid=cat]").input_value() == "a-versicherungen")
            await page.wait_for_function("navigator.serviceWorker.controller !== null", timeout=20000)
            await a.set_offline(True)
            await page.goto(BASE + "#/start"); await page.reload(); await page.wait_for_url(re.compile("#/entsperren")); await unlock(page)
            bal = await balances(page)
            ok("Offline: entsperren, Daten vollständig", bal == {"Girokonto": "743,13 €", "Tagesgeld": "5.050,00 €"}, bal)
            await a.set_offline(False)

            # ---------- Backup und Wiederherstellung ----------
            await page.goto(BASE + "#/einstellungen"); await page.wait_for_load_state()
            if "#/entsperren" in page.url: await unlock(page); await page.goto(BASE + "#/einstellungen")
            async with page.expect_download() as dl:
                await page.get_by_test_id("backup-download").click()
            d = await dl.value
            bpath = Path(tempfile.mkdtemp()) / d.suggested_filename
            await d.save_as(bpath)
            raw = bpath.read_text(encoding="utf-8")
            res = subprocess.run([sys.executable, str(HERE.parent / "docs" / "restore.py"), str(bpath)], input=key + "\n", capture_output=True, text=True, env={**os.environ, "PYTHONIOENCODING": "utf-8"})
            plainjson = bpath.with_suffix(".json").read_text(encoding="utf-8") if bpath.with_suffix(".json").exists() else ""
            await page.goto(BASE + "#/start"); await page.wait_for_timeout(500)
            await page.get_by_test_id("month-card").wait_for(timeout=10000)
            ok("Nach dem Backup verschwindet die Backup-Erinnerung", await page.get_by_test_id("hint-backup").count() == 0)
            ok("Backup verschlüsselt; restore.py öffnet Konten und Buchungen", "AGILA" not in raw and res.returncode == 0 and "Girokonto" in plainjson and "AGILA Hau." in plainjson and "MARKT ALT." in plainjson)
            b, pb, errs_b = await device(p, "B")
            await pb.goto(BASE); await pb.wait_for_url(re.compile("#/einrichtung"))
            await pb.get_by_test_id("restore").click(); await pb.set_input_files("#backupFile", str(bpath))
            await pb.get_by_test_id("restore-key").fill(key); await pb.get_by_test_id("open-backup").click()
            await pb.get_by_test_id("passkey").click(); await pb.get_by_test_id("finish-nopw").click(timeout=15000)
            await pb.get_by_test_id("to-app").click(timeout=20000); await pb.wait_for_url(re.compile("#/start"))
            await dismiss_welcome(pb)
            await pb.wait_for_timeout(600)
            ok("Nach „Backup einspielen“ keine Willkommensauswahl (kein erster Start)", await pb.get_by_test_id("welcome").count() == 0, "")
            bal_b = await balances(pb)
            ok("Zweites Gerät: Backup eingespielt, gleiche Kontostände", bal_b == {"Girokonto": "743,13 €", "Tagesgeld": "5.050,00 €"}, bal_b)
            await pb.goto(BASE + "#/einstellungen"); await pb.locator(".rule").first.wait_for(timeout=10000)
            ok("Zweites Gerät: gelernte Regeln sind mitgekommen", await pb.locator(".rule").count() >= 3, await pb.locator(".rule").count())
            await b.close()

            # ---------- Eigene Gruppen für Kredite und Bausparen (v0.5.1) ----------
            await page.goto(BASE + "#/neu"); await page.get_by_test_id("amount").fill("780,00"); await page.get_by_test_id("text").fill("Kreditrate Hauskredit Sparkasse")
            await page.locator("[data-testid=cat]").select_option("a-kredite"); await page.get_by_test_id("save").click(); await page.wait_for_url(re.compile("#/start"))
            await page.goto(BASE + "#/einstellungen"); await page.get_by_test_id("stat-groups").wait_for()
            await page.get_by_test_id("loan-label-HAUSKREDIT SPARKASSE").fill("Hauskredit")
            await page.get_by_test_id("group-add").click(); await page.get_by_test_id("group-name-0").fill("Hausfinanzierung")
            await page.get_by_test_id("member-0-Hauskredit").click(); await page.get_by_test_id("member-0-Tagesgeld").click()
            await page.get_by_test_id("groups-save").click(); await page.wait_for_timeout(300)
            def euro_val(t):
                m = re.search(r"(-?[\d.]+,\d{2}) €", t)
                return float(m.group(1).replace(".", "").replace(",", ".")) if m else 0.0
            await page.goto(BASE + "#/statistik"); await page.get_by_test_id("pillar-finanzierung").wait_for(timeout=10000)
            fin = page.get_by_test_id("pillar-finanzierung")
            fin_bars = [plain(t) for t in await fin.locator("button.bar").all_inner_texts()]
            await fin.locator("button.bar", has_text="Hausfinanzierung").first.click(); await page.wait_for_timeout(200)
            parts = [plain(t) for t in await fin.locator(".sub .bar").all_inner_texts()]
            fin_kpi = euro_val(plain(await page.get_by_test_id("kpi-finanzierung").inner_text()))
            top = [t for t in fin_bars if not t.startswith(("Hauskredit", "Tagesgeld"))]
            sav_txt = plain(await page.get_by_test_id("pillar-sparen").inner_text()) if await page.get_by_test_id("pillar-sparen").count() else ""
            ok("Statistik: Gruppe „Hausfinanzierung“ in der Säule Finanzierung, Bestandteile nicht doppelt",
               any(t.startswith("Hausfinanzierung 980,00 €") for t in fin_bars) and any(t.startswith("Hauskredit 780,00 €") for t in parts) and any(t.startswith("Tagesgeld 200,00 €") for t in parts)
               and not any(t.startswith("Kredite") for t in fin_bars) and "Tagesgeld" not in sav_txt and abs(sum(euro_val(t) for t in top) - fin_kpi) < 0.01, (fin_bars, parts, fin_kpi))
            await page.goto(BASE + "#/einstellungen"); await page.get_by_test_id("group-counts-0").select_option("sparen"); await page.get_by_test_id("groups-save").click(); await page.wait_for_timeout(300)
            await page.goto(BASE + "#/statistik"); await page.get_by_test_id("kpi-fix").wait_for(); await page.wait_for_timeout(200)
            sav2 = plain(await page.get_by_test_id("pillar-sparen").inner_text()) if await page.get_by_test_id("pillar-sparen").count() else ""
            fin2 = plain(await page.get_by_test_id("pillar-finanzierung").inner_text()) if await page.get_by_test_id("pillar-finanzierung").count() else ""
            ok("Statistik: Gruppe auf „Sparen“ gestellt steht unter Sparen", "Hausfinanzierung" in sav2 and "Hausfinanzierung" not in fin2, (sav2[:80], fin2[:80]))
            await page.goto(BASE + "#/einstellungen"); await page.get_by_test_id("group-counts-0").select_option("finanzierung"); await page.get_by_test_id("groups-save").click(); await page.wait_for_timeout(300)
            await page.get_by_test_id("pillar-a-haushalt").select_option("konsum"); await page.get_by_test_id("pillars-save").click(); await page.wait_for_timeout(300)
            await page.goto(BASE + "#/statistik"); await page.get_by_test_id("kpi-fix").wait_for(); await page.wait_for_timeout(200)
            moved = await page.get_by_test_id("cat-konsum|a-haushalt").count() == 1 and await page.get_by_test_id("cat-fix|a-haushalt").count() == 0
            await page.goto(BASE + "#/einstellungen"); await page.get_by_role("button", name="Voreinstellung wiederherstellen").click(); await page.get_by_test_id("pillars-save").click(); await page.wait_for_timeout(300)
            await page.goto(BASE + "#/statistik"); await page.get_by_test_id("kpi-fix").wait_for(); await page.wait_for_timeout(200)
            back = await page.get_by_test_id("cat-fix|a-haushalt").count() == 1
            ok("Einstellungen: Säule einer Kategorie umstellbar und zurücksetzbar (Haushalt Fixkosten ↔ Konsum)", moved and back, (moved, back))
            await page.get_by_role("button", name="Jetzt sperren").click(); await unlock(page)
            await page.goto(BASE + "#/statistik"); await page.get_by_test_id("kpi-fix").wait_for(); await page.wait_for_timeout(300)
            ok("Statistik-Gruppen bleiben nach Sperren und Entsperren erhalten", await page.get_by_test_id("pillar-finanzierung").locator("button.bar", has_text="Hausfinanzierung").count() == 1)

            # ---------- Buchung von Hand als wiederkehrend einplanen (v0.5.2) ----------
            await page.goto(BASE + "#/buchungen"); await page.get_by_test_id("search").fill("Gehalt Sandra"); await page.wait_for_timeout(200)
            await page.locator(".bk .row", has_text="Gehalt Sandra").first.click()
            await page.locator(".bk.open [data-testid=rec-on]").click(); await page.wait_for_timeout(100)
            rec_day = await page.locator(".bk.open [data-testid=rec-day]").input_value()
            await page.locator(".bk.open [data-testid=save]").click(); await page.wait_for_timeout(300)
            await page.goto(BASE + "#/buchungen?ansicht=wiederkehrend"); await page.locator(".it .row").first.wait_for(timeout=10000)
            planned = [plain(t) for t in await page.locator(".it .row").all_inner_texts()]
            await page.goto(BASE + "#/start"); await page.get_by_test_id("verdict").wait_for(); await page.locator(".calc summary").click(); await page.wait_for_timeout(150)
            calc = plain(await page.locator(".calc").inner_text())
            ok("Buchung als wiederkehrend eingeplant: Gehalt am 30. → Termin am 1., Prognose rechnet danach", rec_day == "1" and any("Gehalt Sandra" in t and "monatlich am 1." in t for t in planned) and "nach „Gehalt Sandra" in calc, (rec_day, planned[:1], calc[:200]))
            await page.goto(BASE + "#/buchungen"); await page.get_by_test_id("search").fill("Gehalt Sandra"); await page.wait_for_timeout(200)
            await page.locator(".bk .row", has_text="Gehalt Sandra").first.click()
            try:
                await page.locator(".bk.open [data-testid=planned-as]").wait_for(timeout=5000); shown = True
            except Exception:
                shown = False
            ok("Die Buchung zeigt, dass sie eingeplant ist (kein zweiter Posten)", shown)

            # ---------- Prognose, Wiederkehrend, Verträge, Kalender (v0.5) ----------
            import openpyxl, datetime
            today = datetime.date.today()
            def prev_bank(d):
                while d.weekday() >= 5: d -= datetime.timedelta(days=1)
                return d
            def next_bank(d):
                while d.weekday() >= 5: d += datetime.timedelta(days=1)
                return d
            def month_add(y, m, k):
                t = y * 12 + m - 1 + k
                return t // 12, t % 12 + 1
            wb = openpyxl.Workbook(); wa = wb.active; wa.title = "Ausgaben"; wa.append(["Ausgaben"]); wa.append(["Datum"])
            we = wb.create_sheet("Einnahmen"); we.append(["Einnahmen"]); we.append(["Datum"])
            dt = lambda d: datetime.datetime.combine(d, datetime.time())
            def put(sheet, d, row):
                if d < today: sheet.append([dt(d)] + row)
            for k in range(-14, 2):
                y, m = month_add(today.year, today.month, k)
                put(we, prev_bank(datetime.date(y, m, 1)), ["Gehalt", "Girokonto", 2450, "EUR", "", "", "", "GEHALT SANDRA"])
                put(wa, next_bank(datetime.date(y, m, 13)), ["Versicherung", "Girokonto", 29.59, "EUR", "", "", "", "AGILA Hau."])
                put(wa, next_bank(datetime.date(y, m, 13)), ["Abos", "Girokonto", 13.99 if k == 0 else 12.99, "EUR", "", "", "", "NETFLIX.COM"])
                put(wa, next_bank(datetime.date(y, m, 2)), ["Strom", "Girokonto", 89, "EUR", "", "", "", "STADTWERKE STROM"])
                for wd, amt in ((4, 61.2), (11, 48.9), (18, 72.35), (25, 55.1)):
                    put(wa, datetime.date(y, m, wd), ["Lebensmittel", "Girokonto", amt + k, "EUR", "", "", "", "REWE MARKT"])
                if m in (2, 5, 8, 11) and k < 0:
                    put(wa, next_bank(datetime.date(y, m, 15)), ["Nebenkosten", "Girokonto", 160.24, "EUR", "", "", "", "Markt Alt."])
            hist = Path(tempfile.mkdtemp()) / "prognose.xlsx"; wb.save(hist)
            dd, pd_, errs_d = await device(p, "D")
            await pd_.goto(BASE); await pd_.wait_for_url(re.compile("#/einrichtung")); await setup(pd_)
            await pd_.get_by_test_id("acc-new").click(); await pd_.get_by_test_id("acc-name").fill("Girokonto"); await pd_.get_by_test_id("acc-start").fill("1.500,00"); await pd_.get_by_test_id("acc-save").click(); await pd_.wait_for_timeout(300)
            await pd_.goto(BASE + "#/import"); await pd_.get_by_test_id("xlsx-file").set_input_files(str(hist)); await pd_.get_by_test_id("legacy-summary").wait_for(timeout=20000)
            for title, cat in (("Ausgaben: Versicherung", "a-versicherungen"), ("Ausgaben: Abos", "a-abos-streaming"), ("Ausgaben: Strom", "a-strom"), ("Ausgaben: Lebensmittel", "a-haushalt"), ("Ausgaben: Nebenkosten", "a-wasser-abwasser"), ("Einnahmen: Gehalt", "e-gehalt")):
                await pd_.locator(".grp").filter(has_text=title).first.locator("[data-testid=cat]").first.select_option(cat)
            await pd_.wait_for_timeout(200)
            await pd_.get_by_test_id("legacy-commit").click(); await pd_.wait_for_url(re.compile("#/start"))
            await pd_.get_by_test_id("hint-recurring").click(); await pd_.wait_for_url(re.compile("ansicht=wiederkehrend"))
            await pd_.locator(".sug strong").first.wait_for(timeout=10000); await pd_.wait_for_timeout(200)
            sug = [plain(t) for t in await pd_.locator(".sug strong").all_inner_texts()]
            ok("Prognose: regelmäßige Zahlungen erkannt, Einkäufe nicht", {"GEHALT SANDRA", "AGILA Hau.", "NETFLIX.COM", "STADTWERKE STROM", "Markt Alt."} <= set(sug) and "REWE MARKT" not in sug, sug)
            await pd_.get_by_test_id("rec-confirm-all").click(); await pd_.wait_for_timeout(300)
            await pd_.goto(BASE + "#/start"); await pd_.get_by_test_id("verdict").wait_for()
            verdict = plain(await pd_.get_by_test_id("verdict").inner_text())
            overdue = plain(await pd_.get_by_test_id("overdue").inner_text()) if await pd_.get_by_test_id("overdue").count() else ""
            ok("Prognose: Leitaussage bis zum nächsten Gehalt", "Gehalt am" in verdict or "ins Minus" in verdict, verdict)
            quarter_due = today.month in (2, 5, 8, 11) and next_bank(datetime.date(today.year, today.month, 15)) < today
            ok("Prognose: nur die fehlende Quartalsabbuchung ist überfällig", ("Markt Alt." in overdue) == quarter_due and "GEHALT" not in overdue and "AGILA" not in overdue, overdue)
            notices = [plain(t) for t in await pd_.get_by_test_id("hint-notice").all_inner_texts()]
            ok("Preisalarm: Netflix teurer, Strom (verbrauchsabhängig) nicht", any("NETFLIX" in t and "Preiserhöhung" in t for t in notices) and not any("STROM" in t for t in notices), notices)
            await pd_.goto(BASE + "#/buchungen?ansicht=wiederkehrend"); await pd_.get_by_test_id("rec-STADTWERKE STROM").click()
            await pd_.get_by_test_id("rec-contract").click()
            until = (today + datetime.timedelta(days=40)).isoformat()
            await pd_.get_by_test_id("rec-until").fill(until); await pd_.get_by_test_id("rec-save").click(); await pd_.wait_for_timeout(300)
            await pd_.get_by_test_id("rec-NETFLIX.COM").click(); await pd_.get_by_test_id("price-ack").click(); await pd_.wait_for_timeout(300)
            await pd_.goto(BASE + "#/start"); await pd_.get_by_test_id("verdict").wait_for()
            notices = [plain(t) for t in await pd_.get_by_test_id("hint-notice").all_inner_texts()]
            ok("Vertrag: Kündigungsfrist erscheint als Hinweis, quittierter Preisalarm verschwindet", any("Kündigung bis" in t for t in notices) and not any("NETFLIX" in t for t in notices), notices)
            await pd_.goto(BASE + "#/buchungen?ansicht=kalender"); await pd_.get_by_test_id("cal-label").wait_for()
            ny, nm = month_add(today.year, today.month, 1)
            sal = prev_bank(datetime.date(ny, nm, 1)).isoformat()
            if sal[:7] != today.isoformat()[:7]:
                await pd_.locator(".nav button").nth(1).click(); await pd_.wait_for_timeout(200)
            cell = plain(await pd_.get_by_test_id(f"cal-{sal}").inner_text()) if await pd_.get_by_test_id(f"cal-{sal}").count() else ""
            ok("Kalender: nächstes Gehalt ist eingeplant", "+2.450" in cell, (sal, cell))
            await pd_.goto(BASE + "#/einstellungen"); await pd_.get_by_test_id("prudence").select_option("vorsichtig"); await pd_.wait_for_timeout(200)
            await pd_.goto(BASE + "#/start"); await pd_.get_by_test_id("verdict").wait_for()
            await pd_.locator(".calc summary").click(); await pd_.wait_for_timeout(150)
            ok("Vorsichtsstufe umstellbar (Rechenweg zeigt sie)", "vorsichtig" in (await pd_.locator(".calc").inner_text()))
            await pd_.screenshot(path="/tmp/fc_0.png", full_page=True)
            await dd.close()

            # ---------- Liquiditätsabgleich, Umbuchung, Spartöpfe (v0.6) ----------
            wb = openpyxl.Workbook(); wa = wb.active; wa.title = "Ausgaben"; wa.append(["Ausgaben"]); wa.append(["Datum"])
            we = wb.create_sheet("Einnahmen"); we.append(["Einnahmen"]); we.append(["Datum"])
            nm_y, nm_m = month_add(today.year, today.month, 1)
            for k in range(-14, 1):
                y, m = month_add(today.year, today.month, k)
                put(we, prev_bank(datetime.date(y, m, 1)), ["Gehalt", "Girokonto", 2450, "EUR", "", "", "", "GEHALT SANDRA"])
                put(wa, next_bank(datetime.date(y, m, 13)), ["Versicherung", "Girokonto", 29.59, "EUR", "", "", "", "AGILA Hau."])
                for wd, amt in ((4, 120.0), (11, 135.0), (18, 128.0), (25, 141.0)):
                    put(wa, datetime.date(y, m, wd), ["Lebensmittel", "Girokonto", amt, "EUR", "", "", "", "REWE MARKT"])
            for yy in (nm_y - 2, nm_y - 1):
                put(wa, next_bank(datetime.date(yy, nm_m, 5)), ["Kfz", "Girokonto", 600, "EUR", "", "", "", "HUK KFZ VERSICHERUNG"])
            wt = wb.create_sheet("Überweisungen"); wt.append(["Überweisungen"]); wt.append(["Datum"])
            for k in range(-14, 1):
                y, m = month_add(today.year, today.month, k)
                put(wt, next_bank(datetime.date(y, m, 2)), ["Girokonto", "Rücklagen", 150, "EUR", "", "", "", "Dauerauftrag Rücklagen"])
            liq = Path(tempfile.mkdtemp()) / "liquiditaet.xlsx"; wb.save(liq)
            de_, pe, errs_e = await device(p, "E")
            await pe.goto(BASE); await pe.wait_for_url(re.compile("#/einrichtung")); await setup(pe)
            for name, typ, ident, start in (("Girokonto", "giro", "1234", "300,00"), ("Rücklagen", "tagesgeld", "5678", "4.850,00")):
                await pe.get_by_test_id("acc-new").click(); await pe.get_by_test_id("acc-name").fill(name); await pe.get_by_test_id("acc-type").select_option(typ)
                await pe.get_by_test_id("acc-id").fill(ident); await pe.get_by_test_id("acc-start").fill(start); await pe.get_by_test_id("acc-save").click(); await pe.wait_for_timeout(250)
            await pe.goto(BASE + "#/import"); await pe.get_by_test_id("xlsx-file").set_input_files(str(liq)); await pe.get_by_test_id("legacy-summary").wait_for(timeout=20000)
            for title, cat in (("Ausgaben: Versicherung", "a-versicherungen"), ("Ausgaben: Lebensmittel", "a-haushalt"), ("Ausgaben: Kfz", "a-versicherungen"), ("Einnahmen: Gehalt", "e-gehalt")):
                await pe.locator(".grp").filter(has_text=title).first.locator("[data-testid=cat]").first.select_option(cat)
            await pe.wait_for_timeout(200); await pe.get_by_test_id("legacy-commit").click(); await pe.wait_for_url(re.compile("#/start"))
            await pe.get_by_test_id("hint-backup").wait_for(timeout=10000)
            big = plain(await pe.get_by_test_id("hint-backup").inner_text())
            async with pe.expect_download() as dl_e:
                await pe.get_by_test_id("hint-backup-run").click()
            await dl_e.value; await pe.wait_for_timeout(300)
            ok("Backup-Erinnerung nach dem Import, ein Tipp sichert, danach ist sie weg", "größere Änderungen" in big and await pe.get_by_test_id("hint-backup").count() == 0, big[:90])
            await pe.goto(BASE + "#/buchungen?ansicht=wiederkehrend"); await pe.get_by_test_id("rec-confirm-all").click(); await pe.wait_for_timeout(300)
            await pe.goto(BASE + "#/start"); await pe.get_by_test_id("advice").wait_for(timeout=10000)
            title1 = plain(await pe.get_by_test_id("advice-title").inner_text())
            await pe.screenshot(path="/tmp/liq_1.png", full_page=True)
            ok("Abgleich: Umbuchung vom Tagesgeld empfohlen, mit Betrag und Termin", ("Umbuchung empfohlen" in title1 and "spätestens" in title1) or "Jetzt umbuchen" in title1, title1)
            # Spartopf für die Kfz-Versicherung
            await pe.get_by_test_id("nav-ruecklagen").click(); await pe.wait_for_url(re.compile("#/ruecklagen"))
            await pe.get_by_test_id("pot-new").click(); await pe.get_by_test_id("pot-kind").select_option("jahr")
            opts = await pe.locator("[data-testid=pot-recurring] option").all_inner_texts()
            await pe.get_by_test_id("pot-recurring").select_option(label=next(o for o in opts if "HUK" in o))
            await pe.get_by_test_id("pot-name").fill("Kfz-Versicherung"); await pe.get_by_test_id("pot-balance").fill("500,00"); await pe.get_by_test_id("pot-save").click(); await pe.wait_for_timeout(300)
            await pe.screenshot(path="/tmp/liq_2.png", full_page=True)
            pots_sum = plain(await pe.get_by_test_id("pots-sum").inner_text()); free = plain(await pe.get_by_test_id("pots-free").inner_text()); rate = plain(await pe.get_by_test_id("rate-sum").inner_text())
            ok("Rücklagen: Jahreszahlungs-Topf mit Rate 50 €, Aufteilung des Tagesgelds", pots_sum == "500,00 €" and free == "4.340,00 €" and rate == "50,00 €", (pots_sum, free, rate))
            await pe.get_by_test_id("pot-new").click(); await pe.get_by_test_id("pot-kind").select_option("ziel"); await pe.get_by_test_id("pot-name").fill("Zu viel")
            await pe.get_by_test_id("pot-target").fill("9.000,00"); await pe.get_by_test_id("pot-due").fill((today + datetime.timedelta(days=200)).isoformat()); await pe.get_by_test_id("pot-balance").fill("9.000,00"); await pe.get_by_test_id("pot-save").click()
            await pe.get_by_role("alert").first.wait_for(timeout=5000)
            ok("Rücklagen: mehr als der freie Teil lässt sich nicht zuteilen", "frei" in plain(await pe.get_by_role("alert").first.inner_text()))
            await pe.get_by_role("button", name="Abbrechen").click()
            await pe.goto(BASE + "#/start"); await pe.get_by_test_id("advice").wait_for()
            adv = plain(await pe.get_by_test_id("advice").inner_text())
            amount_in = await pe.get_by_test_id("advice-amount").input_value()
            ok("Abgleich: Kfz-Versicherung wird aus dem Topf geholt (Topf-Anteil in der Empfehlung)", "Kfz-Versicherung: für" in adv, adv[:200])
            bal_before = await balances(pe)
            await pe.get_by_test_id("advice-confirm").click(); await pe.wait_for_timeout(400)
            bal_after = await balances(pe)
            amt = float(amount_in.replace(".", "").replace(",", "."))
            def num(v): return float(v.replace(" €", "").replace(".", "").replace(",", "."))
            pend = plain(await pe.get_by_test_id("advice").inner_text())
            ok("„Jetzt umgebucht“: bestätigte Umbuchung, beide Kontostände sofort angepasst, wartet auf die Bank",
               abs(num(bal_after["Girokonto"]) - num(bal_before["Girokonto"]) - amt) < 0.01 and abs(num(bal_before["Rücklagen"]) - num(bal_after["Rücklagen"]) - amt) < 0.01 and "wartet auf die Bank" in pend, (amount_in, bal_before, bal_after))
            await pe.goto(BASE + "#/ruecklagen"); await pe.wait_for_timeout(300)
            ok("Spartopf schmilzt erst mit der bestätigten Umbuchung", plain(await pe.get_by_test_id("pots-sum").inner_text()) == "0,00 €", plain(await pe.get_by_test_id("pots-sum").inner_text()))
            r = await import_mail(pe, f"auf dem Konto *1234 wurden folgende Umsätze verbucht:\nÜbertrag Tagesgeld: {amount_in} EUR")
            ok("Kontowecker: Bankbuchung wird der bestätigten Umbuchung zugeordnet", "bestätigte Umbuchung" in r["rows"][0], r["rows"])
            await pe.get_by_test_id("import-commit").click(); await pe.wait_for_url(re.compile("#/start")); await pe.wait_for_timeout(300)
            bal_final = await balances(pe)
            pend2 = plain(await pe.get_by_test_id("advice").inner_text())
            ok("Keine doppelte Umbuchung: Kontostände unverändert, nicht mehr „wartet auf die Bank“", bal_final == bal_after and "wartet auf die Bank" not in pend2, (bal_final, pend2[-80:]))
            await pe.goto(BASE + "#/einstellungen"); await pe.get_by_test_id("buffer").fill("5.000,00"); await pe.get_by_test_id("buffer").blur(); await pe.wait_for_timeout(300)
            await pe.goto(BASE + "#/start"); await pe.get_by_test_id("advice").wait_for()
            title2 = plain(await pe.get_by_test_id("advice-title").inner_text())
            ok("Puffer in den Einstellungen wirkt auf die Empfehlung", title2 != title1 and ("Umbuchung" in title2 or "umbuchen" in title2), (title1, title2))
            # ---------- Dauerauftrag, Startverteilung, automatische Verteilung (v0.6.4) ----------
            await pe.goto(BASE + "#/ruecklagen"); await pe.get_by_test_id("standing-order").wait_for()
            so_txt = plain(await pe.get_by_test_id("standing-order").inner_text())
            ok("Rücklagen: Dauerauftrag aus der Historie erkannt und mit dem Bedarf verglichen", "150,00 €" in so_txt and "erkannt" in so_txt and "bleiben frei" in so_txt, so_txt[:160])
            await pe.get_by_test_id("start-plan").wait_for()
            start_val = await pe.get_by_test_id("start-Kfz-Versicherung").input_value()
            await pe.get_by_test_id("start-apply").click(); await pe.get_by_test_id("auto-dist").wait_for(timeout=10000)
            pots_after_start = plain(await pe.get_by_test_id("pots-sum").inner_text())
            ok("Startverteilung füllt den Kfz-Topf auf seinen Soll-Stand (Raten seit der letzten Zahlung)", start_val.endswith(",00") and pots_after_start == start_val + " €", (start_val, pots_after_start))
            r = await import_mail(pe, "auf dem Konto *1234 wurden folgende Umsätze verbucht:\nDauerauftrag Rücklagen: -150,00 EUR", {0: ("transfer", None, None)})
            tg_opts = await pe.locator("[data-testid=transfer-0] option").all_inner_texts()
            await pe.get_by_test_id("transfer-0").select_option(label=next(o for o in tg_opts if "Rücklagen" in o)); await pe.wait_for_timeout(150)
            await pe.get_by_test_id("import-commit").click(); await pe.wait_for_url(re.compile("#/start")); await pe.wait_for_timeout(500)
            await pe.goto(BASE + "#/ruecklagen"); await pe.get_by_test_id("auto-dist").wait_for(); await pe.wait_for_timeout(300)
            dist = plain(await pe.get_by_test_id("auto-dist").inner_text())
            pots_after = plain(await pe.get_by_test_id("pots-sum").inner_text())
            def eur(v): return float(v.replace(" €", "").replace(".", "").replace(",", "."))
            ok("Neuer Eingang des Dauerauftrags wird automatisch verteilt: Kfz bekommt seine Rate, der Rest bleibt frei", "150,00 € → Kfz-Versicherung 50,00 €" in dist and abs(eur(pots_after) - eur(pots_after_start) - 50) < 0.01, (dist[-120:], pots_after))
            await pe.reload(); await pe.wait_for_url(re.compile("#/entsperren"), timeout=15000); await unlock(pe)
            await pe.goto(BASE + "#/ruecklagen"); await pe.get_by_test_id("auto-dist").wait_for(); await pe.wait_for_timeout(300)
            ok("Jeder Eingang wird nur einmal verteilt", plain(await pe.get_by_test_id("pots-sum").inner_text()) == pots_after)
            await pe.get_by_test_id("shift-from").select_option(label=next(o for o in await pe.locator("[data-testid=shift-from] option").all_inner_texts() if o.startswith("Kfz")))
            await pe.get_by_test_id("shift-to").select_option("frei"); await pe.get_by_test_id("shift-amount").fill("100,00"); await pe.get_by_test_id("shift-do").click(); await pe.wait_for_timeout(300)
            ok("Umschichten in den freien Teil", abs(eur(plain(await pe.get_by_test_id("pots-sum").inner_text())) - eur(pots_after) + 100) < 0.01)

            # ---------- Gehalt als Taktgeber (v0.6.3) ----------
            async def calc_text(pg):
                await pg.goto(BASE + "#/start"); await pg.get_by_test_id("verdict").wait_for()
                await pg.locator(".calc summary").click(); await pg.wait_for_timeout(150)
                return plain(await pg.locator(".calc").inner_text())
            await pe.goto(BASE + "#/buchungen?ansicht=wiederkehrend"); await pe.get_by_test_id("rec-GEHALT SANDRA").click()
            await pe.get_by_test_id("rec-variable").click(); await pe.get_by_test_id("rec-save").click(); await pe.wait_for_timeout(300)
            c1 = await calc_text(pe)
            ok("Auch ein schwankendes Gehalt taktet die Prognose", "nach „GEHALT SANDRA“" in c1 and await pe.get_by_test_id("no-salary").count() == 0, c1[:160])
            await pe.goto(BASE + "#/buchungen?ansicht=wiederkehrend"); await pe.get_by_test_id("rec-GEHALT SANDRA").click()
            await pe.get_by_role("button", name="Nicht mehr einplanen").click(); await pe.wait_for_timeout(300)
            await pe.goto(BASE + "#/start"); await pe.get_by_test_id("no-salary").wait_for(timeout=10000)
            offer = plain(await pe.get_by_test_id("no-salary").inner_text())
            await pe.get_by_test_id("plan-salary-GEHALT SANDRA").click(); await pe.wait_for_timeout(300)
            c2 = await calc_text(pe)
            ok("Ohne Gehalt: Prognose meldet es und bietet das erkannte Gehalt an; ein Tipp plant es ein", "Kein Gehalt eingeplant" in offer and "GEHALT SANDRA" in offer and "nach „GEHALT SANDRA“" in c2 and await pe.get_by_test_id("no-salary").count() == 0, (offer[:120], c2[:120]))
            # ---------- Zweites Gehalt zentral anlegen (v0.6.6) ----------
            await pe.goto(BASE + "#/buchungen?ansicht=wiederkehrend"); await pe.get_by_test_id("rec-new").click()
            await pe.get_by_test_id("rec-label").fill("Gehalt Martin"); await pe.get_by_test_id("rec-amount").fill("2.150,00")
            await pe.get_by_test_id("rec-day").fill("15"); await pe.get_by_test_id("rec-variable").click(); await pe.get_by_test_id("rec-save").click(); await pe.wait_for_timeout(300)
            planned_e = [plain(t) for t in await pe.locator(".it .row").all_inner_texts()]
            ok("Wiederkehrend: zweites Gehalt zentral angelegt, das erste bleibt eingeplant", any(t.startswith("Gehalt Martin") and "monatlich am 15." in t for t in planned_e) and any(t.startswith("GEHALT SANDRA") for t in planned_e), planned_e[:4])
            await de_.close()

            # ---------- Sicherungsdatei im Handyspeicher (v0.6.5) ----------
            PICKER = "window.showSaveFilePicker = async () => (await navigator.storage.getDirectory()).getFileHandle('haushaltsbuch-sicherung.hhb', { create: true });"
            READ = "async () => { const r = await navigator.storage.getDirectory(); const f = await (await r.getFileHandle('haushaltsbuch-sicherung.hhb')).getFile(); return await f.text(); }"
            df, pf, errs_f = await device(p, "F")
            await df.add_init_script(PICKER)
            await pf.goto(BASE); await pf.wait_for_url(re.compile("#/einrichtung")); key_f = await setup(pf)
            await pf.get_by_test_id("acc-new").click(); await pf.get_by_test_id("acc-name").fill("Girokonto"); await pf.get_by_test_id("acc-start").fill("1.000,00"); await pf.get_by_test_id("acc-save").click(); await pf.wait_for_timeout(300)
            await pf.get_by_test_id("mirror-setup-tip").click(); await pf.wait_for_timeout(800)
            first = await pf.evaluate(READ)
            await pf.goto(BASE + "#/neu"); await pf.get_by_test_id("amount").fill("12,34"); await pf.get_by_test_id("text").fill("Sicherungstest Bäckerei")
            await pf.locator("[data-testid=cat]").select_option("a-haushalt"); await pf.get_by_test_id("save").click(); await pf.wait_for_url(re.compile("#/start"))
            await pf.wait_for_timeout(3000)
            second = await pf.evaluate(READ)
            mpath = Path(tempfile.mkdtemp()) / "haushaltsbuch-sicherung.hhb"; mpath.write_text(second, encoding="utf-8")
            res_f = subprocess.run([sys.executable, str(HERE.parent / "docs" / "restore.py"), str(mpath)], input=key_f + "\n", capture_output=True, text=True, env={**os.environ, "PYTHONIOENCODING": "utf-8"})
            mjson = mpath.with_suffix(".json").read_text(encoding="utf-8") if mpath.with_suffix(".json").exists() else ""
            ok("Sicherungsdatei: eingerichtet, nach jeder Änderung aktualisiert, verschlüsselt und mit dem Schlüssel lesbar",
               len(first) > 100 and second != first and "Sicherungstest" not in second and res_f.returncode == 0 and "Sicherungstest Bäckerei" in mjson, (len(first), len(second), res_f.returncode))
            await pf.reload(); await pf.wait_for_url(re.compile("#/entsperren"), timeout=15000); await unlock(pf)
            await pf.goto(BASE + "#/einstellungen"); await pf.get_by_test_id("mirror-status").wait_for(timeout=10000)
            status = plain(await pf.get_by_test_id("mirror-status").inner_text())
            await pf.goto(BASE + "#/pruefung"); await pf.wait_for_timeout(1500)
            check_txt = plain(await pf.locator("main").inner_text())
            ok("Nach Neustart weiter aktiv; Machbarkeitsprüfung meldet „Schreiberlaubnis bleibt“", status.startswith("Aktiv") and "Schreiberlaubnis bleibt nach Neustart" in check_txt and "ja, kein Nachfragen nötig" in check_txt, (status[:60],))
            # ---------- Dauerauftrag als regelmäßige Umbuchung eintragen (v0.6.8) ----------
            await pf.goto(BASE + "#/start"); await pf.get_by_test_id("acc-new").click(); await pf.get_by_test_id("acc-name").fill("Rücklagen")
            await pf.get_by_test_id("acc-type").select_option("tagesgeld"); await pf.get_by_test_id("acc-start").fill("2.000,00"); await pf.get_by_test_id("acc-save").click(); await pf.wait_for_timeout(300)
            await pf.goto(BASE + "#/ruecklagen"); await pf.get_by_test_id("pot-new").click(); await pf.get_by_test_id("pot-kind").select_option("ziel")
            await pf.get_by_test_id("pot-name").fill("Urlaub"); await pf.get_by_test_id("pot-target").fill("1.200,00")
            await pf.get_by_test_id("pot-due").fill((datetime.date.today() + datetime.timedelta(days=370)).isoformat()); await pf.get_by_test_id("pot-save").click(); await pf.wait_for_timeout(300)
            await pf.get_by_test_id("so-form").wait_for(timeout=10000)
            so_default = await pf.get_by_test_id("so-amount-in").input_value()
            await pf.get_by_test_id("so-save").click(); await pf.get_by_test_id("so-amount").wait_for(timeout=10000)
            so_card = plain(await pf.get_by_test_id("standing-order").inner_text())
            await pf.goto(BASE + "#/buchungen?ansicht=wiederkehrend"); await pf.locator(".it .row").first.wait_for()
            rec_f = [plain(t) for t in await pf.locator(".it .row").all_inner_texts()]
            ok("Rücklagen: Dauerauftrag als regelmäßige Umbuchung eingetragen (Vorschlag = Monatsraten), sichtbar unter Wiederkehrend",
               so_default == "100,00" and "100,00 € monatlich am 1. vom Girokonto (eingetragen)" in so_card and any("Umbuchung auf Rücklagen" in t for t in rec_f), (so_default, so_card[:120], rec_f[:2]))
            await pf.goto(BASE + "#/ruecklagen"); await pf.get_by_test_id("start-apply").click(); await pf.get_by_test_id("auto-dist").wait_for()
            await pf.goto(BASE + "#/neu"); await pf.get_by_test_id("tab-umbuchung").click()
            await pf.get_by_test_id("tr-from").select_option(label="Girokonto"); await pf.get_by_test_id("tr-to").select_option(label="Rücklagen")
            await pf.get_by_test_id("tr-amount").fill("100,00"); await pf.get_by_placeholder("z. B. Rücklage für Urlaub").fill("Übertrag Spar"); await pf.get_by_test_id("tr-save").click(); await pf.wait_for_url(re.compile("#/start")); await pf.wait_for_timeout(300)
            await pf.goto(BASE + "#/ruecklagen"); await pf.get_by_test_id("auto-dist").wait_for(); await pf.wait_for_timeout(400)
            dist_f = plain(await pf.get_by_test_id("auto-dist").inner_text())
            ok("Eingang wird an Konto und Betrag erkannt (anderer Banktext) und auf die Töpfe verteilt", "100,00 € → Urlaub 100,00 €" in dist_f, dist_f[-100:])
            # ---------- Rechenweg Sparen (v0.7.2) ----------
            await pf.goto(BASE + "#/neu"); await pf.get_by_test_id("amount").fill("50,00"); await pf.get_by_test_id("text").fill("Übertrag Tagesgeld")
            await pf.locator("[data-testid=cat]").first.select_option("a-andere"); await pf.get_by_test_id("save").click(); await pf.wait_for_url(re.compile("#/start"))
            await pf.goto(BASE + "#/statistik"); await pf.get_by_test_id("savings-trace").wait_for(timeout=10000)
            tr_txt = plain(await pf.get_by_test_id("savings-trace").inner_text()); kpi_s = plain(await pf.get_by_test_id("kpi-sparen").inner_text())
            ok("Statistik: Rechenweg Sparen zeigt jede Buchung mit Grund, meldet Verdachtsfälle, Summe = Kennzahl",
               "zählt 100,00 €: Einzahlung" in tr_txt and "Sieht nach Umbuchung aus" in tr_txt and await pf.get_by_test_id("trace-issues").count() == 1 and f"Summe der gezählten Zeilen: {kpi_s}" in tr_txt, (kpi_s, tr_txt[:200]))
            await df.close()
            dg, pg, errs_g = await device(p, "G")
            await pg.goto(BASE); await pg.wait_for_url(re.compile("#/einrichtung"))
            await pg.get_by_test_id("restore").click(); await pg.set_input_files("#backupFile", str(mpath))
            await pg.get_by_test_id("restore-key").fill(key_f); await pg.get_by_test_id("open-backup").click()
            await pg.get_by_test_id("passkey").click(); await pg.get_by_test_id("finish-nopw").click(timeout=15000)
            await pg.get_by_test_id("to-app").click(timeout=20000); await pg.wait_for_url(re.compile("#/start"))
            await dismiss_welcome(pg)
            ok("Nach gelöschten Browserdaten: Wiederherstellung aus der Sicherungsdatei bis zur letzten Änderung", await balances(pg) == {"Girokonto": "987,66 €"}, await balances(pg))
            await dg.close()

            # ---------- Bausparvertrag mit Vorausdarlehen (v0.7.3), doppelte Umbuchung ----------
            dj, pj, errs_j = await device(p, "J")
            await pj.goto(BASE); await pj.wait_for_url(re.compile("#/einrichtung")); await setup(pj)
            for nm, typ, start in (("Girokonto", "giro", "3.000,00"), ("LBS Bausparen", "bauspar", "10.000,00")):
                await pj.get_by_test_id("acc-new").click(); await pj.get_by_test_id("acc-name").fill(nm); await pj.get_by_test_id("acc-type").select_option(typ)
                await pj.get_by_test_id("acc-start").fill(start); await pj.get_by_test_id("acc-save").click(); await pj.wait_for_timeout(300)
            await pj.goto(BASE + "#/kredite"); await pj.get_by_test_id("loan-new").click(); await pj.get_by_test_id("lf-kind").select_option("voraus")
            for tid, v in (("lf-name", "Vorfinanzierung"), ("lf-balance", "38.900,00"), ("lf-day", "30"), ("lf-rateP", "3,6"), ("lf-pattern", "Zinsen LBS")):
                await pj.get_by_test_id(tid).fill(v)
            await pj.get_by_test_id("lf-save").click(); await pj.get_by_test_id("loan-Vorfinanzierung").wait_for(timeout=10000)
            free_before = plain(await pj.get_by_test_id("debt-free").inner_text())
            alloc = (datetime.date.today().replace(day=1) + datetime.timedelta(days=330)).strftime("%Y-%m")
            await pj.get_by_test_id("bs-new").click()
            for tid, v in (("bs-name", "LBS Bausparvertrag"), ("bs-sum", "38.900,00"), ("bs-rate", "200,00"), ("bs-min", "40"), ("bs-alloc", alloc), ("bs-loanP", "2,5"), ("bs-loanRate", "240,00")):
                await pj.get_by_test_id(tid).fill(v)
            await pj.get_by_test_id("bs-type").select_option("zinsen"); sug = plain(await pj.get_by_test_id("bs-suggest").inner_text())
            await pj.get_by_test_id("bs-save").click(); await pj.get_by_test_id("bs-LBS Bausparvertrag").wait_for(timeout=10000)
            summary_bs = plain(await pj.get_by_test_id("bs-summary").inner_text())
            ok("Bausparvertrag zugeklappt mit Zusammenfassung: Ablösung, Bauspardarlehen, Stand des Abgleichs", summary_bs.startswith("Ablösung") and "Bauspardarlehen" in summary_bs and ("alles stimmig" in summary_bs or "prüfen" in summary_bs), summary_bs)
            await pj.get_by_test_id("bs-details").click(); await pj.get_by_test_id("bs-story").first.wait_for(timeout=5000)
            story = " ".join(plain(t) for t in await pj.get_by_test_id("bs-story").all_inner_texts())
            n_checks = await pj.locator("[data-testid=bs-checks] li").count()
            free_after = plain(await pj.get_by_test_id("debt-free").inner_text())
            ok("Bausparvertrag verknüpft: Erkennungshilfe, Klartext zu Zuteilung und Bauspardarlehen, Abgleich mit drei Ampeln",
               "Nur Zinsen" in sug and "zahlst du monatlich 116,70 € Zinsen" in story and "Dann wird der Bausparvertrag zugeteilt" in story and "Rate für das Bauspardarlehen" in story and n_checks == 3, (sug, story[:220], n_checks))
            ok("„Schuldenfrei“ wird mit dem Bausparvertrag absehbar", free_before == "nicht absehbar" and free_after != "nicht absehbar", (free_before, free_after))
            bau_amt = re.search(r"Bauspardarlehen ([\d.]+,\d{2}) €", summary_bs).group(1)
            await pj.get_by_test_id("bs-edit").click(); await pj.get_by_test_id("bs-c-loan").fill(bau_amt); await pj.get_by_test_id("bs-save").click(); await pj.wait_for_timeout(300)
            if not await pj.get_by_test_id("bs-facts").count(): await pj.get_by_test_id("bs-details").click()
            await pj.get_by_test_id("bs-compare").wait_for(timeout=5000)
            cmp_ok = plain(await pj.get_by_test_id("bs-LBS Bausparvertrag").inner_text())
            await pj.get_by_test_id("bs-edit").click(); await pj.get_by_test_id("bs-c-int").fill("1,00"); await pj.get_by_test_id("bs-save").click(); await pj.wait_for_timeout(300)
            if not await pj.get_by_test_id("bs-facts").count(): await pj.get_by_test_id("bs-details").click()
            await pj.get_by_test_id("bs-compare").wait_for(timeout=5000)
            cmp_off = plain(await pj.get_by_test_id("bs-LBS Bausparvertrag").inner_text())
            ok("Vergleich mit dem Vertrag: passende Werte bestätigt, abweichende markiert", "Die App rechnet wie die Bausparkasse" in cmp_ok and "Größere Abweichung" in cmp_off and await pj.locator("[data-testid=bs-compare] tr.off").count() == 1, (cmp_ok[-120:], cmp_off[-120:]))
            async def tr_j():
                await pj.goto(BASE + "#/neu"); await pj.get_by_test_id("tab-umbuchung").click()
                await pj.get_by_test_id("tr-from").select_option(label="Girokonto"); await pj.get_by_test_id("tr-to").select_option(label="LBS Bausparen")
                await pj.get_by_test_id("tr-amount").fill("200,00"); await pj.get_by_test_id("tr-save").click()
            await tr_j(); await pj.wait_for_url(re.compile("#/start"))
            await tr_j(); await pj.get_by_test_id("tr-dup").wait_for(timeout=5000)
            dup_txt = plain(await pj.get_by_test_id("tr-dup").inner_text())
            await pj.get_by_test_id("tr-save").click(); await pj.wait_for_url(re.compile("#/start"))
            ok("Umbuchung: Warnung vor doppelter Erfassung; nochmal Tippen speichert trotzdem", "Es gibt schon eine Umbuchung über 200,00 €" in dup_txt and (await balances(pj)).get("LBS") == "10.400,00 €", dup_txt[:90])
            await dj.close()

            # ---------- Sondertilgungsplan (v0.7.4) ----------
            dl_, pl, errs_l = await device(p, "L")
            await pl.goto(BASE); await pl.wait_for_url(re.compile("#/einrichtung")); await setup(pl)
            for nm, typ, purpose, start in (("Girokonto", "giro", None, "3.000,00"), ("Sondertilgung", "tagesgeld", "sondertilgung", "20.000,00")):
                await pl.get_by_test_id("acc-new").click(); await pl.get_by_test_id("acc-name").fill(nm); await pl.get_by_test_id("acc-type").select_option(typ)
                if purpose: await pl.locator("select").filter(has=pl.locator("option[value=sondertilgung]")).first.select_option(purpose)
                await pl.get_by_test_id("acc-start").fill(start); await pl.get_by_test_id("acc-save").click(); await pl.wait_for_timeout(300)
            for kind, vals in (("annuitaet", (("lf-name", "Hauskredit"), ("lf-balance", "100.000,00"), ("lf-rate", "500,00"), ("lf-day", "30"), ("lf-rateP", "3"), ("lf-fixed", "2030-12-31"))),
                               ("raten", (("lf-name", "Autokredit"), ("lf-balance", "10.000,00"), ("lf-rate", "300,00"), ("lf-day", "1"), ("lf-rateP", "6"), ("lf-end", "2030-06-30")))):
                await pl.goto(BASE + "#/kredite"); await pl.get_by_test_id("loan-new").click(); await pl.get_by_test_id("lf-kind").select_option(kind)
                for tid, v in vals: await pl.get_by_test_id(tid).fill(v)
                await pl.get_by_test_id("lf-save").click(); await pl.get_by_test_id("loan-" + vals[0][1]).wait_for(timeout=10000)
            await pl.get_by_test_id("special-plan").wait_for(timeout=10000)
            pool = "19.990,00 €" if "19.990,00 € in der Rücklage" in plain(await pl.get_by_test_id("sp-budget").inner_text()) else plain(await pl.get_by_test_id("sp-budget").inner_text()); f_with = plain(await pl.get_by_test_id("sp-free").inner_text()); f_without = plain(await pl.get_by_test_id("sp-free-without").inner_text())
            nxt = plain(await pl.get_by_test_id("sp-next").inner_text()); saving = plain(await pl.get_by_test_id("sp-saving").inner_text())
            def ym(t):
                mon = ["Januar","Februar","März","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"]; m, y = t.split(" ")
                return (int(y), mon.index(m))
            ok("Sondertilgungsplan: Budget ohne Notreserve, früher schuldenfrei, Zinsersparnis und nächster Schritt",
               pool == "19.990,00 €" and ym(f_with) < ym(f_without) and "Sondertilgung auf" in nxt and saving != "0,00 €", (pool, f_with, f_without, nxt[:80], saving))
            await pl.get_by_test_id("sp-details").click(); await pl.get_by_test_id("sp-strategy").select_option("zinsbindung"); await pl.wait_for_timeout(200)
            await pl.goto(BASE + "#/einstellungen"); await pl.get_by_test_id("sp-monthly").fill("200,00"); await pl.get_by_test_id("sp-monthly").blur(); await pl.wait_for_timeout(300)
            await pl.reload(); await pl.wait_for_url(re.compile("#/entsperren"), timeout=15000); await unlock(pl)
            await pl.goto(BASE + "#/einstellungen"); await pl.get_by_test_id("sp-monthly").wait_for(); m_val = await pl.get_by_test_id("sp-monthly").input_value()
            await pl.goto(BASE + "#/kredite"); await pl.get_by_test_id("special-plan").wait_for(); await pl.get_by_test_id("sp-details").click()
            rm_items = [plain(t) for t in await pl.get_by_test_id("rm-item").all_inner_texts()]
            rm_zb = next((t for t in rm_items if "Hauskredit: Zinsbindung endet" in t), "")
            ok("Fahrplan: zum Zinsbindungsende Restschuld, Anteil aus der Rücklage und nachzufinanzierender Betrag", "nachzufinanzieren:" in rm_zb and await pl.get_by_test_id("rm-total").count() == 1, rm_zb)
            ok("Reihenfolge (Details) und monatlicher Betrag (Einstellungen → Kredite) bleiben erhalten", await pl.get_by_test_id("sp-strategy").input_value() == "zinsbindung" and m_val == "200,00", (await pl.get_by_test_id("sp-strategy").input_value(), m_val))
            # Vorfinanzierter Bausparvertrag mit Lücke: Bauspardarlehen und Anschlussfinanzierung im Plan
            await pl.goto(BASE + "#/start"); await pl.get_by_test_id("acc-new").click(); await pl.get_by_test_id("acc-name").fill("LBS"); await pl.get_by_test_id("acc-type").select_option("bauspar")
            await pl.get_by_test_id("acc-start").fill("10.000,00"); await pl.get_by_test_id("acc-save").click(); await pl.wait_for_timeout(300)
            await pl.goto(BASE + "#/kredite"); await pl.get_by_test_id("loan-new").click(); await pl.get_by_test_id("lf-kind").select_option("voraus")
            for tid, v in (("lf-name", "Vorfinanzierung"), ("lf-balance", "38.900,00"), ("lf-day", "30"), ("lf-rateP", "3,6")):
                await pl.get_by_test_id(tid).fill(v)
            await pl.get_by_test_id("lf-save").click(); await pl.get_by_test_id("loan-Vorfinanzierung").wait_for(timeout=10000)
            await pl.get_by_test_id("loan-Vorfinanzierung").click(); await pl.get_by_test_id("loan-link-hint").wait_for(timeout=5000)
            await pl.get_by_test_id("loan-link").click(); await pl.get_by_test_id("bs-form").wait_for(timeout=5000)
            preselected = await pl.get_by_test_id("bs-loan").input_value()
            alloc_l = (datetime.date.today().replace(day=1) + datetime.timedelta(days=330)).strftime("%Y-%m")
            for tid, v in (("bs-name", "LBS Bausparvertrag"), ("bs-sum", "30.000,00"), ("bs-rate", "200,00"), ("bs-min", "40"), ("bs-alloc", alloc_l), ("bs-loanP", "2,5"), ("bs-loanRate", "240,00")):
                await pl.get_by_test_id(tid).fill(v)
            await pl.get_by_test_id("bs-type").select_option("zinsen")
            await pl.get_by_test_id("bs-save").click(); await pl.get_by_test_id("bs-LBS Bausparvertrag").wait_for(timeout=10000)
            await pl.get_by_test_id("bs-details").click(); await pl.get_by_test_id("bs-facts").wait_for(timeout=5000)
            facts = plain(await pl.get_by_test_id("bs-facts").inner_text())
            ok("Vorausdarlehen: „Mit Bausparvertrag verknüpfen“ öffnet das Formular vorbelegt; Details zeigen die Eckdaten", preselected != "" and "Löst ab Vorfinanzierung" in facts and "Mindestsparguthaben 40 % = 12.000,00 €" in facts and "Zuteilung laut Bausparkasse" in facts, (preselected, facts[:200]))
            n_slides = await pl.get_by_test_id("chart-slide").count()
            ok("Diagramme zum Wischen: alle Kredite und jeder Kredit einzeln", n_slides == 3, n_slides)
            await pl.get_by_test_id("sp-details").click(); await pl.get_by_test_id("sp-replacement").wait_for(timeout=5000)
            repl = plain(await pl.get_by_test_id("sp-replacement").inner_text()); free_sum = plain(await pl.get_by_test_id("debt-free").inner_text())
            ok("Sondertilgungsplan rechnet die Bauspar-Ablösung mit: Bauspardarlehen und Anschlussfinanzierung für die Lücke", "Bauspardarlehen über" in repl and "Anschlussfinanzierung über" in repl and free_sum != "nicht absehbar", (repl[:160], free_sum))
            await pl.get_by_test_id("loan-Autokredit").click(); await pl.get_by_test_id("loan-edit").click(); await pl.get_by_test_id("lf-fwd").click(); await pl.get_by_test_id("lf-save").click(); await pl.wait_for_timeout(400)
            budget = plain(await pl.get_by_test_id("sp-budget").inner_text())
            ok("Rate des Autokredits nach der Tilgung weiterleiten (im Kredit eingestellt)", "weitergeleitete Raten" in budget, budget[:120])
            await dl_.close()

            # ---------- Fristen, tilgungsfreie Zeit, Was-wäre-wenn (v0.7.5) ----------
            dm, pm, errs_m = await device(p, "M")
            await pm.goto(BASE); await pm.wait_for_url(re.compile("#/einrichtung")); await setup(pm)
            await pm.get_by_test_id("acc-new").click(); await pm.get_by_test_id("acc-name").fill("Girokonto"); await pm.get_by_test_id("acc-start").fill("3.000,00"); await pm.get_by_test_id("acc-save").click(); await pm.wait_for_timeout(300)
            io_date = (datetime.date.today() + datetime.timedelta(days=60)).isoformat(); fix_date = (datetime.date.today() + datetime.timedelta(days=300)).isoformat()
            await pm.goto(BASE + "#/kredite"); await pm.get_by_test_id("loan-new").click(); await pm.get_by_test_id("lf-kind").select_option("foerder")
            for tid, v in (("lf-name", "KfW"), ("lf-balance", "50.000,00"), ("lf-rate", "600,00"), ("lf-day", "30"), ("lf-rateP", "1,45"), ("lf-io", io_date), ("lf-fixed", fix_date)):
                await pm.get_by_test_id(tid).fill(v)
            await pm.get_by_test_id("lf-save").click(); await pm.get_by_test_id("loan-KfW").wait_for(timeout=10000)
            dl_txt = plain(await pm.get_by_test_id("deadlines").inner_text())
            ok("KfW mit tilgungsfreier Zeit gespeichert; Fristen: Ende der tilgungsfreien Zeit und Zinsbindungsende", "tilgungsfreie Zeit endet" in dl_txt and "Zinsbindung endet" in dl_txt and "Restschuld dann voraussichtlich 50.000,00 €" not in dl_txt, dl_txt[:200])
            async with pm.expect_download() as ics_dl:
                await pm.get_by_test_id("ics").click()
            ics_path = Path(tempfile.mkdtemp()) / "t.ics"; await (await ics_dl.value).save_as(ics_path); ics = ics_path.read_text(encoding="utf-8")
            ok("Termine als Kalenderdatei (.ics) ohne Beträge", ics.startswith("BEGIN:VCALENDAR") and "KfW: Ende der tilgungsfreien Zeit" in ics and "€" not in ics, ics[:80])
            await pm.goto(BASE + "#/start"); await pm.wait_for_timeout(300)
            ok("Übersicht zeigt die Fristen als Hinweise", await pm.get_by_test_id("hint-alarm").count() >= 2, await pm.get_by_test_id("hint-alarm").count())
            await pm.goto(BASE + "#/kredite"); await pm.get_by_test_id("loan-KfW").click(); await pm.get_by_test_id("loan-whatif").click()
            await pm.get_by_test_id("wi-amount").fill("5.000,00"); await pm.get_by_test_id("wi-wish").fill("2045"); await pm.wait_for_timeout(300)
            saving_wi = plain(await pm.get_by_test_id("wi-saving").inner_text()); rows_f = [plain(t) for t in await pm.locator("[data-testid=wi-follow-table] tbody tr").all_inner_texts()]
            ok("Was wäre wenn: Zinsersparnis durch Sondertilgung; Anschlusszins 3/4/5 % mit Rate fürs Wunschende", saving_wi not in ("0,00 €", "-0,00 €") and len(rows_f) == 3 and all("€" in r for r in rows_f), (saving_wi, rows_f))
            await dm.close()

            # ---------- Kredite, Rest (v0.8.2): Ratenprüfung, Szenario B, Zeitstrahl, Sonderzahlung, Ablösung ----------
            dn, pn, errs_n = await device(p, "N")
            await pn.goto(BASE); await pn.wait_for_url(re.compile("#/einrichtung")); await setup(pn)
            for nm, typ, start in (("Girokonto", "giro", "5.000,00"), ("LBS", "bauspar", "10.000,00")):
                await pn.get_by_test_id("acc-new").click(); await pn.get_by_test_id("acc-name").fill(nm); await pn.get_by_test_id("acc-type").select_option(typ)
                await pn.get_by_test_id("acc-start").fill(start); await pn.get_by_test_id("acc-save").click(); await pn.wait_for_timeout(300)
            await pn.goto(BASE + "#/kredite"); await pn.get_by_test_id("loan-new").click(); await pn.get_by_test_id("lf-kind").select_option("annuitaet")
            for tid, v in (("lf-name", "Hauskredit"), ("lf-balance", "182.400,00"), ("lf-date", "2026-07-01"), ("lf-rate", "980,00"), ("lf-day", "30"), ("lf-rateP", "2,85"), ("lf-fixed", "2032-06-30")):
                await pn.get_by_test_id(tid).fill(v)
            await pn.get_by_test_id("lf-save").click(); await pn.get_by_test_id("loan-Hauskredit").wait_for(timeout=10000)
            async def book(date, amount, text, cat="a-kredite"):
                await pn.goto(BASE + "#/neu"); await pn.get_by_test_id("amount").fill(amount); await pn.get_by_test_id("text").fill(text)
                await pn.get_by_test_id("date").fill(date); await pn.locator("[data-testid=cat]").first.select_option(cat)
                await pn.get_by_test_id("save").click(); await pn.wait_for_timeout(250)
                if await pn.get_by_test_id("dup-warning").count(): await pn.get_by_test_id("save").click(); await pn.wait_for_timeout(250)
            for b_date, b_amount, b_text in (("2024-03-30", "980,00", "Kreditrate Hauskredit"), ("2024-12-15", "3.000,00", "Sondertilgung Hauskredit"), ("2025-03-30", "980,00", "Kreditrate Hauskredit"),
                            ("2025-12-15", "4.000,00", "Sondertilgung Hauskredit"), ("2026-07-30", "980,00", "Kreditrate Hauskredit"), ("2026-09-12", "5.000,00", "Hauskredit Sonderzahlung Sparkasse"),
                            ("2026-09-30", "980,00", "Kreditrate Hauskredit"), ("2026-10-30", "980,00", "Kreditrate Hauskredit"), ("2026-10-30", "980,00", "Kreditrate Hauskredit")):
                await book(b_date, b_amount, b_text)
            await book("2026-11-15", "5,00", "Bäcker", "a-andere")
            # Erstattung (10.2): Einnahme mit Ausgabenkategorie mindert die Ausgaben, zählt nicht als Einkommen
            await pn.goto(BASE + "#/neu"); await pn.get_by_test_id("kind-ein").click(); await pn.get_by_test_id("amount").fill("2,00"); await pn.get_by_test_id("text").fill("Erstattung Bäcker")
            await pn.get_by_test_id("date").fill("2026-11-16"); await pn.locator("[data-testid=cat]").first.select_option("a-andere"); await pn.wait_for_timeout(150)
            refund_opts = await pn.locator("[data-testid=refund-of] option").all_inner_texts()
            await pn.get_by_test_id("refund-of").select_option(index=1); await pn.get_by_test_id("save").click(); await pn.wait_for_timeout(300)
            await pn.goto(BASE + "#/buchungen"); await pn.wait_for_timeout(300)
            b_ref = plain(await pn.get_by_test_id("badge-refund").first.inner_text()) if await pn.get_by_test_id("badge-refund").count() else ""
            b_red = plain(await pn.get_by_test_id("badge-refunded").first.inner_text()) if await pn.get_by_test_id("badge-refunded").count() else ""
            ok("Erstattung mit der ursprünglichen Ausgabe verknüpft (optional): beide Buchungen zeigen den Bezug", len(refund_opts) >= 2 and "Bäcker" in refund_opts[1] and b_ref.startswith("Erstattung zu 15.11.2026 Bäcker") and b_red == "erstattet 2,00 €", (refund_opts[:2], b_ref, b_red))
            await pn.goto(BASE + "#/statistik"); await pn.wait_for_timeout(300)
            k_inc, k_kon = plain(await pn.get_by_test_id("kpi-income").inner_text()), plain(await pn.get_by_test_id("kpi-konsum").inner_text())
            ok("Erstattung zu einer Ausgabenkategorie mindert die Ausgaben und zählt nicht als Einkommen", k_inc == "0,00 €" and k_kon == "3,00 €", (k_inc, k_kon))
            await pn.get_by_test_id("stat-range").click(); await pn.get_by_test_id("range-all").click(); await pn.wait_for_timeout(300)
            r_label = plain(await pn.get_by_test_id("stat-label").inner_text()); r_fin = plain(await pn.get_by_test_id("kpi-finanzierung").inner_text())
            gap_note = plain(await pn.get_by_test_id("stat-gap").inner_text()) if await pn.get_by_test_id("stat-gap").count() else ""
            ok("Datenabdeckung: Statistik weist auf Monate ohne Daten hin", "Girokonto: April 2024" in gap_note, gap_note[:120])
            ok("Statistik: gesamter Zeitraum über alle Monate mit Daten", r_label.startswith("März 2024 bis November 2026") and r_fin != "0,00 €", (r_label, r_fin))
            await pn.goto(BASE + "#/kredite"); await pn.get_by_test_id("loan-Hauskredit").click(); await pn.get_by_test_id("loan-issues").wait_for(timeout=5000)
            iss = plain(await pn.get_by_test_id("loan-issues").inner_text())
            ok("Raten prüfen: ausgebliebene Rate (August), doppelte Rate (Oktober), unerwartete Zahlung als mögliche Sondertilgung", "Rate zum 30.08.2026 nicht gefunden" in iss and "Rate zum 30.10.2026 doppelt" in iss and "mögliche Sondertilgung über 5.000,00 €" in iss, iss[:300])
            ok("Auffälligkeiten erscheinen auch als Fristen", "nicht gefunden" in plain(await pn.get_by_test_id("deadlines").inner_text()), "")
            await pn.get_by_test_id("issue-confirm").click(); await pn.wait_for_timeout(300)
            iss2 = plain(await pn.get_by_test_id("loan-issues").inner_text()) if await pn.get_by_test_id("loan-issues").count() else ""
            hist = plain(await pn.get_by_test_id("loan-history").inner_text())
            ok("Bestätigte Zahlung zählt als Sondertilgung; bisherige Sondertilgungen je Jahr mit Mittelwert", "mögliche Sondertilgung" not in iss2 and "2024: 3.000,00 €" in hist and "2025: 4.000,00 €" in hist and "im Mittel 3.500,00 € pro Jahr" in hist, (iss2[:120], hist))
            ph = [plain(t) for t in await pn.locator("[data-testid=loan-phases] li").all_inner_texts()]
            ok("Zeitstrahl: Zinsbindung, Anschlussfinanzierung, getilgt, mit Klartext", len(ph) == 3 and "Zinsbindung" in ph[0] and "980,00 € Rate im Monat zu 2,85 %" in ph[0] and "Anschlussfinanzierung" in ph[1] and "Getilgt" in ph[2], ph)
            fa, fb = plain(await pn.get_by_test_id("debt-free").inner_text()), plain(await pn.get_by_test_id("debt-free-b").inner_text())
            def ym2(t):
                mon = ["Januar","Februar","März","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"]; m, y = t.split(" ")[:2]
                return (int(y), mon.index(m))
            ok("Szenario B „wie bisher“: mit eurem Mittel der Sondertilgungen früher schuldenfrei als vertraglich", ym2(fb) < ym2(fa), (fa, fb))
            # Vorfinanzierung mit Bausparvertrag: Sonderzahlung durchrechnen, dann Ablösung erfassen
            await pn.get_by_test_id("loan-new").click(); await pn.get_by_test_id("lf-kind").select_option("voraus")
            for tid, v in (("lf-name", "Vorfinanzierung"), ("lf-balance", "38.900,00"), ("lf-day", "30"), ("lf-rateP", "3,6")):
                await pn.get_by_test_id(tid).fill(v)
            await pn.get_by_test_id("lf-save").click(); await pn.get_by_test_id("loan-Vorfinanzierung").wait_for(timeout=10000)
            await pn.get_by_test_id("loan-Vorfinanzierung").click(); await pn.get_by_test_id("loan-link").click(); await pn.get_by_test_id("bs-form").wait_for(timeout=5000)
            alloc_n = (datetime.date.today().replace(day=1) + datetime.timedelta(days=310)).strftime("%Y-%m")
            for tid, v in (("bs-name", "LBS Bausparvertrag"), ("bs-sum", "38.900,00"), ("bs-rate", "200,00"), ("bs-min", "40"), ("bs-alloc", alloc_n), ("bs-loanP", "2,5"), ("bs-loanRate", "240,00")):
                await pn.get_by_test_id(tid).fill(v)
            await pn.get_by_test_id("bs-type").select_option("zinsen"); await pn.get_by_test_id("bs-save").click(); await pn.get_by_test_id("bs-LBS Bausparvertrag").wait_for(timeout=10000)
            await pn.get_by_test_id("bs-details").click(); await pn.get_by_test_id("sz-amount").fill("2.000,00"); await pn.wait_for_timeout(250)
            sz = plain(await pn.get_by_test_id("sz-result").inner_text())
            ok("Sonderzahlung in den Bausparvertrag: größeres Guthaben, kleineres Bauspardarlehen, weniger Zinsen", "Bauspardarlehen" in sz and "statt" in sz and "weniger" in sz, sz[:200])
            total_before = plain(await pn.get_by_test_id("loans-total").inner_text())
            await pn.get_by_test_id("bs-settle-any").click(); await pn.get_by_test_id("settle-form").wait_for(timeout=5000)
            pre_debt = await pn.get_by_test_id("st-debt").input_value()
            for tid, v in (("st-date", datetime.date.today().isoformat()), ("st-debt", "38.900,00"), ("st-balance", "10.000,00"), ("st-bauloan", "28.900,00")):
                await pn.get_by_test_id(tid).fill(v)
            preview = plain(await pn.get_by_test_id("st-preview").inner_text())
            await pn.get_by_test_id("st-save").click(); await pn.get_by_test_id("bs-settled").wait_for(timeout=10000)
            settled = plain(await pn.get_by_test_id("bs-settled").inner_text())
            total_after = plain(await pn.get_by_test_id("loans-total").inner_text())
            has_bau = await pn.get_by_test_id("loan-Bauspardarlehen LBS Bausparvertrag").count()
            await pn.goto(BASE + "#/start"); await pn.wait_for_timeout(300); accs = await balances(pn)
            ok("Ablösung in einem Schritt: Bauspardarlehen angelegt, Vorfinanzierung abbezahlt, Bausparkonto ausgebucht und archiviert", pre_debt == "38.900,00" and "archiviert" in preview and "Abgelöst am" in settled and "das Darlehen ist abbezahlt" in settled
               and has_bau == 1 and euro_cents(total_before) - euro_cents(total_after) == 1000000 and "LBS" not in accs, (pre_debt, preview[:60], settled[:80], has_bau, total_before, total_after, list(accs)))
            # Sondertilgungen im virtuellen Spartopf statt auf eigenem Konto
            await pn.goto(BASE + "#/start"); await pn.get_by_test_id("acc-new").click(); await pn.get_by_test_id("acc-name").fill("Rücklagen"); await pn.get_by_test_id("acc-type").select_option("tagesgeld")
            await pn.get_by_test_id("acc-start").fill("8.000,00"); await pn.get_by_test_id("acc-save").click(); await pn.wait_for_timeout(300)
            await pn.goto(BASE + "#/ruecklagen"); await pn.wait_for_timeout(300)
            if await pn.locator("[data-testid=pot-account] select").count(): await pn.locator("[data-testid=pot-account] select").first.select_option(index=1 if await pn.locator("[data-testid=pot-account] select option").count() > 1 else 0)
            await pn.get_by_test_id("pot-new").click(); await pn.get_by_test_id("pot-kind").select_option("ziel"); await pn.get_by_test_id("pot-name").fill("Sondertilgung")
            await pn.get_by_test_id("pot-target").fill("5.000,00"); await pn.get_by_test_id("pot-due").fill((datetime.date.today() + datetime.timedelta(days=200)).isoformat()); await pn.get_by_test_id("pot-balance").fill("2.000,00")
            await pn.get_by_test_id("pot-special").click(); await pn.get_by_test_id("pot-save").click(); await pn.wait_for_timeout(300)
            await pn.goto(BASE + "#/kredite"); await pn.get_by_test_id("special-plan").wait_for(timeout=10000)
            budget_n = plain(await pn.get_by_test_id("sp-budget").inner_text())
            ok("Sondertilgungen im Spartopf: Guthaben und Monatsrate zählen als Budget, ohne eigenes Konto", budget_n.startswith("Budget: 2.000,00 € in der Rücklage") and "dazu 0,00 € im Monat" not in budget_n, budget_n[:120])
            # Tilgungsplan als Excel direkt im Kredit
            await pn.get_by_test_id("loan-Hauskredit").click()
            async with pn.expect_download() as dl_plan:
                await pn.get_by_test_id("loan-xlsx").click()
            plan_path = Path(tempfile.mkdtemp()) / "plan.xlsx"; await (await dl_plan.value).save_as(plan_path)
            import zipfile
            with zipfile.ZipFile(plan_path) as zf: plan_names = zf.namelist(); sheet2 = zf.read("xl/worksheets/sheet2.xml").decode()
            ok("Tilgungsplan als Excel: Übersicht, Tilgungsplan, Restschuld je Jahresende", "xl/worksheets/sheet3.xml" in plan_names and "Hauskredit" in sheet2 and "Restschuld" in sheet2, plan_names)
            # Datenabdeckung und Export in den Einstellungen
            await pn.goto(BASE + "#/einstellungen"); await pn.get_by_test_id("coverage-card").wait_for()
            cov_txt = plain(await pn.get_by_test_id("coverage-card").inner_text())
            ok("Datenabdeckung: Girokonto mit fehlenden Monaten", "Girokonto: Daten seit März 2024" in cov_txt and "es fehlen Daten für" in cov_txt, cov_txt[:160])
            async with pn.expect_download() as dl_all:
                await pn.get_by_test_id("exp-run").click()
            all_path = Path(tempfile.mkdtemp()) / "all.xlsx"; await (await dl_all.value).save_as(all_path)
            with zipfile.ZipFile(all_path) as zf: all_names = zf.namelist(); wb = zf.read("xl/workbook.xml").decode()
            ok("Export Gesamter Finanzbestand als Excel: Konten, Buchungen, Kredite, Tilgungspläne", all([f'name="{n}"' in wb for n in ("Konten", "Buchungen", "Kredite", "Tilgungspläne")]) and "xl/styles.xml" in all_names, wb[:200])
            await pn.get_by_test_id("exp-kind").select_option("zeitraum"); await pn.get_by_test_id("exp-from").fill("2026-11"); await pn.get_by_test_id("exp-to").fill("2026-11"); await pn.get_by_test_id("exp-csv").click()
            async with pn.expect_download() as dl_csv:
                await pn.get_by_test_id("exp-run").click()
            csv_path = Path(tempfile.mkdtemp()) / "z.csv"; await (await dl_csv.value).save_as(csv_path); csv_txt = csv_path.read_text(encoding="utf-8")
            ok("Export als CSV im deutschen Excel-Format", csv_txt.startswith("\ufeffDatum;Konto;Art;") and "15.11.2026;Girokonto;Ausgabe;gebucht;Bäcker;-5,00;" in csv_txt, csv_txt[:160])
            await dn.close()

            # ---------- Erster Start: Ersteinrichtung, Führung, selbst entdecken (v0.8.5) ----------
            do_, po, errs_o = await device(p, "O")
            await po.goto(BASE); await po.wait_for_url(re.compile("#/einrichtung")); await setup(po, welcome=None)
            await po.get_by_test_id("welcome").wait_for(timeout=10000)
            opts_w = [plain(t) for t in await po.locator("[data-testid=welcome] button").all_inner_texts()]
            await po.get_by_test_id("welcome-wizard").click(); await po.get_by_test_id("wizard").wait_for(timeout=5000)
            await po.get_by_test_id("wz-next").click()
            await po.get_by_test_id("wz-yes").click(); await po.get_by_test_id("wz-balance").fill("1.234,56"); await po.get_by_test_id("wz-create").click(); await po.wait_for_timeout(200)
            again = plain(await po.locator("[data-testid=wizard] h1").inner_text()); await po.get_by_test_id("wz-skip").click()
            await po.get_by_test_id("wz-yes").click(); await po.get_by_test_id("wz-balance").fill("5.000,00"); await po.get_by_test_id("wz-create").click(); await po.wait_for_timeout(200)
            await po.get_by_test_id("wz-no").click(); await po.get_by_test_id("wz-no").click()
            await po.get_by_test_id("wz-yes").click(); await po.get_by_test_id("wz-no").click(); await po.get_by_test_id("wz-next").click()
            summary_w = plain(await po.get_by_test_id("wz-summary").inner_text()); to_loans = await po.get_by_test_id("wz-to-loans").count()
            await po.get_by_test_id("wz-finish").click(); await po.wait_for_url(re.compile("#/start")); await po.wait_for_timeout(300); accs_o = await balances(po)
            ok("Erster Start: Auswahl mit drei Möglichkeiten; Ersteinrichtung fragt Konten ab und legt sie an",
               opts_w == ["Hilf mir bei der Einrichtung", "Zeig mir die App", "Ich schaue mich selbst um"] and again.startswith("Noch ein Girokonto") and "Girokonto: 1.234,56 €" in summary_w and "Tagesgeld: 5.000,00 €" in summary_w and to_loans == 1
               and set(accs_o) == {"Girokonto", "Tagesgeld"}, (opts_w, again, summary_w, to_loans, accs_o))
            await po.reload(); await po.wait_for_url(re.compile("#/entsperren"), timeout=15000); await unlock(po); await po.wait_for_timeout(800)
            ok("Willkommensauswahl erscheint nach einem Neustart nie wieder", await po.get_by_test_id("welcome").count() == 0, "")
            await po.goto(BASE + "#/einstellungen"); await po.get_by_test_id("help-tour").click(); await po.get_by_test_id("tour").wait_for(timeout=5000)
            titles = []
            for _ in range(15):
                if not await po.get_by_test_id("tour").count(): break
                titles.append(plain(await po.locator("[data-testid=tour] h2").inner_text())); await po.get_by_test_id("tour-next").click(); await po.wait_for_timeout(150)
            ok("Führung über Einstellungen → Hilfe: sinnvolle Reihenfolge, endet mit „Fertig“", titles[:3] == ["Willkommen im Haushaltsbuch", "Zuerst: deine Konten", "Neue Buchung"] and "Einstellungen" in titles and titles[-1] == "Fertig" and await po.get_by_test_id("tour").count() == 0, titles)
            await do_.close()
            dp_, pp, errs_p = await device(p, "P")
            await pp.goto(BASE); await pp.wait_for_url(re.compile("#/einrichtung")); await setup(pp, welcome="tour")
            await pp.get_by_test_id("tour").wait_for(timeout=5000); first_t = plain(await pp.locator("[data-testid=tour] h2").inner_text())
            await pp.get_by_test_id("tour-next").click(); await pp.wait_for_timeout(300)
            spot = await pp.locator(".spot").count(); second_t = plain(await pp.locator("[data-testid=tour] h2").inner_text())
            await pp.get_by_test_id("tour-end").click(); await pp.wait_for_timeout(200); gone = await pp.get_by_test_id("tour").count() == 0
            await pp.reload(); await pp.wait_for_url(re.compile("#/entsperren"), timeout=15000); await unlock(pp); await pp.wait_for_timeout(800)
            ok("„Zeig mir die App“: Führung zeigt auf das Element, lässt sich jederzeit beenden; danach keine Auswahl mehr", first_t == "Willkommen im Haushaltsbuch" and second_t == "Zuerst: deine Konten" and spot == 1 and gone and await pp.get_by_test_id("welcome").count() == 0, (first_t, second_t, spot, gone))
            await dp_.close()

            # ---------- Leistungstest: zehn Jahre Daten (Bauplan 11) ----------
            import openpyxl, datetime, random
            random.seed(7)
            wb = openpyxl.Workbook(); ws = wb.active; ws.title = "Ausgaben"; ws.append(["Ausgaben"]); ws.append(["Datum", "Kategorie", "Konto", "Betrag", "Währung", "", "", "", "Kommentar"])
            day0 = datetime.date(2016, 1, 1)
            shops = ["REWE", "EDEKA", "ALDI", "LIDL", "DM", "Tankstelle", "Bäckerei", "Fressnapf", "Bauhaus", "Apotheke"]
            n_rows = 0
            for d in range(0, 3650):
                for _ in range(3):
                    ws.append([datetime.datetime.combine(day0 + datetime.timedelta(days=d), datetime.time()), "Lebensmittel", "Girokonto", round(random.uniform(2, 120), 2), "EUR", "", "", "", random.choice(shops)]); n_rows += 1
            wi = wb.create_sheet("Einnahmen"); wi.append(["Einnahmen"]); wi.append(["Datum"])
            for mth in range(120):
                y, mm = 2016 + mth // 12, mth % 12 + 1
                wi.append([datetime.datetime(y, mm, 28), "Gehalt", "Girokonto", 2450, "EUR", "", "", "", "Gehalt"]); n_rows += 1
            big = Path(tempfile.mkdtemp()) / "viele-jahre.xlsx"; wb.save(big)
            c, pc, errs_c = await device(p, "C")
            await pc.goto(BASE); await pc.wait_for_url(re.compile("#/einrichtung")); await setup(pc)
            await pc.get_by_test_id("acc-new").click(); await pc.get_by_test_id("acc-name").fill("Girokonto"); await pc.get_by_test_id("acc-start").fill("1.000,00"); await pc.get_by_test_id("acc-save").click(); await pc.wait_for_timeout(300)
            await pc.goto(BASE + "#/import"); t0 = time.time()
            await pc.get_by_test_id("xlsx-file").set_input_files(str(big)); await pc.get_by_test_id("legacy-summary").wait_for(timeout=120000)
            t_read = time.time() - t0
            g = pc.locator(".grp").filter(has_text="Ausgaben: Lebensmittel").first
            await g.locator("[data-testid=cat]").first.select_option("a-haushalt")
            await pc.locator(".grp").filter(has_text="Einnahmen: Gehalt").first.locator("[data-testid=cat]").first.select_option("e-gehalt")
            await pc.wait_for_timeout(300)
            t0 = time.time(); await pc.get_by_test_id("legacy-commit").click(); await pc.wait_for_url(re.compile("#/start"), timeout=180000); t_commit = time.time() - t0
            await pc.get_by_role("button", name="Jetzt sperren").click()
            t0 = time.time(); await unlock(pc); await pc.get_by_test_id("month-card").wait_for(timeout=60000); t_unlock = time.time() - t0
            await pc.goto(BASE + "#/statistik"); await pc.get_by_test_id("kpi-fix").wait_for()
            t0 = time.time(); await pc.get_by_test_id("stat-year").click(); await pc.locator("button.mb").first.wait_for(timeout=60000); t_year = time.time() - t0
            await pc.get_by_test_id("stat-prev").click(); await pc.locator("button.mb").nth(11).wait_for(timeout=60000)
            perf = f"{n_rows} Zeilen: Datei lesen {t_read:.1f} s, übernehmen {t_commit:.1f} s, entsperren {t_unlock:.1f} s, Jahresstatistik {t_year:.1f} s"
            ok("Leistung: zehn Jahre Daten (über 10.000 Buchungen) bleiben flüssig", t_unlock < 4 and t_year < 4, perf)
            await c.close()

            # ---------- Kredite (v0.7.0) ----------
            await page.goto(BASE + "#/kredite"); await page.get_by_test_id("loan-new").click()
            for tid, v in (("lf-name", "Hauskredit"), ("lf-balance", "150.000,00"), ("lf-rate", "780,00"), ("lf-day", "30"), ("lf-rateP", "3,1"), ("lf-pattern", "Kreditrate Hauskredit"), ("lf-fixed", "2031-12-31")):
                await page.get_by_test_id(tid).fill(v)
            preview = plain(await page.get_by_test_id("lf-preview").inner_text())
            # Rückwärtsrechnung wie in der App: Restschuld vor der Rate = (Restschuld + Rate) ÷ (1 + Sollzins ÷ 12)
            prev_c = round((15000000 + 78000) / (1 + 3100 / 1200000)); exp_p = prev_c - 15000000; exp_i_c = 78000 - exp_p
            fmt = lambda c: f"{c // 100:,}".replace(",", ".") + "," + f"{c % 100:02d}" + " €"
            exp_i = fmt(exp_i_c)
            await page.get_by_test_id("lf-save").click(); await page.get_by_test_id("loan-Hauskredit").wait_for(timeout=10000)
            total = plain(await page.get_by_test_id("loans-total").inner_text())
            await page.get_by_test_id("loan-Hauskredit").click(); await page.get_by_test_id("loan-detail").wait_for()
            matched = plain(await page.get_by_test_id("loan-matched").inner_text()); paid_i = plain(await page.get_by_test_id("paid-interest").inner_text())
            ok("Kredit angelegt: Vorschau, Restschuld, Rate erkannt und rückwirkend in Zinsen und Tilgung aufgeteilt",
               "abbezahlt voraussichtlich" in preview and total == "150.000,00 €" and matched.startswith("1 Buchungen zugeordnet") and paid_i == exp_i, (preview[:80], total, matched[:40], paid_i))
            await page.get_by_test_id("loan-plan").click(); await page.get_by_test_id("plan-table").wait_for(timeout=5000)
            rows_plan = await page.locator("[data-testid=plan-table] tbody tr").count()
            ok("Tilgungsplan je Jahr bis zur Tilgung", rows_plan > 10, rows_plan)
            await page.goto(BASE + "#/statistik"); await page.get_by_test_id("pillar-finanzierung").wait_for()
            await page.get_by_test_id("pillar-finanzierung").locator("button.bar", has_text="Hausfinanzierung").first.click(); await page.wait_for_timeout(200)
            parts_l = [plain(t) for t in await page.get_by_test_id("pillar-finanzierung").locator(".sub .bar").all_inner_texts()]
            ok("Statistik: Kreditrate in der Gruppe als Zinsen und Tilgung", any(t.startswith("Hauskredit: Zinsen " + exp_i) for t in parts_l) and any(t.startswith("Hauskredit: Tilgung " + fmt(exp_p)) for t in parts_l), parts_l)
            await page.goto(BASE + "#/buchungen?ansicht=wiederkehrend"); await page.wait_for_timeout(300)
            n_rate = sum(1 for t in await page.locator(".it .row").all_inner_texts() if "Kreditrate Hauskredit" in plain(t))
            await page.goto(BASE + "#/start"); await page.get_by_test_id("ov-net").wait_for()
            ok("Rate einmal für die Prognose eingeplant; Übersicht zeigt Restschuld und Vermögen netto", n_rate == 1 and await page.get_by_test_id("ov-loans").count() == 1, n_rate)
            await page.goto(BASE + "#/kredite"); await page.get_by_test_id("loan-new").click()
            for tid, v in (("lf-name", "Test"), ("lf-balance", "10.000,00"), ("lf-rate", "10,00"), ("lf-rateP", "5"), ("lf-day", "1")):
                await page.get_by_test_id(tid).fill(v)
            await page.get_by_test_id("lf-save").click(); await page.get_by_role("alert").first.wait_for(timeout=5000)
            ok("Plausibilität: Rate unter den Zinsen wird nicht gespeichert", "deckt die Zinsen" in plain(await page.get_by_role("alert").first.inner_text()))
            await page.get_by_role("button", name="Abbrechen").click()

            # ---------- Sammelabbuchungen (v0.7.1) ----------
            async def debeka(amount, date):
                await page.goto(BASE + "#/neu"); await page.get_by_test_id("amount").fill(amount); await page.get_by_test_id("text").fill("DEBEKA Beiträge")
                await page.get_by_test_id("date").fill(date); await page.locator("[data-testid=cat]").first.select_option("a-versicherungen")
                await page.get_by_test_id("save").click(); await page.wait_for_url(re.compile("#/start"))
            await debeka("61,00", (datetime.date.today() - datetime.timedelta(days=200)).isoformat())
            await debeka("66,40", (datetime.date.today() - datetime.timedelta(days=20)).isoformat())
            await page.goto(BASE + "#/buchungen"); await page.get_by_test_id("search").fill("DEBEKA"); await page.wait_for_timeout(300)
            await page.locator(".bk .row", has_text="66,40").first.click(); ed = page.locator(".bk.open")
            await ed.get_by_test_id("split-toggle").click(); await ed.get_by_test_id("split-add").click()
            for i, (sub, amt) in enumerate((("Kfz", "45,20"), ("Haftpflicht", "8,90"), ("Rechtsschutz", "12,30"))):
                await ed.locator("[data-testid=cat]").nth(i).select_option("a-versicherungen"); await ed.locator("[data-testid=sub]").nth(i).select_option(sub)
                await ed.get_by_test_id(f"split-{i}").fill(amt)
            await ed.get_by_test_id("save").click(); await page.get_by_test_id("retro-offer").wait_for(timeout=10000)
            offer = plain(await page.get_by_test_id("retro-offer").inner_text())
            await page.get_by_test_id("retro-apply").click(); await page.wait_for_timeout(400)
            ok("Sammelabbuchung: von Hand aufgeteilt, frühere (niedrigere) Abbuchung wird rückwirkend angeboten und aufgeteilt",
               "1 frühere Abbuchung passt" in offer and await page.get_by_test_id("retro-offer").count() == 0, offer[:100])
            await page.goto(BASE + "#/neu"); await page.get_by_test_id("amount").fill("54,10"); await page.get_by_test_id("text").fill("DEBEKA Beiträge")
            await page.get_by_test_id("split-learned").wait_for(timeout=5000)
            learned_txt = plain(await page.get_by_test_id("split-learned").inner_text())
            ok("Neue Buchung: „Wie gelernt aufteilen“ findet die passende Kombination (2 von 3 Teilen)", "2 Teile" in learned_txt and "angepasst" not in learned_txt, learned_txt)
            r = await import_mail(page, "auf dem Konto *1234 wurden folgende Umsätze verbucht:\nDEBEKA Beiträge: -69,73 EUR")
            await page.get_by_test_id("import-commit").click(); await page.wait_for_url(re.compile("#/start"))
            await page.goto(BASE + "#/buchungen?pruefen=1"); await page.wait_for_timeout(400)
            await page.locator(".bk .row", has_text="69,73").first.click(); ed2 = page.locator(".bk.open")
            parts_n = sum([await ed2.get_by_test_id(f"split-{i}").count() for i in range(4)])
            note_txt = await ed2.get_by_test_id("note").input_value()
            ok("Kontowecker: gestiegener Beitrag (+5 %) wird automatisch aufgeteilt und unter „Zu prüfen“ vorgelegt",
               await ed2.get_by_test_id("split-2").count() == 1 and "angepasst" in note_txt, (parts_n, note_txt[:160]))
            await page.goto(BASE + "#/start")

            # ---------- Vollständiges Backup (v0.6.6) ----------
            await page.goto(BASE + "#/einstellungen"); await page.get_by_test_id("buffer").fill("300,00"); await page.get_by_test_id("buffer").blur()
            await page.get_by_test_id("prudence").select_option("vorsichtig"); await page.wait_for_timeout(200)
            await page.goto(BASE + "#/ruecklagen"); await page.get_by_test_id("pot-new").click(); await page.get_by_test_id("pot-kind").select_option("ziel")
            await page.get_by_test_id("pot-name").fill("Urlaub 2027"); await page.get_by_test_id("pot-target").fill("1.000,00")
            await page.get_by_test_id("pot-due").fill((datetime.date.today() + datetime.timedelta(days=200)).isoformat()); await page.get_by_test_id("pot-balance").fill("100,00"); await page.get_by_test_id("pot-save").click(); await page.wait_for_timeout(300)
            await page.goto(BASE + "#/einstellungen")
            async with page.expect_download() as dl2:
                await page.get_by_test_id("backup-download").click()
            d2 = await dl2.value; b2 = Path(tempfile.mkdtemp()) / d2.suggested_filename; await d2.save_as(b2)
            h, ph, errs_h = await device(p, "H")
            await ph.goto(BASE); await ph.wait_for_url(re.compile("#/einrichtung"))
            await ph.get_by_test_id("restore").click(); await ph.set_input_files("#backupFile", str(b2))
            await ph.get_by_test_id("restore-key").fill(key); await ph.get_by_test_id("open-backup").click()
            await ph.get_by_test_id("passkey").click(); await ph.get_by_test_id("finish-nopw").click(timeout=15000)
            await ph.get_by_test_id("to-app").click(timeout=20000); await ph.wait_for_url(re.compile("#/start"))
            await dismiss_welcome(ph)
            await ph.goto(BASE + "#/statistik"); await ph.get_by_test_id("kpi-fix").wait_for(); await ph.wait_for_timeout(300)
            fin_h = plain(await ph.get_by_test_id("pillar-finanzierung").inner_text()) if await ph.get_by_test_id("pillar-finanzierung").count() else ""
            await ph.locator("button.bar", has_text="Hausfinanzierung").first.click(); await ph.wait_for_timeout(200)
            parts_h = [plain(t) for t in await ph.locator(".sub .bar").all_inner_texts()]
            await ph.goto(BASE + "#/buchungen?ansicht=wiederkehrend"); await ph.locator(".it .row").first.wait_for(timeout=10000)
            rec_h = [plain(t) for t in await ph.locator(".it .row").all_inner_texts()]
            await ph.goto(BASE + "#/ruecklagen"); await ph.wait_for_timeout(400)
            pots_h = plain(await ph.locator("main").inner_text())
            await ph.goto(BASE + "#/einstellungen"); await ph.get_by_test_id("buffer").wait_for(); await ph.wait_for_timeout(300)
            buf_h = await ph.get_by_test_id("buffer").input_value(); prud_h = await ph.get_by_test_id("prudence").input_value(); rules_h = await ph.locator(".rule").count()
            ok("Vollständiges Backup: Gruppen, Kredit-Namen, wiederkehrende Zahlungen, Spartöpfe, Regeln, Puffer und Vorsichtsstufe kommen mit",
               "Hausfinanzierung" in fin_h and any(t.startswith("Hauskredit") for t in parts_h) and any("Gehalt Sandra" in t for t in rec_h) and "Urlaub 2027" in pots_h
               and buf_h == "300,00" and prud_h == "vorsichtig" and rules_h >= 3, (fin_h[:60], parts_h[:2], rec_h[:2], buf_h, prud_h, rules_h))
            await ph.goto(BASE + "#/kredite"); await ph.wait_for_timeout(400)
            ok("Kredite kommen mit dem Backup mit", await ph.get_by_test_id("loan-Hauskredit").count() == 1)
            await h.close()

            await page.goto(BASE + "#/einstellungen"); await page.get_by_test_id("storage-info").wait_for(timeout=10000)
            st_info = plain(await page.get_by_test_id("storage-info").inner_text())
            ok("Einstellungen: belegter Speicher mit Aufteilung in App-Dateien und Daten", "App-Dateien" in st_info and "MB" in st_info, st_info)

            # ---------- Nach Updates suchen (v0.6.1) ----------
            await page.goto(BASE + "#/einstellungen"); await page.get_by_test_id("check-update").wait_for()
            await page.get_by_test_id("check-update").click(); await page.get_by_test_id("update-msg").wait_for()
            await page.locator("[data-testid=update-msg]", has_text=re.compile("neueste|nicht geklappt")).wait_for(timeout=15000)
            msg_same = plain(await page.get_by_test_id("update-msg").inner_text())
            swfile = site / "sw.js"
            swfile.write_text(swfile.read_text(encoding="utf-8").replace("const VERSION = '", "const VERSION = 'neu2-", 1), encoding="utf-8")
            await page.get_by_test_id("check-update").click()
            await page.locator("[data-testid=update-msg]", has_text="Neue Version gefunden").wait_for(timeout=20000)
            banner = await page.get_by_text("Neue Version verfügbar").count()
            ok("„Nach Updates suchen“: meldet aktuell bzw. neue Version, Hinweis erscheint", "neueste Version" in msg_same and banner == 1, (msg_same, banner))
            async with page.expect_navigation(timeout=20000):
                await page.get_by_role("button", name="Jetzt aktualisieren").click()
            await page.wait_for_url(re.compile("#/entsperren"), timeout=15000); await unlock(page)
            ok("Update über die Einstellungen eingespielt, Daten unverändert", await balances(page) == {"Girokonto": "-36,87 €", "Tagesgeld": "5.050,00 €"} or len(await balances(page)) == 2, await balances(page))

            # ---------- Dateien, Sicherheit ----------
            files = sorted(str(x.relative_to(DIST)) for x in DIST.rglob("*") if x.is_file())
            ok("Auslieferung: genau index.html, app.js, sw.js, Manifest und zwei Symbole", files == sorted(APP_FILES), ", ".join(files))
            csp = [e for e in errs + errs_b + errs_c + errs_d + errs_e + errs_f + errs_g + errs_h + errs_j + errs_l + errs_m + errs_n + errs_o + errs_p if "Content Security Policy" in e or "Refused" in e]
            ok("Keine Verstöße gegen die Content Security Policy", not csp, "; ".join(csp)[:200])
            other = [e for e in errs + errs_b + errs_c + errs_d + errs_e + errs_f + errs_g + errs_h + errs_j + errs_l + errs_m + errs_n + errs_o + errs_p if e not in csp and "Failed to load resource" not in e and "ERR_INTERNET_DISCONNECTED" not in e]
            ok("Keine JavaScript-Fehler", not other, "; ".join(other)[:300])
            await a.close()
    except Exception as e:
        # Absturz zählt als Fehler; das Ergebnis wird trotzdem geschrieben (nie veraltete Zahlen im Prüfbericht)
        import traceback
        traceback.print_exc()
        ok("Ende-zu-Ende-Lauf ohne Absturz", False, f"{type(e).__name__}: {str(e)[:200]}")
    finally:
        server.terminate()
    (HERE / "ergebnis.json").write_text(json.dumps(results, ensure_ascii=False, indent=1), encoding="utf-8")
    failed = [r for r in results if not r["ok"]]
    print(f"\n{len(results) - len(failed)} von {len(results)} Ende-zu-Ende-Tests bestanden")
    sys.exit(1 if failed else 0)

asyncio.run(main())
