#!/usr/bin/env python3
"""
Ende-zu-Ende-Tests v0.2 (Bauplan 9): Chromium mit Smartphone-Profil, virtueller Passkey mit PRF,
App unter /haushaltsbuch/ wie auf GitHub Pages. Ausgangslage ist die gelieferte v0.1 (e2e/v01),
darauf wird v0.2 als Update eingespielt. Ergebnis: e2e/ergebnis.json

Aufruf: python3 e2e/test_app.py <Ordner mit der gebauten App>
"""
import asyncio, json, os, re, shutil, socket, subprocess, sys, tempfile, time
from pathlib import Path
from playwright.async_api import async_playwright

HERE = Path(__file__).resolve().parent
DIST = Path(sys.argv[1] if len(sys.argv) > 1 else "dist/haushaltsbuch/browser").resolve()
V01 = HERE / "v01"
APP_FILES = ["index.html", "app.js", "sw.js", "manifest.webmanifest", "icon.png", "neu.png"]
MAIL = "auf dem Konto *1234 wurden folgende Umsätze verbucht:\nAGILA Hau.: -29,59 EUR\nMarkt Alt.: -160,24 EUR\n\nneuer Saldo: 1.158,12 EUR"
results = []

def freeport():
    with socket.socket() as so:
        so.bind(("127.0.0.1", 0))
        return so.getsockname()[1]

PORT = freeport()
BASE = f"http://localhost:{PORT}/haushaltsbuch/"

def ok(name, cond, detail=""):
    results.append({"test": name, "ok": bool(cond), "detail": str(detail)})
    print(("OK   " if cond else "FAIL ") + name + (f" ({detail})" if detail else ""))

def plain(s):
    return s.replace("\u00a0", " ").replace("\n", " ")

async def device(p, name):
    ctx = await p.chromium.launch_persistent_context(tempfile.mkdtemp(prefix=name), headless=True, viewport={"width": 390, "height": 844},
        device_scale_factor=2, is_mobile=True, has_touch=True, locale="de-DE", accept_downloads=True,
        user_agent="Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/157.0.0.0 Mobile Safari/537.36")
    page = ctx.pages[0] if ctx.pages else await ctx.new_page()
    errors = []
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    page.on("pageerror", lambda e: errors.append(str(e)))
    cdp = await ctx.new_cdp_session(page)
    await cdp.send("WebAuthn.enable", {"enableUI": False})
    await cdp.send("WebAuthn.addVirtualAuthenticator", {"options": {"protocol": "ctap2", "ctap2Version": "ctap2_1", "transport": "internal",
        "hasResidentKey": True, "hasUserVerification": True, "isUserVerified": True, "hasPrf": True, "automaticPresenceSimulation": True}})
    return ctx, page, errors

async def has(page, text, timeout=10000):
    try:
        await page.locator("main").get_by_text(text, exact=False).first.wait_for(timeout=timeout)
        return True
    except Exception:
        return False

async def unlock(page):
    await page.get_by_test_id("unlock-passkey").click()
    await page.wait_for_url(re.compile(r"#/(start|neu|buchungen|einstellungen)"), timeout=15000)

async def balances(page):
    await page.goto(BASE + "#/start"); await page.wait_for_load_state()
    if "#/entsperren" in page.url: await unlock(page)
    await page.locator(".acc .row").first.wait_for()
    out = {}
    for t in await page.locator(".acc .row").all_inner_texts():
        parts = plain(t).split(" ")
        out[parts[0]] = " ".join(parts[-2:])
    return out

async def setup(page, password=None):
    await page.get_by_test_id("neu").click()
    await page.get_by_test_id("passkey").click()
    key = re.sub(r"\s+", "", await page.get_by_test_id("recovery-key").inner_text(timeout=15000))
    groups = key.split("-")
    await page.get_by_test_id("key-written").click()
    a = int(await page.get_by_test_id("group-a").get_attribute("data-group")); b = int(await page.get_by_test_id("group-b").get_attribute("data-group"))
    await page.get_by_test_id("group-a").fill(groups[a]); await page.get_by_test_id("group-b").fill(groups[b]); await page.get_by_test_id("check-key").click()
    if password:
        await page.get_by_test_id("pw1").fill(password); await page.get_by_test_id("pw2").fill(password); await page.get_by_test_id("finish-pw").click()
    else:
        await page.get_by_test_id("finish-nopw").click()
    await page.get_by_test_id("to-app").click(timeout=20000)
    return key

async def import_mail(page, text, choose=None):
    await page.goto(BASE + "#/neu"); await page.wait_for_load_state()
    await page.get_by_test_id("tab-email").click()
    await page.get_by_test_id("mail").fill(text)
    rows = page.locator(".import .row")
    await rows.first.wait_for()
    for i, (kind, a, b) in (choose or {}).items():
        if kind == "cat":
            await rows.nth(i).locator("[data-testid=cat]").select_option(a)
            if b: await rows.nth(i).locator("[data-testid=sub]").select_option(b)
        elif kind == "transfer":
            await page.get_by_test_id(f"transfer-{i}").select_option(a)
    await page.wait_for_timeout(150)
    return {
        "rows": [plain(await rows.nth(i).locator(".head").inner_text()) for i in range(await rows.count())],
        "gap": [plain(t) for t in await page.get_by_test_id("gap").all_inner_texts()],
        "warn": [plain(t) for t in await page.locator(".import p.warn").all_inner_texts()],
        "button": await page.get_by_test_id("import-commit").inner_text(),
    }

async def main():
    site = Path(tempfile.mkdtemp(prefix="site")) / "haushaltsbuch"
    site.mkdir(parents=True)
    for f in APP_FILES: shutil.copy(V01 / f, site / f)
    server = subprocess.Popen([sys.executable, "-m", "http.server", str(PORT), "--bind", "127.0.0.1"], cwd=site.parent, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(0.8)
    try:
        async with async_playwright() as p:
            a, page, errs = await device(p, "A")
            # ---------- Ausgangslage: installierte v0.1 ----------
            await page.goto(BASE); await page.wait_for_url(re.compile("#/einrichtung"))
            pw = "Hunde lieben Brennholz im Winter"
            key = await setup(page, pw)
            await page.wait_for_function("navigator.serviceWorker && navigator.serviceWorker.controller !== null", timeout=20000)
            ok("v0.1 eingerichtet (Ausgangslage wie auf dem Handy)", await has(page, "Version 0.1"))

            # ---------- Update auf v0.2 ----------
            for f in APP_FILES: shutil.copy(DIST / f, site / f)
            await page.evaluate("navigator.serviceWorker.getRegistration().then((r) => r.update())")
            await page.get_by_text("Neue Version verfügbar").wait_for(timeout=20000)
            async with page.expect_navigation(timeout=20000):
                await page.get_by_role("button", name="Jetzt aktualisieren").click()
            await page.wait_for_url(re.compile("#/entsperren"), timeout=15000)
            await unlock(page)
            stores = await page.evaluate("new Promise((r) => { const q = indexedDB.open('haushaltsbuch'); q.onsuccess = () => r([...q.result.objectStoreNames]); })")
            ok("Update v0.1 → v0.2: Fingerabdruck gilt weiter, Testdaten entfernt", await has(page, "Noch keine Konten") and "testdata" not in stores and "accounts" in stores, ", ".join(stores))
            ver = "v" + json.loads((HERE.parent / "package.json").read_text())["version"].removesuffix(".0")
            ok(f"Kopfzeile zeigt {ver}", ver in await page.locator("header").inner_text())

            # ---------- Konten ----------
            for name, typ, ident, start, date in (("Girokonto", "giro", "1234", "1.500,00", "2026-11-10"), ("Tagesgeld", "tagesgeld", "5678", "4.850,00", "2026-11-10")):
                await page.get_by_test_id("acc-new").click()
                await page.get_by_test_id("acc-name").fill(name); await page.get_by_test_id("acc-type").select_option(typ)
                await page.get_by_test_id("acc-id").fill(ident); await page.get_by_test_id("acc-start").fill(start)
                await page.locator(".newbox input[type=date]").fill(date)
                await page.get_by_test_id("acc-save").click(); await page.wait_for_timeout(200)
            await page.get_by_test_id("acc-new").click(); await page.get_by_test_id("acc-name").fill("girokonto"); await page.get_by_test_id("acc-id").fill("1234")
            await page.get_by_test_id("acc-start").fill("1"); await page.get_by_test_id("acc-save").click()
            await page.get_by_role("alert").first.wait_for(timeout=5000)
            dupe = [plain(t) for t in await page.get_by_role("alert").all_inner_texts()]
            ok("Konto: doppelter Name und doppelte Kennung abgelehnt", len(dupe) == 2, "; ".join(dupe))
            await page.get_by_role("button", name="Abbrechen").click()
            bal = await balances(page)
            ok("Konten angelegt mit Startsaldo", bal == {"Girokonto": "1.500,00 €", "Tagesgeld": "4.850,00 €"}, bal)

            # ---------- Kontowecker-Import mit dem Beispiel der Nutzerin ----------
            r = await import_mail(page, MAIL, {0: ("cat", "a-versicherungen", "Tierversicherung"), 1: ("cat", "a-wasser-abwasser", None)})
            ok("Import: Konto *1234 erkannt, zwei Umsätze", len(r["rows"]) == 2 and await has(page, "Konto: Girokonto"), r["rows"])
            ok("Import: Lücke −152,05 € erkannt (Beispiel der Nutzerin)", r["gap"] and "-152,05 €" in r["gap"][0] and "1.310,17 €" in r["gap"][0], r["gap"])
            await page.get_by_test_id("import-commit").click(); await page.wait_for_url(re.compile("#/start"))
            bal = await balances(page)
            hint = [plain(t) for t in await page.locator(".hint-row").all_inner_texts()]
            ok("Import: Kontostand 1.158,12 € laut Bank, Hinweis auf der Übersicht", bal["Girokonto"] == "1.158,12 €" and any("-152,05 €" in h for h in hint), hint)
            r = await import_mail(page, MAIL)
            ok("Gleiche E-Mail nochmal: erkannt, Buchungen abgewählt", any("schon einmal übernommen" in w for w in r["warn"]) and all("schon vorhanden" in x for x in r["rows"]), r["button"])

            # ---------- Lücke per Korrekturbuchung schließen ----------
            await page.goto(BASE + "#/start"); await page.locator(".hint-row", has_text="Girokonto").click()
            await page.get_by_test_id("acc-correction").click(); await page.wait_for_timeout(300)
            bal = await balances(page)
            ok("Korrekturbuchung schließt die Lücke, Kontostand bleibt 1.158,12 €", await page.locator(".hint-row", has_text="Girokonto").count() == 0 and bal["Girokonto"] == "1.158,12 €")

            # ---------- Buchung von Hand mit Aufteilung ----------
            await page.goto(BASE + "#/neu"); await page.get_by_test_id("amount").fill("85,00"); await page.get_by_test_id("text").fill("REWE Einkauf")
            await page.locator("[data-testid=cat]").first.select_option("a-haushalt"); await page.locator("[data-testid=sub]").first.select_option("Lebensmittel")
            await page.get_by_test_id("split-toggle").click(); await page.get_by_test_id("split-0").fill("70,00")
            await page.locator("[data-testid=cat]").nth(1).select_option("a-haushalt"); await page.locator("[data-testid=sub]").nth(1).select_option("Drogerie")
            await page.get_by_test_id("split-1").fill("10,00"); await page.get_by_test_id("save").click()
            await page.get_by_role("alert").first.wait_for(timeout=5000)
            err = [plain(t) for t in await page.get_by_role("alert").all_inner_texts()]
            await page.get_by_test_id("split-1").fill("15,00"); await page.get_by_test_id("save").click(); await page.wait_for_url(re.compile("#/start"))
            bal = await balances(page)
            ok("Aufteilung: Fehlbetrag gemeldet, dann gespeichert", any("-5,00 €" in e for e in err) and bal["Girokonto"] == "1.073,12 €", bal["Girokonto"])

            # ---------- Doppelte Buchung von Hand ----------
            await page.goto(BASE + "#/neu"); await page.get_by_test_id("amount").fill("29,59"); await page.get_by_test_id("text").fill("AGILA Hau.")
            await page.get_by_test_id("text").blur(); await page.wait_for_timeout(200)
            suggested = await page.locator("[data-testid=cat]").input_value()
            ok("Regel aus dem Import schlägt die Kategorie beim Tippen vor", suggested == "a-versicherungen", suggested)
            await page.get_by_test_id("text").fill("AGILA HAUSTIERVERSICHERUNG AG")
            await page.get_by_test_id("save").click()
            try:
                await page.get_by_test_id("dup-warning").wait_for(timeout=5000); warned = True
            except Exception:
                warned = False
            ok("Doppelte Buchung von Hand wird erkannt (abgekürzter Bankentext)", warned)
            await page.get_by_role("button", name="Abbrechen").click()

            # ---------- Umbuchung ----------
            await page.goto(BASE + "#/neu"); await page.get_by_test_id("tab-umbuchung").click()
            await page.get_by_test_id("tr-amount").fill("500,00"); await page.get_by_test_id("tr-save").click(); await page.wait_for_url(re.compile("#/start"))
            bal = await balances(page)
            ok("Umbuchung Girokonto → Tagesgeld: beide Kontostände", bal == {"Girokonto": "573,12 €", "Tagesgeld": "5.350,00 €"}, bal)
            await page.goto(BASE + "#/buchungen"); await page.locator(".bk .row", has_text="Umbuchung nach Tagesgeld").click()
            await page.locator(".bk.open [data-testid=amount]").fill("400,00"); await page.locator(".bk.open [data-testid=save]").click(); await page.wait_for_timeout(300)
            bal = await balances(page)
            ok("Umbuchung bearbeiten ändert beide Seiten", bal == {"Girokonto": "673,12 €", "Tagesgeld": "5.250,00 €"}, bal)
            await page.goto(BASE + "#/buchungen"); await page.locator(".bk .row", has_text="Umbuchung von Girokonto").click()
            try:
                await page.get_by_role("button", name=re.compile("Umbuchung löschen")).click(timeout=5000)
            except Exception:
                await page.screenshot(path="/tmp/fail_transfer.png", full_page=True)
                raise
            await page.get_by_test_id("delete").click(); await page.wait_for_timeout(300)
            bal = await balances(page)
            ok("Umbuchung löschen entfernt beide Seiten", bal == {"Girokonto": "1.073,12 €", "Tagesgeld": "4.850,00 €"}, bal)

            # ---------- Umbuchung aus der E-Mail, Gemeinde-Regel nach Betrag, Zu prüfen ----------
            r = await import_mail(page, "auf dem Konto *1234 wurden folgende Umsätze verbucht:\nÜbertrag Tagesgeld: -200,00 EUR\nMarkt Alt.: -120,00 EUR\nUnbekannt GmbH: -9,99 EUR\n\nneuer Saldo: 743,13 EUR",
                                  {0: ("transfer", None, None), 1: ("cat", "a-steuern-gebuehren", "Grundsteuer")})
            tg = await page.locator("[data-testid=transfer-0] option").all_inner_texts()
            await page.get_by_test_id("transfer-0").select_option(label=[t for t in tg if "Tagesgeld" in t][0]); await page.wait_for_timeout(150)
            r2 = [plain(await page.locator(".import .row").nth(i).locator(".head").inner_text()) for i in range(3)]
            ok("Import: Zeile als Umbuchung markierbar, Saldo geht auf", "Umbuchung" in r2[0] and await page.get_by_test_id("gap").count() == 0, r2)
            await page.get_by_test_id("import-commit").click(); await page.wait_for_url(re.compile("#/start"))
            bal = await balances(page)
            ok("Umbuchung aus E-Mail bucht die Gegenseite aufs Tagesgeld", bal == {"Girokonto": "743,13 €", "Tagesgeld": "5.050,00 €"}, bal)
            ok("Nicht zugeordnete Buchung erscheint als Hinweis „Zu prüfen“", await page.get_by_test_id("hint-unclear").count() == 1)
            await page.get_by_test_id("hint-unclear").click(); await page.wait_for_url(re.compile("#/buchungen"))
            ok("Filter „Zu prüfen“ zeigt genau diese Buchung", [t for t in await page.locator(".bk .t").all_inner_texts()] == ["Unbekannt GmbH"])
            await page.goto(BASE + "#/neu"); await page.get_by_test_id("amount").fill("158,00"); await page.get_by_test_id("text").fill("Markt Alt."); await page.get_by_test_id("text").blur(); await page.wait_for_timeout(150)
            wasser = await page.locator("[data-testid=cat]").input_value()
            await page.get_by_test_id("amount").fill("121,50"); await page.locator("[data-testid=cat]").select_option("a-andere")
            ok("Gemeinde-Regel: 158,00 € → Wasser & Abwasser (120,00 € war Grundsteuer)", wasser == "a-wasser-abwasser", wasser)

            # ---------- Altdaten aus der alten App (XLSX) ----------
            before = await balances(page)
            await page.goto(BASE + "#/einstellungen"); await page.get_by_test_id("to-import").click(); await page.wait_for_url(re.compile("#/import"))
            await page.get_by_test_id("xlsx-file").set_input_files(str(HERE.parent / "test-data" / "altdaten-beispiel.xlsx"))
            await page.get_by_test_id("legacy-summary").wait_for(timeout=10000)
            await page.get_by_test_id("acc-map-Sondertilg 1250").select_option(label="Tagesgeld (*5678)")
            cards = page.locator(".grp")
            async def map_group(title, cat, sub=None):
                g = cards.filter(has_text=title).first
                await g.locator("[data-testid=cat]").first.select_option(cat)
                if sub: await g.locator("[data-testid=sub]").first.select_option(sub)
            await map_group("Ausgaben: Versicherung", "a-versicherungen")
            await map_group("Ausgaben: Nebenkosten", "a-wasser-abwasser")
            await map_group("Ausgaben: Lebensmittel", "a-haushalt", "Lebensmittel")
            await map_group("Ausgaben: Haus", "a-holz")
            await map_group("Einnahmen: Gehalt", "e-gehalt")
            g = cards.filter(has_text="Ausgaben: Nebenkosten").first
            await g.get_by_role("button", name=re.compile("Nach Kommentar unterscheiden")).click()
            await g.locator(".cm-row", has_text="Grundsteuer").wait_for(timeout=5000)
            texts = await g.locator(".cm-row").all_inner_texts()
            row = g.locator(".cm app-category-picker").nth(next(i for i, t in enumerate(texts) if "Grundsteuer" in t))
            await row.locator("[data-testid=cat]").select_option("a-steuern-gebuehren"); await row.locator("[data-testid=sub]").select_option("Grundsteuer")
            await page.wait_for_timeout(200)
            summary = {k: await page.get_by_test_id(k).inner_text() for k in ("sum-import", "sum-after", "sum-dup", "sum-uncat")}
            ok("Altdaten: Datei gelesen, Konten und Kategorien zugeordnet", summary == {"sum-import": "10", "sum-after": "1", "sum-dup": "0", "sum-uncat": "0"}, summary)
            await page.get_by_test_id("legacy-commit").click(); await page.wait_for_url(re.compile("#/start"))
            after = await balances(page)
            ok("Altdaten: Kontostände bleiben unverändert (Buchungen vor dem Startsaldo)", after == before, after)
            await page.goto(BASE + "#/buchungen"); await page.get_by_role("button", name=re.compile("Ältere Buchungen")).click(); await page.wait_for_timeout(200)
            older = [plain(t) for t in await page.locator(".bk .row").all_inner_texts()]
            gs = next((t for t in older if t.startswith("Grundsteuer ")), "")
            ok("Altdaten: Buchungen mit Kategorie und Ausnahme nach Kommentar in der Liste", any("Brennholz Maier" in t and "Holz" in t for t in older) and "Steuern & Gebühren › Grundsteuer" in gs and any("Sparrate" in t and "Umbuchung" in t for t in older), gs)
            await page.goto(BASE + "#/import"); await page.get_by_test_id("xlsx-file").set_input_files(str(HERE.parent / "test-data" / "altdaten-beispiel.xlsx"))
            await page.get_by_test_id("legacy-summary").wait_for(timeout=10000)
            again = {k: await page.get_by_test_id(k).inner_text() for k in ("sum-import", "sum-dup")}
            remembered = await cards.filter(has_text="Ausgaben: Haus").first.locator("[data-testid=cat]").first.input_value()
            ok("Altdaten: zweiter Import bringt nichts doppelt, Zuordnungen sind gemerkt", again == {"sum-import": "0", "sum-dup": "10"} and remembered == "a-holz", (again, remembered))

            # ---------- Sperren, Schnellzugriff, Offline ----------
            await page.goto(BASE + "#/start"); await page.get_by_role("button", name="Jetzt sperren").click()
            await page.goto(BASE + "?start=neue-buchung"); await page.wait_for_url(re.compile(r"ziel=%2Fneu")); await unlock(page)
            ok("Schnellzugriff „Neue Buchung“ nach dem Entsperren", page.url.endswith("#/neu"))
            await page.get_by_test_id("amount").fill("29,59"); await page.get_by_test_id("text").fill("AGILA Hau."); await page.get_by_test_id("text").blur(); await page.wait_for_timeout(200)
            ok("Gelernte Regeln gelten auch nach Sperren und Entsperren", await page.locator("[data-testid=cat]").input_value() == "a-versicherungen")
            await page.wait_for_function("navigator.serviceWorker.controller !== null", timeout=20000)
            await a.set_offline(True)
            await page.goto(BASE + "#/start"); await page.reload(); await page.wait_for_url(re.compile("#/entsperren")); await unlock(page)
            bal = await balances(page)
            ok("Offline: entsperren, Daten vollständig", bal == {"Girokonto": "743,13 €", "Tagesgeld": "5.050,00 €"}, bal)
            await a.set_offline(False)

            # ---------- Backup und Wiederherstellung ----------
            await page.goto(BASE + "#/einstellungen"); await page.wait_for_load_state()
            if "#/entsperren" in page.url: await unlock(page); await page.goto(BASE + "#/einstellungen")
            async with page.expect_download() as dl:
                await page.get_by_test_id("backup-download").click()
            d = await dl.value
            bpath = Path(tempfile.mkdtemp()) / d.suggested_filename
            await d.save_as(bpath)
            raw = bpath.read_text(encoding="utf-8")
            res = subprocess.run([sys.executable, str(HERE.parent / "docs" / "restore.py"), str(bpath)], input=key + "\n", capture_output=True, text=True, env={**os.environ, "PYTHONIOENCODING": "utf-8"})
            plainjson = bpath.with_suffix(".json").read_text(encoding="utf-8") if bpath.with_suffix(".json").exists() else ""
            ok("Backup verschlüsselt; restore.py öffnet Konten und Buchungen", "AGILA" not in raw and res.returncode == 0 and "Girokonto" in plainjson and "AGILA Hau." in plainjson and "MARKT ALT." in plainjson)
            b, pb, errs_b = await device(p, "B")
            await pb.goto(BASE); await pb.wait_for_url(re.compile("#/einrichtung"))
            await pb.get_by_test_id("restore").click(); await pb.set_input_files("#backupFile", str(bpath))
            await pb.get_by_test_id("restore-key").fill(key); await pb.get_by_test_id("open-backup").click()
            await pb.get_by_test_id("passkey").click(); await pb.get_by_test_id("finish-nopw").click(timeout=15000)
            await pb.get_by_test_id("to-app").click(timeout=20000); await pb.wait_for_url(re.compile("#/start"))
            bal_b = await balances(pb)
            ok("Zweites Gerät: Backup eingespielt, gleiche Kontostände", bal_b == {"Girokonto": "743,13 €", "Tagesgeld": "5.050,00 €"}, bal_b)
            await pb.goto(BASE + "#/einstellungen"); await pb.locator(".rule").first.wait_for(timeout=10000)
            ok("Zweites Gerät: gelernte Regeln sind mitgekommen", await pb.locator(".rule").count() >= 3, await pb.locator(".rule").count())
            await b.close()

            # ---------- Dateien, Sicherheit ----------
            files = sorted(str(x.relative_to(DIST)) for x in DIST.rglob("*") if x.is_file())
            ok("Auslieferung: genau index.html, app.js, sw.js, Manifest und zwei Symbole", files == sorted(APP_FILES), ", ".join(files))
            csp = [e for e in errs + errs_b if "Content Security Policy" in e or "Refused" in e]
            ok("Keine Verstöße gegen die Content Security Policy", not csp, "; ".join(csp)[:200])
            other = [e for e in errs + errs_b if e not in csp and "Failed to load resource" not in e and "ERR_INTERNET_DISCONNECTED" not in e]
            ok("Keine JavaScript-Fehler", not other, "; ".join(other)[:300])
            await a.close()
    finally:
        server.terminate()
    (HERE / "ergebnis.json").write_text(json.dumps(results, ensure_ascii=False, indent=1), encoding="utf-8")
    failed = [r for r in results if not r["ok"]]
    print(f"\n{len(results) - len(failed)} von {len(results)} Ende-zu-Ende-Tests bestanden")
    sys.exit(1 if failed else 0)

asyncio.run(main())
