// Fasst den Angular-Build zur Auslieferung zusammen (Bauplan 3 und 8):
// index.html (mit eingebettetem Stylesheet) + app.js (mit Lizenzhinweisen) + sw.js + manifest.webmanifest + icon.png + neu.png.
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync, renameSync, rmSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const root = new URL('..', import.meta.url).pathname;
const dist = join(root, 'dist/haushaltsbuch/browser');
const fail = (msg) => { console.error(`Paketierung abgebrochen: ${msg}`); process.exit(1); };

const js = readdirSync(dist).filter((f) => f.endsWith('.js'));
if (js.length !== 1 || js[0] !== 'main.js') fail(`erwartet genau main.js, gefunden: ${js.join(', ')}`);
const css = readdirSync(dist).filter((f) => f.endsWith('.css'));
if (css.length !== 1) fail(`erwartet genau ein Stylesheet, gefunden: ${css.join(', ')}`);

let html = readFileSync(join(dist, 'index.html'), 'utf8');
const style = readFileSync(join(dist, css[0]), 'utf8');
const linkRe = new RegExp(`<link rel="stylesheet" href="${css[0]}"[^>]*>`);
if (!linkRe.test(html)) fail('Stylesheet-Verweis in index.html nicht gefunden');
html = html.replace(linkRe, () => `<style>${style}</style>`);
if (!html.includes('src="main.js"')) fail('Skript-Verweis in index.html nicht gefunden');
html = html.replace('src="main.js"', 'src="app.js"');
writeFileSync(join(dist, 'index.html'), html);
rmSync(join(dist, css[0]));
renameSync(join(dist, 'main.js'), join(dist, 'app.js'));
// Lizenzhinweise der mitgelieferten Bibliotheken ans Ende von app.js (statt einer eigenen Datei)
const licenses = readFileSync(join(root, 'dist/haushaltsbuch/3rdpartylicenses.txt'), 'utf8').replaceAll('*/', '* /');
writeFileSync(join(dist, 'app.js'), `${readFileSync(join(dist, 'app.js'), 'utf8')}\n/*! Lizenzhinweise der enthaltenen Bibliotheken\n${licenses}\n*/\n`);

const files = ['index.html', 'app.js', 'manifest.webmanifest', 'icon.png', 'neu.png'];
const hash = createHash('sha256');
for (const f of files) hash.update(f).update(readFileSync(join(dist, f)));
const version = `${JSON.parse(readFileSync(join(root, 'package.json'), 'utf8')).version}-${hash.digest('hex').slice(0, 12)}`;
const sw = readFileSync(join(root, 'scripts/sw-template.js'), 'utf8').replace('__VERSION__', version).replace('__FILES__', JSON.stringify(files));
writeFileSync(join(dist, 'sw.js'), sw);

const extra = readdirSync(dist).filter((f) => !files.includes(f) && f !== 'sw.js');
if (extra.length) fail(`unerwartete Dateien im Build: ${extra.join(', ')}`);
console.log(`Ausgeliefert: ${files.concat('sw.js').join(', ')} (Version ${version})`);
