#!/usr/bin/env python3
"""Führt alle Prüfungen vor einer Lieferung aus (Bauplan 9) und schreibt pruefbericht.md."""
import datetime, json, re, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ANSI = re.compile(r"\x1b\[[0-9;]*m")
rows, failed = [], False

def run(name, cmd, check=lambda rc, out: rc == 0):
    global failed
    p = subprocess.run(cmd, cwd=ROOT, shell=True, capture_output=True, text=True)
    out = ANSI.sub("", p.stdout + p.stderr)
    good = check(p.returncode, out)
    failed |= not good
    print(("OK   " if good else "FAIL ") + name)
    return good, out

version = json.loads((ROOT / "package.json").read_text())["version"]
ok_fmt, _ = run("Formatierung", 'npx prettier --check "src/**/*.{ts,html,scss}"')
ok_lint, out_lint = run("Lint", "npx ng lint")
ok_test, out_test = run("Unit-Tests", "npx ng test --watch=false --coverage")
ok_build, out_build = run("Build und Paketierung", "npm run build:prod")
ok_e2e, out_e2e = run("Ende-zu-Ende", f"{sys.executable} e2e/test_app.py dist/haushaltsbuch/browser")
_, out_audit_prod = run("Sicherheit (App)", "npm audit --omit=dev --json", lambda rc, out: '"high": 0' in out and '"critical": 0' in out)
# Ausnahmen für Entwicklungswerkzeuge: nur benannte Meldungen, nur solange es keine korrigierte Version gibt,
# nur wenn die App selbst (npm audit --omit=dev) frei von Befunden ist. Jede Ausnahme steht im Bericht.
DEV_EXCEPTIONS = {
    "GHSA-fc5q-39xc-vjpf": ("picomatch", "4.0.7", "ReDoS in der Mustersuche der Bauwerkzeuge (Angular CLI, Vitest); nicht in der App enthalten, keine korrigierte Version verfügbar"),
}
exceptions_used = []


def dev_audit_ok(rc, out):
    if '"high": 0' in out and '"critical": 0' in out:
        return True
    try:
        data = json.loads(out)
    except ValueError:
        return False
    advisories = set()
    for v in data.get("vulnerabilities", {}).values():
        if v.get("severity") not in ("high", "critical"):
            continue
        for via in v.get("via", []):
            if isinstance(via, dict):
                advisories.add(via.get("url", "").rsplit("/", 1)[-1])
    latest = {}
    for adv in advisories & set(DEV_EXCEPTIONS):
        pkg, vuln_max, _ = DEV_EXCEPTIONS[adv]
        latest[adv] = subprocess.run(f"npm view {pkg} version", shell=True, capture_output=True, text=True).stdout.strip()
    ok_all = bool(advisories) and all(a in DEV_EXCEPTIONS and latest.get(a) == DEV_EXCEPTIONS[a][1] for a in advisories)
    if ok_all:
        exceptions_used.extend(sorted(advisories))
    return ok_all


_, out_audit_all = run("Sicherheit (Werkzeuge)", "npm audit --json", dev_audit_ok)

tests = re.search(r"Tests\s+(\d+) passed \((\d+)\)", out_test)
cov = re.search(r"All files\s*\|\s*([\d.]+)\s*\|\s*([\d.]+)\s*\|\s*([\d.]+)\s*\|\s*([\d.]+)", out_test)
dom = re.search(r"domain/shared\s*\|\s*([\d.]+)\s*\|\s*([\d.]+)\s*\|\s*([\d.]+)\s*\|\s*([\d.]+)", out_test)
init = re.search(r"Initial total\s*\|\s*([\d.]+ kB)\s*\|\s*([\d.]+ kB)", out_build)
e2e = json.loads((ROOT / "e2e" / "ergebnis.json").read_text(encoding="utf-8"))
def vul(out):
    try:
        m = json.loads(out)["metadata"]["vulnerabilities"]
        return ", ".join(f"{k} {v}" for k, v in m.items() if k != "total") + f" (gesamt {m['total']})"
    except Exception:
        return "nicht ermittelbar"

e2e_ok = sum(1 for r in e2e if r["ok"])
md = [
    f"# Prüfbericht Haushaltsbuch v{version}",
    "",
    f"Erstellt am {datetime.date.today().strftime('%d.%m.%Y')} automatisch mit `scripts/pruefbericht.py`. Geliefert wird nur, was alle Prüfungen besteht (Bauplan 9).",
    "",
    f"**Gesamtergebnis: {'bestanden' if not failed else 'NICHT bestanden'}**",
    "",
    "| Prüfung | Ergebnis |",
    "| --- | --- |",
    f"| Formatierung (Prettier) | {'bestanden' if ok_fmt else 'Fehler'} |",
    f"| Lint (ESLint, Angular-Regeln, Barrierefreiheit, Schichtenregel) | {'bestanden, keine Befunde' if ok_lint else 'Fehler'} |",
    f"| TypeScript im strengen Modus, Produktions-Build | {'bestanden' if ok_build else 'Fehler'} |",
    f"| Auslieferung | {re.search(r'Ausgeliefert: (.*)', out_build).group(1) if ok_build else '–'} |",
    f"| Unit-Tests (Vitest) | {tests.group(1) + ' von ' + tests.group(2) + ' bestanden' if tests else 'Fehler'} |",
    f"| Abdeckung gesamt (Zeilen) | {cov.group(4) + ' %' if cov else '–'} |",
    f"| Abdeckung Fachlogik domain (Zeilen, Ziel ≥ 90 %) | {dom.group(4) + ' %' if dom else '–'} |",
    f"| Ende-zu-Ende-Tests (Chromium, virtueller Passkey mit PRF, Update von v0.1, Altdaten-Import, Statistik, Prognose, Liquidität, Leistungstest) | {e2e_ok} von {len(e2e)} bestanden |",
    f"| Sicherheitsprüfung der App-Abhängigkeiten | {vul(out_audit_prod)} |",
    f"| Sicherheitsprüfung inkl. Entwicklungswerkzeuge | {vul(out_audit_all)} |",
    f"| app.js (Grenze: Warnung 600 kB, Abbruch 1 MB) | {init.group(1) + ' roh, ' + init.group(2) + ' übertragen' if init else '–'} |",
    "",
    "## Ende-zu-Ende-Tests im Einzelnen",
    "",
    "| Test | Ergebnis |",
    "| --- | --- |",
    *[f"| {r['test']} | {'bestanden' if r['ok'] else 'FEHLER'}{(' – ' + r['detail'].replace('|', '/')) if r['detail'] and 'Schlüssel' not in r['test'] else ''} |" for r in e2e],
    "",
    "## Bekannte Einschränkungen",
    "",
    "- Getestet ist mit einem virtuellen Passkey in Chromium. Ob dein Handy den Fingerabdruck als Schlüssel liefert (PRF), zeigt erst der Test auf dem Gerät; dafür gibt es die Machbarkeitsprüfung in der App.",
    "- „Dauerhafter Speicher“ vergibt Chrome selbst, meist erst für installierte Apps. Die Machbarkeitsprüfung zeigt den Stand.",
    "- Der Service Worker sw.js ist eigener Code statt des Angular-Service-Workers, damit die App nur aus index.html und app.js plus sw.js, Manifest und zwei Symbolen besteht; Offlinebetrieb und Update nach Bestätigung sind per Ende-zu-Ende-Test geprüft.",
    "- Ob der Schnellzugriff „Neue Buchung“ auf den Startbildschirm gezogen werden kann, hängt vom Launcher ab.",
    "- Die app.js liegt über der Warngrenze von 600 kB (Abbruch erst bei 1 MB); übertragen werden rund 140 kB, danach lädt die App aus dem Zwischenspeicher.",
    "- Der Altdaten-Import ist mit einer nachgebauten Datei im beschriebenen Format geprüft; die echte Datei der alten App zeigt erst dein Test.",
    "- Allgemeiner CSV-Import von Bankumsätzen und Excel-Export folgen; Prognose, Statistik, Rücklagen und Kredite mit v0.4 bis v0.7.",
    "- Die mittleren Befunde der Sicherheitsprüfung betreffen nur das Entwicklungswerkzeug ESLint (minimatch) und sind nicht Teil der App.",
    *[f"- Ausnahme {a} ({DEV_EXCEPTIONS[a][0]} bis {DEV_EXCEPTIONS[a][1]}): {DEV_EXCEPTIONS[a][2]}. Die Ausnahme endet automatisch, sobald eine korrigierte Version erscheint." for a in exceptions_used],
]
(ROOT / "pruefbericht.md").write_text("\n".join(md) + "\n", encoding="utf-8")
print("pruefbericht.md geschrieben" + (" – mit Fehlern" if failed else ""))
sys.exit(1 if failed else 0)
