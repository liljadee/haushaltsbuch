"""Testkatalog nach Lastenheft 22: jedes Abnahmekriterium mit Sollwert und Nachweis.

Status: auto (automatisch geprüft), angepasst (Kriterium an eine Entscheidung angepasst, automatisch geprüft),
manuell (im Praxistest auf dem echten Handy), teilweise (Teil automatisch, Rest offen), offen (Funktion oder Test fehlt).
Nachweise: Namen von Ende-zu-Ende-Tests (Anfang des Namens) und Unit-Tests („datei.spec.ts: Anfang des Namens“).
"""
import json, pathlib, re

K = [
 ("AK-01", "Entsperrung", "Fingerabdruck", "Daten nach erfolgreicher Prüfung lesbar", "auto", ["Gelernte Regeln gelten auch nach Sperren und Entsperren", "Offline: entsperren, Daten vollständig"], [], ""),
 ("AK-02", "Entsperrung", "Geräte-PIN als Rückfall", "funktioniert", "manuell", [], [], "Am Handy: Passkey mit Geräte-PIN statt Finger bestätigen."),
 ("AK-03", "Wiederherstellung", "Passkey gelöscht, Wiederherstellungsschlüssel eingegeben", "Daten vollständig lesbar", "auto", ["Neuer Wiederherstellungsschlüssel: alter passt nicht mehr, neuer öffnet die App"], ["crypto.spec.ts: lässt sich mit dem Wiederherstellungsschlüssel und dem Passwort öffnen"], ""),
 ("AK-04", "Sperre", "1 Minute im Hintergrund", "erneute Authentifizierung nötig", "auto", ["Sperre: nach 1 Minute im Hintergrund"], [], ""),
 ("AK-05", "Verschlüsselung", "Rohdaten im Browserspeicher prüfen", "keine lesbaren Beträge oder Texte", "auto", ["Verschlüsselung: Rohdaten im Browserspeicher", "Backup verschlüsselt; restore.py öffnet Konten und Buchungen"], [], ""),
 ("AK-06", "Vorschau", "Wechsel in den Hintergrund", "Finanzdaten ausgeblendet", "auto", ["Vorschau: beim Wechsel in den Hintergrund"], [], ""),
 ("AK-07", "Offline", "Flugmodus nach Installation", "alle Funktionen außer Updates verfügbar", "auto", ["Offline: entsperren, Daten vollständig"], [], "Zusätzlich im Praxistest einmal im Flugmodus öffnen."),
 ("AK-08", "E-Mail-Import", "Beispiel-E-Mail mit 2 Umsätzen", "2 Buchungen; Saldo nicht als Buchung", "auto", [], ["kontowecker-parser.spec.ts: Beispiel der Nutzerin vom 17.11.2026: zwei Umsätze"], ""),
 ("AK-09", "Saldenabgleich", "E-Mail-Saldo weicht ab", "Hinweis mit Differenzbetrag", "auto", ["Import: Kontostand 1.158,12 € laut Bank, Hinweis auf der Übersicht"], [], ""),
 ("AK-10", "Doppelte E-Mail", "gleiche E-Mail zweimal eingefügt", "Warnung, keine doppelten Buchungen", "auto", ["Gleiche E-Mail nochmal: erkannt, Buchungen abgewählt"], [], ""),
 ("AK-11", "Buchungsdatum", "vor und nach dem Speichern ändern", "korrekt gespeichert; Importdatum unverändert", "auto", [], ["import-date.spec.ts: Importdatum wird beim Erfassen gesetzt"], "Importdatum seit v0.8.8."),
 ("AK-12", "Zuordnungsmonat", "Gehalt am 29.", "zählt zum Folgemonat", "auto", [], ["statistics.spec.ts: Gehalt ab dem 25. zählt zum Folgemonat"], ""),
 ("AK-13", "Import", "Testdateien (Altdaten-XLSX)", "alle Zeilen korrekt; Saldo stimmt", "angepasst", ["Altdaten: Datei gelesen, Konten und Kategorien zugeordnet", "Altdaten: Kontostände bleiben unverändert"], [], "Bank-CSV-Import entfällt (Entscheidung vom 19.11.2026)."),
 ("AK-14", "Dubletten", "gleicher Umsatz mit anderem Datum und gekürztem Text", "als Dublette erkannt", "angepasst", ["Doppelte Buchung von Hand wird erkannt (abgekürzter Bankentext)", "Altdaten: zweiter Import bringt nichts doppelt"], [], "Ohne CSV-Import: E-Mail, Altdaten und Eingabe von Hand."),
 ("AK-15", "Umbuchung", "500 € Giro → Tagesgeld", "beide Konten korrekt; nichts auf Ebene 1", "auto", ["Umbuchung Girokonto → Tagesgeld: beide Kontostände"], ["statistics.spec.ts: Säulen: Fixkosten, Konsum, Sparen; Umbuchungen"], ""),
 ("AK-16", "Kontenumbenennung", "Konto umbenennen", "Historie erhalten", "auto", [], ["import-date.spec.ts: Konto umbenennen"], ""),
 ("AK-17", "Regeln", "bestätigte Zuordnung", "beim nächsten Import vorgeschlagen", "auto", ["Regel aus dem Import schlägt die Kategorie beim Tippen vor"], ["rules.spec.ts: lernt aus einer Zuordnung und schlägt sie beim nächsten Mal sicher vor"], ""),
 ("AK-18", "Jahresausgabe", "Kfz-Versicherung 600 €", "voll im Fälligkeitsmonat, nicht zusätzlich im Durchschnitt", "auto", ["Rücklagen: Jahreszahlungs-Topf mit Rate 50 €"], ["forecast.spec.ts: schätzt variable Ausgaben ohne die wiederkehrenden Zahlungen", "forecast.spec.ts: plant feste Termine ein"], ""),
 ("AK-19", "Variables Einkommen", "6 Testmonate", "Ansatz = zweitniedrigster Wert", "auto", ["Auch ein schwankendes Gehalt taktet die Prognose"], ["recurring.spec.ts: schwankendes Gehalt: vorsichtig der zweitniedrigste"], ""),
 ("AK-20", "Sonderzahlung", "vermutetes Weihnachtsgeld", "nicht in der Prognose bis zur Bestätigung", "auto", ["Sonderzahlungen: erkannt, erst nach Bestätigung eingeplant"], ["special-income.spec.ts: einmaliger Mehrbetrag im Gehalt wird nicht vorgeschlagen"], "Unbestätigt 0 € (Lastenheft 15.3)."),
 ("AK-21", "Liquiditätsprognose", "Testzyklus", "Kontostand, Tiefpunkt und Datum wie Sollwert", "auto", ["Prognose: Leitaussage bis zum nächsten Gehalt"], ["forecast.spec.ts: Kontoverlauf mit Tiefpunkt"], ""),
 ("AK-22", "Sicherheitspuffer", "Testzyklus", "an keinem Tag unter 200 €", "auto", ["Puffer in den Einstellungen wirkt auf die Empfehlung"], ["advice.spec.ts: Fehlbetrag zum Puffer"], ""),
 ("AK-23", "Umbuchungsempfehlung", "Fehlbetrag 600 €", "Empfehlung mit Datum „umbuchen spätestens am“", "auto", ["Abgleich: Umbuchung vom Tagesgeld empfohlen, mit Betrag und Termin"], [], ""),
 ("AK-24", "Ein-Klick-Umbuchung", "„Jetzt umgebucht“", "verknüpfte Buchungen, Status „bestätigt“, Neuberechnung", "auto", ["„Jetzt umgebucht“: bestätigte Umbuchung"], [], ""),
 ("AK-25", "Doppelbuchungsschutz", "bestätigte Umbuchung später importiert", "zugeordnet; keine zweite Umbuchung", "auto", ["Kontowecker: Bankbuchung wird der bestätigten Umbuchung zugeordnet"], ["import-preview.spec.ts: ordnet den Umsatz der bestätigten Umbuchung zu"], ""),
 ("AK-26", "Kreditrate", "Rate per Import", "korrekt in Zins und Tilgung aufgeteilt", "auto", ["Kredit angelegt: Vorschau, Restschuld, Rate erkannt und rückwirkend in Zinsen und Tilgung aufgeteilt"], ["loan.spec.ts: teilt frühere Raten rückwärts vom Stand laut Bank auf"], ""),
 ("AK-27", "Tilgungsplan", "Vergleich mit dem Plan der Bank", "Abweichung höchstens 1 € pro Jahr", "auto", [], ["loan.spec.ts: Tilgungsplan wie bei der Bank"], "Vergleich mit der Annuitätenformel, wie Banken rechnen."),
 ("AK-28", "Kreditalarm", "Zinsbindungsende in 12 Monaten", "Alarm mit Restschuld nach Szenario A und B", "auto", [], ["alarms.spec.ts: Zinsbindungsende ab 12 Monate vorher mit Restschuld", "alarms.spec.ts: nennt die Restschuld nach Szenario A und nach Szenario B"], ""),
 ("AK-29", "Ratenkredit", "vertraglicher Plan endet nicht bei 0 €", "Eingabe wird beanstandet", "auto", [], ["loan.spec.ts: Ratenkredit, dessen Plan zum Laufzeitende nicht bei 0 € endet"], ""),
 ("AK-30", "Sondertilgung", "zwei Kredite mit 4 % und 2 %", "Empfehlung zuerst für 4 %, Grenzen eingehalten", "auto", ["Sondertilgungsplan: Budget ohne Notreserve"], ["special-plan.spec.ts: höchster Zins zuerst", "special-plan.spec.ts: Höchstbetrag je Jahr"], ""),
 ("AK-31", "Rentabilität", "Kreditzins unter Tagesgeldzins nach Steuern", "Hinweis „lohnt sich rechnerisch nicht“", "auto", ["Rentabilität: Hinweis „lohnt sich rechnerisch nicht“"], ["special-plan.spec.ts: Kreditzins unter Tagesgeldzins nach Steuern"], "Tagesgeldzins und Steuersatz unter Einstellungen → Kredite."),
 ("AK-32", "Excel-Export", "Monats- und Jahresübersicht", "Summen stimmen mit der App überein", "auto", ["Export Gesamter Finanzbestand als Excel"], ["export.spec.ts: Monatsübersicht, Kredite mit Tilgungsplan", "export.spec.ts: Jahresübersicht mit Vergleich zum Vorjahr"], ""),
 ("AK-33", "Backup", "Wiederherstellung auf zweitem Gerät", "alle Daten und Einstellungen vollständig", "auto", ["Vollständiges Backup:", "Backup in der laufenden App einspielen"], [], ""),
 ("AK-34", "Backup-Erinnerung", "Zeitraum ohne Backup", "Hinweis erscheint", "angepasst", ["Nach dem Backup verschwindet die Backup-Erinnerung", "Backup-Erinnerung nach dem Import"], [], "Zeitraum wählbar (wöchentlich, 2 Wochen, monatlich) statt fest 30 Tage."),
 ("AK-35", "Schnellzugriff", "Shortcut antippen", "Buchungserfassung direkt geöffnet", "auto", ["Schnellzugriff „Neue Buchung“ nach dem Entsperren"], [], "Zusätzlich im Praxistest am echten Startbildschirm."),
 ("AK-36", "Schnellzugriff gesperrt", "Shortcut bei gesperrter App", "erst Authentifizierung, dann Erfassung", "auto", ["Schnellzugriff „Neue Buchung“ nach dem Entsperren"], [], ""),
 ("AK-37", "Update", "neue Version einspielen", "Daten erhalten; Backup vorher erstellt", "teilweise", ["Update v0.1 → v0.2: Fingerabdruck gilt weiter"], [], "Daten erhalten; Backup vor dem Update seit v0.8.8 (Sicherungsdatei automatisch, sonst Nachfrage); automatischer Test des Update-Ablaufs folgt."),
 ("AK-38", "Leistung", "10 Jahre Testdaten, ca. 30.000 Buchungen", "Entsperren und Dashboard unter 3 Sekunden", "teilweise", ["Leistung: zehn Jahre Daten"], [], "Test mit über 10.000 Buchungen; Erhöhung auf 30.000 folgt."),
 ("AK-39", "Ausreißer", "erhöhtes Gehalt im Dezember zweier Vorjahre", "nicht im Normalwert; als Sonderzahlung vorgeschlagen", "auto", [], ["special-income.spec.ts: erhöhtes Gehalt im Dezember zweier Vorjahre", "special-income.spec.ts: Normalwert ohne Ausreißer"], ""),
 ("AK-40", "Bestätigte Sonderzahlung", "Folgejahr", "im selben Monat in Höhe des Vorjahres eingeplant", "auto", [], ["special-income.spec.ts: bestätigte Sonderzahlung"], ""),
]

def evaluate(root: pathlib.Path, unit_ok: bool):
    res = json.loads((root / "e2e" / "ergebnis.json").read_text(encoding="utf-8")) if (root / "e2e" / "ergebnis.json").exists() else []
    specs = {f.name: f.read_text(encoding="utf-8") for f in (root / "src" / "app").rglob("*.spec.ts")}
    rows, problems = [], []
    for ak, bereich, test, soll, status, e2e, unit, note in K:
        found = []
        for name in e2e:
            hit = [r for r in res if r["test"].startswith(name)]
            if not hit: problems.append(f"{ak}: Ende-zu-Ende-Test fehlt: {name}")
            elif not all(r["ok"] for r in hit): problems.append(f"{ak}: Ende-zu-Ende-Test rot: {name}")
            else: found.append(f"E2E „{name}“")
        for ref in unit:
            f, n = ref.split(": ", 1)
            if not re.search(r"\bit\(\s*'" + re.escape(n), specs.get(f, "")): problems.append(f"{ak}: Unit-Test fehlt: {ref}")
            elif not unit_ok: problems.append(f"{ak}: Unit-Tests nicht bestanden")
            else: found.append(f"Unit „{ref}“")
        rows.append((ak, bereich, test, soll, status, found, note))
    return rows, problems

def write_markdown(root: pathlib.Path, rows, problems) -> dict:
    count = {}
    for r in rows: count[r[4]] = count.get(r[4], 0) + 1
    lines = ["# Testkatalog nach Lastenheft 22", "", "Wird bei jeder Prüfung neu erzeugt (scripts/testkatalog.py). Status: auto = automatisch geprüft; angepasst = Kriterium an eine Entscheidung angepasst, automatisch geprüft; manuell = im Praxistest auf dem Handy; teilweise; offen.", "",
             "Zusammenfassung: " + ", ".join(f"{v} {k}" for k, v in sorted(count.items())), "",
             "| Kennung | Bereich | Test | Sollwert | Status | Nachweis | Hinweis |", "| --- | --- | --- | --- | --- | --- | --- |"]
    for ak, bereich, test, soll, status, found, note in rows:
        lines.append(f"| {ak} | {bereich} | {test} | {soll} | {status} | {'<br>'.join(found) or '–'} | {note} |")
    if problems: lines += ["", "## Probleme", ""] + [f"- {p}" for p in problems]
    (root / "docs" / "testkatalog.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    return count
